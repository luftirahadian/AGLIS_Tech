--
-- PostgreSQL database dump
--

\restrict 2GCpJmvmGIe72mYBbCagUEyNkyM9bxc6YOnSXNr0fsdywnpcRz5feNqfjAhW3Tf

-- Dumped from database version 14.19 (Ubuntu 14.19-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.19 (Ubuntu 14.19-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: check_overdue_invoices(); Type: FUNCTION; Schema: public; Owner: aglis_user
--

CREATE FUNCTION public.check_overdue_invoices() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  UPDATE invoices
  SET status = 'overdue'
  WHERE due_date < CURRENT_DATE
    AND status IN ('sent', 'viewed', 'partial')
    AND is_deleted = FALSE;
END;
$$;


ALTER FUNCTION public.check_overdue_invoices() OWNER TO aglis_user;

--
-- Name: generate_registration_number(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.generate_registration_number() RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
  today_str VARCHAR(8);
  daily_count INTEGER;
  reg_number VARCHAR(50);
BEGIN
  -- Format: REGyyyymmddxxx (e.g., REG20251010001)
  today_str := TO_CHAR(CURRENT_DATE, 'YYYYMMDD');
  
  -- Get count of registrations today
  SELECT COUNT(*) INTO daily_count
  FROM customer_registrations
  WHERE DATE(created_at) = CURRENT_DATE;
  
  -- Generate registration number: REG + yyyymmdd + 3-digit counter
  reg_number := 'REG' || today_str || LPAD((daily_count + 1)::TEXT, 3, '0');
  
  RETURN reg_number;
END;
$$;


ALTER FUNCTION public.generate_registration_number() OWNER TO postgres;

--
-- Name: set_registration_number(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_registration_number() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.registration_number IS NULL OR NEW.registration_number = '' THEN
    NEW.registration_number := generate_registration_number();
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_registration_number() OWNER TO postgres;

--
-- Name: update_invoice_outstanding(); Type: FUNCTION; Schema: public; Owner: aglis_user
--

CREATE FUNCTION public.update_invoice_outstanding() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.outstanding_amount := NEW.total_amount - NEW.paid_amount;
  
  -- Auto-update status based on payment
  IF NEW.outstanding_amount <= 0 THEN
    NEW.status := 'paid';
    NEW.paid_at := CURRENT_TIMESTAMP;
  ELSIF NEW.paid_amount > 0 AND NEW.outstanding_amount > 0 THEN
    NEW.status := 'partial';
  END IF;
  
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_invoice_outstanding() OWNER TO aglis_user;

--
-- Name: update_notification_timestamp(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_notification_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_notification_timestamp() OWNER TO postgres;

--
-- Name: update_role_permissions_updated_at(); Type: FUNCTION; Schema: public; Owner: aglis_user
--

CREATE FUNCTION public.update_role_permissions_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_role_permissions_updated_at() OWNER TO aglis_user;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alert_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alert_history (
    id integer NOT NULL,
    alert_rule_id integer,
    triggered_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    metric_value numeric,
    severity character varying(20),
    message text,
    notification_sent boolean DEFAULT false,
    channels_used jsonb,
    resolved_at timestamp with time zone,
    resolved_by integer,
    resolution_notes text
);


ALTER TABLE public.alert_history OWNER TO postgres;

--
-- Name: alert_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.alert_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alert_history_id_seq OWNER TO postgres;

--
-- Name: alert_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.alert_history_id_seq OWNED BY public.alert_history.id;


--
-- Name: alert_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alert_rules (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    category character varying(50),
    metric character varying(100) NOT NULL,
    condition character varying(50) NOT NULL,
    threshold numeric,
    severity character varying(20) DEFAULT 'medium'::character varying,
    notification_channels jsonb DEFAULT '["email", "whatsapp"]'::jsonb,
    recipients jsonb DEFAULT '[]'::jsonb,
    is_active boolean DEFAULT true,
    cooldown_minutes integer DEFAULT 60,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.alert_rules OWNER TO postgres;

--
-- Name: alert_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.alert_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alert_rules_id_seq OWNER TO postgres;

--
-- Name: alert_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.alert_rules_id_seq OWNED BY public.alert_rules.id;


--
-- Name: attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attachments (
    id integer NOT NULL,
    ticket_id integer,
    filename character varying(255) NOT NULL,
    original_filename character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_size integer,
    mime_type character varying(100),
    uploaded_by integer,
    upload_type character varying(20),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT attachments_upload_type_check CHECK (((upload_type)::text = ANY ((ARRAY['before'::character varying, 'during'::character varying, 'after'::character varying, 'document'::character varying])::text[])))
);


ALTER TABLE public.attachments OWNER TO postgres;

--
-- Name: attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.attachments_id_seq OWNER TO postgres;

--
-- Name: attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attachments_id_seq OWNED BY public.attachments.id;


--
-- Name: billing_alerts; Type: TABLE; Schema: public; Owner: aglis_user
--

CREATE TABLE public.billing_alerts (
    id integer NOT NULL,
    invoice_id integer,
    customer_id integer NOT NULL,
    alert_type character varying(50) NOT NULL,
    alert_message text NOT NULL,
    sent_via character varying(50),
    sent_at timestamp without time zone,
    is_read boolean DEFAULT false,
    read_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT billing_alerts_alert_type_check CHECK (((alert_type)::text = ANY ((ARRAY['overdue'::character varying, 'due_soon'::character varying, 'payment_received'::character varying, 'payment_failed'::character varying, 'reminder'::character varying])::text[])))
);


ALTER TABLE public.billing_alerts OWNER TO aglis_user;

--
-- Name: TABLE billing_alerts; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON TABLE public.billing_alerts IS 'Billing alerts and reminders for customers and admins';


--
-- Name: billing_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.billing_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.billing_alerts_id_seq OWNER TO aglis_user;

--
-- Name: billing_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aglis_user
--

ALTER SEQUENCE public.billing_alerts_id_seq OWNED BY public.billing_alerts.id;


--
-- Name: billing_schedules; Type: TABLE; Schema: public; Owner: aglis_user
--

CREATE TABLE public.billing_schedules (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    schedule_name character varying(200),
    billing_frequency character varying(20) DEFAULT 'monthly'::character varying NOT NULL,
    billing_day integer DEFAULT 1,
    due_days integer DEFAULT 7,
    invoice_template_items jsonb,
    is_active boolean DEFAULT true,
    next_billing_date date,
    last_billing_date date,
    auto_send boolean DEFAULT false,
    auto_reminder boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT billing_schedules_billing_frequency_check CHECK (((billing_frequency)::text = ANY ((ARRAY['daily'::character varying, 'weekly'::character varying, 'monthly'::character varying, 'quarterly'::character varying, 'yearly'::character varying])::text[])))
);


ALTER TABLE public.billing_schedules OWNER TO aglis_user;

--
-- Name: TABLE billing_schedules; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON TABLE public.billing_schedules IS 'Recurring billing schedules for automatic invoice generation';


--
-- Name: COLUMN billing_schedules.invoice_template_items; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON COLUMN public.billing_schedules.invoice_template_items IS 'JSON array of line items to include in recurring invoices';


--
-- Name: billing_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.billing_schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.billing_schedules_id_seq OWNER TO aglis_user;

--
-- Name: billing_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aglis_user
--

ALTER SEQUENCE public.billing_schedules_id_seq OWNED BY public.billing_schedules.id;


--
-- Name: customer_complaints; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_complaints (
    id integer NOT NULL,
    customer_id integer,
    complaint_date date NOT NULL,
    complaint_type character varying(50),
    complaint_description text NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying,
    status character varying(20) DEFAULT 'open'::character varying,
    resolution text,
    resolved_date date,
    resolved_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customer_complaints OWNER TO postgres;

--
-- Name: customer_complaints_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_complaints_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_complaints_id_seq OWNER TO postgres;

--
-- Name: customer_complaints_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_complaints_id_seq OWNED BY public.customer_complaints.id;


--
-- Name: customer_equipment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_equipment (
    id integer NOT NULL,
    customer_id integer,
    equipment_type character varying(50) NOT NULL,
    brand character varying(50),
    model character varying(100),
    serial_number character varying(100),
    mac_address character varying(17),
    installation_date date,
    warranty_expiry date,
    status character varying(20) DEFAULT 'active'::character varying,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customer_equipment OWNER TO postgres;

--
-- Name: customer_equipment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_equipment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_equipment_id_seq OWNER TO postgres;

--
-- Name: customer_equipment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_equipment_id_seq OWNED BY public.customer_equipment.id;


--
-- Name: customer_payment_methods; Type: TABLE; Schema: public; Owner: aglis_user
--

CREATE TABLE public.customer_payment_methods (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    method_type character varying(50) NOT NULL,
    provider character varying(100),
    account_number_masked character varying(50),
    account_holder_name character varying(200),
    payment_token character varying(255),
    token_expires_at timestamp without time zone,
    is_primary boolean DEFAULT false,
    is_active boolean DEFAULT true,
    auto_debit_enabled boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_deleted boolean DEFAULT false,
    CONSTRAINT customer_payment_methods_method_type_check CHECK (((method_type)::text = ANY ((ARRAY['bank_account'::character varying, 'credit_card'::character varying, 'e_wallet'::character varying, 'auto_debit'::character varying])::text[])))
);


ALTER TABLE public.customer_payment_methods OWNER TO aglis_user;

--
-- Name: TABLE customer_payment_methods; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON TABLE public.customer_payment_methods IS 'Saved payment methods for customers (auto-debit, cards, etc.)';


--
-- Name: customer_payment_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.customer_payment_methods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_payment_methods_id_seq OWNER TO aglis_user;

--
-- Name: customer_payment_methods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aglis_user
--

ALTER SEQUENCE public.customer_payment_methods_id_seq OWNED BY public.customer_payment_methods.id;


--
-- Name: customer_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_payments (
    id integer NOT NULL,
    customer_id integer,
    invoice_number character varying(50),
    payment_date date NOT NULL,
    amount numeric(12,2) NOT NULL,
    payment_method character varying(50),
    payment_reference character varying(100),
    billing_period_start date,
    billing_period_end date,
    payment_status character varying(20) DEFAULT 'completed'::character varying,
    notes text,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customer_payments OWNER TO postgres;

--
-- Name: customer_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_payments_id_seq OWNER TO postgres;

--
-- Name: customer_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_payments_id_seq OWNED BY public.customer_payments.id;


--
-- Name: customer_registrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_registrations (
    id integer NOT NULL,
    registration_number character varying(50) NOT NULL,
    full_name character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    phone character varying(20) NOT NULL,
    id_card_number character varying(50),
    id_card_photo character varying(255),
    address text NOT NULL,
    rt character varying(10),
    rw character varying(10),
    kelurahan character varying(100),
    kecamatan character varying(100),
    city character varying(100) NOT NULL,
    postal_code character varying(10),
    latitude numeric(10,8),
    longitude numeric(11,8),
    address_notes text,
    service_type character varying(20) DEFAULT 'broadband'::character varying NOT NULL,
    package_id integer,
    preferred_installation_date date,
    preferred_time_slot character varying(20),
    status character varying(30) DEFAULT 'pending_verification'::character varying NOT NULL,
    rejection_reason text,
    verified_by integer,
    verified_at timestamp without time zone,
    verification_notes text,
    approved_by integer,
    approved_at timestamp without time zone,
    approval_notes text,
    survey_ticket_id integer,
    survey_scheduled_date timestamp without time zone,
    survey_completed_date timestamp without time zone,
    survey_notes text,
    survey_result character varying(20),
    customer_id integer,
    installation_ticket_id integer,
    referral_code character varying(50),
    notes text,
    utm_source character varying(100),
    utm_medium character varying(100),
    utm_campaign character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT valid_service_type CHECK (((service_type)::text = 'broadband'::text)),
    CONSTRAINT valid_status CHECK (((status)::text = ANY ((ARRAY['pending_verification'::character varying, 'verified'::character varying, 'survey_scheduled'::character varying, 'survey_completed'::character varying, 'approved'::character varying, 'customer_created'::character varying, 'rejected'::character varying, 'cancelled'::character varying])::text[]))),
    CONSTRAINT valid_survey_result CHECK ((((survey_result)::text = ANY ((ARRAY['feasible'::character varying, 'not_feasible'::character varying])::text[])) OR (survey_result IS NULL))),
    CONSTRAINT valid_time_slot CHECK ((((preferred_time_slot)::text = ANY ((ARRAY['morning'::character varying, 'afternoon'::character varying, 'evening'::character varying])::text[])) OR (preferred_time_slot IS NULL)))
);


ALTER TABLE public.customer_registrations OWNER TO postgres;

--
-- Name: TABLE customer_registrations; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.customer_registrations IS 'Stores customer registration requests from public form';


--
-- Name: COLUMN customer_registrations.registration_number; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.customer_registrations.registration_number IS 'Unique registration number: REG-YYYYMMDD-NNNN';


--
-- Name: COLUMN customer_registrations.service_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.customer_registrations.service_type IS 'Currently only supports broadband service';


--
-- Name: COLUMN customer_registrations.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.customer_registrations.status IS 'Valid statuses: pending_verification, verified, survey_scheduled, survey_completed, approved, customer_created, rejected, cancelled';


--
-- Name: customer_registrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_registrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_registrations_id_seq OWNER TO postgres;

--
-- Name: customer_registrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_registrations_id_seq OWNED BY public.customer_registrations.id;


--
-- Name: customer_service_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_service_history (
    id integer NOT NULL,
    customer_id integer,
    ticket_id integer,
    service_date date NOT NULL,
    service_type character varying(50),
    technician_id integer,
    service_duration integer,
    customer_rating integer,
    customer_feedback text,
    service_notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT customer_service_history_customer_rating_check CHECK (((customer_rating >= 1) AND (customer_rating <= 5)))
);


ALTER TABLE public.customer_service_history OWNER TO postgres;

--
-- Name: customer_service_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_service_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_service_history_id_seq OWNER TO postgres;

--
-- Name: customer_service_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_service_history_id_seq OWNED BY public.customer_service_history.id;


--
-- Name: customer_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_sessions (
    id integer NOT NULL,
    customer_id integer,
    session_token character varying(255) NOT NULL,
    ip_address character varying(45),
    user_agent text,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customer_sessions OWNER TO postgres;

--
-- Name: customer_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_sessions_id_seq OWNER TO postgres;

--
-- Name: customer_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_sessions_id_seq OWNED BY public.customer_sessions.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    customer_id character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    ktp character varying(20),
    phone character varying(20) NOT NULL,
    phone_alt character varying(20),
    email character varying(255),
    address text NOT NULL,
    latitude numeric(10,8),
    longitude numeric(11,8),
    odp character varying(100),
    pic_name character varying(255),
    pic_position character varying(100),
    pic_phone character varying(20),
    business_type character varying(50) DEFAULT 'residential'::character varying,
    operating_hours character varying(100),
    username character varying(100) NOT NULL,
    password character varying(255) NOT NULL,
    client_area_password character varying(255) NOT NULL,
    customer_type character varying(20) DEFAULT 'regular'::character varying,
    payment_type character varying(20) DEFAULT 'postpaid'::character varying,
    payment_status character varying(20) DEFAULT 'unpaid'::character varying,
    account_status character varying(20) DEFAULT 'active'::character varying,
    service_type character varying(30) DEFAULT 'broadband'::character varying,
    package_id integer,
    subscription_start_date date,
    billing_cycle character varying(20) DEFAULT 'monthly'::character varying,
    due_date date,
    last_payment_date date,
    outstanding_balance numeric(12,2) DEFAULT 0,
    ip_address inet,
    ip_type character varying(20) DEFAULT 'dynamic'::character varying,
    installation_date date,
    assigned_technician_id integer,
    signal_strength integer,
    signal_quality character varying(20),
    total_tickets integer DEFAULT 0,
    last_service_date date,
    customer_rating numeric(3,2) DEFAULT 0,
    service_quality_score integer DEFAULT 0,
    notes text,
    registration_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    account_activation_date timestamp without time zone,
    last_login_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    city character varying(100),
    province character varying(100),
    customer_portal_password character varying(255),
    email_verified boolean DEFAULT false,
    last_login_at timestamp with time zone,
    portal_active boolean DEFAULT true
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: COLUMN customers.city; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.customers.city IS 'City/Kota from customer address';


--
-- Name: COLUMN customers.province; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.customers.province IS 'Province/Provinsi from customer address';


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customers_id_seq OWNER TO postgres;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: equipment_master; Type: TABLE; Schema: public; Owner: aglis_user
--

CREATE TABLE public.equipment_master (
    id integer NOT NULL,
    equipment_code character varying(50) NOT NULL,
    equipment_name character varying(100) NOT NULL,
    category character varying(50) NOT NULL,
    description text,
    unit character varying(20) DEFAULT 'unit'::character varying,
    unit_price numeric(12,2) DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.equipment_master OWNER TO aglis_user;

--
-- Name: equipment_master_id_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.equipment_master_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.equipment_master_id_seq OWNER TO aglis_user;

--
-- Name: equipment_master_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aglis_user
--

ALTER SEQUENCE public.equipment_master_id_seq OWNED BY public.equipment_master.id;


--
-- Name: equipment_service_mapping; Type: TABLE; Schema: public; Owner: aglis_user
--

CREATE TABLE public.equipment_service_mapping (
    id integer NOT NULL,
    equipment_id integer NOT NULL,
    service_type_code character varying(50) NOT NULL,
    service_category_code character varying(50),
    is_required boolean DEFAULT false,
    quantity_default integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.equipment_service_mapping OWNER TO aglis_user;

--
-- Name: equipment_service_mapping_id_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.equipment_service_mapping_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.equipment_service_mapping_id_seq OWNER TO aglis_user;

--
-- Name: equipment_service_mapping_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aglis_user
--

ALTER SEQUENCE public.equipment_service_mapping_id_seq OWNED BY public.equipment_service_mapping.id;


--
-- Name: failed_login_attempts; Type: TABLE; Schema: public; Owner: aglis_user
--

CREATE TABLE public.failed_login_attempts (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    ip_address character varying(50),
    user_agent text,
    attempted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    reason character varying(50) DEFAULT 'invalid_credentials'::character varying,
    user_id integer
);


ALTER TABLE public.failed_login_attempts OWNER TO aglis_user;

--
-- Name: TABLE failed_login_attempts; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON TABLE public.failed_login_attempts IS 'Logs all failed login attempts for security monitoring and analysis';


--
-- Name: failed_login_attempts_id_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.failed_login_attempts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_login_attempts_id_seq OWNER TO aglis_user;

--
-- Name: failed_login_attempts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aglis_user
--

ALTER SEQUENCE public.failed_login_attempts_id_seq OWNED BY public.failed_login_attempts.id;


--
-- Name: inventory_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory_items (
    id integer NOT NULL,
    item_code character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    category character varying(50) NOT NULL,
    unit character varying(20) NOT NULL,
    unit_price numeric(10,2),
    minimum_stock integer DEFAULT 0,
    current_stock integer DEFAULT 0,
    location character varying(100),
    supplier character varying(100),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.inventory_items OWNER TO postgres;

--
-- Name: inventory_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inventory_items_id_seq OWNER TO postgres;

--
-- Name: inventory_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_items_id_seq OWNED BY public.inventory_items.id;


--
-- Name: inventory_stock; Type: TABLE; Schema: public; Owner: aglis_user
--

CREATE TABLE public.inventory_stock (
    id integer NOT NULL,
    equipment_id integer NOT NULL,
    warehouse_location character varying(100) DEFAULT 'Warehouse Karawang'::character varying,
    current_stock integer DEFAULT 0 NOT NULL,
    minimum_stock integer DEFAULT 5 NOT NULL,
    maximum_stock integer DEFAULT 100 NOT NULL,
    unit_cost numeric(12,2) DEFAULT 0,
    total_value numeric(15,2) GENERATED ALWAYS AS (((current_stock)::numeric * unit_cost)) STORED,
    supplier_name character varying(100),
    supplier_contact character varying(50),
    last_restock_date date,
    last_restock_quantity integer DEFAULT 0,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.inventory_stock OWNER TO aglis_user;

--
-- Name: inventory_stock_id_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.inventory_stock_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inventory_stock_id_seq OWNER TO aglis_user;

--
-- Name: inventory_stock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aglis_user
--

ALTER SEQUENCE public.inventory_stock_id_seq OWNED BY public.inventory_stock.id;


--
-- Name: inventory_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory_transactions (
    id integer NOT NULL,
    item_id integer,
    transaction_type character varying(20) NOT NULL,
    quantity integer NOT NULL,
    reference_type character varying(20),
    reference_id integer,
    technician_id integer,
    notes text,
    transaction_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    CONSTRAINT inventory_transactions_transaction_type_check CHECK (((transaction_type)::text = ANY ((ARRAY['in'::character varying, 'out'::character varying, 'adjustment'::character varying])::text[])))
);


ALTER TABLE public.inventory_transactions OWNER TO postgres;

--
-- Name: inventory_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inventory_transactions_id_seq OWNER TO postgres;

--
-- Name: inventory_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_transactions_id_seq OWNED BY public.inventory_transactions.id;


--
-- Name: invoice_line_items; Type: TABLE; Schema: public; Owner: aglis_user
--

CREATE TABLE public.invoice_line_items (
    id integer NOT NULL,
    invoice_id integer NOT NULL,
    item_type character varying(50) NOT NULL,
    item_reference_id integer,
    description text NOT NULL,
    quantity numeric(10,2) DEFAULT 1 NOT NULL,
    unit_price numeric(15,2) NOT NULL,
    discount_amount numeric(15,2) DEFAULT 0,
    discount_percentage numeric(5,2) DEFAULT 0,
    line_total numeric(15,2) NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT invoice_line_items_item_type_check CHECK (((item_type)::text = ANY ((ARRAY['package'::character varying, 'service'::character varying, 'equipment'::character varying, 'installation'::character varying, 'addon'::character varying, 'other'::character varying])::text[])))
);


ALTER TABLE public.invoice_line_items OWNER TO aglis_user;

--
-- Name: TABLE invoice_line_items; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON TABLE public.invoice_line_items IS 'Line items for each invoice (services, packages, equipment, etc.)';


--
-- Name: COLUMN invoice_line_items.item_reference_id; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON COLUMN public.invoice_line_items.item_reference_id IS 'FK to source table (packages, services, equipment)';


--
-- Name: invoice_line_items_id_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.invoice_line_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoice_line_items_id_seq OWNER TO aglis_user;

--
-- Name: invoice_line_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aglis_user
--

ALTER SEQUENCE public.invoice_line_items_id_seq OWNED BY public.invoice_line_items.id;


--
-- Name: invoice_number_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.invoice_number_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoice_number_seq OWNER TO aglis_user;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: aglis_user
--

CREATE TABLE public.invoices (
    id integer NOT NULL,
    invoice_number character varying(50) NOT NULL,
    customer_id integer NOT NULL,
    invoice_date date DEFAULT CURRENT_DATE NOT NULL,
    due_date date NOT NULL,
    billing_period_start date,
    billing_period_end date,
    subtotal numeric(15,2) DEFAULT 0 NOT NULL,
    tax_amount numeric(15,2) DEFAULT 0 NOT NULL,
    tax_percentage numeric(5,2) DEFAULT 11.00,
    discount_amount numeric(15,2) DEFAULT 0,
    discount_percentage numeric(5,2) DEFAULT 0,
    total_amount numeric(15,2) NOT NULL,
    paid_amount numeric(15,2) DEFAULT 0,
    outstanding_amount numeric(15,2) NOT NULL,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    invoice_type character varying(20) DEFAULT 'recurring'::character varying,
    payment_terms text,
    payment_method_preferred character varying(50),
    notes text,
    internal_notes text,
    terms_conditions text,
    sent_at timestamp without time zone,
    viewed_at timestamp without time zone,
    paid_at timestamp without time zone,
    last_reminder_sent timestamp without time zone,
    reminder_count integer DEFAULT 0,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp without time zone,
    deleted_by integer,
    CONSTRAINT invoices_invoice_type_check CHECK (((invoice_type)::text = ANY ((ARRAY['recurring'::character varying, 'one_time'::character varying, 'installation'::character varying, 'additional'::character varying])::text[]))),
    CONSTRAINT invoices_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'sent'::character varying, 'viewed'::character varying, 'paid'::character varying, 'partial'::character varying, 'overdue'::character varying, 'cancelled'::character varying, 'refunded'::character varying])::text[])))
);


ALTER TABLE public.invoices OWNER TO aglis_user;

--
-- Name: TABLE invoices; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON TABLE public.invoices IS 'Customer invoices for billing management';


--
-- Name: COLUMN invoices.invoice_number; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON COLUMN public.invoices.invoice_number IS 'Unique invoice number (e.g., INV-2025-001234)';


--
-- Name: COLUMN invoices.outstanding_amount; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON COLUMN public.invoices.outstanding_amount IS 'Remaining amount to be paid (total - paid)';


--
-- Name: COLUMN invoices.status; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON COLUMN public.invoices.status IS 'Invoice status: draft, sent, viewed, paid, partial, overdue, cancelled, refunded';


--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoices_id_seq OWNER TO aglis_user;

--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aglis_user
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: notification_analytics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_analytics (
    id integer NOT NULL,
    notification_id integer NOT NULL,
    user_id integer NOT NULL,
    viewed_at timestamp without time zone,
    read_at timestamp without time zone,
    clicked_at timestamp without time zone,
    dismissed_at timestamp without time zone,
    archived_at timestamp without time zone,
    deleted_at timestamp without time zone,
    time_to_view integer,
    time_to_read integer,
    time_to_click integer,
    device_type character varying(50),
    browser character varying(100),
    os character varying(100),
    channel character varying(50),
    ip_address character varying(50),
    country character varying(100),
    city character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_analytics OWNER TO postgres;

--
-- Name: TABLE notification_analytics; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.notification_analytics IS 'Tracks user engagement with notifications';


--
-- Name: notification_analytics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_analytics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_analytics_id_seq OWNER TO postgres;

--
-- Name: notification_analytics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notification_analytics_id_seq OWNED BY public.notification_analytics.id;


--
-- Name: notification_analytics_summary; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_analytics_summary (
    id integer NOT NULL,
    date date NOT NULL,
    type character varying(100),
    priority character varying(50),
    total_sent integer DEFAULT 0,
    total_delivered integer DEFAULT 0,
    total_failed integer DEFAULT 0,
    total_viewed integer DEFAULT 0,
    total_read integer DEFAULT 0,
    total_clicked integer DEFAULT 0,
    total_dismissed integer DEFAULT 0,
    total_archived integer DEFAULT 0,
    total_deleted integer DEFAULT 0,
    delivery_rate numeric(5,2),
    view_rate numeric(5,2),
    read_rate numeric(5,2),
    click_rate numeric(5,2),
    avg_time_to_view integer,
    avg_time_to_read integer,
    avg_time_to_click integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_analytics_summary OWNER TO postgres;

--
-- Name: TABLE notification_analytics_summary; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.notification_analytics_summary IS 'Daily aggregated notification analytics';


--
-- Name: notification_analytics_summary_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_analytics_summary_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_analytics_summary_id_seq OWNER TO postgres;

--
-- Name: notification_analytics_summary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notification_analytics_summary_id_seq OWNED BY public.notification_analytics_summary.id;


--
-- Name: notification_push_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_push_log (
    id integer NOT NULL,
    notification_id integer NOT NULL,
    device_id integer NOT NULL,
    status character varying(50) NOT NULL,
    sent_at timestamp without time zone,
    delivered_at timestamp without time zone,
    clicked_at timestamp without time zone,
    error_message text,
    fcm_message_id character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_push_log OWNER TO postgres;

--
-- Name: TABLE notification_push_log; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.notification_push_log IS 'Tracks push notification delivery status';


--
-- Name: notification_push_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_push_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_push_log_id_seq OWNER TO postgres;

--
-- Name: notification_push_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notification_push_log_id_seq OWNED BY public.notification_push_log.id;


--
-- Name: notification_routing_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_routing_rules (
    id integer NOT NULL,
    notification_type character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    send_to_individual boolean DEFAULT true,
    send_to_groups boolean DEFAULT false,
    target_groups integer[],
    conditions jsonb,
    message_template text,
    is_active boolean DEFAULT true,
    priority integer DEFAULT 0,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_routing_rules OWNER TO postgres;

--
-- Name: TABLE notification_routing_rules; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.notification_routing_rules IS 'Rules for routing notifications to WhatsApp individuals and groups';


--
-- Name: notification_routing_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_routing_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_routing_rules_id_seq OWNER TO postgres;

--
-- Name: notification_routing_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notification_routing_rules_id_seq OWNED BY public.notification_routing_rules.id;


--
-- Name: notification_schedules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_schedules (
    id integer NOT NULL,
    template_id integer,
    schedule_name character varying(255) NOT NULL,
    description text,
    target_type character varying(50) NOT NULL,
    target_criteria jsonb,
    template_data jsonb,
    schedule_type character varying(50) NOT NULL,
    scheduled_at timestamp without time zone,
    cron_expression character varying(100),
    timezone character varying(100) DEFAULT 'Asia/Jakarta'::character varying,
    recurrence_rule character varying(255),
    status character varying(50) DEFAULT 'active'::character varying,
    last_run_at timestamp without time zone,
    next_run_at timestamp without time zone,
    total_runs integer DEFAULT 0,
    total_sent integer DEFAULT 0,
    total_failed integer DEFAULT 0,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_schedules OWNER TO postgres;

--
-- Name: TABLE notification_schedules; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.notification_schedules IS 'Scheduled notification campaigns';


--
-- Name: notification_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_schedules_id_seq OWNER TO postgres;

--
-- Name: notification_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notification_schedules_id_seq OWNED BY public.notification_schedules.id;


--
-- Name: notification_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_settings (
    id integer NOT NULL,
    user_id integer,
    email_notifications boolean DEFAULT true,
    push_notifications boolean DEFAULT true,
    sound_notifications boolean DEFAULT true,
    notification_types jsonb DEFAULT '{}'::jsonb,
    quiet_hours_start time without time zone,
    quiet_hours_end time without time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    whatsapp_notifications boolean DEFAULT true
);


ALTER TABLE public.notification_settings OWNER TO postgres;

--
-- Name: COLUMN notification_settings.whatsapp_notifications; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.notification_settings.whatsapp_notifications IS 'Enable/disable WhatsApp notifications for user';


--
-- Name: notification_settings_advanced; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_settings_advanced (
    id integer NOT NULL,
    user_id integer NOT NULL,
    web_notifications boolean DEFAULT true,
    mobile_push boolean DEFAULT true,
    email_notifications boolean DEFAULT true,
    sms_notifications boolean DEFAULT false,
    quiet_hours_enabled boolean DEFAULT false,
    quiet_hours_start time without time zone,
    quiet_hours_end time without time zone,
    quiet_hours_timezone character varying(100) DEFAULT 'Asia/Jakarta'::character varying,
    dnd_enabled boolean DEFAULT false,
    dnd_until timestamp without time zone,
    batch_notifications boolean DEFAULT false,
    batch_interval integer DEFAULT 60,
    show_low_priority boolean DEFAULT true,
    show_normal_priority boolean DEFAULT true,
    show_high_priority boolean DEFAULT true,
    show_urgent_priority boolean DEFAULT true,
    type_settings jsonb DEFAULT '{}'::jsonb,
    group_by_type boolean DEFAULT true,
    group_by_priority boolean DEFAULT false,
    auto_archive_after_days integer DEFAULT 30,
    auto_delete_after_days integer DEFAULT 90,
    daily_digest boolean DEFAULT false,
    weekly_digest boolean DEFAULT false,
    digest_time time without time zone DEFAULT '08:00:00'::time without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_settings_advanced OWNER TO postgres;

--
-- Name: TABLE notification_settings_advanced; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.notification_settings_advanced IS 'Advanced notification preferences per user';


--
-- Name: COLUMN notification_settings_advanced.type_settings; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.notification_settings_advanced.type_settings IS 'JSON object with per-type notification settings';


--
-- Name: notification_settings_advanced_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_settings_advanced_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_settings_advanced_id_seq OWNER TO postgres;

--
-- Name: notification_settings_advanced_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notification_settings_advanced_id_seq OWNED BY public.notification_settings_advanced.id;


--
-- Name: notification_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_settings_id_seq OWNER TO postgres;

--
-- Name: notification_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notification_settings_id_seq OWNED BY public.notification_settings.id;


--
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_templates (
    id integer NOT NULL,
    template_code character varying(100) NOT NULL,
    template_name character varying(255) NOT NULL,
    description text,
    category character varying(100),
    type character varying(100) NOT NULL,
    priority character varying(50) DEFAULT 'normal'::character varying,
    title_template text NOT NULL,
    message_template text NOT NULL,
    variables jsonb DEFAULT '[]'::jsonb,
    example_data jsonb,
    channels jsonb DEFAULT '["web", "mobile", "email"]'::jsonb,
    icon character varying(100),
    color character varying(50),
    action_url_template character varying(500),
    is_active boolean DEFAULT true,
    created_by integer,
    updated_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_templates OWNER TO postgres;

--
-- Name: TABLE notification_templates; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.notification_templates IS 'Reusable notification templates with variable substitution';


--
-- Name: COLUMN notification_templates.title_template; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.notification_templates.title_template IS 'Title with {{variable}} placeholders';


--
-- Name: COLUMN notification_templates.message_template; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.notification_templates.message_template IS 'Message with {{variable}} placeholders';


--
-- Name: COLUMN notification_templates.variables; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.notification_templates.variables IS 'Array of variable names used in templates';


--
-- Name: notification_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_templates_id_seq OWNER TO postgres;

--
-- Name: notification_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notification_templates_id_seq OWNED BY public.notification_templates.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer,
    ticket_id integer,
    type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    is_read boolean DEFAULT false,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    data jsonb,
    priority character varying(20) DEFAULT 'normal'::character varying,
    is_archived boolean DEFAULT false,
    expires_at timestamp with time zone,
    template_id integer,
    template_data jsonb
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: COLUMN notifications.template_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.notifications.template_id IS 'Reference to notification template used';


--
-- Name: COLUMN notifications.template_data; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.notifications.template_data IS 'Data used to render the template';


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_id_seq OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: odp; Type: TABLE; Schema: public; Owner: aglis_user
--

CREATE TABLE public.odp (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    location text NOT NULL,
    area character varying(100),
    latitude numeric(10,8),
    longitude numeric(11,8),
    total_ports integer DEFAULT 8 NOT NULL,
    used_ports integer DEFAULT 0 NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT odp_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'full'::character varying, 'maintenance'::character varying, 'inactive'::character varying])::text[])))
);


ALTER TABLE public.odp OWNER TO aglis_user;

--
-- Name: odp_id_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.odp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.odp_id_seq OWNER TO aglis_user;

--
-- Name: odp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aglis_user
--

ALTER SEQUENCE public.odp_id_seq OWNED BY public.odp.id;


--
-- Name: packages_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.packages_master (
    id integer NOT NULL,
    package_name character varying(100) NOT NULL,
    package_type character varying(50) NOT NULL,
    bandwidth_up integer NOT NULL,
    bandwidth_down integer NOT NULL,
    monthly_price numeric(12,2) NOT NULL,
    setup_fee numeric(12,2) DEFAULT 0,
    sla_level character varying(20) DEFAULT 'silver'::character varying,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.packages_master OWNER TO postgres;

--
-- Name: packages_master_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.packages_master_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.packages_master_id_seq OWNER TO postgres;

--
-- Name: packages_master_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.packages_master_id_seq OWNED BY public.packages_master.id;


--
-- Name: payment_number_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.payment_number_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_number_seq OWNER TO aglis_user;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: aglis_user
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    payment_number character varying(50) NOT NULL,
    invoice_id integer,
    customer_id integer NOT NULL,
    payment_date date DEFAULT CURRENT_DATE NOT NULL,
    amount numeric(15,2) NOT NULL,
    payment_method character varying(50) NOT NULL,
    payment_channel character varying(100),
    transaction_id character varying(100),
    reference_number character varying(100),
    payment_gateway character varying(50),
    gateway_response jsonb,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    verified_by integer,
    verified_at timestamp without time zone,
    notes text,
    internal_notes text,
    refund_amount numeric(15,2) DEFAULT 0,
    refund_reason text,
    refunded_at timestamp without time zone,
    refunded_by integer,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp without time zone,
    deleted_by integer,
    CONSTRAINT payments_payment_method_check CHECK (((payment_method)::text = ANY ((ARRAY['cash'::character varying, 'bank_transfer'::character varying, 'credit_card'::character varying, 'debit_card'::character varying, 'e_wallet'::character varying, 'virtual_account'::character varying, 'qris'::character varying, 'other'::character varying])::text[]))),
    CONSTRAINT payments_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'verified'::character varying, 'completed'::character varying, 'failed'::character varying, 'cancelled'::character varying, 'refunded'::character varying])::text[])))
);


ALTER TABLE public.payments OWNER TO aglis_user;

--
-- Name: TABLE payments; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON TABLE public.payments IS 'Payment records for invoices';


--
-- Name: COLUMN payments.payment_gateway; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON COLUMN public.payments.payment_gateway IS 'Payment gateway used: midtrans, xendit, manual';


--
-- Name: COLUMN payments.gateway_response; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON COLUMN public.payments.gateway_response IS 'Full JSON response from payment gateway';


--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payments_id_seq OWNER TO aglis_user;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aglis_user
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: aglis_user
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    resource character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.permissions OWNER TO aglis_user;

--
-- Name: TABLE permissions; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON TABLE public.permissions IS 'Available permissions in the system';


--
-- Name: COLUMN permissions.name; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON COLUMN public.permissions.name IS 'Unique permission identifier (e.g., tickets.view)';


--
-- Name: COLUMN permissions.resource; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON COLUMN public.permissions.resource IS 'Resource category (e.g., tickets, customers)';


--
-- Name: COLUMN permissions.action; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON COLUMN public.permissions.action IS 'Action type (e.g., view, create, edit, delete)';


--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO aglis_user;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aglis_user
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: aglis_user
--

CREATE TABLE public.role_permissions (
    id integer NOT NULL,
    role character varying(50) NOT NULL,
    permission_id integer,
    granted boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.role_permissions OWNER TO aglis_user;

--
-- Name: TABLE role_permissions; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON TABLE public.role_permissions IS 'Junction table linking roles to permissions';


--
-- Name: COLUMN role_permissions.granted; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON COLUMN public.role_permissions.granted IS 'Whether the permission is granted (true) or revoked (false)';


--
-- Name: role_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.role_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_permissions_id_seq OWNER TO aglis_user;

--
-- Name: role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aglis_user
--

ALTER SEQUENCE public.role_permissions_id_seq OWNED BY public.role_permissions.id;


--
-- Name: service_categories; Type: TABLE; Schema: public; Owner: aglis_user
--

CREATE TABLE public.service_categories (
    id integer NOT NULL,
    service_type_code character varying(50) NOT NULL,
    category_code character varying(50) NOT NULL,
    category_name character varying(100) NOT NULL,
    description text,
    estimated_duration integer DEFAULT 120,
    sla_multiplier numeric(3,2) DEFAULT 1.0,
    requires_checklist boolean DEFAULT false,
    is_active boolean DEFAULT true,
    display_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.service_categories OWNER TO aglis_user;

--
-- Name: service_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.service_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_categories_id_seq OWNER TO aglis_user;

--
-- Name: service_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aglis_user
--

ALTER SEQUENCE public.service_categories_id_seq OWNED BY public.service_categories.id;


--
-- Name: service_pricelist; Type: TABLE; Schema: public; Owner: aglis_user
--

CREATE TABLE public.service_pricelist (
    id integer NOT NULL,
    service_type_code character varying(50) NOT NULL,
    service_category_code character varying(50),
    price_name character varying(150) NOT NULL,
    description text,
    base_price numeric(12,2) DEFAULT 0 NOT NULL,
    is_free boolean DEFAULT false,
    is_active boolean DEFAULT true,
    applies_to_package character varying(50),
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.service_pricelist OWNER TO aglis_user;

--
-- Name: service_pricelist_id_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.service_pricelist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_pricelist_id_seq OWNER TO aglis_user;

--
-- Name: service_pricelist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aglis_user
--

ALTER SEQUENCE public.service_pricelist_id_seq OWNED BY public.service_pricelist.id;


--
-- Name: service_types; Type: TABLE; Schema: public; Owner: aglis_user
--

CREATE TABLE public.service_types (
    id integer NOT NULL,
    type_code character varying(50) NOT NULL,
    type_name character varying(100) NOT NULL,
    description text,
    icon character varying(50),
    default_duration integer DEFAULT 120,
    is_active boolean DEFAULT true,
    display_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.service_types OWNER TO aglis_user;

--
-- Name: service_types_backup; Type: TABLE; Schema: public; Owner: aglis_user
--

CREATE TABLE public.service_types_backup (
    id integer,
    service_code character varying(50),
    service_name character varying(100),
    category character varying(50),
    description text,
    estimated_duration integer,
    base_price numeric(12,2),
    is_active boolean,
    display_order integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.service_types_backup OWNER TO aglis_user;

--
-- Name: service_types_id_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.service_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_types_id_seq OWNER TO aglis_user;

--
-- Name: service_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aglis_user
--

ALTER SEQUENCE public.service_types_id_seq OWNED BY public.service_types.id;


--
-- Name: skill_levels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.skill_levels (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    display_order integer DEFAULT 0,
    description text,
    min_experience_months integer DEFAULT 0,
    min_completed_tickets integer DEFAULT 0,
    min_avg_rating numeric(3,2) DEFAULT 0.0,
    daily_ticket_capacity integer DEFAULT 8,
    expected_resolution_time_hours integer DEFAULT 24,
    can_handle_critical_tickets boolean DEFAULT false,
    can_mentor_others boolean DEFAULT false,
    requires_supervision boolean DEFAULT true,
    icon character varying(50),
    color character varying(50),
    badge_text character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer
);


ALTER TABLE public.skill_levels OWNER TO postgres;

--
-- Name: TABLE skill_levels; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.skill_levels IS 'Master data for technician skill level definitions';


--
-- Name: skill_levels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.skill_levels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.skill_levels_id_seq OWNER TO postgres;

--
-- Name: skill_levels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.skill_levels_id_seq OWNED BY public.skill_levels.id;


--
-- Name: specialization_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.specialization_categories (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    display_order integer DEFAULT 0,
    icon character varying(50),
    color character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.specialization_categories OWNER TO postgres;

--
-- Name: TABLE specialization_categories; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.specialization_categories IS 'Categories for grouping specializations (FTTH, NOC, etc)';


--
-- Name: specialization_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.specialization_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.specialization_categories_id_seq OWNER TO postgres;

--
-- Name: specialization_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.specialization_categories_id_seq OWNED BY public.specialization_categories.id;


--
-- Name: specializations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.specializations (
    id integer NOT NULL,
    category_id integer,
    code character varying(100) NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    required_skill_level character varying(50) DEFAULT 'junior'::character varying,
    difficulty_level integer DEFAULT 3,
    is_high_demand boolean DEFAULT false,
    is_critical_service boolean DEFAULT false,
    icon character varying(50),
    color character varying(50),
    display_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer,
    CONSTRAINT specializations_difficulty_level_check CHECK (((difficulty_level >= 1) AND (difficulty_level <= 5)))
);


ALTER TABLE public.specializations OWNER TO postgres;

--
-- Name: TABLE specializations; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.specializations IS 'Master data for technician specialization types';


--
-- Name: specializations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.specializations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.specializations_id_seq OWNER TO postgres;

--
-- Name: specializations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.specializations_id_seq OWNED BY public.specializations.id;


--
-- Name: system_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_metrics (
    id integer NOT NULL,
    metric_type character varying(100) NOT NULL,
    metric_value numeric NOT NULL,
    metadata jsonb,
    recorded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_metrics OWNER TO postgres;

--
-- Name: system_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_metrics_id_seq OWNER TO postgres;

--
-- Name: system_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_metrics_id_seq OWNED BY public.system_metrics.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: aglis_user
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value text,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_settings OWNER TO aglis_user;

--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: aglis_user
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_settings_id_seq OWNER TO aglis_user;

--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aglis_user
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: technician_equipment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.technician_equipment (
    id integer NOT NULL,
    technician_id integer,
    equipment_type character varying(50) NOT NULL,
    equipment_name character varying(100) NOT NULL,
    brand character varying(50),
    model character varying(50),
    serial_number character varying(100),
    condition character varying(20) DEFAULT 'good'::character varying,
    assigned_date date DEFAULT CURRENT_DATE,
    return_date date,
    is_active boolean DEFAULT true,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT technician_equipment_condition_check CHECK (((condition)::text = ANY ((ARRAY['excellent'::character varying, 'good'::character varying, 'fair'::character varying, 'poor'::character varying, 'damaged'::character varying])::text[])))
);


ALTER TABLE public.technician_equipment OWNER TO postgres;

--
-- Name: TABLE technician_equipment; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.technician_equipment IS 'Equipment assignment and tracking';


--
-- Name: technician_equipment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.technician_equipment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.technician_equipment_id_seq OWNER TO postgres;

--
-- Name: technician_equipment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.technician_equipment_id_seq OWNED BY public.technician_equipment.id;


--
-- Name: technician_location_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.technician_location_history (
    id integer NOT NULL,
    technician_id integer,
    latitude numeric(10,8) NOT NULL,
    longitude numeric(11,8) NOT NULL,
    accuracy numeric(6,2),
    speed numeric(5,2),
    heading numeric(5,2),
    activity_type character varying(20) DEFAULT 'unknown'::character varying,
    battery_level integer,
    recorded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT technician_location_history_activity_type_check CHECK (((activity_type)::text = ANY ((ARRAY['stationary'::character varying, 'walking'::character varying, 'driving'::character varying, 'unknown'::character varying])::text[])))
);


ALTER TABLE public.technician_location_history OWNER TO postgres;

--
-- Name: TABLE technician_location_history; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.technician_location_history IS 'GPS location tracking for field technicians';


--
-- Name: technician_location_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.technician_location_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.technician_location_history_id_seq OWNER TO postgres;

--
-- Name: technician_location_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.technician_location_history_id_seq OWNED BY public.technician_location_history.id;


--
-- Name: technician_performance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.technician_performance (
    id integer NOT NULL,
    technician_id integer,
    period_start date NOT NULL,
    period_end date NOT NULL,
    tickets_assigned integer DEFAULT 0,
    tickets_completed integer DEFAULT 0,
    tickets_cancelled integer DEFAULT 0,
    average_resolution_time numeric(5,2),
    customer_satisfaction_avg numeric(3,2) DEFAULT 0.00,
    first_time_fix_rate numeric(5,2) DEFAULT 0.00,
    sla_compliance_rate numeric(5,2) DEFAULT 0.00,
    travel_time_avg numeric(5,2),
    utilization_rate numeric(5,2),
    supervisor_rating numeric(3,2),
    supervisor_notes text,
    improvement_areas text[],
    achievements text[],
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer
);


ALTER TABLE public.technician_performance OWNER TO postgres;

--
-- Name: TABLE technician_performance; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.technician_performance IS 'Performance metrics and KPI tracking';


--
-- Name: technician_performance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.technician_performance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.technician_performance_id_seq OWNER TO postgres;

--
-- Name: technician_performance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.technician_performance_id_seq OWNED BY public.technician_performance.id;


--
-- Name: technician_schedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.technician_schedule (
    id integer NOT NULL,
    technician_id integer,
    schedule_date date NOT NULL,
    shift_start time without time zone NOT NULL,
    shift_end time without time zone NOT NULL,
    break_start time without time zone,
    break_end time without time zone,
    is_working_day boolean DEFAULT true,
    schedule_type character varying(20) DEFAULT 'regular'::character varying,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT technician_schedule_schedule_type_check CHECK (((schedule_type)::text = ANY ((ARRAY['regular'::character varying, 'overtime'::character varying, 'on_call'::character varying, 'leave'::character varying])::text[])))
);


ALTER TABLE public.technician_schedule OWNER TO postgres;

--
-- Name: TABLE technician_schedule; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.technician_schedule IS 'Work schedule and availability management';


--
-- Name: technician_schedule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.technician_schedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.technician_schedule_id_seq OWNER TO postgres;

--
-- Name: technician_schedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.technician_schedule_id_seq OWNED BY public.technician_schedule.id;


--
-- Name: technician_skills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.technician_skills (
    id integer NOT NULL,
    technician_id integer,
    skill_name character varying(50) NOT NULL,
    skill_category character varying(30) NOT NULL,
    proficiency_level integer,
    acquired_date date DEFAULT CURRENT_DATE,
    verified_by integer,
    verification_date date,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT technician_skills_proficiency_level_check CHECK (((proficiency_level >= 1) AND (proficiency_level <= 5)))
);


ALTER TABLE public.technician_skills OWNER TO postgres;

--
-- Name: TABLE technician_skills; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.technician_skills IS 'Detailed skill tracking and proficiency levels';


--
-- Name: technician_skills_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.technician_skills_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.technician_skills_id_seq OWNER TO postgres;

--
-- Name: technician_skills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.technician_skills_id_seq OWNED BY public.technician_skills.id;


--
-- Name: technician_specializations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.technician_specializations (
    id integer NOT NULL,
    technician_id integer,
    specialization_id integer,
    proficiency_level character varying(50) DEFAULT 'beginner'::character varying,
    years_experience numeric(4,2) DEFAULT 0,
    acquired_date date DEFAULT CURRENT_DATE,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.technician_specializations OWNER TO postgres;

--
-- Name: TABLE technician_specializations; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.technician_specializations IS 'Junction table linking technicians to their specializations';


--
-- Name: technician_specializations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.technician_specializations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.technician_specializations_id_seq OWNER TO postgres;

--
-- Name: technician_specializations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.technician_specializations_id_seq OWNED BY public.technician_specializations.id;


--
-- Name: technicians; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.technicians (
    id integer NOT NULL,
    user_id integer,
    employee_id character varying(20) NOT NULL,
    full_name character varying(100) NOT NULL,
    phone character varying(20) NOT NULL,
    phone_alt character varying(20),
    email character varying(100),
    address text,
    emergency_contact_name character varying(100),
    emergency_contact_phone character varying(20),
    hire_date date DEFAULT CURRENT_DATE NOT NULL,
    employment_status character varying(20) DEFAULT 'active'::character varying,
    "position" character varying(50) DEFAULT 'technician'::character varying,
    department character varying(50) DEFAULT 'field_operations'::character varying,
    supervisor_id integer,
    skill_level character varying(20) DEFAULT 'junior'::character varying,
    specializations text[],
    certifications jsonb DEFAULT '[]'::jsonb,
    work_zone character varying(50),
    max_daily_tickets integer DEFAULT 8,
    preferred_shift character varying(20) DEFAULT 'day'::character varying,
    total_tickets_completed integer DEFAULT 0,
    average_completion_time numeric(5,2),
    customer_rating numeric(3,2) DEFAULT 0.00,
    sla_compliance_rate numeric(5,2) DEFAULT 0.00,
    current_latitude numeric(10,8),
    current_longitude numeric(11,8),
    last_location_update timestamp without time zone,
    is_available boolean DEFAULT true,
    availability_status character varying(20) DEFAULT 'available'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer,
    CONSTRAINT technicians_availability_status_check CHECK (((availability_status)::text = ANY ((ARRAY['available'::character varying, 'busy'::character varying, 'break'::character varying, 'offline'::character varying])::text[]))),
    CONSTRAINT technicians_employment_status_check CHECK (((employment_status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'suspended'::character varying, 'terminated'::character varying])::text[]))),
    CONSTRAINT technicians_preferred_shift_check CHECK (((preferred_shift)::text = ANY ((ARRAY['day'::character varying, 'night'::character varying, 'flexible'::character varying])::text[]))),
    CONSTRAINT technicians_skill_level_check CHECK (((skill_level)::text = ANY ((ARRAY['junior'::character varying, 'senior'::character varying, 'expert'::character varying, 'specialist'::character varying])::text[])))
);


ALTER TABLE public.technicians OWNER TO postgres;

--
-- Name: TABLE technicians; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.technicians IS 'Enhanced technician profiles with comprehensive tracking';


--
-- Name: technicians_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.technicians_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.technicians_id_seq OWNER TO postgres;

--
-- Name: technicians_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.technicians_id_seq OWNED BY public.technicians.id;


--
-- Name: ticket_status_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_status_history (
    id integer NOT NULL,
    ticket_id integer,
    old_status character varying(20),
    new_status character varying(20) NOT NULL,
    changed_by integer,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ticket_status_history OWNER TO postgres;

--
-- Name: ticket_status_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_status_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ticket_status_history_id_seq OWNER TO postgres;

--
-- Name: ticket_status_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_status_history_id_seq OWNED BY public.ticket_status_history.id;


--
-- Name: ticket_technicians; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_technicians (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    technician_id integer NOT NULL,
    role character varying(50) DEFAULT 'member'::character varying,
    assigned_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    assigned_by integer,
    notes text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ticket_technicians OWNER TO postgres;

--
-- Name: ticket_technicians_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_technicians_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ticket_technicians_id_seq OWNER TO postgres;

--
-- Name: ticket_technicians_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_technicians_id_seq OWNED BY public.ticket_technicians.id;


--
-- Name: tickets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tickets (
    id integer NOT NULL,
    ticket_number character varying(20) NOT NULL,
    customer_id integer,
    assigned_technician_id integer,
    created_by integer,
    type character varying(20) NOT NULL,
    priority character varying(10) DEFAULT 'normal'::character varying,
    category character varying(50),
    title character varying(200) NOT NULL,
    description text NOT NULL,
    status character varying(20) DEFAULT 'open'::character varying,
    scheduled_date timestamp without time zone,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    estimated_duration integer,
    actual_duration integer,
    sla_due_date timestamp without time zone,
    is_sla_breached boolean DEFAULT false,
    customer_rating integer,
    customer_feedback text,
    equipment_needed text[],
    work_notes text,
    resolution_notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completion_data jsonb,
    CONSTRAINT tickets_customer_rating_check CHECK (((customer_rating >= 1) AND (customer_rating <= 5))),
    CONSTRAINT tickets_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'normal'::character varying, 'high'::character varying, 'critical'::character varying])::text[]))),
    CONSTRAINT tickets_status_check CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'assigned'::character varying, 'in_progress'::character varying, 'completed'::character varying, 'cancelled'::character varying, 'on_hold'::character varying])::text[]))),
    CONSTRAINT tickets_type_check CHECK (((type)::text = ANY ((ARRAY['installation'::character varying, 'repair'::character varying, 'maintenance'::character varying, 'upgrade'::character varying, 'wifi_setup'::character varying, 'downgrade'::character varying, 'dismantle'::character varying])::text[])))
);


ALTER TABLE public.tickets OWNER TO postgres;

--
-- Name: COLUMN tickets.completion_data; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tickets.completion_data IS 'Store completion evidence: OTDR photo, attenuation photo, modem SN photo, signal measurements, speed test results, installation checklist';


--
-- Name: tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tickets_id_seq OWNER TO postgres;

--
-- Name: tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tickets_id_seq OWNED BY public.tickets.id;


--
-- Name: user_activity_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_activity_logs (
    id integer NOT NULL,
    user_id integer,
    action character varying(50) NOT NULL,
    target_user_id integer,
    target_username character varying(50),
    details jsonb,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_activity_logs OWNER TO postgres;

--
-- Name: TABLE user_activity_logs; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.user_activity_logs IS 'Audit trail for user management actions';


--
-- Name: COLUMN user_activity_logs.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_activity_logs.user_id IS 'User who performed the action';


--
-- Name: COLUMN user_activity_logs.action; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_activity_logs.action IS 'Action type: created, updated, deleted, restored, password_reset';


--
-- Name: COLUMN user_activity_logs.target_user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_activity_logs.target_user_id IS 'User who was affected by the action';


--
-- Name: COLUMN user_activity_logs.details; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_activity_logs.details IS 'Additional details about the action (JSON)';


--
-- Name: user_activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_activity_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_activity_logs_id_seq OWNER TO postgres;

--
-- Name: user_activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_activity_logs_id_seq OWNED BY public.user_activity_logs.id;


--
-- Name: user_devices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_devices (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_token character varying(500) NOT NULL,
    device_type character varying(50) NOT NULL,
    device_name character varying(255),
    device_model character varying(255),
    os_version character varying(100),
    app_version character varying(100),
    is_active boolean DEFAULT true,
    last_active_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_devices OWNER TO postgres;

--
-- Name: TABLE user_devices; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.user_devices IS 'Stores device tokens for push notifications';


--
-- Name: COLUMN user_devices.device_token; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_devices.device_token IS 'FCM/APNs device token';


--
-- Name: COLUMN user_devices.device_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_devices.device_type IS 'Type: android, ios, or web';


--
-- Name: user_devices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_devices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_devices_id_seq OWNER TO postgres;

--
-- Name: user_devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_devices_id_seq OWNED BY public.user_devices.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(100) NOT NULL,
    phone character varying(20),
    role character varying(20) NOT NULL,
    is_active boolean DEFAULT true,
    avatar_url character varying(255),
    last_login timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    deleted_at timestamp without time zone,
    deleted_by integer,
    email_verified boolean DEFAULT false,
    email_verified_at timestamp without time zone,
    email_verification_token character varying(255) DEFAULT NULL::character varying,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp without time zone,
    last_failed_login timestamp without time zone,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'supervisor'::character varying, 'technician'::character varying, 'customer_service'::character varying, 'manager'::character varying, 'noc'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: COLUMN users.deleted_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.deleted_at IS 'Timestamp when user was soft deleted (NULL = not deleted)';


--
-- Name: COLUMN users.deleted_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.deleted_by IS 'User ID who performed the deletion';


--
-- Name: COLUMN users.email_verified; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.email_verified IS 'Whether user email has been verified';


--
-- Name: COLUMN users.email_verified_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.email_verified_at IS 'Timestamp when email was verified';


--
-- Name: COLUMN users.email_verification_token; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.email_verification_token IS 'Token for email verification (hashed)';


--
-- Name: COLUMN users.failed_login_attempts; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.failed_login_attempts IS 'Number of consecutive failed login attempts';


--
-- Name: COLUMN users.locked_until; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.locked_until IS 'Account is locked until this timestamp (NULL = indefinite lock if attempts >= 15)';


--
-- Name: COLUMN users.last_failed_login; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.last_failed_login IS 'Timestamp of last failed login attempt';


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: whatsapp_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.whatsapp_groups (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    category character varying(50) NOT NULL,
    work_zone character varying(50),
    group_chat_id character varying(255),
    phone_number character varying(100),
    notification_types jsonb DEFAULT '[]'::jsonb,
    priority_filter character varying(20),
    is_active boolean DEFAULT true,
    is_verified boolean DEFAULT false,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT whatsapp_groups_category_check CHECK (((category)::text = ANY ((ARRAY['technicians'::character varying, 'supervisors'::character varying, 'managers'::character varying, 'noc'::character varying, 'customer_service'::character varying, 'all'::character varying])::text[])))
);


ALTER TABLE public.whatsapp_groups OWNER TO postgres;

--
-- Name: TABLE whatsapp_groups; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.whatsapp_groups IS 'Master data for WhatsApp groups used for team notifications';


--
-- Name: COLUMN whatsapp_groups.notification_types; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.whatsapp_groups.notification_types IS 'JSON array of notification types: ["ticket_assigned", "sla_warning", "daily_summary"]';


--
-- Name: whatsapp_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.whatsapp_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.whatsapp_groups_id_seq OWNER TO postgres;

--
-- Name: whatsapp_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.whatsapp_groups_id_seq OWNED BY public.whatsapp_groups.id;


--
-- Name: whatsapp_message_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.whatsapp_message_templates (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    category character varying(50),
    template text NOT NULL,
    variables jsonb,
    example_message text,
    language character varying(10) DEFAULT 'id'::character varying,
    is_active boolean DEFAULT true,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.whatsapp_message_templates OWNER TO postgres;

--
-- Name: TABLE whatsapp_message_templates; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.whatsapp_message_templates IS 'Reusable message templates for WhatsApp notifications';


--
-- Name: whatsapp_message_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.whatsapp_message_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.whatsapp_message_templates_id_seq OWNER TO postgres;

--
-- Name: whatsapp_message_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.whatsapp_message_templates_id_seq OWNED BY public.whatsapp_message_templates.id;


--
-- Name: whatsapp_notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.whatsapp_notifications (
    id integer NOT NULL,
    notification_id integer,
    user_id integer,
    group_id integer,
    recipient_type character varying(20),
    phone_number character varying(100) NOT NULL,
    message text NOT NULL,
    template_name character varying(100),
    status character varying(20) DEFAULT 'pending'::character varying,
    provider character varying(50),
    provider_message_id character varying(255),
    provider_response jsonb,
    error_message text,
    retry_count integer DEFAULT 0,
    sent_at timestamp without time zone,
    delivered_at timestamp without time zone,
    read_at timestamp without time zone,
    failed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    ticket_id integer,
    invoice_id integer,
    notification_type character varying(100),
    CONSTRAINT whatsapp_notifications_recipient_type_check CHECK (((recipient_type)::text = ANY ((ARRAY['individual'::character varying, 'group'::character varying])::text[]))),
    CONSTRAINT whatsapp_notifications_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'sent'::character varying, 'delivered'::character varying, 'read'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.whatsapp_notifications OWNER TO postgres;

--
-- Name: TABLE whatsapp_notifications; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.whatsapp_notifications IS 'Delivery log for WhatsApp notifications';


--
-- Name: whatsapp_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.whatsapp_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.whatsapp_notifications_id_seq OWNER TO postgres;

--
-- Name: whatsapp_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.whatsapp_notifications_id_seq OWNED BY public.whatsapp_notifications.id;


--
-- Name: alert_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_history ALTER COLUMN id SET DEFAULT nextval('public.alert_history_id_seq'::regclass);


--
-- Name: alert_rules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_rules ALTER COLUMN id SET DEFAULT nextval('public.alert_rules_id_seq'::regclass);


--
-- Name: attachments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments ALTER COLUMN id SET DEFAULT nextval('public.attachments_id_seq'::regclass);


--
-- Name: billing_alerts id; Type: DEFAULT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.billing_alerts ALTER COLUMN id SET DEFAULT nextval('public.billing_alerts_id_seq'::regclass);


--
-- Name: billing_schedules id; Type: DEFAULT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.billing_schedules ALTER COLUMN id SET DEFAULT nextval('public.billing_schedules_id_seq'::regclass);


--
-- Name: customer_complaints id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_complaints ALTER COLUMN id SET DEFAULT nextval('public.customer_complaints_id_seq'::regclass);


--
-- Name: customer_equipment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_equipment ALTER COLUMN id SET DEFAULT nextval('public.customer_equipment_id_seq'::regclass);


--
-- Name: customer_payment_methods id; Type: DEFAULT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.customer_payment_methods ALTER COLUMN id SET DEFAULT nextval('public.customer_payment_methods_id_seq'::regclass);


--
-- Name: customer_payments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_payments ALTER COLUMN id SET DEFAULT nextval('public.customer_payments_id_seq'::regclass);


--
-- Name: customer_registrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_registrations ALTER COLUMN id SET DEFAULT nextval('public.customer_registrations_id_seq'::regclass);


--
-- Name: customer_service_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_service_history ALTER COLUMN id SET DEFAULT nextval('public.customer_service_history_id_seq'::regclass);


--
-- Name: customer_sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_sessions ALTER COLUMN id SET DEFAULT nextval('public.customer_sessions_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: equipment_master id; Type: DEFAULT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.equipment_master ALTER COLUMN id SET DEFAULT nextval('public.equipment_master_id_seq'::regclass);


--
-- Name: equipment_service_mapping id; Type: DEFAULT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.equipment_service_mapping ALTER COLUMN id SET DEFAULT nextval('public.equipment_service_mapping_id_seq'::regclass);


--
-- Name: failed_login_attempts id; Type: DEFAULT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.failed_login_attempts ALTER COLUMN id SET DEFAULT nextval('public.failed_login_attempts_id_seq'::regclass);


--
-- Name: inventory_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_items ALTER COLUMN id SET DEFAULT nextval('public.inventory_items_id_seq'::regclass);


--
-- Name: inventory_stock id; Type: DEFAULT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.inventory_stock ALTER COLUMN id SET DEFAULT nextval('public.inventory_stock_id_seq'::regclass);


--
-- Name: inventory_transactions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_transactions ALTER COLUMN id SET DEFAULT nextval('public.inventory_transactions_id_seq'::regclass);


--
-- Name: invoice_line_items id; Type: DEFAULT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.invoice_line_items ALTER COLUMN id SET DEFAULT nextval('public.invoice_line_items_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: notification_analytics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_analytics ALTER COLUMN id SET DEFAULT nextval('public.notification_analytics_id_seq'::regclass);


--
-- Name: notification_analytics_summary id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_analytics_summary ALTER COLUMN id SET DEFAULT nextval('public.notification_analytics_summary_id_seq'::regclass);


--
-- Name: notification_push_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_push_log ALTER COLUMN id SET DEFAULT nextval('public.notification_push_log_id_seq'::regclass);


--
-- Name: notification_routing_rules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_routing_rules ALTER COLUMN id SET DEFAULT nextval('public.notification_routing_rules_id_seq'::regclass);


--
-- Name: notification_schedules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_schedules ALTER COLUMN id SET DEFAULT nextval('public.notification_schedules_id_seq'::regclass);


--
-- Name: notification_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_settings ALTER COLUMN id SET DEFAULT nextval('public.notification_settings_id_seq'::regclass);


--
-- Name: notification_settings_advanced id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_settings_advanced ALTER COLUMN id SET DEFAULT nextval('public.notification_settings_advanced_id_seq'::regclass);


--
-- Name: notification_templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_templates ALTER COLUMN id SET DEFAULT nextval('public.notification_templates_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: odp id; Type: DEFAULT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.odp ALTER COLUMN id SET DEFAULT nextval('public.odp_id_seq'::regclass);


--
-- Name: packages_master id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packages_master ALTER COLUMN id SET DEFAULT nextval('public.packages_master_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: role_permissions id; Type: DEFAULT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.role_permissions ALTER COLUMN id SET DEFAULT nextval('public.role_permissions_id_seq'::regclass);


--
-- Name: service_categories id; Type: DEFAULT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.service_categories ALTER COLUMN id SET DEFAULT nextval('public.service_categories_id_seq'::regclass);


--
-- Name: service_pricelist id; Type: DEFAULT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.service_pricelist ALTER COLUMN id SET DEFAULT nextval('public.service_pricelist_id_seq'::regclass);


--
-- Name: service_types id; Type: DEFAULT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.service_types ALTER COLUMN id SET DEFAULT nextval('public.service_types_id_seq'::regclass);


--
-- Name: skill_levels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skill_levels ALTER COLUMN id SET DEFAULT nextval('public.skill_levels_id_seq'::regclass);


--
-- Name: specialization_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specialization_categories ALTER COLUMN id SET DEFAULT nextval('public.specialization_categories_id_seq'::regclass);


--
-- Name: specializations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specializations ALTER COLUMN id SET DEFAULT nextval('public.specializations_id_seq'::regclass);


--
-- Name: system_metrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_metrics ALTER COLUMN id SET DEFAULT nextval('public.system_metrics_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: technician_equipment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technician_equipment ALTER COLUMN id SET DEFAULT nextval('public.technician_equipment_id_seq'::regclass);


--
-- Name: technician_location_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technician_location_history ALTER COLUMN id SET DEFAULT nextval('public.technician_location_history_id_seq'::regclass);


--
-- Name: technician_performance id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technician_performance ALTER COLUMN id SET DEFAULT nextval('public.technician_performance_id_seq'::regclass);


--
-- Name: technician_schedule id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technician_schedule ALTER COLUMN id SET DEFAULT nextval('public.technician_schedule_id_seq'::regclass);


--
-- Name: technician_skills id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technician_skills ALTER COLUMN id SET DEFAULT nextval('public.technician_skills_id_seq'::regclass);


--
-- Name: technician_specializations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technician_specializations ALTER COLUMN id SET DEFAULT nextval('public.technician_specializations_id_seq'::regclass);


--
-- Name: technicians id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technicians ALTER COLUMN id SET DEFAULT nextval('public.technicians_id_seq'::regclass);


--
-- Name: ticket_status_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_status_history ALTER COLUMN id SET DEFAULT nextval('public.ticket_status_history_id_seq'::regclass);


--
-- Name: ticket_technicians id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_technicians ALTER COLUMN id SET DEFAULT nextval('public.ticket_technicians_id_seq'::regclass);


--
-- Name: tickets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets ALTER COLUMN id SET DEFAULT nextval('public.tickets_id_seq'::regclass);


--
-- Name: user_activity_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity_logs ALTER COLUMN id SET DEFAULT nextval('public.user_activity_logs_id_seq'::regclass);


--
-- Name: user_devices id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_devices ALTER COLUMN id SET DEFAULT nextval('public.user_devices_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: whatsapp_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whatsapp_groups ALTER COLUMN id SET DEFAULT nextval('public.whatsapp_groups_id_seq'::regclass);


--
-- Name: whatsapp_message_templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whatsapp_message_templates ALTER COLUMN id SET DEFAULT nextval('public.whatsapp_message_templates_id_seq'::regclass);


--
-- Name: whatsapp_notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whatsapp_notifications ALTER COLUMN id SET DEFAULT nextval('public.whatsapp_notifications_id_seq'::regclass);


--
-- Data for Name: alert_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alert_history (id, alert_rule_id, triggered_at, metric_value, severity, message, notification_sent, channels_used, resolved_at, resolved_by, resolution_notes) FROM stdin;
1	7	2025-10-15 19:21:25.076795+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 02.21.25\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
2	7	2025-10-15 19:21:25.159514+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 02.21.25\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
3	7	2025-10-15 19:21:25.236005+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 02.21.25\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
4	7	2025-10-15 19:21:25.257137+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 02.21.25\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
5	7	2025-10-15 20:25:00.034848+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 03.25.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
7	7	2025-10-15 20:25:00.037316+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 03.25.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
6	7	2025-10-15 20:25:00.035718+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 03.25.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
8	7	2025-10-15 20:25:00.040243+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 03.25.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
10	7	2025-10-15 21:25:00.037647+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 04.25.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
9	7	2025-10-15 21:25:00.037071+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 04.25.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
11	7	2025-10-15 21:30:00.044679+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 04.30.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
12	7	2025-10-15 21:30:00.049196+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 04.30.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
14	7	2025-10-15 22:30:00.05769+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.30.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
13	7	2025-10-15 22:30:00.056621+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.30.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
15	7	2025-10-15 22:30:00.073163+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.30.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
16	7	2025-10-15 22:30:00.074874+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.30.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
17	7	2025-10-15 22:30:11.467398+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.30.11\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
18	7	2025-10-15 22:30:11.486311+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.30.11\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
20	7	2025-10-15 22:30:11.600526+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.30.11\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
19	7	2025-10-15 22:30:11.600441+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.30.11\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
21	7	2025-10-15 22:43:21.576485+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.43.21\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
22	7	2025-10-15 22:43:21.630566+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.43.21\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
23	7	2025-10-15 22:43:21.707367+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.43.21\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
24	7	2025-10-15 22:43:21.728013+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.43.21\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
25	7	2025-10-15 22:53:31.018779+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.53.31\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
26	7	2025-10-15 22:53:31.081203+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.53.31\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
27	7	2025-10-15 22:53:31.158617+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.53.31\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
28	7	2025-10-15 22:53:31.169971+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.53.31\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
29	7	2025-10-15 22:55:20.106727+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.55.20\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
30	7	2025-10-15 22:55:20.123693+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.55.20\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
31	7	2025-10-15 22:55:20.277767+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.55.20\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
32	7	2025-10-15 22:55:20.29058+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.55.20\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
33	7	2025-10-15 22:56:14.062446+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.56.14\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
34	7	2025-10-15 22:56:14.066039+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.56.14\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
35	7	2025-10-15 22:56:14.187411+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.56.14\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
36	7	2025-10-15 22:56:14.221496+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 05.56.14\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
37	7	2025-10-15 23:05:59.072535+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 06.05.59\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
38	7	2025-10-15 23:05:59.092285+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 06.05.59\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
39	7	2025-10-15 23:05:59.188488+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 06.05.59\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
40	7	2025-10-15 23:05:59.26316+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 06.05.59\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
41	7	2025-10-15 23:06:54.844631+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 06.06.54\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
42	7	2025-10-15 23:06:54.85559+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 06.06.54\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
43	7	2025-10-15 23:06:54.984494+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 06.06.54\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
44	7	2025-10-15 23:06:55.005117+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 06.06.55\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
45	7	2025-10-15 23:08:20.855107+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 06.08.20\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
46	7	2025-10-15 23:08:20.879586+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 06.08.20\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
47	7	2025-10-15 23:08:21.013002+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 06.08.21\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
48	7	2025-10-15 23:08:21.023221+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 06.08.21\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
49	7	2025-10-16 00:10:00.024773+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.10.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
50	7	2025-10-16 00:10:00.027174+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.10.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
51	7	2025-10-16 00:10:00.029071+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.10.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
52	7	2025-10-16 00:10:00.032223+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.10.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
53	7	2025-10-16 00:14:56.30293+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.14.56\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
54	7	2025-10-16 00:14:56.355164+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.14.56\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
56	7	2025-10-16 00:14:56.427811+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.14.56\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
55	7	2025-10-16 00:14:56.420004+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.14.56\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
58	7	2025-10-16 00:39:44.213729+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.39.44\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
57	7	2025-10-16 00:39:44.208774+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.39.44\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
60	7	2025-10-16 00:39:44.312034+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.39.44\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
59	7	2025-10-16 00:39:44.301025+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.39.44\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
62	7	2025-10-16 00:49:51.934555+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.49.51\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
61	7	2025-10-16 00:49:51.929216+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.49.51\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
63	7	2025-10-16 00:49:52.043551+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.49.52\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
64	7	2025-10-16 00:49:52.103419+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.49.52\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
65	7	2025-10-16 00:56:13.513401+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.56.13\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
66	7	2025-10-16 00:56:13.523923+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.56.13\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
67	7	2025-10-16 00:56:13.642047+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.56.13\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
68	7	2025-10-16 00:56:13.65462+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 07.56.13\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
69	7	2025-10-16 01:03:50.046333+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.03.50\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
70	7	2025-10-16 01:03:50.101661+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.03.50\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
71	7	2025-10-16 01:03:50.171896+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.03.50\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
72	7	2025-10-16 01:03:50.199804+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.03.50\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
73	7	2025-10-16 01:06:07.776729+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.06.07\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
74	7	2025-10-16 01:06:07.778227+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.06.07\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
75	7	2025-10-16 01:06:07.896495+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.06.07\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
76	7	2025-10-16 01:06:07.973301+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.06.07\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
77	7	2025-10-16 01:11:20.309511+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.11.20\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
78	7	2025-10-16 01:11:20.334125+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.11.20\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
79	7	2025-10-16 01:11:20.452683+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.11.20\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
80	7	2025-10-16 01:11:20.503279+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.11.20\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
81	7	2025-10-16 01:13:54.873149+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.13.54\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
82	7	2025-10-16 01:13:54.878781+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.13.54\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
83	7	2025-10-16 01:13:54.998184+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.13.54\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
84	7	2025-10-16 01:13:54.999991+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.13.54\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
85	7	2025-10-16 01:19:02.348905+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.19.02\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
86	7	2025-10-16 01:19:02.37612+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.19.02\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
87	7	2025-10-16 01:19:02.475707+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.19.02\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
88	7	2025-10-16 01:19:02.507673+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.19.02\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
90	7	2025-10-16 01:31:34.409927+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.31.34\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
89	7	2025-10-16 01:31:34.408137+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.31.34\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
91	7	2025-10-16 01:31:34.52048+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.31.34\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
92	7	2025-10-16 01:31:34.597625+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.31.34\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
93	7	2025-10-16 01:40:33.249212+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.40.33\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
94	7	2025-10-16 01:40:33.252639+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.40.33\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
95	7	2025-10-16 01:40:33.440485+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.40.33\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
96	7	2025-10-16 01:40:33.44563+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 08.40.33\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
97	7	2025-10-16 02:11:53.299418+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 09.11.53\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
98	7	2025-10-16 02:11:53.326+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 09.11.53\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
99	7	2025-10-16 02:11:53.462032+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 09.11.53\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
100	7	2025-10-16 02:11:53.465454+00	2	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 2\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 09.11.53\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
101	7	2025-10-16 03:15:00.044725+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 10.15.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
102	7	2025-10-16 03:15:00.047504+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 10.15.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
103	7	2025-10-16 03:15:00.048577+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 10.15.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
104	7	2025-10-16 03:15:00.053798+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 10.15.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
105	7	2025-10-16 03:35:54.241781+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 10.35.54\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
106	7	2025-10-16 03:35:54.341971+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 10.35.54\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
107	7	2025-10-16 03:35:54.367383+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 10.35.54\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
108	7	2025-10-16 03:35:54.431237+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 10.35.54\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
109	7	2025-10-16 04:22:50.888215+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 11.22.50\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
110	7	2025-10-16 04:22:50.917745+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 11.22.50\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
111	7	2025-10-16 04:22:51.011154+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 11.22.51\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
112	7	2025-10-16 04:22:51.01582+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 11.22.51\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
115	7	2025-10-16 05:25:00.035793+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 12.25.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
116	7	2025-10-16 05:25:00.039035+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 12.25.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
114	7	2025-10-16 05:25:00.034498+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 12.25.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
113	7	2025-10-16 05:25:00.034117+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 12.25.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
119	7	2025-10-16 06:25:00.037699+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 13.25.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
117	7	2025-10-16 06:25:00.03667+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 13.25.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
118	7	2025-10-16 06:25:00.037029+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 13.25.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
120	7	2025-10-16 06:30:00.058228+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 13.30.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
121	7	2025-10-16 07:25:00.03569+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 14.25.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
122	7	2025-10-16 07:25:00.03924+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 14.25.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
123	7	2025-10-16 07:30:00.050739+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 14.30.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
124	7	2025-10-16 07:35:00.036525+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 14.35.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
125	7	2025-10-16 08:25:00.038027+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 15.25.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
126	7	2025-10-16 08:30:00.043089+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 15.30.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
127	7	2025-10-16 08:35:00.036174+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 15.35.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
128	7	2025-10-16 08:35:00.03724+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 15.35.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
129	7	2025-10-16 09:25:00.042994+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 16.25.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
130	7	2025-10-16 09:30:00.047004+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 16.30.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
131	7	2025-10-16 09:35:00.036635+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 16.35.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
132	7	2025-10-16 09:40:00.038167+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 16.40.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
133	7	2025-10-16 10:30:00.046958+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 17.30.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
134	7	2025-10-16 10:35:00.03718+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 17.35.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
135	7	2025-10-16 10:40:00.035588+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 17.40.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
136	7	2025-10-16 10:45:00.052143+00	3	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 3\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 17.45.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
137	7	2025-10-16 11:30:00.05005+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 18.30.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
138	7	2025-10-16 11:40:00.033401+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 18.40.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
139	7	2025-10-16 11:45:00.048601+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 18.45.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
140	7	2025-10-16 11:50:00.035174+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 18.50.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
141	7	2025-10-16 12:30:00.051898+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 19.30.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
142	7	2025-10-16 12:40:00.033074+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 19.40.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
143	7	2025-10-16 12:45:00.051585+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 19.45.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
144	7	2025-10-16 12:50:00.039151+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 19.50.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
145	7	2025-10-16 13:35:00.037579+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 20.35.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
146	7	2025-10-16 13:40:00.035032+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 20.40.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
147	7	2025-10-16 13:45:00.059044+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 20.45.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
148	7	2025-10-16 13:55:00.035056+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 20.55.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
149	7	2025-10-16 14:40:00.034997+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 21.40.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
150	7	2025-10-16 14:40:00.03518+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 21.40.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
151	7	2025-10-16 14:50:00.033859+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 21.50.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
152	7	2025-10-16 14:55:00.038137+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 21.55.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
153	7	2025-10-16 15:40:00.034767+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 22.40.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
154	7	2025-10-16 15:45:00.05064+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 22.45.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
155	7	2025-10-16 15:50:00.036153+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 22.50.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
156	7	2025-10-16 16:00:00.051922+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 23.00.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
157	7	2025-10-16 16:40:00.034961+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 23.40.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
159	7	2025-10-16 16:50:00.036105+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 23.50.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
158	7	2025-10-16 16:50:00.035783+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 16/10/2025, 23.50.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
160	7	2025-10-16 17:05:00.036322+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 00.05.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
161	7	2025-10-16 17:40:00.03731+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 00.40.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
163	7	2025-10-16 17:50:00.038914+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 00.50.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
162	7	2025-10-16 17:50:00.038136+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 00.50.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
164	7	2025-10-16 18:05:00.040068+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 01.05.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
165	7	2025-10-16 18:45:00.045743+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 01.45.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
166	7	2025-10-16 18:55:00.03526+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 01.55.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
167	7	2025-10-16 18:55:00.040693+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 01.55.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
168	7	2025-10-16 19:10:00.039637+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 02.10.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
169	7	2025-10-16 19:45:00.048437+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 02.45.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
170	7	2025-10-16 19:55:00.03749+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 02.55.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
171	7	2025-10-16 20:00:00.053393+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 03.00.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
172	7	2025-10-16 20:15:00.048194+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 03.15.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
173	7	2025-10-16 20:45:00.053514+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 03.45.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
174	7	2025-10-16 20:55:00.039577+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 03.55.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
175	7	2025-10-16 21:05:00.048217+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 04.05.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
176	7	2025-10-16 21:20:00.041493+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 04.20.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
177	7	2025-10-16 21:50:00.040986+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 04.50.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
178	7	2025-10-16 22:00:00.043439+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 05.00.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
179	7	2025-10-16 22:10:00.033703+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 05.10.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
180	7	2025-10-16 22:25:00.041346+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 05.25.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
181	7	2025-10-16 22:55:00.038495+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 05.55.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
182	7	2025-10-16 23:00:00.047371+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 06.00.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
183	7	2025-10-16 23:10:00.039702+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 06.10.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
184	7	2025-10-16 23:30:00.046173+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 06.30.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
185	7	2025-10-17 00:00:00.047956+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 07.00.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
186	7	2025-10-17 00:05:00.033541+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 07.05.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
187	7	2025-10-17 00:15:00.052669+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 07.15.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
188	7	2025-10-17 00:30:00.04717+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 07.30.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
189	7	2025-10-17 01:00:00.065252+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 08.00.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
190	7	2025-10-17 01:05:00.033279+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 08.05.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
191	7	2025-10-17 01:20:00.035827+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 08.20.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
192	7	2025-10-17 01:30:00.050089+00	4	high	🟠 *ALERT: SLA VIOLATION*\n\n📊 Current Value: 4\n⚠️ Threshold: 0\n📈 Severity: HIGH\n\n📝 Details: Alert when ticket exceeds SLA deadline\n\n⏰ Time: 17/10/2025, 08.30.00\n\n*Action Required:* Please investigate immediately!\n\n_AGLIS Monitoring System_ 🔔	t	["whatsapp"]	\N	\N	\N
\.


--
-- Data for Name: alert_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alert_rules (id, name, description, category, metric, condition, threshold, severity, notification_channels, recipients, is_active, cooldown_minutes, created_at, updated_at) FROM stdin;
1	API Error Rate High	Alert when API error rate exceeds 1% in last 5 minutes	performance	api_error_rate	greater_than	1	high	["email", "whatsapp"]	["628179380800"]	t	60	2025-10-15 19:18:04.377151+00	2025-10-15 19:18:04.377151+00
2	Slow API Response	Alert when average API response time exceeds 3 seconds	performance	api_response_time	greater_than	3000	medium	["email", "whatsapp"]	["628179380800"]	t	60	2025-10-15 19:18:04.377151+00	2025-10-15 19:18:04.377151+00
3	Database Connection Failed	Alert when database connection fails	system	database_connection	equals	0	critical	["email", "whatsapp"]	["628179380800"]	t	60	2025-10-15 19:18:04.377151+00	2025-10-15 19:18:04.377151+00
4	Disk Space Low	Alert when disk space usage exceeds 80%	system	disk_usage	greater_than	80	high	["email", "whatsapp"]	["628179380800"]	t	60	2025-10-15 19:18:04.377151+00	2025-10-15 19:18:04.377151+00
5	Memory Usage High	Alert when memory usage exceeds 90%	system	memory_usage	greater_than	90	high	["email", "whatsapp"]	["628179380800"]	t	60	2025-10-15 19:18:04.377151+00	2025-10-15 19:18:04.377151+00
6	WhatsApp Provider Down	Alert when WhatsApp success rate < 80%	system	whatsapp_success_rate	less_than	80	high	["email", "whatsapp"]	["628179380800"]	t	60	2025-10-15 19:18:04.377151+00	2025-10-15 19:18:04.377151+00
7	SLA Violation	Alert when ticket exceeds SLA deadline	business	sla_violation	greater_than	0	high	["whatsapp"]	["628179380800"]	t	60	2025-10-15 19:18:04.377151+00	2025-10-15 19:18:04.377151+00
8	Backup Failed	Alert when daily backup fails	system	backup_status	equals	0	critical	["email", "whatsapp"]	["628179380800"]	t	60	2025-10-15 19:18:04.377151+00	2025-10-15 19:18:04.377151+00
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attachments (id, ticket_id, filename, original_filename, file_path, file_size, mime_type, uploaded_by, upload_type, created_at) FROM stdin;
\.


--
-- Data for Name: billing_alerts; Type: TABLE DATA; Schema: public; Owner: aglis_user
--

COPY public.billing_alerts (id, invoice_id, customer_id, alert_type, alert_message, sent_via, sent_at, is_read, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: billing_schedules; Type: TABLE DATA; Schema: public; Owner: aglis_user
--

COPY public.billing_schedules (id, customer_id, schedule_name, billing_frequency, billing_day, due_days, invoice_template_items, is_active, next_billing_date, last_billing_date, auto_send, auto_reminder, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_complaints; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_complaints (id, customer_id, complaint_date, complaint_type, complaint_description, priority, status, resolution, resolved_date, resolved_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_equipment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_equipment (id, customer_id, equipment_type, brand, model, serial_number, mac_address, installation_date, warranty_expiry, status, notes, created_at, updated_at) FROM stdin;
10	5	cable	Belden	Cat6 UTP	BLD-005	\N	2024-09-05	\N	inactive	Kabel 40 meter dari ODP	2024-09-05 00:00:00	2025-10-14 00:55:54.341206
1	1	modem	TP-Link	Archer C6	TL001234567	00:11:22:33:44:55	2025-01-01	2027-01-01	active	Modem WiFi dual band	2025-01-01 00:00:00	2025-10-13 00:08:59.916642
2	1	cable	Belden	Cat6 UTP	BLD-001	\N	2025-01-01	\N	active	Kabel 50 meter dari ODP ke rumah	2025-01-01 00:00:00	2025-10-13 00:08:59.916642
3	2	modem	Huawei	HG8245H	HW555666777	00:22:33:44:55:66	2024-12-15	2026-12-15	active	ONT Fiber dengan WiFi AC	2024-12-15 00:00:00	2025-10-13 00:08:59.916642
4	2	cable	Belden	Cat6 UTP	BLD-002	\N	2024-12-15	\N	active	Kabel 60 meter dari ODP	2024-12-15 00:00:00	2025-10-13 00:08:59.916642
5	3	modem	ZTE	F670L	ZT888999000	00:33:44:55:66:77	2024-11-20	2026-11-20	active	ONT Fiber dual band WiFi	2024-11-20 00:00:00	2025-10-13 00:08:59.916642
6	3	cable	Belden	Cat6 UTP	BLD-003	\N	2024-11-20	\N	active	Kabel 45 meter dari ODP	2024-11-20 00:00:00	2025-10-13 00:08:59.916642
7	4	modem	Fiberhome	HG6245D	FH111222333	00:44:55:66:77:88	2024-10-10	2026-10-10	active	ONT Fiber WiFi 5	2024-10-10 00:00:00	2025-10-13 00:08:59.916642
8	4	cable	Belden	Cat6 UTP	BLD-004	\N	2024-10-10	\N	active	Kabel 70 meter dari ODP	2024-10-10 00:00:00	2025-10-13 00:08:59.916642
9	5	modem	TP-Link	Archer C50	TL444555666	00:55:66:77:88:99	2024-09-05	2026-09-05	active	Modem WiFi standar	2024-09-05 00:00:00	2025-10-13 00:08:59.916642
11	6	modem	Huawei	HG8245H5	HW777888999	00:66:77:88:99:AA	2024-08-15	2026-08-15	active	ONT Fiber WiFi AC	2024-08-15 00:00:00	2025-10-13 00:08:59.916642
12	6	cable	Belden	Cat6 UTP	BLD-006	\N	2024-08-15	\N	active	Kabel 55 meter dari ODP	2024-08-15 00:00:00	2025-10-13 00:08:59.916642
13	7	modem	ZTE	F670	ZT000111222	00:77:88:99:AA:BB	2024-07-22	2026-07-22	active	ONT Fiber dual band	2024-07-22 00:00:00	2025-10-13 00:08:59.916642
14	7	cable	Belden	Cat6 UTP	BLD-007	\N	2024-07-22	\N	active	Kabel 65 meter dari ODP	2024-07-22 00:00:00	2025-10-13 00:08:59.916642
15	8	modem	Fiberhome	HG6245N	FH333444555	00:88:99:AA:BB:CC	2024-06-10	2026-06-10	active	ONT Fiber WiFi 6	2024-06-10 00:00:00	2025-10-13 00:08:59.916642
16	8	cable	Belden	Cat6 UTP	BLD-008	\N	2024-06-10	\N	inactive	Kabel 75 meter dari ODP	2024-06-10 00:00:00	2025-10-14 01:23:48.751276
17	11	ONT Huawei HG8245H	Huawei	HG8245H	SN1760407323	00:11:22:33:44:55	2025-10-14	2026-10-14	active	API test equipment	2025-10-14 02:02:13.298134	2025-10-14 02:02:13.298134
18	11	Router TP-Link Archer C6	TP-Link	Archer C6	SN-TEST-001	AA:BB:CC:DD:EE:FF	2025-10-14	2026-10-14	active	Test equipment via API	2025-10-14 02:31:21.830279	2025-10-14 02:31:21.830279
19	15	ONT Huawei HG8245H	ONT	Huawei HG8245H	\N	\N	2025-10-14	\N	active	\N	2025-10-14 03:02:51.975374	2025-10-14 03:02:51.975374
20	15	Kabel Drop FTTH	Kabel	Drop FTTH	\N	\N	2025-10-14	\N	active	\N	2025-10-14 03:03:01.888868	2025-10-14 03:03:01.888868
21	15	Patch Cord SC-SC	Patch	Cord SC-SC	\N	\N	2025-10-14	\N	active	\N	2025-10-14 03:03:14.620948	2025-10-14 03:03:14.620948
22	15	Rosette Box	Rosette	Box	\N	\N	2025-10-14	\N	active	\N	2025-10-14 03:03:24.77412	2025-10-14 03:03:24.77412
\.


--
-- Data for Name: customer_payment_methods; Type: TABLE DATA; Schema: public; Owner: aglis_user
--

COPY public.customer_payment_methods (id, customer_id, method_type, provider, account_number_masked, account_holder_name, payment_token, token_expires_at, is_primary, is_active, auto_debit_enabled, created_at, updated_at, is_deleted) FROM stdin;
\.


--
-- Data for Name: customer_payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_payments (id, customer_id, invoice_number, payment_date, amount, payment_method, payment_reference, billing_period_start, billing_period_end, payment_status, notes, created_by, created_at, updated_at) FROM stdin;
32	5	INV-2025-000004	2025-10-14	149900.00	cash		2025-09-30	2025-10-30	completed		17	2025-10-14 00:48:46.237334	2025-10-14 00:48:46.237334
1	1	INV-2025-000001	2025-01-01	149900.00	transfer	TRF-001-2025	2025-01-01	2025-01-31	completed	Pembayaran bulan pertama - Home Bronze	\N	2025-01-01 00:00:00	2025-10-13 00:08:59.918809
2	1	INV-2025-000009	2025-02-01	149900.00	transfer	TRF-009-2025	2025-02-01	2025-02-28	completed	Pembayaran bulan kedua	\N	2025-02-01 00:00:00	2025-10-13 00:08:59.918809
3	2	INV-2024-000002	2024-12-15	199900.00	cash	CASH-001-2024	2024-12-15	2025-01-15	completed	Pembayaran tunai - Home Silver	\N	2024-12-15 00:00:00	2025-10-13 00:08:59.918809
4	2	INV-2025-000010	2025-01-15	199900.00	transfer	TRF-010-2025	2025-01-15	2025-02-15	completed	Pembayaran transfer	\N	2025-01-15 00:00:00	2025-10-13 00:08:59.918809
5	3	INV-2024-000003	2024-11-20	249900.00	transfer	TRF-003-2024	2024-11-20	2024-12-20	completed	Pembayaran bulanan - Home Gold	\N	2024-11-20 00:00:00	2025-10-13 00:08:59.918809
6	3	INV-2024-000011	2024-12-20	249900.00	transfer	TRF-011-2024	2024-12-20	2025-01-20	completed	Pembayaran berikutnya	\N	2024-12-20 00:00:00	2025-10-13 00:08:59.918809
7	4	INV-2024-000004	2024-10-10	289900.00	transfer	TRF-004-2024	2024-10-10	2024-11-10	completed	Pembayaran bulanan - Home Platinum	\N	2024-10-10 00:00:00	2025-10-13 00:08:59.918809
8	4	INV-2024-000012	2024-11-10	289900.00	transfer	TRF-012-2024	2024-11-10	2024-12-10	completed	Pembayaran berikutnya	\N	2024-11-10 00:00:00	2025-10-13 00:08:59.918809
9	4	INV-2024-000013	2024-12-10	289900.00	transfer	TRF-013-2024	2024-12-10	2025-01-10	completed	Pembayaran berikutnya	\N	2024-12-10 00:00:00	2025-10-13 00:08:59.918809
10	5	INV-2024-000005	2024-09-05	149900.00	transfer	TRF-005-2024	2024-09-05	2024-10-05	completed	Pembayaran bulanan - Home Bronze	\N	2024-09-05 00:00:00	2025-10-13 00:08:59.918809
11	5	INV-2024-000014	2024-10-05	149900.00	transfer	TRF-014-2024	2024-10-05	2024-11-05	completed	Pembayaran berikutnya	\N	2024-10-05 00:00:00	2025-10-13 00:08:59.918809
12	5	INV-2024-000015	2024-11-05	149900.00	transfer	TRF-015-2024	2024-11-05	2024-12-05	completed	Pembayaran berikutnya	\N	2024-11-05 00:00:00	2025-10-13 00:08:59.918809
13	5	INV-2024-000016	2024-12-05	149900.00	transfer	TRF-016-2024	2024-12-05	2025-01-05	completed	Pembayaran berikutnya	\N	2024-12-05 00:00:00	2025-10-13 00:08:59.918809
14	6	INV-2024-000006	2024-08-15	199900.00	transfer	TRF-006-2024	2024-08-15	2024-09-15	completed	Pembayaran bulanan - Home Silver	\N	2024-08-15 00:00:00	2025-10-13 00:08:59.918809
15	6	INV-2024-000017	2024-09-15	199900.00	transfer	TRF-017-2024	2024-09-15	2024-10-15	completed	Pembayaran berikutnya	\N	2024-09-15 00:00:00	2025-10-13 00:08:59.918809
16	6	INV-2024-000018	2024-10-15	199900.00	transfer	TRF-018-2024	2024-10-15	2024-11-15	completed	Pembayaran berikutnya	\N	2024-10-15 00:00:00	2025-10-13 00:08:59.918809
17	6	INV-2024-000019	2024-11-15	199900.00	transfer	TRF-019-2024	2024-11-15	2024-12-15	completed	Pembayaran berikutnya	\N	2024-11-15 00:00:00	2025-10-13 00:08:59.918809
18	6	INV-2024-000020	2024-12-15	199900.00	transfer	TRF-020-2024	2024-12-15	2025-01-15	completed	Pembayaran berikutnya	\N	2024-12-15 00:00:00	2025-10-13 00:08:59.918809
19	7	INV-2024-000007	2024-07-22	249900.00	transfer	TRF-007-2024	2024-07-22	2024-08-22	completed	Pembayaran bulanan - Home Gold	\N	2024-07-22 00:00:00	2025-10-13 00:08:59.918809
20	7	INV-2024-000021	2024-08-22	249900.00	transfer	TRF-021-2024	2024-08-22	2024-09-22	completed	Pembayaran berikutnya	\N	2024-08-22 00:00:00	2025-10-13 00:08:59.918809
21	7	INV-2024-000022	2024-09-22	249900.00	transfer	TRF-022-2024	2024-09-22	2024-10-22	completed	Pembayaran berikutnya	\N	2024-09-22 00:00:00	2025-10-13 00:08:59.918809
22	7	INV-2024-000023	2024-10-22	249900.00	transfer	TRF-023-2024	2024-10-22	2024-11-22	completed	Pembayaran berikutnya	\N	2024-10-22 00:00:00	2025-10-13 00:08:59.918809
23	7	INV-2024-000024	2024-11-22	249900.00	transfer	TRF-024-2024	2024-11-22	2024-12-22	completed	Pembayaran berikutnya	\N	2024-11-22 00:00:00	2025-10-13 00:08:59.918809
24	7	INV-2024-000025	2024-12-22	249900.00	transfer	TRF-025-2024	2024-12-22	2025-01-22	completed	Pembayaran berikutnya	\N	2024-12-22 00:00:00	2025-10-13 00:08:59.918809
25	8	INV-2024-000008	2024-06-10	289900.00	transfer	TRF-008-2024	2024-06-10	2024-07-10	completed	Pembayaran bulanan - Home Platinum	\N	2024-06-10 00:00:00	2025-10-13 00:08:59.918809
26	8	INV-2024-000026	2024-07-10	289900.00	transfer	TRF-026-2024	2024-07-10	2024-08-10	completed	Pembayaran berikutnya	\N	2024-07-10 00:00:00	2025-10-13 00:08:59.918809
27	8	INV-2024-000027	2024-08-10	289900.00	transfer	TRF-027-2024	2024-08-10	2024-09-10	completed	Pembayaran berikutnya	\N	2024-08-10 00:00:00	2025-10-13 00:08:59.918809
28	8	INV-2024-000028	2024-09-10	289900.00	transfer	TRF-028-2024	2024-09-10	2024-10-10	completed	Pembayaran berikutnya	\N	2024-09-10 00:00:00	2025-10-13 00:08:59.918809
29	8	INV-2024-000029	2024-10-10	289900.00	transfer	TRF-029-2024	2024-10-10	2024-11-10	completed	Pembayaran berikutnya	\N	2024-10-10 00:00:00	2025-10-13 00:08:59.918809
30	8	INV-2024-000030	2024-11-10	289900.00	transfer	TRF-030-2024	2024-11-10	2024-12-10	completed	Pembayaran berikutnya	\N	2024-11-10 00:00:00	2025-10-13 00:08:59.918809
31	8	INV-2024-000031	2024-12-10	289900.00	transfer	TRF-031-2024	2024-12-10	2025-01-10	completed	Pembayaran berikutnya	\N	2024-12-10 00:00:00	2025-10-13 00:08:59.918809
\.


--
-- Data for Name: customer_registrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_registrations (id, registration_number, full_name, email, phone, id_card_number, id_card_photo, address, rt, rw, kelurahan, kecamatan, city, postal_code, latitude, longitude, address_notes, service_type, package_id, preferred_installation_date, preferred_time_slot, status, rejection_reason, verified_by, verified_at, verification_notes, approved_by, approved_at, approval_notes, survey_ticket_id, survey_scheduled_date, survey_completed_date, survey_notes, survey_result, customer_id, installation_ticket_id, referral_code, notes, utm_source, utm_medium, utm_campaign, created_at, updated_at) FROM stdin;
1	REG-20251013-0001	Test User	test789@example.com	081234567890	\N	\N	Test Address	\N	\N	\N	\N	Jakarta	\N	\N	\N	\N	broadband	1	\N	\N	customer_created	\N	17	2025-10-13 10:03:39.66	\N	17	2025-10-13 10:03:43.091	\N	\N	\N	\N	\N	\N	5	5	\N	\N	\N	\N	\N	2025-10-13 00:40:59.662549	2025-10-13 19:36:48.160158
2	REG-20251013-0002	Lufti Rahadiansyah	luftirahadian@gmail.com	08197670700	\N	\N	Grahayana Residence\nBlok G2/12	\N	\N	\N	\N	Karawang	41361	\N	\N	\N	broadband	1	\N	morning	customer_created	\N	17	2025-10-14 03:32:36.349	\N	17	2025-10-14 03:32:39.846	\N	\N	\N	\N	\N	\N	6	6	\N	\N	\N	\N	\N	2025-10-13 20:01:16.932151	2025-10-13 20:42:08.040838
3	REG-20251013-0003	Ega Nabila	eganabila@gmail.com	08197670700	\N	\N	Jalan kertanegara no.136 Grand Taruma	\N	\N	\N	\N	Karawang	41361	\N	\N	\N	broadband	1	\N	afternoon	customer_created	\N	17	2025-10-14 03:42:28.243	\N	17	2025-10-14 03:42:31.049	\N	\N	\N	\N	\N	\N	7	7	\N	\N	\N	\N	\N	2025-10-13 20:32:19.491027	2025-10-13 20:54:22.556522
4	REG-20251013-0004	Rahadian	rahadian@gmail.com	08197670700	\N	\N	Grahayana Residence\nBlok G2/12	\N	\N	\N	\N	Karawang	41361	\N	\N	\N	broadband	1	\N	evening	customer_created	\N	17	2025-10-14 04:02:04.905	\N	17	2025-10-14 04:02:31.471	\N	\N	\N	\N	\N	\N	8	8	\N	\N	\N	\N	\N	2025-10-13 21:00:49.027476	2025-10-13 21:03:14.714096
10	REG20251014005	Test User Workflow 1760407323	test.workflow.1760407323@email.com	081200009528	3216000000008902	\N	Jl. Test Workflow No. 123	001	005	Karawang Baru	Karawang Timur	Karawang	41314	\N	\N	\N	broadband	1	2025-10-21	\N	customer_created	\N	17	2025-10-14 09:02:07.011	Quick verification for API testing	17	2025-10-14 09:02:08.077	Fast track approval for API testing	\N	\N	\N	\N	\N	11	12	\N	\N	\N	\N	\N	2025-10-14 02:02:04.863642	2025-10-14 02:02:10.13896
9	REG20251014004	Test User Workflow 1760407267	test.workflow.1760407267@email.com	081200017918	3216000000028532	\N	Jl. Test Workflow No. 123	001	005	Karawang Baru	Karawang Timur	Karawang	41314	\N	\N	\N	broadband	1	2025-10-21	\N	customer_created	\N	17	2025-10-14 09:01:10.986	Quick verification for API testing	17	2025-10-14 09:01:12.042	Fast track approval for API testing	\N	\N	\N	\N	\N	12	13	\N	\N	\N	\N	\N	2025-10-14 02:01:08.838033	2025-10-14 02:02:43.255433
8	REG20251014003	Test User Workflow 1760407191	test.workflow.1760407191@email.com	081200023457	3216000000024033	\N	Jl. Test Workflow No. 123	001	005	Karawang Baru	Karawang Timur	Karawang	41314	\N	\N	\N	broadband	1	2025-10-21	\N	customer_created	\N	17	2025-10-14 08:59:54.369	Quick verification for API testing	17	2025-10-14 08:59:55.435	Fast track approval for API testing	\N	\N	\N	\N	\N	13	14	\N	\N	\N	\N	\N	2025-10-14 01:59:52.298238	2025-10-14 02:02:57.934026
5	REG-20251013-0005	Nabila	nabila@gmail.com	08197670700	\N	\N	Jalan kertanegara no.136 Grand Taruma	\N	\N	\N	\N	Karawang	41361	\N	\N	\N	broadband	2	\N	morning	customer_created	\N	17	2025-10-14 09:04:12.194	\N	17	2025-10-14 09:04:16.424	\N	\N	\N	\N	\N	\N	14	15	\N	\N	\N	\N	\N	2025-10-13 23:39:30.294369	2025-10-14 02:04:18.886709
6	REG20251014001	ega	ega@gmail.com	08197670700	\N	\N	Grahayana Residence\nBlok G2/12	\N	\N	\N	\N	Karawang	41361	\N	\N	\N	broadband	3	\N	evening	customer_created	\N	17	2025-10-14 09:07:38.14	Quick verified via detail page	17	2025-10-14 09:07:42.364	Quick approved via detail page	\N	\N	\N	\N	\N	15	16	\N	\N	\N	\N	\N	2025-10-14 01:49:15.472385	2025-10-14 02:07:45.051161
7	REG20251014002	Test User Workflow 1760407142	test.workflow.1760407142@email.com	081200025435	3216000000029378	\N	Jl. Test Workflow No. 123	001	005	Karawang Baru	Karawang Timur	Karawang	41314	\N	\N	\N	broadband	1	2025-10-21	\N	customer_created	\N	17	2025-10-14 11:28:02.89	Quick verified via detail page	17	2025-10-14 11:28:07.343	Quick approved via detail page	\N	\N	\N	\N	\N	16	20	\N	\N	\N	\N	\N	2025-10-14 01:59:03.81013	2025-10-14 04:28:10.445904
11	REG20251015001	Ahmad Test Customer	test.customer@aglis.biz.id	0817102070	\N	\N	Jl. Test Street No. 123	\N	\N	\N	\N	Karawang	\N	\N	\N	\N	broadband	4	\N	morning	customer_created	\N	17	2025-10-15 11:09:54.443	\N	17	2025-10-15 11:10:05.094	\N	\N	\N	\N	\N	\N	17	23	\N	ASAP	\N	\N	\N	2025-10-15 04:06:22.43063	2025-10-15 04:10:08.465237
12	REG20251015002	Udin	udin@email.com	0817102070	\N	\N	Jalan kertanegara no.136 Grand Taruma	\N	\N	\N	\N	Karawang	41361	\N	\N	\N	broadband	3	\N	morning	customer_created	\N	17	2025-10-15 12:04:39.031	\N	17	2025-10-15 12:04:41.983	\N	\N	\N	\N	\N	\N	18	24	\N	\N	\N	\N	\N	2025-10-15 04:49:55.067424	2025-10-15 05:07:05.294015
13	REG20251016001	Riky Van Boomel	vanbommel@gmail.com	082321922280	\N	\N	Jl. Neraka Jahanam No. 666	001	005	\N	\N	Karawang	\N	\N	\N	\N	broadband	1	\N	morning	customer_created	\N	17	2025-10-16 11:28:18.634	\N	17	2025-10-16 11:28:33.963	\N	\N	\N	\N	\N	\N	19	31	\N	\N	\N	\N	\N	2025-10-16 04:27:28.346726	2025-10-16 04:28:41.281382
\.


--
-- Data for Name: customer_service_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_service_history (id, customer_id, ticket_id, service_date, service_type, technician_id, service_duration, customer_rating, customer_feedback, service_notes, created_at) FROM stdin;
\.


--
-- Data for Name: customer_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_sessions (id, customer_id, session_token, ip_address, user_agent, expires_at, created_at) FROM stdin;
1	17	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjdXN0b21lcklkIjoxNywiY3VzdG9tZXJDb2RlIjoiQUdMUzIwMjUxMDE1MDAwMSIsInR5cGUiOiJjdXN0b21lciIsImlhdCI6MTc2MDU2OTQ0MCwiZXhwIjoxNzYxMTc0MjQwfQ.MQoSnMMiE5FTYMDhw2h2badWY2NHako1eM_kVCajD7k	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-22 23:04:00.30501+00	2025-10-15 23:04:00.30501+00
2	17	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjdXN0b21lcklkIjoxNywiY3VzdG9tZXJDb2RlIjoiQUdMUzIwMjUxMDE1MDAwMSIsInR5cGUiOiJjdXN0b21lciIsImlhdCI6MTc2MDU2OTQ0MywiZXhwIjoxNzYxMTc0MjQzfQ.f3cgxED7Hd7jJE2lGYBk9UC3vXQp50A20sG-YZhILJg	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-22 23:04:03.079927+00	2025-10-15 23:04:03.079927+00
4	17	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjdXN0b21lcklkIjoxNywiY3VzdG9tZXJDb2RlIjoiQUdMUzIwMjUxMDE1MDAwMSIsInR5cGUiOiJjdXN0b21lciIsImlhdCI6MTc2MDU2OTczNywiZXhwIjoxNzYxMTc0NTM3fQ.anOlgCA5ivPVC_efLbr29n3LFlLFRSC0fuz_fyCfmuk	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-22 23:08:57.453772+00	2025-10-15 23:08:57.453772+00
5	17	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjdXN0b21lcklkIjoxNywiY3VzdG9tZXJDb2RlIjoiQUdMUzIwMjUxMDE1MDAwMSIsInR5cGUiOiJjdXN0b21lciIsImlhdCI6MTc2MDU2OTg3NiwiZXhwIjoxNzYxMTc0Njc2fQ.2MR32tvi9OBZT1wa4p5hW2Ke_8Y49eM-sK7zgqxc5Js	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-22 23:11:16.2526+00	2025-10-15 23:11:16.2526+00
6	17	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjdXN0b21lcklkIjoxNywiY3VzdG9tZXJDb2RlIjoiQUdMUzIwMjUxMDE1MDAwMSIsInR5cGUiOiJjdXN0b21lciIsImlhdCI6MTc2MDU3MDUwMiwiZXhwIjoxNzYxMTc1MzAyfQ.3WBNyzDvEeGT1fwm523AxM82IJrPBXQ4teRKZI0uQ8g	103.55.225.241	curl/7.81.0	2025-10-22 23:21:42.535559+00	2025-10-15 23:21:42.535559+00
7	17	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjdXN0b21lcklkIjoxNywiY3VzdG9tZXJDb2RlIjoiQUdMUzIwMjUxMDE1MDAwMSIsInR5cGUiOiJjdXN0b21lciIsImlhdCI6MTc2MDU3MDcwNiwiZXhwIjoxNzYxMTc1NTA2fQ.MMhpxP4j3wKa4mhrwUczk4ZfCTiTdEhxm3bY3GrhE5Q	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-22 23:25:06.088598+00	2025-10-15 23:25:06.088598+00
8	8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjdXN0b21lcklkIjo4LCJjdXN0b21lckNvZGUiOiJBR0xTMjAyNTEwMTQwMDA0IiwidHlwZSI6ImN1c3RvbWVyIiwiaWF0IjoxNzYwNTcwODE5LCJleHAiOjE3NjExNzU2MTl9.RolJZ4ACavbQNoVd_Vs_ay91h5Aqe24az3Q3Ya5JGog	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-22 23:26:59.496622+00	2025-10-15 23:26:59.496622+00
9	17	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjdXN0b21lcklkIjoxNywiY3VzdG9tZXJDb2RlIjoiQUdMUzIwMjUxMDE1MDAwMSIsInR5cGUiOiJjdXN0b21lciIsImlhdCI6MTc2MDU3MjAyMSwiZXhwIjoxNzYxMTc2ODIxfQ.-fjaMV-GOALOilhBL7t2mfA8CKZ5c5shhZ2X6L-_A_c	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-22 23:47:01.759835+00	2025-10-15 23:47:01.759835+00
10	19	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjdXN0b21lcklkIjoxOSwiY3VzdG9tZXJDb2RlIjoiQUdMUzIwMjUxMDE2MDAwMSIsInR5cGUiOiJjdXN0b21lciIsImlhdCI6MTc2MDU4OTMyMiwiZXhwIjoxNzYxMTk0MTIyfQ.lRzQ7sUbA1gpaKGdfYoyaGzn2ChSsOI6OMS_5MFvflY	110.138.83.57	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-23 04:35:22.258564+00	2025-10-16 04:35:22.258564+00
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, customer_id, name, ktp, phone, phone_alt, email, address, latitude, longitude, odp, pic_name, pic_position, pic_phone, business_type, operating_hours, username, password, client_area_password, customer_type, payment_type, payment_status, account_status, service_type, package_id, subscription_start_date, billing_cycle, due_date, last_payment_date, outstanding_balance, ip_address, ip_type, installation_date, assigned_technician_id, signal_strength, signal_quality, total_tickets, last_service_date, customer_rating, service_quality_score, notes, registration_date, account_activation_date, last_login_date, created_at, updated_at, city, province, customer_portal_password, email_verified, last_login_at, portal_active) FROM stdin;
16	AGLS202510140010	Test User Workflow 1760407142	3216000000029378	081200025435	\N	test.workflow.1760407142@email.com	Jl. Test Workflow No. 123	\N	\N	\N	\N	\N	\N	residential	\N	testworkflow1760407142_00025435@customer	$2a$10$DbdCsWmQ9pNN6/M68Utx3OYRO9t36PofbIVxa8/ay0njFW0JpDDJG	9X9SU1NP	regular	postpaid	unpaid	pending_installation	broadband	1	\N	monthly	\N	\N	0.00	\N	dynamic	\N	\N	\N	\N	0	\N	0.00	0	\N	2025-10-14 04:28:10.445904	\N	\N	2025-10-14 04:28:10.445904	2025-10-14 04:28:10.445904	Karawang	\N	\N	f	\N	t
19	AGLS202510160001	Riky Van Boomel	\N	082321922280	\N	vanbommel@gmail.com	Jl. Neraka Jahanam No. 666	\N	\N	\N	\N	\N	\N	residential	\N	vanbommel_21922280@customer	$2a$10$NlUyhLCGCPL3lfrDiZsHy.XNGLh2jwMpMCdVarLltSGRDL3xDFO1q	TDA37ARC	regular	postpaid	unpaid	active	broadband	1	\N	monthly	\N	\N	0.00	\N	dynamic	2025-10-16	\N	\N	\N	0	\N	0.00	0	\N	2025-10-16 04:28:41.281382	\N	\N	2025-10-16 04:28:41.281382	2025-10-16 04:35:22.251042	Karawang	\N	\N	f	2025-10-16 04:35:22.251042+00	t
17	AGLS202510150001	Ahmad Test Customer	\N	0817102070	\N	test.customer@aglis.biz.id	Jl. Test Street No. 123 teluk jambe	\N	\N	\N	\N	\N	\N	residential	\N	testcustomer_17102070@customer	$2a$10$5o6toVekSCMo6lR0GyPrKeZr4R1HjnNdfTqrzLNT4HIZGO25EyGNO	GLSPQZSG	regular	postpaid	unpaid	active	broadband	4	\N	monthly	\N	\N	0.00	\N	dynamic	2025-10-15	\N	\N	\N	0	\N	0.00	0	\N	2025-10-15 04:10:08.465237	\N	\N	2025-10-15 04:10:08.465237	2025-10-15 23:47:24.738977	Karawang	\N	\N	f	2025-10-15 23:47:01.754803+00	t
6	AGLS202510140002	Lufti Rahadiansyah	\N	08197670700	\N	luftirahadian@gmail.com	Grahayana Residence\nBlok G2/12	\N	\N	\N	\N	\N	\N	residential	\N	luftirahadian_97670700@customer	$2a$10$fxLRf.AzQz5AkagJVJW2oexi6YFQH117sIRwUT1le2K0jjmIV3AAa	6TA6HVHN	regular	postpaid	unpaid	active	broadband	1	\N	monthly	\N	\N	0.00	\N	dynamic	2025-10-14	\N	\N	\N	0	\N	0.00	0	\N	2025-10-13 20:42:08.040838	\N	\N	2025-10-13 20:42:08.040838	2025-10-14 22:54:34.365857	Karawang	\N	\N	f	\N	t
7	AGLS202510140003	Ega Nabila	\N	08197670700	\N	eganabila@gmail.com	Jalan kertanegara no.136 Grand Taruma	\N	\N	\N	\N	\N	\N	residential	\N	eganabila_97670700@customer	$2a$10$9VgqiOopp.54EOmfOBDRtemeUuPLJVRoaHO.kM3DWipm9217XDHFy	1XHWTRBU	regular	postpaid	unpaid	active	broadband	1	\N	monthly	\N	\N	0.00	\N	dynamic	2025-10-14	\N	\N	\N	0	\N	0.00	0	\N	2025-10-13 20:54:22.556522	\N	\N	2025-10-13 20:54:22.556522	2025-10-14 22:55:21.237579	Karawang	\N	\N	f	\N	t
18	AGLS202510150002	Udin	\N	0817102070	\N	udin@email.com	Jalan kertanegara no.136 Grand Taruma	\N	\N	\N	\N	\N	\N	residential	\N	udin_17102070@customer	$2a$10$7AhHQoEW3jcfJX1LIy2WJ.FXfv8IY.gUxXn/6EI651nzOouX3.rG6	BETQPO7N	regular	postpaid	unpaid	active	broadband	3	\N	monthly	\N	\N	0.00	\N	dynamic	2025-10-15	\N	\N	\N	0	\N	0.00	0	\N	2025-10-15 05:07:05.294015	\N	\N	2025-10-15 05:07:05.294015	2025-10-15 16:55:30.344571	Karawang	\N	\N	f	\N	t
8	AGLS202510140004	Rahadian	\N	08197670700	\N	rahadian@gmail.com	Grahayana Residence\nBlok G2/12 Sukaluyu	\N	\N	\N	\N	\N	\N	residential	\N	rahadian_97670700@customer	$2a$10$I./unQc/BWruWFdO932bPOTXpUpt1/HMAmacaSKDtRIT8Yetan26m	IFULX891	regular	postpaid	unpaid	active	broadband	1	\N	monthly	\N	\N	0.00	\N	dynamic	2025-10-14	\N	\N	\N	0	\N	0.00	0	\N	2025-10-13 21:03:14.714096	\N	\N	2025-10-13 21:03:14.714096	2025-10-15 23:32:53.198852	Karawang	\N	\N	f	2025-10-15 23:26:59.492472+00	t
5	AGLS202510140001	Test User	\N	081234567890	\N	test789@example.com	Test Address	\N	\N	\N	\N	\N	\N	residential	\N	test789_34567890@customer	$2a$10$o3ToS8gABuG/s8hAJ5J7COiSN2PoFysxfieaavbbaQWZRY6KV.8Km	QIQ3MA6R	regular	postpaid	paid	pending_installation	broadband	1	\N	monthly	\N	2025-10-14	0.00	\N	dynamic	\N	\N	\N	\N	0	\N	0.00	0	\N	2025-10-13 19:36:48.160158	\N	\N	2025-10-13 19:36:48.160158	2025-10-14 00:48:46.239748	Jakarta	\N	\N	f	\N	t
14	AGLS202510140008	Nabila	\N	08197670700	\N	nabila@gmail.com	Jalan kertanegara no.136 Grand Taruma	\N	\N	\N	\N	\N	\N	residential	\N	nabila_97670700@customer	$2a$10$F20n90sCzCjyDXg3LApa6ewzkCXVoTpKbN6aPABQo6fZFZrN99vIq	IFFJQRUN	regular	postpaid	unpaid	active	broadband	2	\N	monthly	\N	\N	0.00	\N	dynamic	2025-10-14	\N	\N	\N	0	\N	0.00	0	\N	2025-10-14 02:04:18.886709	\N	\N	2025-10-14 02:04:18.886709	2025-10-14 03:17:38.148814	Karawang	\N	\N	f	\N	t
13	AGLS202510140007	Test User Workflow 1760407191	3216000000024033	081200023457	\N	test.workflow.1760407191@email.com	Jl. Test Workflow No. 123	\N	\N	\N	\N	\N	\N	residential	\N	testworkflow1760407191_00023457@customer	$2a$10$e9Clr/xH9egYLZ1xTB1FBu3/huMm.lo0WP76E/d5uDmJEL/s2fXC2	Z6IBX0ZG	regular	postpaid	unpaid	active	broadband	1	\N	monthly	\N	\N	0.00	\N	dynamic	2025-10-14	\N	\N	\N	0	\N	0.00	0	\N	2025-10-14 02:02:57.934026	\N	\N	2025-10-14 02:02:57.934026	2025-10-14 03:22:29.424493	Karawang	\N	\N	f	\N	t
12	AGLS202510140006	Test User Workflow 1760407267	3216000000028532	081200017918	\N	test.workflow.1760407267@email.com	Jl. Test Workflow No. 123	\N	\N	\N	\N	\N	\N	residential	\N	testworkflow1760407267_00017918@customer	$2a$10$WPXuQJN.nph3fmjD5eJRn.sDTqx.qVv.umM3veK437j/y7cVd0tma	Z37SHK0D	regular	postpaid	unpaid	active	broadband	1	\N	monthly	\N	\N	0.00	\N	dynamic	2025-10-14	\N	\N	\N	0	\N	0.00	0	\N	2025-10-14 02:02:43.255433	\N	\N	2025-10-14 02:02:43.255433	2025-10-14 03:32:09.212801	Karawang	\N	\N	f	\N	t
11	AGLS202510140005	Test User Workflow 1760407323	3216000000008902	081200009528	\N	test.workflow.1760407323@email.com	Jl. Test Workflow No. 123	\N	\N	\N	\N	\N	\N	residential	\N	testworkflow1760407323_00009528@customer	$2a$10$zFquQQRoD9QZFcPvTdiWFexujB4htW.rUGtuUp1yTPv/tEv2qD6vC	CR60MHAL	regular	postpaid	unpaid	active	broadband	1	\N	monthly	\N	\N	0.00	\N	dynamic	2025-10-14	\N	\N	\N	0	\N	0.00	0	\N	2025-10-14 02:02:10.13896	\N	\N	2025-10-14 02:02:10.13896	2025-10-14 03:36:54.36008	Karawang	\N	\N	f	\N	t
15	AGLS202510140009	ega	\N	08197670700	\N	ega@gmail.com	Grahayana Residence\nBlok G2/12	\N	\N	\N	\N	\N	\N	residential	\N	ega_97670700@customer	$2a$10$6aLut31ClqI.Zk8gK18su.25XRaAKjCWjOPXGb8uDQ6asyY8P59Qi	ROC94BJC	regular	postpaid	unpaid	active	broadband	3	\N	monthly	\N	\N	0.00	\N	dynamic	2025-10-14	\N	\N	\N	0	\N	0.00	0	\N	2025-10-14 02:07:45.051161	\N	\N	2025-10-14 02:07:45.051161	2025-10-14 03:40:22.911872	Karawang	\N	\N	f	\N	t
\.


--
-- Data for Name: equipment_master; Type: TABLE DATA; Schema: public; Owner: aglis_user
--

COPY public.equipment_master (id, equipment_code, equipment_name, category, description, unit, unit_price, is_active, created_at, updated_at) FROM stdin;
1	ont_huawei_hg8245h	ONT Huawei HG8245H	devices	ONT Fiber dengan WiFi AC - untuk paket Silver/Gold	unit	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
2	ont_zte_f670l	ONT ZTE F670L	devices	ONT Fiber dual band WiFi - untuk paket Gold/Platinum	unit	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
3	ont_fiberhome_hg6245d	ONT Fiberhome HG6245D	devices	ONT Fiber WiFi 5 - untuk paket Platinum	unit	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
4	modem_tplink_c6	Modem TP-Link Archer C6	devices	Modem WiFi dual band - untuk paket Bronze/Silver	unit	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
5	modem_tplink_c50	Modem TP-Link Archer C50	devices	Modem WiFi standar - untuk paket Bronze	unit	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
6	access_point	WiFi Access Point	devices	Access Point untuk coverage tambahan	unit	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
7	mesh_node	WiFi Mesh Node	devices	Node tambahan untuk mesh network	unit	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
8	cable_fiber_sm	Kabel Fiber Optic Single Mode	cables	Kabel fiber optic untuk instalasi FTTH	meter	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
9	cable_utp_cat6	Kabel UTP Cat6	cables	Kabel UTP kategori 6 untuk network indoor	meter	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
10	cable_drop_ftth	Kabel Drop FTTH	cables	Kabel drop wire dari ODP ke rumah	meter	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
11	patch_cord_sc_sc	Patch Cord SC-SC	cables	Patch cord SC-SC untuk koneksi ONT	pcs	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
12	patch_cord_sc_upc	Patch Cord SC-UPC	cables	Patch cord SC-UPC single mode	pcs	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
13	pigtail_sc	Pigtail SC/UPC	cables	Pigtail untuk splicing di ODP	pcs	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
14	connector_rj45	Connector RJ45	accessories	Konektor RJ45 untuk kabel UTP	pcs	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
15	splitter_1x2	Splitter Optical 1:2	accessories	Splitter 1:2 untuk pembagian signal	pcs	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
16	splitter_1x4	Splitter Optical 1:4	accessories	Splitter 1:4 untuk ODP	pcs	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
17	splitter_1x8	Splitter Optical 1:8	accessories	Splitter 1:8 untuk ODP besar	pcs	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
18	closure_box	Closure Box	accessories	Box untuk sambungan fiber di luar	pcs	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
19	rosette_box	Rosette Box	accessories	Terminal box untuk ONT di dalam rumah	pcs	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
20	cable_clip	Cable Clip	accessories	Klip kabel untuk rapi instalasi	pcs	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
21	cable_tie	Cable Tie	accessories	Pengikat kabel	pcs	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
22	otdr	OTDR (Optical Time Domain Reflectometer)	tools	Alat ukur untuk testing fiber optic	unit	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
23	power_meter	Optical Power Meter	tools	Pengukur daya optical signal	unit	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
24	vfl	Visual Fault Locator	tools	Laser merah untuk deteksi putus fiber	unit	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
25	cleaver	Fiber Cleaver	tools	Pemotong fiber dengan presisi tinggi	unit	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
26	stripping_tool	Fiber Stripping Tool	tools	Tool untuk mengupas coating fiber	unit	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
27	crimping_tool	Crimping Tool RJ45	tools	Tang crimping untuk kabel UTP	unit	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
28	cable_tester	LAN Cable Tester	tools	Alat tes kabel UTP	unit	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
29	multimeter	Multimeter Digital	tools	Pengukur listrik untuk cek power	unit	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
30	fusion_splicer	Fusion Splicer	tools	Mesin sambung fiber optic (untuk teknisi senior)	unit	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
31	alcohol_cleaner	Alkohol Pembersih	accessories	Pembersih untuk konektor fiber	botol	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
32	tape_isolasi	Isolasi Listrik	accessories	Isolasi untuk sambungan	roll	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
33	label_cable	Label Kabel	accessories	Label identifikasi kabel	pcs	0.00	t	2025-10-14 01:01:06.54855	2025-10-14 01:01:06.54855
\.


--
-- Data for Name: equipment_service_mapping; Type: TABLE DATA; Schema: public; Owner: aglis_user
--

COPY public.equipment_service_mapping (id, equipment_id, service_type_code, service_category_code, is_required, quantity_default, created_at) FROM stdin;
\.


--
-- Data for Name: failed_login_attempts; Type: TABLE DATA; Schema: public; Owner: aglis_user
--

COPY public.failed_login_attempts (id, username, ip_address, user_agent, attempted_at, reason, user_id) FROM stdin;
1	admin	127.0.0.1	curl/7.81.0	2025-10-13 13:22:24.531726	invalid_password	17
2	admin	127.0.0.1	curl/7.81.0	2025-10-13 13:22:25.500062	invalid_password	17
3	admin	127.0.0.1	curl/7.81.0	2025-10-13 13:22:26.45889	invalid_password	17
4	admin	127.0.0.1	curl/7.81.0	2025-10-13 13:22:27.415992	invalid_password	17
5	admin	127.0.0.1	curl/7.81.0	2025-10-13 13:22:28.374285	invalid_password	17
6	admin	127.0.0.1	curl/7.81.0	2025-10-14 01:55:58.963991	invalid_password	17
7	admin	127.0.0.1	curl/7.81.0	2025-10-14 01:56:12.146678	invalid_password	17
8	admin	127.0.0.1	curl/7.81.0	2025-10-14 01:56:18.442701	invalid_password	17
9	admin	127.0.0.1	curl/7.81.0	2025-10-14 01:57:08.022131	invalid_password	17
10	admin	127.0.0.1	curl/7.81.0	2025-10-14 01:57:23.278634	invalid_password	17
11	admin	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-14 03:57:10.583752	invalid_password	17
12	admin	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-14 19:01:33.349065	invalid_password	17
13	admin	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-14 19:10:43.587678	invalid_password	17
14	admin	127.0.0.1	curl/7.81.0	2025-10-15 03:48:28.209118	invalid_password	17
15	admin	127.0.0.1	curl/7.81.0	2025-10-15 03:50:20.095514	invalid_password	17
16	admin	127.0.0.1	curl/7.81.0	2025-10-15 03:50:20.210436	invalid_password	17
17	admin	127.0.0.1	curl/7.81.0	2025-10-15 04:01:35.679223	invalid_password	17
18	admin	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-15 17:24:39.836815	invalid_password	17
19	admin	110.138.83.57	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-16 04:06:15.07854	invalid_password	17
\.


--
-- Data for Name: inventory_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory_items (id, item_code, name, description, category, unit, unit_price, minimum_stock, current_stock, location, supplier, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inventory_stock; Type: TABLE DATA; Schema: public; Owner: aglis_user
--

COPY public.inventory_stock (id, equipment_id, warehouse_location, current_stock, minimum_stock, maximum_stock, unit_cost, supplier_name, supplier_contact, last_restock_date, last_restock_quantity, notes, created_at, updated_at) FROM stdin;
34	1	Warehouse Karawang	45	10	100	450000.00	PT Huawei Indonesia	021-12345678	2025-01-15	50	Stock untuk paket Silver/Gold	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
35	2	Warehouse Karawang	35	8	80	480000.00	PT ZTE Indonesia	021-23456789	2025-01-15	40	Stock untuk paket Gold/Platinum	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
36	3	Warehouse Karawang	25	5	60	520000.00	PT Fiberhome Indonesia	021-34567890	2025-01-10	30	Stock untuk paket Platinum	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
37	4	Warehouse Karawang	50	15	120	350000.00	PT TP-Link Indonesia	021-45678901	2025-01-20	60	Stock untuk paket Bronze/Silver	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
38	5	Warehouse Karawang	40	10	100	280000.00	PT TP-Link Indonesia	021-45678901	2025-01-20	50	Stock untuk paket Bronze	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
39	6	Warehouse Karawang	20	5	50	650000.00	PT Ubiquiti Indonesia	021-56789012	2025-01-12	25	Untuk WiFi extension	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
40	7	Warehouse Karawang	15	3	40	850000.00	PT TP-Link Indonesia	021-45678901	2025-01-18	20	Untuk mesh network setup	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
41	8	Warehouse Karawang	5000	500	10000	3500.00	PT Belden Indonesia	021-67890123	2025-01-05	8000	Dalam meter, stock utama	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
42	9	Warehouse Karawang	3000	300	8000	4500.00	PT Belden Indonesia	021-67890123	2025-01-05	5000	Dalam meter	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
43	10	Warehouse Karawang	8000	1000	15000	2800.00	PT Supreme Cable	021-78901234	2025-01-08	10000	Drop cable dari ODP ke rumah (meter)	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
44	11	Warehouse Karawang	200	30	500	25000.00	PT Supreme Cable	021-78901234	2025-01-08	250	Patch cord untuk ONT	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
45	12	Warehouse Karawang	180	25	400	28000.00	PT Supreme Cable	021-78901234	2025-01-08	200	Patch cord SC-UPC	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
46	13	Warehouse Karawang	150	20	350	15000.00	PT Supreme Cable	021-78901234	2025-01-08	180	Pigtail untuk splicing	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
47	14	Warehouse Karawang	500	100	1000	1500.00	Toko Elektronik Karawang	0267-123456	2025-01-10	600	Konektor RJ45	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
48	15	Warehouse Karawang	80	15	200	75000.00	PT Optic Network	021-89012345	2025-01-12	100	Splitter 1:2	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
49	16	Warehouse Karawang	60	10	150	125000.00	PT Optic Network	021-89012345	2025-01-12	80	Splitter 1:4	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
50	17	Warehouse Karawang	40	8	100	185000.00	PT Optic Network	021-89012345	2025-01-12	50	Splitter 1:8	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
51	18	Warehouse Karawang	50	10	120	150000.00	PT Fiber Tech	021-90123456	2025-01-14	60	Closure box outdoor	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
52	19	Warehouse Karawang	100	20	250	35000.00	PT Fiber Tech	021-90123456	2025-01-14	120	Terminal box indoor	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
53	20	Warehouse Karawang	800	100	2000	500.00	Toko Elektronik Karawang	0267-123456	2025-01-10	1000	Klip kabel	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
54	21	Warehouse Karawang	1000	150	2500	200.00	Toko Elektronik Karawang	0267-123456	2025-01-10	1200	Pengikat kabel	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
55	22	Warehouse Karawang	2	1	5	45000000.00	PT Test Equipment	021-01234567	2024-12-01	2	OTDR untuk testing - High Value	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
56	23	Warehouse Karawang	8	2	15	3500000.00	PT Test Equipment	021-01234567	2024-12-15	8	Optical Power Meter	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
57	24	Warehouse Karawang	10	3	20	850000.00	PT Test Equipment	021-01234567	2025-01-05	10	Visual Fault Locator	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
58	25	Warehouse Karawang	5	2	10	2500000.00	PT Fiber Tools	021-11223344	2024-11-20	5	Fiber Cleaver	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
59	26	Warehouse Karawang	12	3	25	450000.00	PT Fiber Tools	021-11223344	2025-01-08	15	Fiber Stripping Tool	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
60	27	Warehouse Karawang	15	5	30	250000.00	Toko Elektronik Karawang	0267-123456	2025-01-10	20	Crimping Tool RJ45	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
61	28	Warehouse Karawang	10	3	20	350000.00	Toko Elektronik Karawang	0267-123456	2025-01-10	12	LAN Cable Tester	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
62	29	Warehouse Karawang	12	4	25	450000.00	Toko Elektronik Karawang	0267-123456	2025-01-10	15	Multimeter Digital	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
63	30	Warehouse Karawang	1	1	3	85000000.00	PT Fiber Tools	021-11223344	2024-10-15	1	Fusion Splicer - High Value	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
64	31	Warehouse Karawang	50	10	100	35000.00	Toko Kimia Karawang	0267-234567	2025-01-15	60	Alkohol pembersih fiber (botol)	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
65	32	Warehouse Karawang	80	15	200	15000.00	Toko Elektronik Karawang	0267-123456	2025-01-10	100	Isolasi listrik (roll)	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
66	33	Warehouse Karawang	300	50	800	500.00	Toko Elektronik Karawang	0267-123456	2025-01-10	400	Label identifikasi kabel (pcs)	2025-10-14 01:01:14.131981	2025-10-14 01:01:14.137292
\.


--
-- Data for Name: inventory_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory_transactions (id, item_id, transaction_type, quantity, reference_type, reference_id, technician_id, notes, transaction_date, created_by) FROM stdin;
\.


--
-- Data for Name: invoice_line_items; Type: TABLE DATA; Schema: public; Owner: aglis_user
--

COPY public.invoice_line_items (id, invoice_id, item_type, item_reference_id, description, quantity, unit_price, discount_amount, discount_percentage, line_total, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: aglis_user
--

COPY public.invoices (id, invoice_number, customer_id, invoice_date, due_date, billing_period_start, billing_period_end, subtotal, tax_amount, tax_percentage, discount_amount, discount_percentage, total_amount, paid_amount, outstanding_amount, status, invoice_type, payment_terms, payment_method_preferred, notes, internal_notes, terms_conditions, sent_at, viewed_at, paid_at, last_reminder_sent, reminder_count, created_by, created_at, updated_at, is_deleted, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: notification_analytics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_analytics (id, notification_id, user_id, viewed_at, read_at, clicked_at, dismissed_at, archived_at, deleted_at, time_to_view, time_to_read, time_to_click, device_type, browser, os, channel, ip_address, country, city, created_at) FROM stdin;
\.


--
-- Data for Name: notification_analytics_summary; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_analytics_summary (id, date, type, priority, total_sent, total_delivered, total_failed, total_viewed, total_read, total_clicked, total_dismissed, total_archived, total_deleted, delivery_rate, view_rate, read_rate, click_rate, avg_time_to_view, avg_time_to_read, avg_time_to_click, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_push_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_push_log (id, notification_id, device_id, status, sent_at, delivered_at, clicked_at, error_message, fcm_message_id, created_at) FROM stdin;
\.


--
-- Data for Name: notification_routing_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_routing_rules (id, notification_type, name, description, send_to_individual, send_to_groups, target_groups, conditions, message_template, is_active, priority, created_by, created_at, updated_at) FROM stdin;
1	ticket_assigned	Ticket Assignment - Personal	Send personal WhatsApp to assigned technician	t	f	\N	{"priority": ["normal", "high", "urgent"]}	TICKET_ASSIGNED	t	100	1	2025-10-15 01:13:56.070224	2025-10-15 01:13:56.070224
2	ticket_assigned	Ticket Assignment - Group Notification	Notify work zone technician group	f	t	{1,2,3}	{"priority": ["high", "urgent"]}	NEW_TICKET_AVAILABLE	t	50	1	2025-10-15 01:13:56.070224	2025-10-15 01:13:56.070224
3	sla_warning	SLA Warning - Technician & Supervisor	Alert technician and supervisor group when approaching SLA	t	t	{4}	{"remaining_hours": "<= 2"}	SLA_WARNING	t	200	1	2025-10-15 01:13:56.070224	2025-10-15 01:13:56.070224
4	new_ticket	New Ticket - Technician Group	Broadcast new open ticket to technician group by work zone	f	t	{1,2,3}	{"status": "open"}	NEW_TICKET_AVAILABLE	t	80	1	2025-10-15 01:13:56.070224	2025-10-15 01:13:56.070224
5	daily_summary	Daily Summary - Management	Send daily operations summary to management group	f	t	{6}	{}	DAILY_SUMMARY	t	10	1	2025-10-15 01:13:56.070224	2025-10-15 01:13:56.070224
6	system_alert	System Alert - NOC Team	Critical system alerts to NOC team	f	t	{5}	{"severity": ["high", "critical"]}	SYSTEM_ALERT	t	300	1	2025-10-15 01:13:56.070224	2025-10-15 01:13:56.070224
7	registration_approved	Registration Approved - Customer	Send approval notification to customer	t	f	\N	{}	REGISTRATION_APPROVED	t	100	1	2025-10-15 01:13:56.070224	2025-10-15 01:13:56.070224
8	payment_received	Payment Confirmation - Customer	Send payment receipt to customer	t	f	\N	{}	PAYMENT_RECEIVED	t	100	1	2025-10-15 01:13:56.070224	2025-10-15 01:13:56.070224
\.


--
-- Data for Name: notification_schedules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_schedules (id, template_id, schedule_name, description, target_type, target_criteria, template_data, schedule_type, scheduled_at, cron_expression, timezone, recurrence_rule, status, last_run_at, next_run_at, total_runs, total_sent, total_failed, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_settings (id, user_id, email_notifications, push_notifications, sound_notifications, notification_types, quiet_hours_start, quiet_hours_end, created_at, updated_at, whatsapp_notifications) FROM stdin;
1	1	t	t	t	{"new_ticket": true, "system_alert": true, "ticket_updated": true, "ticket_assigned": true, "ticket_completed": true, "technician_status": true}	\N	\N	2025-10-13 00:09:00.203162+00	2025-10-13 00:09:00.203162+00	t
2	2	t	t	t	{"new_ticket": true, "system_alert": true, "ticket_updated": true, "ticket_assigned": true, "ticket_completed": true, "technician_status": true}	\N	\N	2025-10-13 00:09:00.203162+00	2025-10-13 00:09:00.203162+00	t
3	3	t	t	t	{"new_ticket": true, "system_alert": true, "ticket_updated": true, "ticket_assigned": true, "ticket_completed": true, "technician_status": true}	\N	\N	2025-10-13 00:09:00.203162+00	2025-10-13 00:09:00.203162+00	t
4	4	t	t	t	{"new_ticket": true, "system_alert": true, "ticket_updated": true, "ticket_assigned": true, "ticket_completed": true, "technician_status": true}	\N	\N	2025-10-13 00:09:00.203162+00	2025-10-13 00:09:00.203162+00	t
5	5	t	t	t	{"new_ticket": true, "system_alert": true, "ticket_updated": true, "ticket_assigned": true, "ticket_completed": true, "technician_status": true}	\N	\N	2025-10-13 00:09:00.203162+00	2025-10-13 00:09:00.203162+00	t
6	6	t	t	t	{"new_ticket": true, "system_alert": true, "ticket_updated": true, "ticket_assigned": true, "ticket_completed": true, "technician_status": true}	\N	\N	2025-10-13 00:09:00.203162+00	2025-10-13 00:09:00.203162+00	t
7	7	t	t	t	{"new_ticket": true, "system_alert": true, "ticket_updated": true, "ticket_assigned": true, "ticket_completed": true, "technician_status": true}	\N	\N	2025-10-13 00:09:00.203162+00	2025-10-13 00:09:00.203162+00	t
8	8	t	t	t	{"new_ticket": true, "system_alert": true, "ticket_updated": true, "ticket_assigned": true, "ticket_completed": true, "technician_status": true}	\N	\N	2025-10-13 00:09:00.203162+00	2025-10-13 00:09:00.203162+00	t
17	17	t	t	t	{"new_ticket": true, "system_alert": true, "ticket_updated": true, "ticket_assigned": true, "ticket_completed": true, "technician_status": true}	\N	\N	2025-10-13 00:17:16.213431+00	2025-10-13 00:17:16.213431+00	t
18	22	t	t	t	{"new_ticket": true, "system_alert": true, "ticket_updated": true, "ticket_assigned": true, "ticket_completed": true, "technician_status": true}	\N	\N	2025-10-14 19:00:32.875117+00	2025-10-14 19:00:32.875117+00	t
\.


--
-- Data for Name: notification_settings_advanced; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_settings_advanced (id, user_id, web_notifications, mobile_push, email_notifications, sms_notifications, quiet_hours_enabled, quiet_hours_start, quiet_hours_end, quiet_hours_timezone, dnd_enabled, dnd_until, batch_notifications, batch_interval, show_low_priority, show_normal_priority, show_high_priority, show_urgent_priority, type_settings, group_by_type, group_by_priority, auto_archive_after_days, auto_delete_after_days, daily_digest, weekly_digest, digest_time, created_at, updated_at) FROM stdin;
1	17	t	t	t	f	f	\N	\N	Asia/Jakarta	f	\N	f	60	t	t	t	t	{}	t	f	30	90	f	f	08:00:00	2025-10-14 07:09:01.334709	2025-10-14 07:09:01.334709
\.


--
-- Data for Name: notification_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_templates (id, template_code, template_name, description, category, type, priority, title_template, message_template, variables, example_data, channels, icon, color, action_url_template, is_active, created_by, updated_by, created_at, updated_at) FROM stdin;
1	TICKET_ASSIGNED	Tiket Ditugaskan	Notifikasi ketika tiket ditugaskan ke teknisi	ticket	ticket_assigned	high	Tiket Baru #{{ticket_number}}	Anda mendapat tiket baru {{ticket_type}} untuk {{customer_name}} di {{location}}	["ticket_number", "ticket_type", "customer_name", "location"]	{"location": "Jakarta", "ticket_type": "instalasi", "customer_name": "John Doe", "ticket_number": "TK-001"}	["web", "mobile", "email"]	clipboard	blue	\N	t	\N	\N	2025-10-14 05:41:15.449562	2025-10-14 05:41:15.449562
2	TICKET_UPDATED	Status Tiket Diperbarui	Notifikasi ketika status tiket berubah	ticket	ticket_updated	normal	Tiket #{{ticket_number}} Diperbarui	Status tiket berubah dari {{old_status}} ke {{new_status}}	["ticket_number", "old_status", "new_status"]	{"new_status": "in_progress", "old_status": "pending", "ticket_number": "TK-001"}	["web", "mobile", "email"]	refresh	yellow	\N	t	\N	\N	2025-10-14 05:41:15.449562	2025-10-14 05:41:15.449562
3	TICKET_COMPLETED	Tiket Selesai	Notifikasi ketika tiket diselesaikan	ticket	ticket_completed	normal	Tiket #{{ticket_number}} Selesai	Tiket {{ticket_type}} telah berhasil diselesaikan. Rating: {{rating}} ⭐	["ticket_number", "ticket_type", "rating"]	{"rating": "5", "ticket_type": "instalasi", "ticket_number": "TK-001"}	["web", "mobile", "email"]	check-circle	green	\N	t	\N	\N	2025-10-14 05:41:15.449562	2025-10-14 05:41:15.449562
4	NEW_REGISTRATION	Pendaftaran Customer Baru	Notifikasi registrasi customer baru	customer	new_registration	normal	Pendaftaran Customer Baru	{{customer_name}} telah mendaftar sebagai customer baru. Nomor registrasi: {{registration_number}}	["customer_name", "registration_number"]	{"customer_name": "John Doe", "registration_number": "REG-20251014-001"}	["web", "mobile", "email"]	user-plus	blue	\N	t	\N	\N	2025-10-14 05:41:15.449562	2025-10-14 05:41:15.449562
5	CUSTOMER_ACTIVATED	Customer Diaktifkan	Notifikasi ketika customer diaktifkan	customer	customer_status	normal	Customer Diaktifkan	Customer {{customer_name}} dengan paket {{package_name}} telah diaktifkan	["customer_name", "package_name"]	{"package_name": "Premium 50Mbps", "customer_name": "John Doe"}	["web", "mobile", "email"]	check-circle	green	\N	t	\N	\N	2025-10-14 05:41:15.449562	2025-10-14 05:41:15.449562
6	SYSTEM_ALERT	Peringatan Sistem	Notifikasi peringatan sistem	system	system_alert	urgent	Peringatan Sistem: {{alert_type}}	{{alert_message}}	["alert_type", "alert_message"]	{"alert_type": "Performance", "alert_message": "Server load tinggi, segera periksa"}	["web", "mobile", "email"]	alert-triangle	red	\N	t	\N	\N	2025-10-14 05:41:15.449562	2025-10-14 05:41:15.449562
7	SYSTEM_MAINTENANCE	Maintenance Terjadwal	Notifikasi maintenance sistem	system	system_maintenance	high	Maintenance Sistem	Sistem akan menjalani maintenance pada {{maintenance_date}} pukul {{maintenance_time}}. Durasi estimasi: {{duration}}	["maintenance_date", "maintenance_time", "duration"]	{"duration": "2 jam", "maintenance_date": "15 Oktober 2025", "maintenance_time": "02:00 WIB"}	["web", "mobile", "email"]	tool	orange	\N	t	\N	\N	2025-10-14 05:41:15.449562	2025-10-14 05:41:15.449562
8	TECHNICIAN_STATUS	Status Teknisi	Notifikasi perubahan status teknisi	technician	technician_status	normal	Status Teknisi Diperbarui	Teknisi {{technician_name}} sekarang {{status}}	["technician_name", "status"]	{"status": "tersedia", "technician_name": "Ahmad"}	["web", "mobile", "email"]	user-check	green	\N	t	\N	\N	2025-10-14 05:41:15.449562	2025-10-14 05:41:15.449562
9	PAYMENT_RECEIVED	Pembayaran Diterima	Notifikasi pembayaran customer	payment	payment_received	normal	Pembayaran Diterima	Pembayaran sebesar {{amount}} dari {{customer_name}} untuk periode {{period}} telah diterima	["amount", "customer_name", "period"]	{"amount": "Rp 500.000", "period": "November 2025", "customer_name": "John Doe"}	["web", "mobile", "email"]	dollar-sign	green	\N	t	\N	\N	2025-10-14 05:41:15.449562	2025-10-14 05:41:15.449562
10	PAYMENT_DUE	Tagihan Jatuh Tempo	Notifikasi tagihan mendekati jatuh tempo	payment	payment_due	high	Tagihan Jatuh Tempo	Customer {{customer_name}} memiliki tagihan sebesar {{amount}} yang jatuh tempo pada {{due_date}}	["customer_name", "amount", "due_date"]	{"amount": "Rp 500.000", "due_date": "20 Oktober 2025", "customer_name": "John Doe"}	["web", "mobile", "email"]	alert-circle	red	\N	t	\N	\N	2025-10-14 05:41:15.449562	2025-10-14 05:41:15.449562
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, user_id, ticket_id, type, title, message, is_read, read_at, created_at, data, priority, is_archived, expires_at, template_id, template_data) FROM stdin;
1	5	\N	new_registration	Pendaftaran Customer Baru	Test User telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0001	f	\N	2025-10-13 00:40:59.681934+00	{"registration_id": 1, "registration_number": "REG-20251013-0001"}	normal	f	\N	\N	\N
2	6	\N	new_registration	Pendaftaran Customer Baru	Test User telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0001	f	\N	2025-10-13 00:40:59.684648+00	{"registration_id": 1, "registration_number": "REG-20251013-0001"}	normal	f	\N	\N	\N
3	7	\N	new_registration	Pendaftaran Customer Baru	Test User telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0001	f	\N	2025-10-13 00:40:59.686049+00	{"registration_id": 1, "registration_number": "REG-20251013-0001"}	normal	f	\N	\N	\N
4	8	\N	new_registration	Pendaftaran Customer Baru	Test User telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0001	f	\N	2025-10-13 00:40:59.687274+00	{"registration_id": 1, "registration_number": "REG-20251013-0001"}	normal	f	\N	\N	\N
5	17	\N	new_registration	Pendaftaran Customer Baru	Test User telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0001	t	2025-10-13 00:45:48.333378+00	2025-10-13 00:40:59.688464+00	{"registration_id": 1, "registration_number": "REG-20251013-0001"}	normal	f	\N	\N	\N
6	5	\N	new_registration	Pendaftaran Customer Baru	Lufti Rahadiansyah telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0002	f	\N	2025-10-13 20:01:16.985902+00	{"registration_id": 2, "registration_number": "REG-20251013-0002"}	normal	f	\N	\N	\N
7	6	\N	new_registration	Pendaftaran Customer Baru	Lufti Rahadiansyah telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0002	f	\N	2025-10-13 20:01:16.988336+00	{"registration_id": 2, "registration_number": "REG-20251013-0002"}	normal	f	\N	\N	\N
8	7	\N	new_registration	Pendaftaran Customer Baru	Lufti Rahadiansyah telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0002	f	\N	2025-10-13 20:01:16.989333+00	{"registration_id": 2, "registration_number": "REG-20251013-0002"}	normal	f	\N	\N	\N
9	8	\N	new_registration	Pendaftaran Customer Baru	Lufti Rahadiansyah telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0002	f	\N	2025-10-13 20:01:16.991156+00	{"registration_id": 2, "registration_number": "REG-20251013-0002"}	normal	f	\N	\N	\N
10	17	\N	new_registration	Pendaftaran Customer Baru	Lufti Rahadiansyah telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0002	f	\N	2025-10-13 20:01:16.993583+00	{"registration_id": 2, "registration_number": "REG-20251013-0002"}	normal	f	\N	\N	\N
11	5	\N	new_registration	Pendaftaran Customer Baru	Ega Nabila telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0003	f	\N	2025-10-13 20:32:19.538992+00	{"registration_id": 3, "registration_number": "REG-20251013-0003"}	normal	f	\N	\N	\N
12	6	\N	new_registration	Pendaftaran Customer Baru	Ega Nabila telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0003	f	\N	2025-10-13 20:32:19.540886+00	{"registration_id": 3, "registration_number": "REG-20251013-0003"}	normal	f	\N	\N	\N
13	7	\N	new_registration	Pendaftaran Customer Baru	Ega Nabila telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0003	f	\N	2025-10-13 20:32:19.541855+00	{"registration_id": 3, "registration_number": "REG-20251013-0003"}	normal	f	\N	\N	\N
14	8	\N	new_registration	Pendaftaran Customer Baru	Ega Nabila telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0003	f	\N	2025-10-13 20:32:19.542797+00	{"registration_id": 3, "registration_number": "REG-20251013-0003"}	normal	f	\N	\N	\N
16	5	\N	new_registration	Pendaftaran Customer Baru	Rahadian telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0004	f	\N	2025-10-13 21:00:49.087004+00	{"registration_id": 4, "registration_number": "REG-20251013-0004"}	normal	f	\N	\N	\N
17	6	\N	new_registration	Pendaftaran Customer Baru	Rahadian telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0004	f	\N	2025-10-13 21:00:49.089168+00	{"registration_id": 4, "registration_number": "REG-20251013-0004"}	normal	f	\N	\N	\N
18	7	\N	new_registration	Pendaftaran Customer Baru	Rahadian telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0004	f	\N	2025-10-13 21:00:49.090216+00	{"registration_id": 4, "registration_number": "REG-20251013-0004"}	normal	f	\N	\N	\N
19	8	\N	new_registration	Pendaftaran Customer Baru	Rahadian telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0004	f	\N	2025-10-13 21:00:49.091322+00	{"registration_id": 4, "registration_number": "REG-20251013-0004"}	normal	f	\N	\N	\N
21	5	\N	new_registration	Pendaftaran Customer Baru	Nabila telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0005	f	\N	2025-10-13 23:39:30.350578+00	{"registration_id": 5, "registration_number": "REG-20251013-0005"}	normal	f	\N	\N	\N
22	6	\N	new_registration	Pendaftaran Customer Baru	Nabila telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0005	f	\N	2025-10-13 23:39:30.352645+00	{"registration_id": 5, "registration_number": "REG-20251013-0005"}	normal	f	\N	\N	\N
23	7	\N	new_registration	Pendaftaran Customer Baru	Nabila telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0005	f	\N	2025-10-13 23:39:30.353622+00	{"registration_id": 5, "registration_number": "REG-20251013-0005"}	normal	f	\N	\N	\N
24	8	\N	new_registration	Pendaftaran Customer Baru	Nabila telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0005	f	\N	2025-10-13 23:39:30.354585+00	{"registration_id": 5, "registration_number": "REG-20251013-0005"}	normal	f	\N	\N	\N
27	5	\N	new_registration	Pendaftaran Customer Baru	ega telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014001	f	\N	2025-10-14 01:49:15.528288+00	{"registration_id": 6, "registration_number": "REG20251014001"}	normal	f	\N	\N	\N
28	6	\N	new_registration	Pendaftaran Customer Baru	ega telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014001	f	\N	2025-10-14 01:49:15.529996+00	{"registration_id": 6, "registration_number": "REG20251014001"}	normal	f	\N	\N	\N
29	7	\N	new_registration	Pendaftaran Customer Baru	ega telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014001	f	\N	2025-10-14 01:49:15.531181+00	{"registration_id": 6, "registration_number": "REG20251014001"}	normal	f	\N	\N	\N
25	17	\N	new_registration	Pendaftaran Customer Baru	Nabila telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0005	t	2025-10-14 14:23:56.070904+00	2025-10-13 23:39:30.355524+00	{"registration_id": 5, "registration_number": "REG-20251013-0005"}	normal	f	\N	\N	\N
20	17	\N	new_registration	Pendaftaran Customer Baru	Rahadian telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0004	t	2025-10-14 14:23:56.740054+00	2025-10-13 21:00:49.092306+00	{"registration_id": 4, "registration_number": "REG-20251013-0004"}	normal	f	\N	\N	\N
30	8	\N	new_registration	Pendaftaran Customer Baru	ega telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014001	f	\N	2025-10-14 01:49:15.532226+00	{"registration_id": 6, "registration_number": "REG20251014001"}	normal	f	\N	\N	\N
31	5	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407142 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014002	f	\N	2025-10-14 01:59:03.919897+00	{"registration_id": 7, "registration_number": "REG20251014002"}	normal	f	\N	\N	\N
32	6	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407142 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014002	f	\N	2025-10-14 01:59:03.921633+00	{"registration_id": 7, "registration_number": "REG20251014002"}	normal	f	\N	\N	\N
33	7	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407142 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014002	f	\N	2025-10-14 01:59:03.922671+00	{"registration_id": 7, "registration_number": "REG20251014002"}	normal	f	\N	\N	\N
34	8	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407142 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014002	f	\N	2025-10-14 01:59:03.92367+00	{"registration_id": 7, "registration_number": "REG20251014002"}	normal	f	\N	\N	\N
36	5	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407191 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014003	f	\N	2025-10-14 01:59:52.342473+00	{"registration_id": 8, "registration_number": "REG20251014003"}	normal	f	\N	\N	\N
37	6	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407191 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014003	f	\N	2025-10-14 01:59:52.344016+00	{"registration_id": 8, "registration_number": "REG20251014003"}	normal	f	\N	\N	\N
38	7	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407191 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014003	f	\N	2025-10-14 01:59:52.34501+00	{"registration_id": 8, "registration_number": "REG20251014003"}	normal	f	\N	\N	\N
39	8	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407191 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014003	f	\N	2025-10-14 01:59:52.345949+00	{"registration_id": 8, "registration_number": "REG20251014003"}	normal	f	\N	\N	\N
41	5	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407267 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014004	f	\N	2025-10-14 02:01:08.953198+00	{"registration_id": 9, "registration_number": "REG20251014004"}	normal	f	\N	\N	\N
42	6	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407267 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014004	f	\N	2025-10-14 02:01:08.955516+00	{"registration_id": 9, "registration_number": "REG20251014004"}	normal	f	\N	\N	\N
43	7	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407267 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014004	f	\N	2025-10-14 02:01:08.956777+00	{"registration_id": 9, "registration_number": "REG20251014004"}	normal	f	\N	\N	\N
44	8	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407267 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014004	f	\N	2025-10-14 02:01:08.957836+00	{"registration_id": 9, "registration_number": "REG20251014004"}	normal	f	\N	\N	\N
46	5	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407323 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014005	f	\N	2025-10-14 02:02:04.979041+00	{"registration_id": 10, "registration_number": "REG20251014005"}	normal	f	\N	\N	\N
47	6	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407323 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014005	f	\N	2025-10-14 02:02:04.981285+00	{"registration_id": 10, "registration_number": "REG20251014005"}	normal	f	\N	\N	\N
48	7	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407323 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014005	f	\N	2025-10-14 02:02:04.982505+00	{"registration_id": 10, "registration_number": "REG20251014005"}	normal	f	\N	\N	\N
49	8	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407323 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014005	f	\N	2025-10-14 02:02:04.98369+00	{"registration_id": 10, "registration_number": "REG20251014005"}	normal	f	\N	\N	\N
51	8	\N	new_ticket	New Ticket #17	New broadband ticket created by AGLIS Administrator	f	\N	2025-10-14 03:44:24.097136+00	{"ticket_id": 17, "customer_id": 6}	normal	f	\N	\N	\N
53	8	\N	new_ticket	New Ticket #18	New broadband ticket created by AGLIS Administrator	f	\N	2025-10-14 04:07:33.781544+00	{"ticket_id": 18, "customer_id": 15}	normal	f	\N	\N	\N
55	8	\N	new_ticket	New Ticket #19	New broadband ticket created by AGLIS Administrator	f	\N	2025-10-14 04:10:01.692831+00	{"ticket_id": 19, "customer_id": 14}	normal	f	\N	\N	\N
57	17	\N	ticket_assigned	Tiket Baru Ditugaskan	Anda mendapat tiket baru #TK-001 untuk instalasi di Karawang	t	2025-10-14 14:22:58.905555+00	2025-10-14 05:07:52.432974+00	{"ticket_id": 1, "customer_name": "John Doe"}	high	f	\N	\N	\N
56	17	\N	new_ticket	New Ticket #19	New broadband ticket created by AGLIS Administrator	t	2025-10-14 14:23:10.073249+00	2025-10-14 04:10:01.698706+00	{"ticket_id": 19, "customer_id": 14}	normal	f	\N	\N	\N
54	17	\N	new_ticket	New Ticket #18	New broadband ticket created by AGLIS Administrator	t	2025-10-14 14:23:10.741646+00	2025-10-14 04:07:33.784028+00	{"ticket_id": 18, "customer_id": 15}	normal	f	\N	\N	\N
52	17	\N	new_ticket	New Ticket #17	New broadband ticket created by AGLIS Administrator	t	2025-10-14 14:23:12.588754+00	2025-10-14 03:44:24.101824+00	{"ticket_id": 17, "customer_id": 6}	normal	f	\N	\N	\N
50	17	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407323 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014005	t	2025-10-14 14:23:13.355836+00	2025-10-14 02:02:04.984852+00	{"registration_id": 10, "registration_number": "REG20251014005"}	normal	f	\N	\N	\N
58	17	\N	ticket_updated	Status Tiket Diperbarui	Tiket #TK-002 telah dipindahkan ke status "In Progress"	t	2025-10-14 14:23:25.994893+00	2025-10-14 05:07:52.435433+00	{"ticket_id": 2, "new_status": "in_progress", "old_status": "pending"}	normal	f	\N	\N	\N
40	17	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407191 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014003	t	2025-10-14 14:23:47.87221+00	2025-10-14 01:59:52.34688+00	{"registration_id": 8, "registration_number": "REG20251014003"}	normal	f	\N	\N	\N
35	17	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407142 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014002	t	2025-10-14 14:23:48.638035+00	2025-10-14 01:59:03.924816+00	{"registration_id": 7, "registration_number": "REG20251014002"}	normal	f	\N	\N	\N
60	17	\N	technician_status	Status Teknisi Diperbarui	Teknisi Ahmad telah menyelesaikan tugas dan tersedia untuk penugasan baru	t	2025-10-14 14:22:17.373813+00	2025-10-14 05:07:52.437831+00	{"status": "available", "technician_id": 3}	normal	f	\N	\N	\N
61	17	\N	new_ticket	Tiket Baru Dibuat	Customer baru telah membuat tiket untuk layanan internet	t	2025-10-14 14:22:25.772729+00	2025-10-14 05:07:52.439277+00	{"ticket_id": 4, "customer_id": 5, "service_type": "internet"}	normal	f	\N	\N	\N
68	17	\N	ticket_completed	Tiket Selesai	Tiket #TK-003 telah berhasil diselesaikan. Customer telah memberikan rating 5 bintang.	t	2025-10-14 16:44:05.759409+00	2025-10-14 16:43:45.415029+00	{"rating": 5, "ticket_id": 3, "completion_time": "2 hours"}	normal	f	\N	\N	\N
67	17	\N	new_ticket	Tiket Baru Dibuat	Customer baru telah membuat tiket untuk layanan internet	t	2025-10-14 16:44:06.448814+00	2025-10-14 16:43:45.414139+00	{"ticket_id": 4, "customer_id": 5, "service_type": "internet"}	normal	f	\N	\N	\N
66	17	\N	technician_status	Status Teknisi Diperbarui	Teknisi Ahmad telah menyelesaikan tugas dan tersedia untuk penugasan baru	t	2025-10-14 16:44:07.306667+00	2025-10-14 16:43:45.413251+00	{"status": "available", "technician_id": 3}	normal	f	\N	\N	\N
65	17	\N	system_alert	Peringatan Sistem	Server mengalami peningkatan beban. Monitor performa sistem.	t	2025-10-14 16:44:10.74022+00	2025-10-14 16:43:45.412357+00	{"severity": "high", "alert_type": "performance"}	urgent	f	\N	\N	\N
62	17	\N	ticket_completed	Tiket Selesai	Tiket #TK-003 telah berhasil diselesaikan. Customer telah memberikan rating 5 bintang.	t	2025-10-14 14:22:54.538494+00	2025-10-14 05:07:52.440303+00	{"rating": 5, "ticket_id": 3, "completion_time": "2 hours"}	normal	f	\N	\N	\N
59	17	\N	system_alert	Peringatan Sistem	Server mengalami peningkatan beban. Monitor performa sistem.	t	2025-10-14 14:22:58.138065+00	2025-10-14 05:07:52.436461+00	{"severity": "high", "alert_type": "performance"}	urgent	f	\N	\N	\N
45	17	\N	new_registration	Pendaftaran Customer Baru	Test User Workflow 1760407267 telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014004	t	2025-10-14 14:23:47.320099+00	2025-10-14 02:01:08.959459+00	{"registration_id": 9, "registration_number": "REG20251014004"}	normal	f	\N	\N	\N
26	17	\N	new_registration	Pendaftaran Customer Baru	ega telah mendaftar sebagai customer baru. Nomor registrasi: REG20251014001	t	2025-10-14 14:23:49.386566+00	2025-10-14 01:49:15.526303+00	{"registration_id": 6, "registration_number": "REG20251014001"}	normal	f	\N	\N	\N
15	17	\N	new_registration	Pendaftaran Customer Baru	Ega Nabila telah mendaftar sebagai customer baru. Nomor registrasi: REG-20251013-0003	t	2025-10-14 14:23:57.354644+00	2025-10-13 20:32:19.544368+00	{"registration_id": 3, "registration_number": "REG-20251013-0003"}	normal	f	\N	\N	\N
63	17	\N	ticket_assigned	Tiket Baru Ditugaskan	Anda mendapat tiket baru #TK-001 untuk instalasi di Karawang	t	2025-10-14 16:44:13.799488+00	2025-10-14 16:43:45.40963+00	{"ticket_id": 1, "customer_name": "John Doe"}	high	f	\N	\N	\N
64	17	\N	ticket_updated	Status Tiket Diperbarui	Tiket #TK-002 telah dipindahkan ke status "In Progress"	t	2025-10-14 16:44:26.643016+00	2025-10-14 16:43:45.411417+00	{"ticket_id": 2, "new_status": "in_progress", "old_status": "pending"}	normal	f	\N	\N	\N
69	23	\N	ticket_assigned	Ticket #18 Assigned	You have been assigned to ticket #18 - undefined	f	\N	2025-10-14 18:40:21.534265+00	{"ticket_id": "18", "assigned_by": 22}	normal	f	\N	\N	\N
70	23	\N	ticket_assigned	Ticket #17 Assigned	You have been assigned to ticket #17 - undefined	f	\N	2025-10-14 19:01:00.082015+00	{"ticket_id": "17", "assigned_by": 22}	normal	f	\N	\N	\N
71	8	\N	new_ticket	New Ticket #21	New broadband ticket created by AGLIS Administrator	f	\N	2025-10-14 19:02:32.417821+00	{"ticket_id": 21, "customer_id": 7}	normal	f	\N	\N	\N
73	22	\N	ticket_assigned	Ticket #21 Assigned	You have been assigned to ticket #21 - undefined	f	\N	2025-10-14 19:14:18.522404+00	{"ticket_id": "21", "assigned_by": 22}	normal	f	\N	\N	\N
74	8	\N	new_ticket	New Ticket #22	New broadband ticket created by AGLIS Administrator	f	\N	2025-10-14 22:35:04.375201+00	{"ticket_id": 22, "customer_id": 7}	normal	f	\N	\N	\N
75	17	\N	new_ticket	New Ticket #22	New broadband ticket created by AGLIS Administrator	t	2025-10-15 00:13:48.289703+00	2025-10-14 22:35:04.379494+00	{"ticket_id": 22, "customer_id": 7}	normal	f	\N	\N	\N
72	17	\N	new_ticket	New Ticket #21	New broadband ticket created by AGLIS Administrator	t	2025-10-15 00:13:48.777673+00	2025-10-14 19:02:32.421781+00	{"ticket_id": 21, "customer_id": 7}	normal	f	\N	\N	\N
76	5	\N	new_registration	Pendaftaran Customer Baru	Ahmad Test Customer telah mendaftar sebagai customer baru. Nomor registrasi: REG20251015001	f	\N	2025-10-15 04:06:22.530491+00	{"registration_id": 11, "registration_number": "REG20251015001"}	normal	f	\N	\N	\N
77	6	\N	new_registration	Pendaftaran Customer Baru	Ahmad Test Customer telah mendaftar sebagai customer baru. Nomor registrasi: REG20251015001	f	\N	2025-10-15 04:06:22.53465+00	{"registration_id": 11, "registration_number": "REG20251015001"}	normal	f	\N	\N	\N
78	7	\N	new_registration	Pendaftaran Customer Baru	Ahmad Test Customer telah mendaftar sebagai customer baru. Nomor registrasi: REG20251015001	f	\N	2025-10-15 04:06:22.535645+00	{"registration_id": 11, "registration_number": "REG20251015001"}	normal	f	\N	\N	\N
79	8	\N	new_registration	Pendaftaran Customer Baru	Ahmad Test Customer telah mendaftar sebagai customer baru. Nomor registrasi: REG20251015001	f	\N	2025-10-15 04:06:22.53665+00	{"registration_id": 11, "registration_number": "REG20251015001"}	normal	f	\N	\N	\N
80	17	\N	new_registration	Pendaftaran Customer Baru	Ahmad Test Customer telah mendaftar sebagai customer baru. Nomor registrasi: REG20251015001	f	\N	2025-10-15 04:06:22.537657+00	{"registration_id": 11, "registration_number": "REG20251015001"}	normal	f	\N	\N	\N
81	5	\N	new_registration	Pendaftaran Customer Baru	Udin telah mendaftar sebagai customer baru. Nomor registrasi: REG20251015002	f	\N	2025-10-15 04:49:55.11616+00	{"registration_id": 12, "registration_number": "REG20251015002"}	normal	f	\N	\N	\N
82	6	\N	new_registration	Pendaftaran Customer Baru	Udin telah mendaftar sebagai customer baru. Nomor registrasi: REG20251015002	f	\N	2025-10-15 04:49:55.118611+00	{"registration_id": 12, "registration_number": "REG20251015002"}	normal	f	\N	\N	\N
83	7	\N	new_registration	Pendaftaran Customer Baru	Udin telah mendaftar sebagai customer baru. Nomor registrasi: REG20251015002	f	\N	2025-10-15 04:49:55.119756+00	{"registration_id": 12, "registration_number": "REG20251015002"}	normal	f	\N	\N	\N
84	8	\N	new_registration	Pendaftaran Customer Baru	Udin telah mendaftar sebagai customer baru. Nomor registrasi: REG20251015002	f	\N	2025-10-15 04:49:55.120928+00	{"registration_id": 12, "registration_number": "REG20251015002"}	normal	f	\N	\N	\N
85	17	\N	new_registration	Pendaftaran Customer Baru	Udin telah mendaftar sebagai customer baru. Nomor registrasi: REG20251015002	f	\N	2025-10-15 04:49:55.122602+00	{"registration_id": 12, "registration_number": "REG20251015002"}	normal	f	\N	\N	\N
86	8	\N	new_ticket	New Ticket #27	New broadband ticket created by AGLIS Administrator	f	\N	2025-10-15 06:24:25.726039+00	{"ticket_id": 27, "customer_id": 18}	normal	f	\N	\N	\N
87	17	\N	new_ticket	New Ticket #27	New broadband ticket created by AGLIS Administrator	f	\N	2025-10-15 06:24:25.730581+00	{"ticket_id": 27, "customer_id": 18}	normal	f	\N	\N	\N
88	8	\N	new_ticket	New Ticket #28	New broadband ticket created by AGLIS Administrator	f	\N	2025-10-16 00:32:32.561611+00	{"ticket_id": 28, "customer_id": 18}	normal	f	\N	\N	\N
89	17	\N	new_ticket	New Ticket #28	New broadband ticket created by AGLIS Administrator	f	\N	2025-10-16 00:32:32.56603+00	{"ticket_id": 28, "customer_id": 18}	normal	f	\N	\N	\N
90	8	\N	new_ticket	New Ticket #29	New broadband ticket created by AGLIS Administrator	f	\N	2025-10-16 00:57:47.668868+00	{"ticket_id": 29, "customer_id": 18}	normal	f	\N	\N	\N
91	17	\N	new_ticket	New Ticket #29	New broadband ticket created by AGLIS Administrator	f	\N	2025-10-16 00:57:47.673553+00	{"ticket_id": 29, "customer_id": 18}	normal	f	\N	\N	\N
92	8	\N	new_ticket	New Ticket #30	New broadband ticket created by AGLIS Administrator	f	\N	2025-10-16 01:33:40.01183+00	{"ticket_id": 30, "customer_id": 18}	normal	f	\N	\N	\N
93	17	\N	new_ticket	New Ticket #30	New broadband ticket created by AGLIS Administrator	f	\N	2025-10-16 01:33:40.016539+00	{"ticket_id": 30, "customer_id": 18}	normal	f	\N	\N	\N
94	5	\N	new_registration	Pendaftaran Customer Baru	Riky Van Boomel telah mendaftar sebagai customer baru. Nomor registrasi: REG20251016001	f	\N	2025-10-16 04:27:28.387077+00	{"registration_id": 13, "registration_number": "REG20251016001"}	normal	f	\N	\N	\N
95	6	\N	new_registration	Pendaftaran Customer Baru	Riky Van Boomel telah mendaftar sebagai customer baru. Nomor registrasi: REG20251016001	f	\N	2025-10-16 04:27:28.388915+00	{"registration_id": 13, "registration_number": "REG20251016001"}	normal	f	\N	\N	\N
96	7	\N	new_registration	Pendaftaran Customer Baru	Riky Van Boomel telah mendaftar sebagai customer baru. Nomor registrasi: REG20251016001	f	\N	2025-10-16 04:27:28.389942+00	{"registration_id": 13, "registration_number": "REG20251016001"}	normal	f	\N	\N	\N
97	8	\N	new_registration	Pendaftaran Customer Baru	Riky Van Boomel telah mendaftar sebagai customer baru. Nomor registrasi: REG20251016001	f	\N	2025-10-16 04:27:28.390916+00	{"registration_id": 13, "registration_number": "REG20251016001"}	normal	f	\N	\N	\N
98	17	\N	new_registration	Pendaftaran Customer Baru	Riky Van Boomel telah mendaftar sebagai customer baru. Nomor registrasi: REG20251016001	f	\N	2025-10-16 04:27:28.391879+00	{"registration_id": 13, "registration_number": "REG20251016001"}	normal	f	\N	\N	\N
\.


--
-- Data for Name: odp; Type: TABLE DATA; Schema: public; Owner: aglis_user
--

COPY public.odp (id, name, location, area, latitude, longitude, total_ports, used_ports, status, notes, created_at, updated_at) FROM stdin;
1	ODP-KRW-001-A12	Jl. Tuparev Raya, RT 01/RW 03, Karawang Barat	Karawang Barat	-6.31861100	107.30138900	16	8	active	ODP perumahan Tuparev	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
2	ODP-KRW-002-B08	Jl. Kertabumi, Perumahan Griya Asri, Karawang Barat	Karawang Barat	-6.32250000	107.29583300	24	12	active	ODP cluster Griya Asri	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
3	ODP-KRW-003-C15	Jl. Interchange Tol, Perumahan Taman Karawang, Karawang Barat	Karawang Barat	-6.31527800	107.28888900	16	6	active	ODP Taman Karawang	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
4	ODP-KRW-004-D20	Jl. Arteri Taman Karawang, Karawang Barat	Karawang Barat	-6.31944400	107.29277800	32	18	active	ODP area residensial Arteri	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
5	ODP-KRW-005-E10	Jl. Pancasila, RT 05/RW 08, Karawang Timur	Karawang Timur	-6.30611100	107.32222200	16	10	active	ODP area Pancasila	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
6	ODP-KRW-006-F12	Jl. Galuh Mas, Perumahan Galuh Mas, Karawang Timur	Karawang Timur	-6.31083300	107.32861100	24	15	active	ODP cluster Galuh Mas	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
7	ODP-KRW-007-G18	Jl. Tarumanegara, RT 03/RW 05, Karawang Timur	Karawang Timur	-6.30388900	107.33000000	16	8	active	ODP Tarumanegara residensial	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
8	ODP-KRW-008-H05	Jl. Syech Quro, Karawang Timur	Karawang Timur	-6.30972200	107.32555600	16	5	active	ODP area Syech Quro	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
9	ODP-KRW-009-I14	Jl. Panatayuda I, Telukjambe Timur	Telukjambe Timur	-6.29111100	107.29777800	24	14	active	ODP Panatayuda cluster	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
10	ODP-KRW-010-J22	Jl. Kota Baru Parahyangan, Telukjambe Timur	Telukjambe Timur	-6.28722200	107.30250000	32	20	active	ODP Kota Baru Parahyangan	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
11	ODP-KRW-011-K08	Jl. Surotokunto, RT 02/RW 04, Telukjambe Timur	Telukjambe Timur	-6.29388900	107.30583300	16	6	active	ODP Surotokunto	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
12	ODP-KRW-012-L15	Jl. Wirasaba, Telukjambe Barat	Telukjambe Barat	-6.29055600	107.28500000	16	8	active	ODP Wirasaba residensial	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
13	ODP-KRW-013-M20	Jl. Bumi Telukjambe, Perumahan Bumi Telukjambe Indah	Telukjambe Barat	-6.28666700	107.28083300	24	12	active	ODP Bumi Telukjambe Indah	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
14	ODP-KRW-014-N12	Jl. Raya Klari, RT 01/RW 02, Klari	Klari	-6.26888900	107.36250000	16	10	active	ODP area Klari	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
15	ODP-KRW-015-O18	Jl. Cikampek Karawang, Perumahan Klari Asri, Klari	Klari	-6.26527800	107.36888900	24	16	active	ODP Klari Asri cluster	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
16	ODP-KRW-016-P10	Jl. Ir. H. Juanda, RT 03/RW 06, Cikampek	Cikampek	-6.41666700	107.45000000	16	8	active	ODP Cikampek pusat	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
17	ODP-KRW-017-Q15	Jl. Raya Cikampek, Perumahan Cikampek Indah	Cikampek	-6.42000000	107.45555600	24	12	active	ODP Cikampek Indah	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
18	ODP-KRW-018-R08	Jl. Raya Rengasdengklok, RT 02/RW 03	Rengasdengklok	-6.15888900	107.29722200	16	6	active	ODP Rengasdengklok	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
19	ODP-KRW-019-S12	Jl. Proklamasi, Rengasdengklok	Rengasdengklok	-6.16111100	107.30166700	16	8	active	ODP area Proklamasi	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
20	ODP-KRW-020-T10	Jl. Ciampel Raya, RT 04/RW 07, Ciampel	Ciampel	-6.34861100	107.42000000	16	5	active	ODP Ciampel residensial	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
21	ODP-KRW-021-U14	Jl. Tirtajaya, Perumahan Tirtajaya Indah	Tirtajaya	-6.29944400	107.34305600	24	14	active	ODP Tirtajaya cluster	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
22	ODP-KRW-022-V12	Jl. Veteran, RT 01/RW 02, Purwakarta	Purwakarta	-6.54777800	107.44361100	16	10	active	ODP Purwakarta pusat	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
23	ODP-KRW-023-W08	Jl. Raya Sadang, Perumahan Sadang Indah, Purwakarta	Purwakarta	-6.55222200	107.45000000	16	6	active	ODP Sadang Indah	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
24	ODP-KRW-024-X15	Jl. Raya Jatisari, RT 02/RW 05, Jatisari	Jatisari	-6.33194400	107.33750000	16	8	active	ODP Jatisari	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
25	ODP-KRW-025-Y20	Jl. Industri Karawang, Perumahan Graha Industri	Karawang Barat	-6.32500000	107.29888900	24	22	active	ODP Graha Industri, hampir penuh	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
26	ODP-KRW-026-Z08	Jl. Pasar Baru, Karawang Timur	Karawang Timur	-6.30833300	107.32000000	8	8	full	ODP penuh, perlu ekspansi	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
27	ODP-KRW-027-AA12	Jl. Tarumanegara Raya, Karawang Timur	Karawang Timur	-6.30555600	107.32666700	16	0	maintenance	Sedang maintenance dan upgrade port	2025-10-14 01:16:37.793583	2025-10-14 01:16:37.793583
\.


--
-- Data for Name: packages_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.packages_master (id, package_name, package_type, bandwidth_up, bandwidth_down, monthly_price, setup_fee, sla_level, description, is_active, created_at, updated_at) FROM stdin;
1	Home Bronze 30M	broadband	30	30	149900.00	100000.00	bronze	Paket internet rumahan Bronze dengan kecepatan 30 Mbps - cocok untuk browsing dan streaming	t	2025-10-13 00:08:59.855067	2025-10-14 03:01:45.033147
2	Home Silver 50M	broadband	50	50	199900.00	100000.00	silver	Paket internet rumahan Silver dengan kecepatan 50 Mbps - cocok untuk keluarga dan WFH	t	2025-10-13 00:08:59.855067	2025-10-14 03:01:45.033147
3	Home Gold 75M	broadband	75	75	249900.00	150000.00	gold	Paket internet rumahan Gold dengan kecepatan 75 Mbps - cocok untuk gaming dan streaming HD	t	2025-10-13 00:08:59.855067	2025-10-14 03:01:45.033147
4	Home Platinum 100M	broadband	100	100	289900.00	150000.00	gold	Paket internet rumahan Platinum dengan kecepatan 100 Mbps - cocok untuk kebutuhan maksimal	t	2025-10-13 00:08:59.855067	2025-10-14 03:01:45.033147
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: aglis_user
--

COPY public.payments (id, payment_number, invoice_id, customer_id, payment_date, amount, payment_method, payment_channel, transaction_id, reference_number, payment_gateway, gateway_response, status, verified_by, verified_at, notes, internal_notes, refund_amount, refund_reason, refunded_at, refunded_by, created_by, created_at, updated_at, is_deleted, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: aglis_user
--

COPY public.permissions (id, name, resource, action, description, created_at) FROM stdin;
1	dashboard.view	dashboard	view	View dashboard	2025-10-13 11:39:08.570519
2	analytics.view	analytics	view	View analytics	2025-10-13 11:39:08.570519
3	tickets.view	tickets	view	View tickets	2025-10-13 11:39:08.570519
4	tickets.create	tickets	create	Create new tickets	2025-10-13 11:39:08.570519
5	tickets.edit	tickets	edit	Edit tickets	2025-10-13 11:39:08.570519
6	tickets.delete	tickets	delete	Delete tickets	2025-10-13 11:39:08.570519
7	tickets.assign	tickets	assign	Assign tickets to technicians	2025-10-13 11:39:08.570519
8	tickets.close	tickets	close	Close tickets	2025-10-13 11:39:08.570519
9	customers.view	customers	view	View customers	2025-10-13 11:39:08.570519
10	customers.create	customers	create	Create new customers	2025-10-13 11:39:08.570519
11	customers.edit	customers	edit	Edit customer information	2025-10-13 11:39:08.570519
12	customers.delete	customers	delete	Delete customers	2025-10-13 11:39:08.570519
13	customers.export	customers	export	Export customer data	2025-10-13 11:39:08.570519
14	registrations.view	registrations	view	View registrations	2025-10-13 11:39:08.570519
15	registrations.verify	registrations	verify	Verify registrations	2025-10-13 11:39:08.570519
16	registrations.approve	registrations	approve	Approve registrations	2025-10-13 11:39:08.570519
17	registrations.reject	registrations	reject	Reject registrations	2025-10-13 11:39:08.570519
18	registrations.delete	registrations	delete	Delete registrations	2025-10-13 11:39:08.570519
19	registrations.export	registrations	export	Export registration data	2025-10-13 11:39:08.570519
20	technicians.view	technicians	view	View technicians	2025-10-13 11:39:08.570519
21	technicians.edit	technicians	edit	Edit technician information	2025-10-13 11:39:08.570519
22	technicians.schedule	technicians	schedule	Manage technician schedules	2025-10-13 11:39:08.570519
23	inventory.view	inventory	view	View inventory	2025-10-13 11:39:08.570519
24	inventory.create	inventory	create	Add new inventory items	2025-10-13 11:39:08.570519
25	inventory.edit	inventory	edit	Edit inventory items	2025-10-13 11:39:08.570519
26	inventory.delete	inventory	delete	Delete inventory items	2025-10-13 11:39:08.570519
27	inventory.transactions	inventory	transactions	Manage inventory transactions	2025-10-13 11:39:08.570519
28	users.view	users	view	View users	2025-10-13 11:39:08.570519
29	users.create	users	create	Create new users	2025-10-13 11:39:08.570519
30	users.edit	users	edit	Edit user information	2025-10-13 11:39:08.570519
31	users.delete	users	delete	Delete users	2025-10-13 11:39:08.570519
32	users.reset_password	users	reset_password	Reset user passwords	2025-10-13 11:39:08.570519
33	permissions.view	permissions	view	View permissions	2025-10-13 11:39:08.570519
34	permissions.manage	permissions	manage	Manage role permissions	2025-10-13 11:39:08.570519
35	reports.view	reports	view	View reports	2025-10-13 11:39:08.570519
36	reports.export	reports	export	Export reports	2025-10-13 11:39:08.570519
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: aglis_user
--

COPY public.role_permissions (id, role, permission_id, granted, created_at, updated_at) FROM stdin;
1	admin	1	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
2	admin	2	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
3	admin	3	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
4	admin	4	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
5	admin	5	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
6	admin	6	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
7	admin	7	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
8	admin	8	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
9	admin	9	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
10	admin	10	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
11	admin	11	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
12	admin	12	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
13	admin	13	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
14	admin	14	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
15	admin	15	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
16	admin	16	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
17	admin	17	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
18	admin	18	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
19	admin	19	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
20	admin	20	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
21	admin	21	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
22	admin	22	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
23	admin	23	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
24	admin	24	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
25	admin	25	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
26	admin	26	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
27	admin	27	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
28	admin	28	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
29	admin	29	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
30	admin	30	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
31	admin	31	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
32	admin	32	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
33	admin	33	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
34	admin	34	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
35	admin	35	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
36	admin	36	t	2025-10-13 11:39:08.573114	2025-10-13 11:39:08.573114
37	supervisor	1	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
38	supervisor	2	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
39	supervisor	3	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
40	supervisor	4	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
41	supervisor	5	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
42	supervisor	6	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
43	supervisor	7	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
44	supervisor	8	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
45	supervisor	9	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
46	supervisor	10	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
47	supervisor	11	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
48	supervisor	12	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
49	supervisor	13	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
50	supervisor	14	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
51	supervisor	15	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
52	supervisor	16	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
53	supervisor	17	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
54	supervisor	18	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
55	supervisor	19	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
56	supervisor	20	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
57	supervisor	21	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
58	supervisor	22	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
59	supervisor	23	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
60	supervisor	24	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
61	supervisor	25	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
62	supervisor	26	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
63	supervisor	27	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
64	supervisor	28	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
65	supervisor	30	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
66	supervisor	35	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
67	supervisor	36	t	2025-10-13 11:39:08.576103	2025-10-13 11:39:08.576103
68	technician	1	t	2025-10-13 11:39:08.577569	2025-10-13 11:39:08.577569
69	technician	3	t	2025-10-13 11:39:08.577569	2025-10-13 11:39:08.577569
70	technician	5	t	2025-10-13 11:39:08.577569	2025-10-13 11:39:08.577569
71	technician	8	t	2025-10-13 11:39:08.577569	2025-10-13 11:39:08.577569
72	technician	9	t	2025-10-13 11:39:08.577569	2025-10-13 11:39:08.577569
73	technician	20	t	2025-10-13 11:39:08.577569	2025-10-13 11:39:08.577569
74	technician	23	t	2025-10-13 11:39:08.577569	2025-10-13 11:39:08.577569
75	customer_service	1	t	2025-10-13 11:39:08.578479	2025-10-13 11:39:08.578479
76	customer_service	3	t	2025-10-13 11:39:08.578479	2025-10-13 11:39:08.578479
77	customer_service	4	t	2025-10-13 11:39:08.578479	2025-10-13 11:39:08.578479
78	customer_service	5	t	2025-10-13 11:39:08.578479	2025-10-13 11:39:08.578479
79	customer_service	9	t	2025-10-13 11:39:08.578479	2025-10-13 11:39:08.578479
80	customer_service	10	t	2025-10-13 11:39:08.578479	2025-10-13 11:39:08.578479
81	customer_service	11	t	2025-10-13 11:39:08.578479	2025-10-13 11:39:08.578479
82	customer_service	14	t	2025-10-13 11:39:08.578479	2025-10-13 11:39:08.578479
83	customer_service	15	t	2025-10-13 11:39:08.578479	2025-10-13 11:39:08.578479
84	customer_service	16	t	2025-10-13 11:39:08.578479	2025-10-13 11:39:08.578479
85	customer_service	17	t	2025-10-13 11:39:08.578479	2025-10-13 11:39:08.578479
86	customer_service	20	t	2025-10-13 11:39:08.578479	2025-10-13 11:39:08.578479
87	manager	1	t	2025-10-15 00:02:28.938869	2025-10-15 00:02:28.938869
88	manager	2	t	2025-10-15 00:02:28.938869	2025-10-15 00:02:28.938869
89	manager	3	t	2025-10-15 00:02:28.938869	2025-10-15 00:02:28.938869
90	manager	4	t	2025-10-15 00:02:28.938869	2025-10-15 00:02:28.938869
91	manager	5	t	2025-10-15 00:02:28.938869	2025-10-15 00:02:28.938869
92	manager	7	t	2025-10-15 00:02:28.938869	2025-10-15 00:02:28.938869
93	manager	8	t	2025-10-15 00:02:28.938869	2025-10-15 00:02:28.938869
94	manager	9	t	2025-10-15 00:02:28.938869	2025-10-15 00:02:28.938869
95	manager	10	t	2025-10-15 00:02:28.938869	2025-10-15 00:02:28.938869
96	manager	11	t	2025-10-15 00:02:28.938869	2025-10-15 00:02:28.938869
97	manager	13	t	2025-10-15 00:02:28.938869	2025-10-15 00:02:28.938869
98	manager	14	t	2025-10-15 00:02:28.938869	2025-10-15 00:02:28.938869
99	manager	15	t	2025-10-15 00:02:28.938869	2025-10-15 00:02:28.938869
100	manager	16	t	2025-10-15 00:02:28.938869	2025-10-15 00:02:28.938869
101	manager	17	t	2025-10-15 00:02:28.938869	2025-10-15 00:02:28.938869
102	manager	19	t	2025-10-15 00:02:28.938869	2025-10-15 00:02:28.938869
103	manager	20	t	2025-10-15 00:02:28.938869	2025-10-15 00:02:28.938869
104	manager	23	t	2025-10-15 00:02:28.938869	2025-10-15 00:02:28.938869
105	noc	1	t	2025-10-15 00:02:28.943013	2025-10-15 00:02:28.943013
106	noc	2	t	2025-10-15 00:02:28.943013	2025-10-15 00:02:28.943013
107	noc	3	t	2025-10-15 00:02:28.943013	2025-10-15 00:02:28.943013
108	noc	4	t	2025-10-15 00:02:28.943013	2025-10-15 00:02:28.943013
109	noc	5	t	2025-10-15 00:02:28.943013	2025-10-15 00:02:28.943013
110	noc	7	t	2025-10-15 00:02:28.943013	2025-10-15 00:02:28.943013
111	noc	9	t	2025-10-15 00:02:28.943013	2025-10-15 00:02:28.943013
112	noc	11	t	2025-10-15 00:02:28.943013	2025-10-15 00:02:28.943013
113	noc	14	t	2025-10-15 00:02:28.943013	2025-10-15 00:02:28.943013
114	noc	20	t	2025-10-15 00:02:28.943013	2025-10-15 00:02:28.943013
115	noc	21	t	2025-10-15 00:02:28.943013	2025-10-15 00:02:28.943013
116	noc	23	t	2025-10-15 00:02:28.943013	2025-10-15 00:02:28.943013
117	noc	24	t	2025-10-15 00:02:28.943013	2025-10-15 00:02:28.943013
118	noc	25	t	2025-10-15 00:02:28.943013	2025-10-15 00:02:28.943013
\.


--
-- Data for Name: service_categories; Type: TABLE DATA; Schema: public; Owner: aglis_user
--

COPY public.service_categories (id, service_type_code, category_code, category_name, description, estimated_duration, sla_multiplier, requires_checklist, is_active, display_order, created_at, updated_at) FROM stdin;
1	installation	fiber_installation	Fiber Installation	Install fiber optic cable and equipment	180	1.00	f	t	1	2025-10-14 01:15:55.407723	2025-10-14 01:15:55.407723
2	installation	copper_installation	Copper Installation	Install copper cable and equipment	150	1.00	f	t	2	2025-10-14 01:15:55.407723	2025-10-14 01:15:55.407723
3	installation	wireless_installation	Wireless Installation	Install wireless equipment and antenna	120	1.00	f	t	3	2025-10-14 01:15:55.407723	2025-10-14 01:15:55.407723
4	installation	hybrid_installation	Hybrid Installation	Install hybrid fiber-wireless setup	200	1.00	f	t	4	2025-10-14 01:15:55.407723	2025-10-14 01:15:55.407723
7	repair	cable_damage	Cable Damage	Repair damaged or cut cables	120	1.00	f	t	1	2025-10-14 01:15:55.409731	2025-10-14 01:15:55.409731
8	repair	equipment_failure	Equipment Failure	Fix or replace faulty equipment	90	1.00	f	t	2	2025-10-14 01:15:55.409731	2025-10-14 01:15:55.409731
9	repair	signal_issue	Signal Issue	Troubleshoot and fix signal problems	60	1.00	f	t	3	2025-10-14 01:15:55.409731	2025-10-14 01:15:55.409731
10	repair	connection_problem	Connection Problem	Fix internet connection issues	45	1.00	f	t	4	2025-10-14 01:15:55.409731	2025-10-14 01:15:55.409731
11	repair	port_issue	Port Issue	Fix port or splitter problems	60	1.00	f	t	5	2025-10-14 01:15:55.409731	2025-10-14 01:15:55.409731
26	wifi_setup	new_wifi_config	New WiFi Configuration	Configure new WiFi settings	15	1.00	f	t	1	2025-10-14 01:15:55.412965	2025-10-14 01:15:55.412965
27	wifi_setup	wifi_extension	WiFi Range Extension	Extend WiFi coverage area	30	1.00	f	t	2	2025-10-14 01:15:55.412965	2025-10-14 01:15:55.412965
28	wifi_setup	wifi_security	WiFi Security Setup	Setup WiFi security and password	20	1.00	f	t	3	2025-10-14 01:15:55.412965	2025-10-14 01:15:55.412965
29	wifi_setup	mesh_network	Mesh Network Setup	Setup mesh WiFi network	45	1.00	f	t	4	2025-10-14 01:15:55.412965	2025-10-14 01:15:55.412965
5	installation	new_registration	Instalasi Pelanggan Baru	Instalasi lengkap untuk pelanggan registrasi baru	180	1.00	f	t	5	2025-10-14 01:15:55.407723	2025-10-14 01:16:09.067648
37	dismantle	full_dismantle	Full Dismantle	Pencabutan lengkap semua equipment dan kabel	180	1.00	f	t	1	2025-10-14 01:15:55.416552	2025-10-14 01:15:55.416552
38	dismantle	partial_dismantle	Partial Dismantle	Pencabutan sebagian equipment	90	1.00	f	t	2	2025-10-14 01:15:55.416552	2025-10-14 01:15:55.416552
39	dismantle	equipment_return	Equipment Return	Pengembalian equipment ke warehouse	60	1.00	f	t	3	2025-10-14 01:15:55.416552	2025-10-14 01:15:55.416552
35	downgrade	speed_reduction	Pengurangan Kecepatan	Mengurangi kecepatan internet	15	1.00	f	t	2	2025-10-14 01:15:55.414595	2025-10-14 01:15:55.414595
36	downgrade	feature_removal	Penghapusan Fitur	Menghapus fitur tambahan (static IP, dll)	10	1.00	f	t	3	2025-10-14 01:15:55.414595	2025-10-14 01:15:55.414595
12	maintenance	preventive_maintenance	Preventive Maintenance	Regular preventive maintenance check	90	1.00	f	t	1	2025-10-14 01:15:55.410494	2025-10-14 01:15:55.410494
13	maintenance	equipment_inspection	Equipment Inspection	Inspect equipment condition	60	1.00	f	t	2	2025-10-14 01:15:55.410494	2025-10-14 01:15:55.410494
14	maintenance	network_optimization	Network Optimization	Optimize network performance	120	1.00	f	t	3	2025-10-14 01:15:55.410494	2025-10-14 01:15:55.410494
15	maintenance	cleaning_service	Cleaning Service	Clean equipment and cable management	45	1.00	f	t	4	2025-10-14 01:15:55.410494	2025-10-14 01:15:55.410494
20	upgrade	speed_upgrade	Speed Upgrade	Upgrade internet speed	15	1.00	f	t	1	2025-10-14 01:15:55.411301	2025-10-14 01:15:55.411301
21	upgrade	equipment_upgrade	Equipment Upgrade	Upgrade to newer equipment	30	1.00	f	t	2	2025-10-14 01:15:55.411301	2025-10-14 01:15:55.411301
22	upgrade	plan_upgrade	Service Plan Upgrade	Change to higher service plan	10	1.00	f	t	3	2025-10-14 01:15:55.411301	2025-10-14 01:15:55.411301
23	upgrade	technology_upgrade	Technology Upgrade	Upgrade to new technology (e.g., fiber)	120	1.00	f	t	4	2025-10-14 01:15:55.411301	2025-10-14 01:15:55.411301
6	installation	relocation_internal	Relokasi Internal Rumah	Pindah posisi modem dalam satu rumah yang sama	60	1.00	f	t	6	2025-10-14 01:15:55.407723	2025-10-14 01:16:09.067648
30	wifi_setup	change_password	Ganti Password WiFi	Mengganti password WiFi dan nama SSID	15	1.00	f	t	5	2025-10-14 01:15:55.412965	2025-10-14 01:16:09.067648
31	wifi_setup	dual_band_setup	Setup WiFi Dual Band	Konfigurasi WiFi 2.4GHz dan 5GHz optimal	30	1.00	f	t	6	2025-10-14 01:15:55.412965	2025-10-14 01:16:09.067648
32	wifi_setup	guest_network	Setup Guest Network	Membuat jaringan WiFi terpisah untuk tamu	20	1.00	f	t	7	2025-10-14 01:15:55.412965	2025-10-14 01:16:09.067648
33	wifi_setup	parental_control	Setup Parental Control	Konfigurasi kontrol orang tua untuk anak	30	1.00	f	t	8	2025-10-14 01:15:55.412965	2025-10-14 01:16:09.067648
40	repair	slow_speed	Internet Lambat	Keluhan kecepatan internet lebih lambat dari paket yang dilanggan	60	1.00	f	t	6	2025-10-14 01:16:09.062739	2025-10-14 01:16:09.067648
41	repair	no_internet	Tidak Ada Internet	Internet mati total / tidak bisa akses sama sekali	90	1.00	f	t	7	2025-10-14 01:16:09.062739	2025-10-14 01:16:09.067648
42	repair	intermittent_connection	Koneksi Putus-Putus	Internet sering putus-nyambung secara berkala	75	1.00	f	t	8	2025-10-14 01:16:09.062739	2025-10-14 01:16:09.067648
43	repair	high_ping	Ping Tinggi / Lag	Gaming atau video call lag karena latency tinggi	45	1.00	f	t	9	2025-10-14 01:16:09.062739	2025-10-14 01:16:09.067648
44	repair	packet_loss	Packet Loss	Troubleshoot packet loss pada koneksi	60	1.00	f	t	10	2025-10-14 01:16:09.062739	2025-10-14 01:16:09.067648
45	repair	wifi_weak_signal	Sinyal WiFi Lemah	Sinyal WiFi tidak kuat / tidak sampai ke beberapa ruangan	45	1.00	f	t	11	2025-10-14 01:16:09.062739	2025-10-14 01:16:09.067648
46	repair	cant_connect_wifi	Tidak Bisa Konek WiFi	Device tidak bisa connect ke WiFi	30	1.00	f	t	12	2025-10-14 01:16:09.062739	2025-10-14 01:16:09.067648
47	repair	modem_restart	Modem Sering Restart	Modem/ONT sering restart sendiri	60	1.00	f	t	13	2025-10-14 01:16:09.062739	2025-10-14 01:16:09.067648
48	repair	red_light	Lampu Merah/LOS	Lampu indikator merah atau LOS pada modem/ONT	90	1.00	f	t	14	2025-10-14 01:16:09.062739	2025-10-14 01:16:09.067648
63	dismantle	voluntary_termination	Pemutusan Sukarela	Customer mengajukan pemutusan layanan sendiri	90	1.00	f	t	4	2025-10-14 01:16:09.06695	2025-10-14 01:16:09.067648
64	dismantle	non_payment	Pemutusan Karena Nunggak	Pemutusan layanan karena tidak bayar	60	1.00	f	t	5	2025-10-14 01:16:09.06695	2025-10-14 01:16:09.067648
65	dismantle	relocation_external	Pindah Alamat (Luar Area)	Customer pindah ke luar coverage area	90	1.00	f	t	6	2025-10-14 01:16:09.06695	2025-10-14 01:16:09.067648
34	downgrade	package_downgrade	Downgrade Paket Internet	Downgrade dari paket tinggi ke paket rendah	15	1.00	f	t	1	2025-10-14 01:15:55.414595	2025-10-14 01:16:09.067648
62	downgrade	remove_static_ip	Hapus Static IP	Kembali ke dynamic IP dari static IP	15	1.00	f	t	4	2025-10-14 01:16:09.066289	2025-10-14 01:16:09.067648
16	maintenance	fiber_cleaning	Cleaning Konektor Fiber	Pembersihan konektor fiber untuk signal optimal	30	1.00	f	t	5	2025-10-14 01:15:55.410494	2025-10-14 01:16:09.067648
17	maintenance	speed_test	Speed Test & Verification	Test kecepatan dan verifikasi sesuai paket	20	1.00	f	t	6	2025-10-14 01:15:55.410494	2025-10-14 01:16:09.067648
18	maintenance	cable_management	Cable Management	Rapihkan kabel indoor untuk estetika dan keamanan	30	1.00	f	t	7	2025-10-14 01:15:55.410494	2025-10-14 01:16:09.067648
19	maintenance	firmware_update	Update Firmware Modem	Update firmware modem/ONT ke versi terbaru	30	1.00	f	t	8	2025-10-14 01:15:55.410494	2025-10-14 01:16:09.067648
68	maintenance	network_config	Network Configuration	Network configuration and optimization	180	1.00	f	t	9	2025-10-16 01:10:26.462461	2025-10-16 01:10:26.462461
67	maintenance	redundancy_setup	Redundancy Setup	Backup connection and failover configuration	240	1.00	f	t	10	2025-10-16 01:10:26.462461	2025-10-16 01:10:26.462461
69	maintenance	security_audit	Security Audit	Security assessment and network audit	240	1.00	f	t	11	2025-10-16 01:10:26.462461	2025-10-16 01:10:26.462461
24	upgrade	package_upgrade	Upgrade Paket Internet	Upgrade dari Bronze ke Silver/Gold/Platinum	15	1.00	f	t	5	2025-10-14 01:15:55.411301	2025-10-14 01:16:09.067648
25	upgrade	add_static_ip	Tambah Static IP	Upgrade ke static IP untuk kebutuhan khusus	20	1.00	f	t	6	2025-10-14 01:15:55.411301	2025-10-14 01:16:09.067648
66	upgrade	bandwidth_upgrade	Bandwidth Upgrade	Bandwidth increase and speed enhancement	180	1.00	f	t	7	2025-10-16 01:10:26.462461	2025-10-16 01:10:26.462461
\.


--
-- Data for Name: service_pricelist; Type: TABLE DATA; Schema: public; Owner: aglis_user
--

COPY public.service_pricelist (id, service_type_code, service_category_code, price_name, description, base_price, is_free, is_active, applies_to_package, notes, created_at, updated_at) FROM stdin;
1	installation	fiber_installation	Biaya Instalasi Bronze	Biaya instalasi + setup untuk paket Bronze 30M	100000.00	f	t	bronze	Sudah termasuk kabel s.d 50m	2025-10-14 01:16:01.220025	2025-10-14 01:16:01.231477
2	installation	fiber_installation	Biaya Instalasi Silver	Biaya instalasi + setup untuk paket Silver 50M	100000.00	f	t	silver	Sudah termasuk kabel s.d 50m	2025-10-14 01:16:01.220025	2025-10-14 01:16:01.231477
3	installation	fiber_installation	Biaya Instalasi Gold	Biaya instalasi + setup untuk paket Gold 75M	150000.00	f	t	gold	Sudah termasuk kabel s.d 75m	2025-10-14 01:16:01.220025	2025-10-14 01:16:01.231477
4	installation	fiber_installation	Biaya Instalasi Platinum	Biaya instalasi + setup untuk paket Platinum 100M	150000.00	f	t	platinum	Sudah termasuk kabel s.d 100m	2025-10-14 01:16:01.220025	2025-10-14 01:16:01.231477
5	installation	new_registration	Biaya Registrasi Pelanggan Baru	Biaya administrasi pendaftaran pelanggan baru	0.00	t	t	all	GRATIS untuk semua paket	2025-10-14 01:16:01.220025	2025-10-14 01:16:01.231477
6	installation	relocation_internal	Biaya Relokasi Dalam Rumah	Pindah posisi modem dalam satu rumah	150000.00	f	t	all	Kabel tambahan dikenakan biaya terpisah	2025-10-14 01:16:01.220025	2025-10-14 01:16:01.231477
22	maintenance	preventive_maintenance	Maintenance Rutin Tahunan	Pemeriksaan dan maintenance rutin tahunan	0.00	t	t	all	GRATIS untuk pelanggan aktif	2025-10-14 01:16:01.225493	2025-10-14 01:16:01.231477
23	maintenance	fiber_cleaning	Cleaning Konektor Fiber	Pembersihan konektor fiber untuk signal optimal	0.00	t	t	all	GRATIS service	2025-10-14 01:16:01.225493	2025-10-14 01:16:01.231477
24	maintenance	speed_test	Speed Test & Verifikasi	Test kecepatan dan verifikasi sesuai paket	0.00	t	t	all	GRATIS service	2025-10-14 01:16:01.225493	2025-10-14 01:16:01.231477
25	maintenance	cable_management	Rapihkan Kabel	Rapihkan instalasi kabel indoor	50000.00	f	t	all	Biaya tenaga saja	2025-10-14 01:16:01.225493	2025-10-14 01:16:01.231477
26	maintenance	firmware_update	Update Firmware Modem	Update firmware modem/ONT	0.00	t	t	all	GRATIS service	2025-10-14 01:16:01.225493	2025-10-14 01:16:01.231477
27	upgrade	package_upgrade	Biaya Upgrade Paket	Biaya admin upgrade ke paket lebih tinggi	0.00	t	t	all	GRATIS upgrade, langsung berlaku bulan depan	2025-10-14 01:16:01.226389	2025-10-14 01:16:01.231477
28	upgrade	speed_upgrade	Biaya Upgrade Kecepatan	Biaya admin upgrade kecepatan	0.00	t	t	all	GRATIS, hanya perlu config	2025-10-14 01:16:01.226389	2025-10-14 01:16:01.231477
29	upgrade	equipment_upgrade	Upgrade ke Modem/ONT Lebih Baik	Upgrade modem ke spec lebih tinggi	150000.00	f	t	all	Selisih harga modem baru dengan lama	2025-10-14 01:16:01.226389	2025-10-14 01:16:01.231477
30	upgrade	add_static_ip	Tambah Static IP	Biaya setup static IP	100000.00	f	t	all	Biaya setup + bulanan Rp 50.000	2025-10-14 01:16:01.226389	2025-10-14 01:16:01.231477
31	wifi_setup	change_password	Ganti Password WiFi	Mengganti password dan nama WiFi	0.00	t	t	all	GRATIS service	2025-10-14 01:16:01.22717	2025-10-14 01:16:01.231477
32	wifi_setup	new_wifi_config	Konfigurasi WiFi Baru	Setup WiFi dari awal	0.00	t	t	all	GRATIS untuk instalasi baru	2025-10-14 01:16:01.22717	2025-10-14 01:16:01.231477
33	wifi_setup	dual_band_setup	Setup WiFi Dual Band	Konfigurasi optimal WiFi 2.4GHz & 5GHz	0.00	t	t	all	GRATIS service	2025-10-14 01:16:01.22717	2025-10-14 01:16:01.231477
34	wifi_setup	wifi_extension	Pasang Access Point Tambahan	Instalasi AP untuk extend coverage	250000.00	f	t	all	Harga AP + instalasi, AP belum termasuk	2025-10-14 01:16:01.22717	2025-10-14 01:16:01.231477
35	wifi_setup	mesh_network	Setup Mesh WiFi Network	Instalasi mesh network (2-3 node)	350000.00	f	t	all	Biaya setup, mesh device belum termasuk	2025-10-14 01:16:01.22717	2025-10-14 01:16:01.231477
36	wifi_setup	guest_network	Setup Guest Network	Buat WiFi terpisah untuk tamu	0.00	t	t	all	GRATIS service	2025-10-14 01:16:01.22717	2025-10-14 01:16:01.231477
37	wifi_setup	parental_control	Setup Parental Control	Konfigurasi kontrol untuk anak	50000.00	f	t	all	Biaya setup dan training	2025-10-14 01:16:01.22717	2025-10-14 01:16:01.231477
45	installation	\N	Kabel Tambahan (per meter)	Biaya kabel drop tambahan di atas quota	5000.00	f	t	all	Per meter kelebihan dari quota paket	2025-10-14 01:16:01.229756	2025-10-14 01:16:01.231477
46	maintenance	\N	Denda Keterlambatan Pembayaran	Denda jika terlambat bayar >7 hari	50000.00	f	t	all	Per bulan keterlambatan	2025-10-14 01:16:01.229756	2025-10-14 01:16:01.231477
47	installation	\N	Biaya Reaktivasi	Reaktivasi layanan setelah suspend	100000.00	f	t	all	Biaya reconnect + admin	2025-10-14 01:16:01.229756	2025-10-14 01:16:01.231477
\.


--
-- Data for Name: service_types; Type: TABLE DATA; Schema: public; Owner: aglis_user
--

COPY public.service_types (id, type_code, type_name, description, icon, default_duration, is_active, display_order, created_at, updated_at) FROM stdin;
1	installation	Installation	New service installation and setup	wrench	120	t	1	2025-10-14 01:15:55.404858	2025-10-14 01:15:55.404858
2	repair	Repair	Fix existing service issues and problems	tool	120	t	2	2025-10-14 01:15:55.404858	2025-10-14 01:15:55.404858
3	maintenance	Maintenance	Scheduled maintenance and inspection	settings	120	t	3	2025-10-14 01:15:55.404858	2025-10-14 01:15:55.404858
4	upgrade	Upgrade	Service upgrade or enhancement	trending-up	60	t	4	2025-10-14 01:15:55.404858	2025-10-14 01:15:55.404858
5	wifi_setup	WiFi Setup	WiFi configuration and optimization	wifi	60	t	5	2025-10-14 01:15:55.404858	2025-10-14 01:15:55.404858
6	downgrade	Downgrade	Service plan downgrade or speed reduction	trending-down	60	t	6	2025-10-14 01:15:55.404858	2025-10-14 01:32:00.848867
7	dismantle	Dismantle	Service termination and equipment removal	trash-2	120	t	7	2025-10-14 01:15:55.404858	2025-10-14 01:32:00.850968
\.


--
-- Data for Name: service_types_backup; Type: TABLE DATA; Schema: public; Owner: aglis_user
--

COPY public.service_types_backup (id, service_code, service_name, category, description, estimated_duration, base_price, is_active, display_order, created_at, updated_at) FROM stdin;
1	install_new	New Installation	installation	Instalasi baru untuk customer baru	180	0.00	t	1	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
2	install_relocation	Relocation/Move	installation	Relokasi/pindah alamat customer	120	150000.00	t	2	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
3	install_upgrade	Upgrade Package	installation	Upgrade ke paket yang lebih tinggi	90	0.00	t	3	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
4	repair_signal	Signal Issue/Weak	repair	Perbaikan masalah signal lemah atau tidak stabil	120	0.00	t	10	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
5	repair_connection	Connection Lost/Down	repair	Perbaikan masalah koneksi internet mati	90	0.00	t	11	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
6	repair_slow_speed	Slow Speed	repair	Perbaikan masalah internet lambat	60	0.00	t	12	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
7	repair_equipment	Equipment Malfunction	repair	Perbaikan/ganti equipment rusak	90	0.00	t	13	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
8	repair_cable	Cable Damaged	repair	Perbaikan kabel putus/rusak	120	50000.00	t	14	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
9	repair_port	Port Problem	repair	Perbaikan masalah port/konektor	60	0.00	t	15	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
10	maintenance_preventive	Preventive Maintenance	maintenance	Maintenance rutin preventif	60	0.00	t	20	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
11	maintenance_cleaning	Equipment Cleaning	maintenance	Pembersihan dan perawatan equipment	45	0.00	t	21	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
12	maintenance_signal_check	Signal Quality Check	maintenance	Pengecekan kualitas signal	30	0.00	t	22	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
13	upgrade_speed	Speed Upgrade	upgrade	Upgrade kecepatan internet	60	0.00	t	30	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
14	upgrade_equipment	Equipment Upgrade	upgrade	Upgrade/ganti equipment ke yang lebih baru	90	0.00	t	31	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
15	upgrade_fiber	Fiber Upgrade	upgrade	Upgrade dari copper ke fiber	180	500000.00	t	32	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
16	support_config	Configuration Support	support	Bantuan setting/konfigurasi	45	0.00	t	40	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
17	support_troubleshoot	Troubleshooting	support	Diagnosa dan troubleshooting masalah	60	0.00	t	41	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
18	support_consultation	Technical Consultation	support	Konsultasi teknis	30	0.00	t	42	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
19	survey_site	Site Survey	survey	Survey lokasi untuk instalasi baru	90	0.00	t	50	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
20	disconnect	Service Disconnection	disconnection	Pemutusan layanan (cancel)	60	0.00	t	60	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
21	reconnect	Service Reconnection	reconnection	Penyambungan kembali layanan	60	100000.00	t	61	2025-10-14 01:02:14.733409	2025-10-14 01:02:14.733409
\.


--
-- Data for Name: skill_levels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.skill_levels (id, code, name, display_order, description, min_experience_months, min_completed_tickets, min_avg_rating, daily_ticket_capacity, expected_resolution_time_hours, can_handle_critical_tickets, can_mentor_others, requires_supervision, icon, color, badge_text, is_active, created_at, updated_at, created_by, updated_by) FROM stdin;
1	junior	Junior Technician	1	Entry-level technician with basic technical skills. Handles routine installations and maintenance under supervision. Still learning advanced troubleshooting techniques.	0	0	3.50	5	48	f	f	t	🌱	#10b981	JUNIOR	t	2025-10-14 23:16:48.581527	2025-10-14 23:16:48.581527	\N	\N
2	senior	Senior Technician	2	Experienced technician capable of handling complex issues independently. Can perform advanced installations and troubleshooting. Provides guidance to junior technicians.	12	100	4.00	8	24	f	t	f	⭐	#3b82f6	SENIOR	t	2025-10-14 23:16:48.581527	2025-10-14 23:16:48.581527	\N	\N
3	expert	Expert Technician	3	Highly skilled technician with deep technical expertise. Handles critical and escalated issues. Can work on NOC operations and network infrastructure. Trains and mentors other technicians.	36	500	4.50	10	12	t	t	f	🏆	#f59e0b	EXPERT	t	2025-10-14 23:16:48.581527	2025-10-14 23:16:48.581527	\N	\N
4	specialist	Technical Specialist	4	Master-level technician with specialized expertise in specific areas. Handles the most complex and critical issues. Leads technical projects and provides strategic technical guidance.	60	1000	4.70	12	6	t	t	f	💎	#8b5cf6	SPECIALIST	t	2025-10-14 23:16:48.581527	2025-10-14 23:16:48.581527	\N	\N
\.


--
-- Data for Name: specialization_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.specialization_categories (id, code, name, description, display_order, icon, color, is_active, created_at, updated_at) FROM stdin;
1	ftth_installation	FTTH Installation & Activation	Fiber To The Home installation, activation, and customer premises equipment setup	1	🏠	#3b82f6	t	2025-10-14 23:16:48.583869	2025-10-14 23:16:48.583869
2	ftth_maintenance	FTTH Maintenance & Repair	Fiber optic maintenance, troubleshooting, and repair services	2	🔧	#10b981	t	2025-10-14 23:16:48.583869	2025-10-14 23:16:48.583869
3	network_infrastructure	Network Infrastructure	Core network equipment, ODP/ODC, and backbone infrastructure	3	🌐	#f59e0b	t	2025-10-14 23:16:48.583869	2025-10-14 23:16:48.583869
4	noc_operations	NOC Operations	Network Operations Center monitoring, troubleshooting, and management	4	📡	#8b5cf6	t	2025-10-14 23:16:48.583869	2025-10-14 23:16:48.583869
5	customer_support	Customer Support & Service	Technical support, customer service, and issue resolution	5	👥	#06b6d4	t	2025-10-14 23:16:48.583869	2025-10-14 23:16:48.583869
6	wireless_services	Wireless Services	Wireless network setup, point-to-point links, and radio equipment	6	📶	#ec4899	t	2025-10-14 23:16:48.583869	2025-10-14 23:16:48.583869
\.


--
-- Data for Name: specializations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.specializations (id, category_id, code, name, description, required_skill_level, difficulty_level, is_high_demand, is_critical_service, icon, color, display_order, is_active, created_at, updated_at, created_by, updated_by) FROM stdin;
1	1	ftth_basic_install	FTTH Basic Installation	Basic fiber installation for residential customers including drop cable, rosette, and ONT setup	junior	2	t	f	\N	\N	1	t	2025-10-14 23:16:48.584969	2025-10-14 23:16:48.584969	\N	\N
2	1	ftth_aerial_install	FTTH Aerial Installation	Overhead fiber installation using poles and aerial cables	senior	3	t	f	\N	\N	2	t	2025-10-14 23:16:48.584969	2025-10-14 23:16:48.584969	\N	\N
3	1	ftth_underground_install	FTTH Underground Installation	Underground fiber installation through conduits and trenching	senior	4	f	f	\N	\N	3	t	2025-10-14 23:16:48.584969	2025-10-14 23:16:48.584969	\N	\N
4	1	ftth_building_install	FTTH Multi-Story Building	Fiber installation in apartments and multi-story buildings with vertical cabling	senior	4	t	f	\N	\N	4	t	2025-10-14 23:16:48.584969	2025-10-14 23:16:48.584969	\N	\N
5	1	ont_configuration	ONT Configuration & Activation	ONT device configuration, VLAN setup, WiFi configuration, and service activation	junior	2	t	f	\N	\N	5	t	2025-10-14 23:16:48.584969	2025-10-14 23:16:48.584969	\N	\N
6	1	cpe_setup	Customer Premises Equipment Setup	Router, WiFi extender, mesh system, and customer device configuration	junior	1	t	f	\N	\N	6	t	2025-10-14 23:16:48.584969	2025-10-14 23:16:48.584969	\N	\N
7	2	fiber_troubleshooting	Fiber Optic Troubleshooting	Diagnose fiber issues using OTDR, power meter, and visual fault locator	senior	3	t	t	\N	\N	1	t	2025-10-14 23:16:48.587298	2025-10-14 23:16:48.587298	\N	\N
8	2	fiber_splicing	Fiber Optic Splicing	Fusion splicing and mechanical splicing of fiber optic cables	expert	4	t	t	\N	\N	2	t	2025-10-14 23:16:48.587298	2025-10-14 23:16:48.587298	\N	\N
9	2	fiber_testing	Fiber Testing & Measurement	OTDR testing, power measurement, insertion loss testing, and documentation	senior	3	t	f	\N	\N	3	t	2025-10-14 23:16:48.587298	2025-10-14 23:16:48.587298	\N	\N
10	2	drop_cable_repair	Drop Cable Repair	Repair and replacement of damaged drop cables from ODP to customer	junior	2	t	f	\N	\N	4	t	2025-10-14 23:16:48.587298	2025-10-14 23:16:48.587298	\N	\N
11	2	ont_replacement	ONT Troubleshooting & Replacement	ONT device troubleshooting, replacement, and reconfiguration	junior	2	t	f	\N	\N	5	t	2025-10-14 23:16:48.587298	2025-10-14 23:16:48.587298	\N	\N
12	3	odp_installation	ODP/ODC Installation & Maintenance	Optical Distribution Point/Cabinet installation, splitter configuration, and port management	senior	3	t	t	\N	\N	1	t	2025-10-14 23:16:48.588236	2025-10-14 23:16:48.588236	\N	\N
13	3	fdt_installation	FDT/FAT Installation	Fiber Distribution Terminal and Fiber Access Terminal setup and management	senior	3	f	t	\N	\N	2	t	2025-10-14 23:16:48.588236	2025-10-14 23:16:48.588236	\N	\N
14	3	backbone_fiber	Backbone Fiber Installation	Core fiber network installation and backbone connectivity	expert	5	f	t	\N	\N	3	t	2025-10-14 23:16:48.588236	2025-10-14 23:16:48.588236	\N	\N
15	3	network_equipment	Network Equipment Installation	OLT, switches, routers, and core network equipment installation	expert	4	f	t	\N	\N	4	t	2025-10-14 23:16:48.588236	2025-10-14 23:16:48.588236	\N	\N
16	3	power_systems	Power Systems & UPS	Power supply, battery backup, and UPS systems for network equipment	senior	3	f	t	\N	\N	5	t	2025-10-14 23:16:48.588236	2025-10-14 23:16:48.588236	\N	\N
17	4	noc_monitoring	Network Monitoring & Analysis	24/7 network monitoring, alarm analysis, and proactive issue detection	senior	3	t	t	\N	\N	1	t	2025-10-14 23:16:48.589118	2025-10-14 23:16:48.589118	\N	\N
18	4	olt_management	OLT Management & Configuration	OLT provisioning, ONT registration, VLAN configuration, and bandwidth management	expert	4	t	t	\N	\N	2	t	2025-10-14 23:16:48.589118	2025-10-14 23:16:48.589118	\N	\N
19	4	remote_troubleshooting	Remote Troubleshooting	Remote diagnosis and resolution of customer and network issues	senior	3	t	t	\N	\N	3	t	2025-10-14 23:16:48.589118	2025-10-14 23:16:48.589118	\N	\N
20	4	network_optimization	Network Performance Optimization	Network analysis, optimization, and capacity planning	expert	4	f	t	\N	\N	4	t	2025-10-14 23:16:48.589118	2025-10-14 23:16:48.589118	\N	\N
21	4	incident_management	Incident Management & Escalation	Incident handling, escalation procedures, and crisis management	expert	4	t	t	\N	\N	5	t	2025-10-14 23:16:48.589118	2025-10-14 23:16:48.589118	\N	\N
22	5	technical_support	Technical Support Level 1	Basic customer technical support, issue diagnosis, and resolution	junior	1	t	f	\N	\N	1	t	2025-10-14 23:16:48.59	2025-10-14 23:16:48.59	\N	\N
23	5	wifi_optimization	WiFi Optimization & Troubleshooting	WiFi signal optimization, channel selection, and coverage improvement	junior	2	t	f	\N	\N	2	t	2025-10-14 23:16:48.59	2025-10-14 23:16:48.59	\N	\N
24	5	speed_testing	Speed Test & Quality Assurance	Internet speed testing, quality verification, and SLA compliance check	junior	1	t	f	\N	\N	3	t	2025-10-14 23:16:48.59	2025-10-14 23:16:48.59	\N	\N
25	5	customer_education	Customer Education & Training	Educate customers on service usage, equipment, and troubleshooting	junior	1	f	f	\N	\N	4	t	2025-10-14 23:16:48.59	2025-10-14 23:16:48.59	\N	\N
26	6	ptp_installation	Point-to-Point Link Installation	Wireless point-to-point link setup and alignment	senior	3	f	f	\N	\N	1	t	2025-10-14 23:16:48.590876	2025-10-14 23:16:48.590876	\N	\N
27	6	radio_equipment	Radio Equipment Configuration	Mikrotik, Ubiquiti, and other wireless equipment configuration	senior	3	f	f	\N	\N	2	t	2025-10-14 23:16:48.590876	2025-10-14 23:16:48.590876	\N	\N
28	6	tower_climbing	Tower Climbing & Installation	Tower climbing safety and equipment installation at height	expert	5	f	t	\N	\N	3	t	2025-10-14 23:16:48.590876	2025-10-14 23:16:48.590876	\N	\N
\.


--
-- Data for Name: system_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_metrics (id, metric_type, metric_value, metadata, recorded_at) FROM stdin;
1	memory_usage	29.1412353515625	{}	2025-10-15 19:21:25.058317+00
2	disk_usage	7	{}	2025-10-15 19:21:25.065828+00
3	whatsapp_success_rate	100	{}	2025-10-15 19:21:25.068169+00
4	sla_violation	2	{}	2025-10-15 19:21:25.07028+00
5	memory_usage	29.169607162475586	{}	2025-10-15 19:21:25.137964+00
6	disk_usage	7	{}	2025-10-15 19:21:25.146008+00
7	whatsapp_success_rate	100	{}	2025-10-15 19:21:25.149153+00
8	sla_violation	2	{}	2025-10-15 19:21:25.152229+00
9	memory_usage	29.245805740356445	{}	2025-10-15 19:21:25.217078+00
10	disk_usage	7	{}	2025-10-15 19:21:25.22467+00
11	whatsapp_success_rate	100	{}	2025-10-15 19:21:25.227521+00
12	sla_violation	2	{}	2025-10-15 19:21:25.229208+00
13	memory_usage	29.2510986328125	{}	2025-10-15 19:21:25.236945+00
14	disk_usage	7	{}	2025-10-15 19:21:25.244597+00
15	whatsapp_success_rate	100	{}	2025-10-15 19:21:25.247586+00
16	sla_violation	2	{}	2025-10-15 19:21:25.250132+00
17	memory_usage	26.674842834472656	{}	2025-10-15 19:25:00.022659+00
18	memory_usage	26.668739318847656	{}	2025-10-15 19:25:00.022177+00
19	memory_usage	26.669740676879883	{}	2025-10-15 19:25:00.023456+00
20	memory_usage	26.668739318847656	{}	2025-10-15 19:25:00.025013+00
21	disk_usage	7	{}	2025-10-15 19:25:00.029498+00
22	disk_usage	7	{}	2025-10-15 19:25:00.029859+00
23	disk_usage	7	{}	2025-10-15 19:25:00.03048+00
24	disk_usage	7	{}	2025-10-15 19:25:00.031104+00
25	whatsapp_success_rate	100	{}	2025-10-15 19:25:00.032291+00
26	whatsapp_success_rate	100	{}	2025-10-15 19:25:00.032565+00
27	whatsapp_success_rate	100	{}	2025-10-15 19:25:00.033561+00
28	whatsapp_success_rate	100	{}	2025-10-15 19:25:00.03394+00
29	sla_violation	2	{}	2025-10-15 19:25:00.034696+00
30	sla_violation	2	{}	2025-10-15 19:25:00.035113+00
31	sla_violation	2	{}	2025-10-15 19:25:00.035934+00
32	sla_violation	2	{}	2025-10-15 19:25:00.037285+00
33	memory_usage	26.643037796020508	{}	2025-10-15 19:30:00.027297+00
34	memory_usage	26.64356231689453	{}	2025-10-15 19:30:00.028975+00
35	memory_usage	26.643037796020508	{}	2025-10-15 19:30:00.031169+00
36	memory_usage	26.688432693481445	{}	2025-10-15 19:30:00.035237+00
37	disk_usage	7	{}	2025-10-15 19:30:00.037151+00
38	disk_usage	7	{}	2025-10-15 19:30:00.037171+00
39	disk_usage	7	{}	2025-10-15 19:30:00.037852+00
40	whatsapp_success_rate	100	{}	2025-10-15 19:30:00.040052+00
41	whatsapp_success_rate	100	{}	2025-10-15 19:30:00.040735+00
42	whatsapp_success_rate	100	{}	2025-10-15 19:30:00.04107+00
43	disk_usage	7	{}	2025-10-15 19:30:00.041068+00
44	sla_violation	2	{}	2025-10-15 19:30:00.042541+00
45	sla_violation	2	{}	2025-10-15 19:30:00.042978+00
46	sla_violation	2	{}	2025-10-15 19:30:00.043442+00
47	whatsapp_success_rate	100	{}	2025-10-15 19:30:00.043688+00
48	sla_violation	2	{}	2025-10-15 19:30:00.047579+00
49	memory_usage	26.558494567871094	{}	2025-10-15 19:35:00.018743+00
50	memory_usage	26.561546325683594	{}	2025-10-15 19:35:00.0188+00
51	memory_usage	26.59602165222168	{}	2025-10-15 19:35:00.023315+00
52	memory_usage	26.59602165222168	{}	2025-10-15 19:35:00.023753+00
53	disk_usage	7	{}	2025-10-15 19:35:00.025724+00
54	disk_usage	7	{}	2025-10-15 19:35:00.02685+00
55	disk_usage	7	{}	2025-10-15 19:35:00.030048+00
56	whatsapp_success_rate	100	{}	2025-10-15 19:35:00.030301+00
57	whatsapp_success_rate	100	{}	2025-10-15 19:35:00.030363+00
58	disk_usage	7	{}	2025-10-15 19:35:00.031651+00
59	whatsapp_success_rate	100	{}	2025-10-15 19:35:00.033522+00
60	sla_violation	2	{}	2025-10-15 19:35:00.033937+00
61	whatsapp_success_rate	100	{}	2025-10-15 19:35:00.034376+00
62	sla_violation	2	{}	2025-10-15 19:35:00.034522+00
63	sla_violation	2	{}	2025-10-15 19:35:00.035689+00
64	sla_violation	2	{}	2025-10-15 19:35:00.037686+00
65	memory_usage	26.632213592529297	{}	2025-10-15 19:40:00.01792+00
66	memory_usage	26.632213592529297	{}	2025-10-15 19:40:00.018896+00
67	memory_usage	26.635265350341797	{}	2025-10-15 19:40:00.019624+00
68	memory_usage	26.66950225830078	{}	2025-10-15 19:40:00.024777+00
69	disk_usage	7	{}	2025-10-15 19:40:00.025348+00
70	disk_usage	7	{}	2025-10-15 19:40:00.025572+00
71	disk_usage	7	{}	2025-10-15 19:40:00.02631+00
72	whatsapp_success_rate	100	{}	2025-10-15 19:40:00.028391+00
73	whatsapp_success_rate	100	{}	2025-10-15 19:40:00.028443+00
74	whatsapp_success_rate	100	{}	2025-10-15 19:40:00.029262+00
75	disk_usage	7	{}	2025-10-15 19:40:00.030459+00
76	sla_violation	2	{}	2025-10-15 19:40:00.030662+00
77	sla_violation	2	{}	2025-10-15 19:40:00.031543+00
78	sla_violation	2	{}	2025-10-15 19:40:00.031829+00
79	whatsapp_success_rate	100	{}	2025-10-15 19:40:00.03279+00
80	sla_violation	2	{}	2025-10-15 19:40:00.03586+00
81	memory_usage	26.52139663696289	{}	2025-10-15 19:45:00.028855+00
82	memory_usage	26.52277946472168	{}	2025-10-15 19:45:00.029519+00
83	memory_usage	26.53207778930664	{}	2025-10-15 19:45:00.032582+00
84	memory_usage	26.58390998840332	{}	2025-10-15 19:45:00.035317+00
85	disk_usage	7	{}	2025-10-15 19:45:00.036469+00
86	disk_usage	7	{}	2025-10-15 19:45:00.037125+00
87	whatsapp_success_rate	100	{}	2025-10-15 19:45:00.03944+00
88	whatsapp_success_rate	100	{}	2025-10-15 19:45:00.040375+00
89	disk_usage	7	{}	2025-10-15 19:45:00.040822+00
90	sla_violation	2	{}	2025-10-15 19:45:00.042114+00
91	sla_violation	2	{}	2025-10-15 19:45:00.042778+00
92	disk_usage	7	{}	2025-10-15 19:45:00.042911+00
93	whatsapp_success_rate	100	{}	2025-10-15 19:45:00.044198+00
94	sla_violation	2	{}	2025-10-15 19:45:00.046539+00
95	whatsapp_success_rate	100	{}	2025-10-15 19:45:00.046845+00
96	sla_violation	2	{}	2025-10-15 19:45:00.049376+00
97	memory_usage	26.60040855407715	{}	2025-10-15 19:50:00.018308+00
98	memory_usage	26.60040855407715	{}	2025-10-15 19:50:00.018251+00
99	memory_usage	26.60040855407715	{}	2025-10-15 19:50:00.019835+00
100	memory_usage	26.60040855407715	{}	2025-10-15 19:50:00.020968+00
101	disk_usage	7	{}	2025-10-15 19:50:00.024395+00
102	disk_usage	7	{}	2025-10-15 19:50:00.025118+00
103	disk_usage	7	{}	2025-10-15 19:50:00.026278+00
104	whatsapp_success_rate	100	{}	2025-10-15 19:50:00.027492+00
105	disk_usage	7	{}	2025-10-15 19:50:00.027918+00
106	whatsapp_success_rate	100	{}	2025-10-15 19:50:00.028105+00
107	whatsapp_success_rate	100	{}	2025-10-15 19:50:00.028798+00
108	sla_violation	2	{}	2025-10-15 19:50:00.029799+00
109	sla_violation	2	{}	2025-10-15 19:50:00.030506+00
110	whatsapp_success_rate	100	{}	2025-10-15 19:50:00.030598+00
111	sla_violation	2	{}	2025-10-15 19:50:00.03098+00
112	sla_violation	2	{}	2025-10-15 19:50:00.033372+00
113	memory_usage	26.583099365234375	{}	2025-10-15 19:55:00.019591+00
114	memory_usage	26.583099365234375	{}	2025-10-15 19:55:00.019916+00
115	memory_usage	26.577091217041016	{}	2025-10-15 19:55:00.020364+00
116	memory_usage	26.622724533081055	{}	2025-10-15 19:55:00.023923+00
118	disk_usage	7	{}	2025-10-15 19:55:00.026457+00
119	disk_usage	7	{}	2025-10-15 19:55:00.027754+00
121	whatsapp_success_rate	100	{}	2025-10-15 19:55:00.029191+00
122	disk_usage	7	{}	2025-10-15 19:55:00.029518+00
123	whatsapp_success_rate	100	{}	2025-10-15 19:55:00.030264+00
125	sla_violation	2	{}	2025-10-15 19:55:00.031564+00
126	whatsapp_success_rate	100	{}	2025-10-15 19:55:00.032146+00
127	sla_violation	2	{}	2025-10-15 19:55:00.032481+00
128	sla_violation	2	{}	2025-10-15 19:55:00.035398+00
1249	memory_usage	29.746627807617188	{}	2025-10-16 00:55:00.012472+00
1252	disk_usage	7	{}	2025-10-16 00:55:00.018516+00
1256	whatsapp_success_rate	100	{}	2025-10-16 00:55:00.021018+00
1259	sla_violation	2	{}	2025-10-16 00:55:00.023813+00
1346	memory_usage	30.405712127685547	{}	2025-10-16 01:10:00.012669+00
1351	disk_usage	7	{}	2025-10-16 01:10:00.021092+00
1355	whatsapp_success_rate	100	{}	2025-10-16 01:10:00.023769+00
1359	sla_violation	2	{}	2025-10-16 01:10:00.026108+00
1443	memory_usage	30.547380447387695	{}	2025-10-16 01:25:00.01061+00
1446	disk_usage	7	{}	2025-10-16 01:25:00.016472+00
1450	whatsapp_success_rate	100	{}	2025-10-16 01:25:00.019668+00
1454	sla_violation	2	{}	2025-10-16 01:25:00.022142+00
1544	memory_usage	29.95929718017578	{}	2025-10-16 01:45:00.033669+00
1547	disk_usage	7	{}	2025-10-16 01:45:00.040754+00
1549	whatsapp_success_rate	100	{}	2025-10-16 01:45:00.044314+00
1551	sla_violation	2	{}	2025-10-16 01:45:00.046634+00
1649	memory_usage	29.71196174621582	{}	2025-10-16 02:15:00.020284+00
1653	disk_usage	7	{}	2025-10-16 02:15:00.029818+00
1657	whatsapp_success_rate	100	{}	2025-10-16 02:15:00.032699+00
1662	sla_violation	2	{}	2025-10-16 02:15:00.03641+00
1746	memory_usage	29.427194595336914	{}	2025-10-16 02:45:00.027265+00
1750	disk_usage	7	{}	2025-10-16 02:45:00.03686+00
1752	whatsapp_success_rate	100	{}	2025-10-16 02:45:00.039806+00
1755	sla_violation	3	{}	2025-10-16 02:45:00.042333+00
1843	memory_usage	29.509305953979492	{}	2025-10-16 03:15:00.028437+00
1846	disk_usage	7	{}	2025-10-16 03:15:00.037412+00
1851	whatsapp_success_rate	100	{}	2025-10-16 03:15:00.040878+00
1853	sla_violation	3	{}	2025-10-16 03:15:00.043991+00
1940	memory_usage	29.869651794433594	{}	2025-10-16 03:40:00.018737+00
1950	disk_usage	7	{}	2025-10-16 03:40:00.025736+00
1951	whatsapp_success_rate	100	{}	2025-10-16 03:40:00.028605+00
1952	sla_violation	3	{}	2025-10-16 03:40:00.029995+00
2049	memory_usage	30.11312484741211	{}	2025-10-16 04:15:00.015209+00
2052	disk_usage	7	{}	2025-10-16 04:15:00.023541+00
2055	whatsapp_success_rate	100	{}	2025-10-16 04:15:00.029869+00
2058	sla_violation	3	{}	2025-10-16 04:15:00.033099+00
2146	memory_usage	30.083227157592773	{}	2025-10-16 04:40:00.010175+00
2150	disk_usage	7	{}	2025-10-16 04:40:00.016858+00
2154	whatsapp_success_rate	100	{}	2025-10-16 04:40:00.019495+00
2157	sla_violation	3	{}	2025-10-16 04:40:00.021685+00
2243	memory_usage	29.99567985534668	{}	2025-10-16 05:10:00.022523+00
2249	disk_usage	7	{}	2025-10-16 05:10:00.03015+00
2253	whatsapp_success_rate	100	{}	2025-10-16 05:10:00.032713+00
2256	sla_violation	3	{}	2025-10-16 05:10:00.035502+00
2340	memory_usage	18.089008331298828	{}	2025-10-16 05:40:00.021536+00
2344	disk_usage	7	{}	2025-10-16 05:40:00.027543+00
2348	whatsapp_success_rate	100	{}	2025-10-16 05:40:00.030838+00
2352	sla_violation	3	{}	2025-10-16 05:40:00.0335+00
2449	memory_usage	18.289852142333984	{}	2025-10-16 06:15:00.025933+00
2453	disk_usage	7	{}	2025-10-16 06:15:00.034991+00
2456	whatsapp_success_rate	100	{}	2025-10-16 06:15:00.038915+00
2460	sla_violation	3	{}	2025-10-16 06:15:00.041563+00
2546	memory_usage	18.253564834594727	{}	2025-10-16 06:45:00.03088+00
2550	disk_usage	7	{}	2025-10-16 06:45:00.038798+00
2553	whatsapp_success_rate	100	{}	2025-10-16 06:45:00.041745+00
2557	sla_violation	3	{}	2025-10-16 06:45:00.045234+00
2643	memory_usage	18.34397315979004	{}	2025-10-16 07:15:00.032482+00
2648	disk_usage	7	{}	2025-10-16 07:15:00.040188+00
2653	whatsapp_success_rate	100	{}	2025-10-16 07:15:00.043446+00
2656	sla_violation	3	{}	2025-10-16 07:15:00.046225+00
2753	memory_usage	18.312597274780273	{}	2025-10-16 07:50:00.017453+00
2759	disk_usage	7	{}	2025-10-16 07:50:00.025506+00
2763	whatsapp_success_rate	100	{}	2025-10-16 07:50:00.028079+00
2766	sla_violation	3	{}	2025-10-16 07:50:00.030672+00
2850	memory_usage	18.36676597595215	{}	2025-10-16 08:20:00.017718+00
2855	disk_usage	7	{}	2025-10-16 08:20:00.025741+00
2858	whatsapp_success_rate	100	{}	2025-10-16 08:20:00.028142+00
2862	sla_violation	3	{}	2025-10-16 08:20:00.030868+00
2947	memory_usage	18.39895248413086	{}	2025-10-16 08:50:00.019997+00
2951	disk_usage	7	{}	2025-10-16 08:50:00.027554+00
2956	whatsapp_success_rate	100	{}	2025-10-16 08:50:00.030734+00
2960	sla_violation	3	{}	2025-10-16 08:50:00.035692+00
3044	memory_usage	18.44048500061035	{}	2025-10-16 09:20:00.017764+00
3048	disk_usage	7	{}	2025-10-16 09:20:00.025124+00
3052	whatsapp_success_rate	100	{}	2025-10-16 09:20:00.027727+00
3056	sla_violation	3	{}	2025-10-16 09:20:00.030719+00
3139	memory_usage	18.500900268554688	{}	2025-10-16 09:50:00.022689+00
3144	disk_usage	7	{}	2025-10-16 09:50:00.029855+00
3148	whatsapp_success_rate	100	{}	2025-10-16 09:50:00.033711+00
3151	sla_violation	3	{}	2025-10-16 09:50:00.036762+00
3218	memory_usage	18.468904495239258	{}	2025-10-16 10:15:00.028966+00
3222	disk_usage	7	{}	2025-10-16 10:15:00.038001+00
3225	whatsapp_success_rate	100	{}	2025-10-16 10:15:00.040732+00
3228	sla_violation	3	{}	2025-10-16 10:15:00.044147+00
3265	memory_usage	18.474674224853516	{}	2025-10-16 10:30:00.026302+00
3269	disk_usage	7	{}	2025-10-16 10:30:00.033555+00
3271	whatsapp_success_rate	100	{}	2025-10-16 10:30:00.03617+00
3275	sla_violation	3	{}	2025-10-16 10:30:00.039179+00
3287	disk_usage	7	{}	2025-10-16 10:35:00.028237+00
3291	whatsapp_success_rate	100	{}	2025-10-16 10:35:00.030879+00
3295	sla_violation	3	{}	2025-10-16 10:35:00.033206+00
3299	memory_usage	18.501949310302734	{}	2025-10-16 10:40:00.018392+00
3304	disk_usage	7	{}	2025-10-16 10:40:00.024998+00
3307	whatsapp_success_rate	100	{}	2025-10-16 10:40:00.027899+00
3312	sla_violation	3	{}	2025-10-16 10:40:00.030571+00
3316	memory_usage	18.488740921020508	{}	2025-10-16 10:45:00.033841+00
3322	disk_usage	7	{}	2025-10-16 10:45:00.042928+00
3326	whatsapp_success_rate	100	{}	2025-10-16 10:45:00.045803+00
3328	sla_violation	3	{}	2025-10-16 10:45:00.047819+00
3345	memory_usage	18.440532684326172	{}	2025-10-16 10:55:00.01781+00
3347	disk_usage	7	{}	2025-10-16 10:55:00.025167+00
117	disk_usage	7	{}	2025-10-15 19:55:00.026306+00
120	whatsapp_success_rate	100	{}	2025-10-15 19:55:00.028908+00
124	sla_violation	2	{}	2025-10-15 19:55:00.031213+00
129	memory_usage	26.618194580078125	{}	2025-10-15 20:00:00.027467+00
130	memory_usage	26.61576271057129	{}	2025-10-15 20:00:00.029419+00
131	memory_usage	26.625490188598633	{}	2025-10-15 20:00:00.029918+00
132	memory_usage	26.61576271057129	{}	2025-10-15 20:00:00.030511+00
133	disk_usage	7	{}	2025-10-15 20:00:00.035978+00
134	disk_usage	7	{}	2025-10-15 20:00:00.036021+00
135	disk_usage	7	{}	2025-10-15 20:00:00.037634+00
136	disk_usage	7	{}	2025-10-15 20:00:00.039636+00
137	whatsapp_success_rate	100	{}	2025-10-15 20:00:00.041346+00
138	whatsapp_success_rate	100	{}	2025-10-15 20:00:00.041605+00
139	whatsapp_success_rate	100	{}	2025-10-15 20:00:00.042347+00
140	whatsapp_success_rate	100	{}	2025-10-15 20:00:00.042384+00
141	sla_violation	2	{}	2025-10-15 20:00:00.043981+00
142	sla_violation	2	{}	2025-10-15 20:00:00.044192+00
143	sla_violation	2	{}	2025-10-15 20:00:00.044977+00
144	sla_violation	2	{}	2025-10-15 20:00:00.045732+00
145	memory_usage	26.641559600830078	{}	2025-10-15 20:05:00.009101+00
146	disk_usage	7	{}	2025-10-15 20:05:00.01526+00
147	whatsapp_success_rate	100	{}	2025-10-15 20:05:00.017627+00
148	memory_usage	26.64618492126465	{}	2025-10-15 20:05:00.017797+00
149	memory_usage	26.64928436279297	{}	2025-10-15 20:05:00.018757+00
150	memory_usage	26.64923667907715	{}	2025-10-15 20:05:00.01907+00
151	sla_violation	2	{}	2025-10-15 20:05:00.020448+00
152	disk_usage	7	{}	2025-10-15 20:05:00.023646+00
153	disk_usage	7	{}	2025-10-15 20:05:00.024494+00
154	disk_usage	7	{}	2025-10-15 20:05:00.026281+00
155	whatsapp_success_rate	100	{}	2025-10-15 20:05:00.026578+00
156	whatsapp_success_rate	100	{}	2025-10-15 20:05:00.026982+00
157	sla_violation	2	{}	2025-10-15 20:05:00.029346+00
158	sla_violation	2	{}	2025-10-15 20:05:00.029744+00
159	whatsapp_success_rate	100	{}	2025-10-15 20:05:00.029795+00
160	sla_violation	2	{}	2025-10-15 20:05:00.033207+00
161	memory_usage	26.638078689575195	{}	2025-10-15 20:10:00.017643+00
162	memory_usage	26.638078689575195	{}	2025-10-15 20:10:00.01748+00
163	memory_usage	26.638078689575195	{}	2025-10-15 20:10:00.017886+00
164	memory_usage	26.639461517333984	{}	2025-10-15 20:10:00.019344+00
165	disk_usage	7	{}	2025-10-15 20:10:00.023968+00
166	disk_usage	7	{}	2025-10-15 20:10:00.024026+00
167	disk_usage	7	{}	2025-10-15 20:10:00.024085+00
168	disk_usage	7	{}	2025-10-15 20:10:00.025873+00
169	whatsapp_success_rate	100	{}	2025-10-15 20:10:00.026538+00
170	whatsapp_success_rate	100	{}	2025-10-15 20:10:00.026883+00
171	whatsapp_success_rate	100	{}	2025-10-15 20:10:00.02702+00
172	whatsapp_success_rate	100	{}	2025-10-15 20:10:00.028465+00
173	sla_violation	2	{}	2025-10-15 20:10:00.029161+00
174	sla_violation	2	{}	2025-10-15 20:10:00.029614+00
175	sla_violation	2	{}	2025-10-15 20:10:00.029627+00
176	sla_violation	2	{}	2025-10-15 20:10:00.030952+00
177	memory_usage	26.731204986572266	{}	2025-10-15 20:15:00.025038+00
178	memory_usage	26.731204986572266	{}	2025-10-15 20:15:00.029077+00
179	memory_usage	26.734590530395508	{}	2025-10-15 20:15:00.030804+00
180	memory_usage	26.744747161865234	{}	2025-10-15 20:15:00.031728+00
181	disk_usage	7	{}	2025-10-15 20:15:00.033551+00
182	disk_usage	7	{}	2025-10-15 20:15:00.036359+00
183	whatsapp_success_rate	100	{}	2025-10-15 20:15:00.036513+00
184	disk_usage	7	{}	2025-10-15 20:15:00.038515+00
185	whatsapp_success_rate	100	{}	2025-10-15 20:15:00.038839+00
186	sla_violation	2	{}	2025-10-15 20:15:00.039092+00
187	disk_usage	7	{}	2025-10-15 20:15:00.039433+00
188	whatsapp_success_rate	100	{}	2025-10-15 20:15:00.041018+00
189	sla_violation	2	{}	2025-10-15 20:15:00.041372+00
190	whatsapp_success_rate	100	{}	2025-10-15 20:15:00.041932+00
191	sla_violation	2	{}	2025-10-15 20:15:00.043564+00
192	sla_violation	2	{}	2025-10-15 20:15:00.046905+00
193	memory_usage	26.73025131225586	{}	2025-10-15 20:20:00.018651+00
194	memory_usage	26.73025131225586	{}	2025-10-15 20:20:00.019136+00
195	memory_usage	26.757144927978516	{}	2025-10-15 20:20:00.021686+00
196	disk_usage	7	{}	2025-10-15 20:20:00.026584+00
197	disk_usage	7	{}	2025-10-15 20:20:00.027374+00
198	disk_usage	7	{}	2025-10-15 20:20:00.027474+00
199	memory_usage	26.782751083374023	{}	2025-10-15 20:20:00.028244+00
200	whatsapp_success_rate	100	{}	2025-10-15 20:20:00.029157+00
201	whatsapp_success_rate	100	{}	2025-10-15 20:20:00.02971+00
202	whatsapp_success_rate	100	{}	2025-10-15 20:20:00.030303+00
203	sla_violation	2	{}	2025-10-15 20:20:00.031936+00
204	sla_violation	2	{}	2025-10-15 20:20:00.032693+00
205	sla_violation	2	{}	2025-10-15 20:20:00.033257+00
206	disk_usage	7	{}	2025-10-15 20:20:00.034069+00
207	whatsapp_success_rate	100	{}	2025-10-15 20:20:00.036535+00
208	sla_violation	2	{}	2025-10-15 20:20:00.038888+00
209	memory_usage	26.79142951965332	{}	2025-10-15 20:25:00.0181+00
210	memory_usage	26.793479919433594	{}	2025-10-15 20:25:00.019641+00
211	memory_usage	26.79448127746582	{}	2025-10-15 20:25:00.019873+00
212	disk_usage	7	{}	2025-10-15 20:25:00.024767+00
213	memory_usage	26.82647705078125	{}	2025-10-15 20:25:00.025168+00
214	disk_usage	7	{}	2025-10-15 20:25:00.025983+00
215	disk_usage	7	{}	2025-10-15 20:25:00.026368+00
216	whatsapp_success_rate	100	{}	2025-10-15 20:25:00.02741+00
217	whatsapp_success_rate	100	{}	2025-10-15 20:25:00.029502+00
218	whatsapp_success_rate	100	{}	2025-10-15 20:25:00.029785+00
219	sla_violation	2	{}	2025-10-15 20:25:00.029881+00
220	sla_violation	2	{}	2025-10-15 20:25:00.031587+00
221	disk_usage	7	{}	2025-10-15 20:25:00.031846+00
222	sla_violation	2	{}	2025-10-15 20:25:00.0322+00
223	whatsapp_success_rate	100	{}	2025-10-15 20:25:00.034562+00
224	sla_violation	2	{}	2025-10-15 20:25:00.036748+00
225	memory_usage	26.801776885986328	{}	2025-10-15 20:30:00.026744+00
226	memory_usage	26.814794540405273	{}	2025-10-15 20:30:00.028782+00
227	memory_usage	26.814794540405273	{}	2025-10-15 20:30:00.030928+00
228	memory_usage	26.816272735595703	{}	2025-10-15 20:30:00.032335+00
229	disk_usage	7	{}	2025-10-15 20:30:00.034937+00
230	disk_usage	7	{}	2025-10-15 20:30:00.037517+00
231	disk_usage	7	{}	2025-10-15 20:30:00.038425+00
232	whatsapp_success_rate	100	{}	2025-10-15 20:30:00.038701+00
233	disk_usage	7	{}	2025-10-15 20:30:00.038957+00
234	whatsapp_success_rate	100	{}	2025-10-15 20:30:00.039861+00
235	whatsapp_success_rate	100	{}	2025-10-15 20:30:00.04089+00
236	sla_violation	2	{}	2025-10-15 20:30:00.041057+00
237	whatsapp_success_rate	100	{}	2025-10-15 20:30:00.041853+00
238	sla_violation	2	{}	2025-10-15 20:30:00.041987+00
239	sla_violation	2	{}	2025-10-15 20:30:00.042961+00
1250	memory_usage	29.746627807617188	{}	2025-10-16 00:55:00.012864+00
1254	disk_usage	7	{}	2025-10-16 00:55:00.019775+00
1258	whatsapp_success_rate	100	{}	2025-10-16 00:55:00.022729+00
1261	sla_violation	2	{}	2025-10-16 00:55:00.02547+00
1347	memory_usage	30.408573150634766	{}	2025-10-16 01:10:00.013852+00
1350	disk_usage	7	{}	2025-10-16 01:10:00.020355+00
1354	whatsapp_success_rate	100	{}	2025-10-16 01:10:00.02258+00
1358	sla_violation	2	{}	2025-10-16 01:10:00.02466+00
1444	memory_usage	30.535459518432617	{}	2025-10-16 01:25:00.01507+00
1452	disk_usage	7	{}	2025-10-16 01:25:00.021048+00
1455	whatsapp_success_rate	100	{}	2025-10-16 01:25:00.02417+00
1456	sla_violation	2	{}	2025-10-16 01:25:00.026385+00
1553	memory_usage	30.26409149169922	{}	2025-10-16 01:50:00.009989+00
1557	disk_usage	7	{}	2025-10-16 01:50:00.017372+00
1560	whatsapp_success_rate	100	{}	2025-10-16 01:50:00.020065+00
1564	sla_violation	2	{}	2025-10-16 01:50:00.023032+00
1650	memory_usage	29.71196174621582	{}	2025-10-16 02:15:00.02039+00
1655	disk_usage	7	{}	2025-10-16 02:15:00.031155+00
1660	whatsapp_success_rate	100	{}	2025-10-16 02:15:00.035161+00
1664	sla_violation	2	{}	2025-10-16 02:15:00.036788+00
1747	memory_usage	29.43277359008789	{}	2025-10-16 02:45:00.029054+00
1751	disk_usage	7	{}	2025-10-16 02:45:00.038766+00
1756	whatsapp_success_rate	100	{}	2025-10-16 02:45:00.042496+00
1759	sla_violation	3	{}	2025-10-16 02:45:00.045607+00
1848	memory_usage	29.5712947845459	{}	2025-10-16 03:15:00.038433+00
1854	disk_usage	7	{}	2025-10-16 03:15:00.044459+00
1855	whatsapp_success_rate	100	{}	2025-10-16 03:15:00.047071+00
1856	sla_violation	3	{}	2025-10-16 03:15:00.049674+00
1953	memory_usage	29.876184463500977	{}	2025-10-16 03:45:00.018233+00
1957	disk_usage	7	{}	2025-10-16 03:45:00.026703+00
1959	whatsapp_success_rate	100	{}	2025-10-16 03:45:00.029147+00
1962	sla_violation	3	{}	2025-10-16 03:45:00.031161+00
2050	memory_usage	30.12213706970215	{}	2025-10-16 04:15:00.01758+00
2053	disk_usage	7	{}	2025-10-16 04:15:00.027372+00
2057	whatsapp_success_rate	100	{}	2025-10-16 04:15:00.032732+00
2061	sla_violation	3	{}	2025-10-16 04:15:00.036879+00
2147	memory_usage	30.086565017700195	{}	2025-10-16 04:40:00.011319+00
2151	disk_usage	7	{}	2025-10-16 04:40:00.017273+00
2153	whatsapp_success_rate	100	{}	2025-10-16 04:40:00.019448+00
2158	sla_violation	3	{}	2025-10-16 04:40:00.022007+00
2244	memory_usage	30.025672912597656	{}	2025-10-16 05:10:00.023287+00
2248	disk_usage	7	{}	2025-10-16 05:10:00.029771+00
2252	whatsapp_success_rate	100	{}	2025-10-16 05:10:00.032104+00
2255	sla_violation	3	{}	2025-10-16 05:10:00.034487+00
2353	memory_usage	18.356943130493164	{}	2025-10-16 05:45:00.028571+00
2357	disk_usage	7	{}	2025-10-16 05:45:00.036673+00
2360	whatsapp_success_rate	100	{}	2025-10-16 05:45:00.039218+00
2365	sla_violation	3	{}	2025-10-16 05:45:00.042765+00
2450	memory_usage	18.294334411621094	{}	2025-10-16 06:15:00.027934+00
2454	disk_usage	7	{}	2025-10-16 06:15:00.035314+00
2458	whatsapp_success_rate	100	{}	2025-10-16 06:15:00.03989+00
2462	sla_violation	3	{}	2025-10-16 06:15:00.042762+00
2547	memory_usage	18.2833194732666	{}	2025-10-16 06:45:00.031092+00
2551	disk_usage	7	{}	2025-10-16 06:45:00.039253+00
2554	whatsapp_success_rate	100	{}	2025-10-16 06:45:00.042553+00
2558	sla_violation	3	{}	2025-10-16 06:45:00.045637+00
2644	memory_usage	18.39442253112793	{}	2025-10-16 07:15:00.03397+00
2649	disk_usage	7	{}	2025-10-16 07:15:00.040441+00
2652	whatsapp_success_rate	100	{}	2025-10-16 07:15:00.043284+00
2655	sla_violation	3	{}	2025-10-16 07:15:00.04577+00
2754	memory_usage	18.312597274780273	{}	2025-10-16 07:50:00.017457+00
2758	disk_usage	7	{}	2025-10-16 07:50:00.024889+00
2762	whatsapp_success_rate	100	{}	2025-10-16 07:50:00.027603+00
2767	sla_violation	3	{}	2025-10-16 07:50:00.030697+00
2851	memory_usage	18.36676597595215	{}	2025-10-16 08:20:00.019037+00
2856	disk_usage	7	{}	2025-10-16 08:20:00.026001+00
2860	whatsapp_success_rate	100	{}	2025-10-16 08:20:00.029111+00
2864	sla_violation	3	{}	2025-10-16 08:20:00.031328+00
2948	memory_usage	18.39895248413086	{}	2025-10-16 08:50:00.020708+00
2952	disk_usage	7	{}	2025-10-16 08:50:00.027794+00
2955	whatsapp_success_rate	100	{}	2025-10-16 08:50:00.030653+00
2959	sla_violation	3	{}	2025-10-16 08:50:00.034825+00
3057	memory_usage	18.489646911621094	{}	2025-10-16 09:25:00.022459+00
3061	disk_usage	7	{}	2025-10-16 09:25:00.031862+00
3065	whatsapp_success_rate	100	{}	2025-10-16 09:25:00.035243+00
3069	sla_violation	3	{}	2025-10-16 09:25:00.037676+00
3140	memory_usage	18.500900268554688	{}	2025-10-16 09:50:00.023565+00
3146	disk_usage	7	{}	2025-10-16 09:50:00.030993+00
3149	whatsapp_success_rate	100	{}	2025-10-16 09:50:00.034227+00
3152	sla_violation	3	{}	2025-10-16 09:50:00.036986+00
3219	memory_usage	18.499135971069336	{}	2025-10-16 10:15:00.030772+00
3224	disk_usage	7	{}	2025-10-16 10:15:00.03975+00
3229	whatsapp_success_rate	100	{}	2025-10-16 10:15:00.04491+00
3231	sla_violation	3	{}	2025-10-16 10:15:00.047351+00
3266	memory_usage	18.474674224853516	{}	2025-10-16 10:30:00.026613+00
3270	disk_usage	7	{}	2025-10-16 10:30:00.03529+00
3274	whatsapp_success_rate	100	{}	2025-10-16 10:30:00.037739+00
3278	sla_violation	3	{}	2025-10-16 10:30:00.041247+00
3289	disk_usage	7	{}	2025-10-16 10:35:00.028935+00
3293	whatsapp_success_rate	100	{}	2025-10-16 10:35:00.031264+00
3296	sla_violation	3	{}	2025-10-16 10:35:00.03377+00
3300	memory_usage	18.501949310302734	{}	2025-10-16 10:40:00.018798+00
3303	disk_usage	7	{}	2025-10-16 10:40:00.024924+00
3308	whatsapp_success_rate	100	{}	2025-10-16 10:40:00.027924+00
3311	sla_violation	3	{}	2025-10-16 10:40:00.030557+00
3329	memory_usage	18.450260162353516	{}	2025-10-16 10:50:00.017113+00
3332	disk_usage	7	{}	2025-10-16 10:50:00.023846+00
3336	whatsapp_success_rate	100	{}	2025-10-16 10:50:00.027016+00
3340	sla_violation	3	{}	2025-10-16 10:50:00.03053+00
3346	memory_usage	18.440532684326172	{}	2025-10-16 10:55:00.01898+00
3348	disk_usage	7	{}	2025-10-16 10:55:00.025463+00
3352	whatsapp_success_rate	100	{}	2025-10-16 10:55:00.028405+00
3354	sla_violation	3	{}	2025-10-16 10:55:00.031236+00
3361	memory_usage	18.471479415893555	{}	2025-10-16 11:00:00.027161+00
3363	disk_usage	7	{}	2025-10-16 11:00:00.034742+00
3365	memory_usage	18.503856658935547	{}	2025-10-16 11:00:00.035034+00
3368	whatsapp_success_rate	100	{}	2025-10-16 11:00:00.03972+00
3370	disk_usage	7	{}	2025-10-16 11:00:00.042452+00
3372	sla_violation	3	{}	2025-10-16 11:00:00.043473+00
3373	whatsapp_success_rate	100	{}	2025-10-16 11:00:00.044822+00
3375	sla_violation	3	{}	2025-10-16 11:00:00.046999+00
3379	memory_usage	18.459796905517578	{}	2025-10-16 11:05:00.0192+00
240	sla_violation	2	{}	2025-10-15 20:30:00.044175+00
242	memory_usage	26.682662963867188	{}	2025-10-15 20:35:00.018434+00
241	memory_usage	26.682662963867188	{}	2025-10-15 20:35:00.018197+00
243	memory_usage	26.682662963867188	{}	2025-10-15 20:35:00.019721+00
244	memory_usage	26.687097549438477	{}	2025-10-15 20:35:00.021895+00
245	disk_usage	7	{}	2025-10-15 20:35:00.025207+00
246	disk_usage	7	{}	2025-10-15 20:35:00.025446+00
247	disk_usage	7	{}	2025-10-15 20:35:00.027314+00
248	whatsapp_success_rate	100	{}	2025-10-15 20:35:00.027731+00
249	whatsapp_success_rate	100	{}	2025-10-15 20:35:00.027976+00
250	disk_usage	7	{}	2025-10-15 20:35:00.028208+00
251	sla_violation	2	{}	2025-10-15 20:35:00.03+00
252	whatsapp_success_rate	100	{}	2025-10-15 20:35:00.030138+00
253	sla_violation	2	{}	2025-10-15 20:35:00.030355+00
254	whatsapp_success_rate	100	{}	2025-10-15 20:35:00.030636+00
255	sla_violation	2	{}	2025-10-15 20:35:00.033277+00
256	sla_violation	2	{}	2025-10-15 20:35:00.033781+00
257	memory_usage	26.69816017150879	{}	2025-10-15 20:40:00.017516+00
258	memory_usage	26.69816017150879	{}	2025-10-15 20:40:00.017814+00
259	memory_usage	26.69816017150879	{}	2025-10-15 20:40:00.018623+00
260	memory_usage	26.712322235107422	{}	2025-10-15 20:40:00.020674+00
261	disk_usage	7	{}	2025-10-15 20:40:00.024306+00
262	disk_usage	7	{}	2025-10-15 20:40:00.024643+00
263	disk_usage	7	{}	2025-10-15 20:40:00.024769+00
264	disk_usage	7	{}	2025-10-15 20:40:00.026966+00
265	whatsapp_success_rate	100	{}	2025-10-15 20:40:00.027054+00
266	whatsapp_success_rate	100	{}	2025-10-15 20:40:00.027257+00
267	whatsapp_success_rate	100	{}	2025-10-15 20:40:00.027826+00
268	whatsapp_success_rate	100	{}	2025-10-15 20:40:00.029357+00
269	sla_violation	2	{}	2025-10-15 20:40:00.0298+00
270	sla_violation	2	{}	2025-10-15 20:40:00.029833+00
271	sla_violation	2	{}	2025-10-15 20:40:00.030096+00
272	sla_violation	2	{}	2025-10-15 20:40:00.031814+00
273	memory_usage	26.76262855529785	{}	2025-10-15 20:45:00.026009+00
274	memory_usage	26.760005950927734	{}	2025-10-15 20:45:00.027859+00
275	memory_usage	26.760005950927734	{}	2025-10-15 20:45:00.031214+00
276	disk_usage	7	{}	2025-10-15 20:45:00.034364+00
277	disk_usage	7	{}	2025-10-15 20:45:00.037399+00
279	whatsapp_success_rate	100	{}	2025-10-15 20:45:00.037895+00
278	memory_usage	26.80191993713379	{}	2025-10-15 20:45:00.037315+00
280	disk_usage	7	{}	2025-10-15 20:45:00.038776+00
281	whatsapp_success_rate	100	{}	2025-10-15 20:45:00.041738+00
282	sla_violation	2	{}	2025-10-15 20:45:00.042541+00
283	whatsapp_success_rate	100	{}	2025-10-15 20:45:00.04265+00
284	sla_violation	2	{}	2025-10-15 20:45:00.044298+00
285	disk_usage	7	{}	2025-10-15 20:45:00.045767+00
286	sla_violation	2	{}	2025-10-15 20:45:00.04577+00
287	whatsapp_success_rate	100	{}	2025-10-15 20:45:00.049987+00
288	sla_violation	2	{}	2025-10-15 20:45:00.052706+00
289	memory_usage	26.735830307006836	{}	2025-10-15 20:50:00.017409+00
290	memory_usage	26.738882064819336	{}	2025-10-15 20:50:00.017522+00
291	memory_usage	26.735830307006836	{}	2025-10-15 20:50:00.017307+00
292	memory_usage	26.740550994873047	{}	2025-10-15 20:50:00.019205+00
293	disk_usage	7	{}	2025-10-15 20:50:00.02437+00
294	disk_usage	7	{}	2025-10-15 20:50:00.024379+00
295	disk_usage	7	{}	2025-10-15 20:50:00.024377+00
296	disk_usage	7	{}	2025-10-15 20:50:00.025004+00
297	whatsapp_success_rate	100	{}	2025-10-15 20:50:00.027344+00
298	whatsapp_success_rate	100	{}	2025-10-15 20:50:00.027659+00
299	whatsapp_success_rate	100	{}	2025-10-15 20:50:00.027735+00
300	whatsapp_success_rate	100	{}	2025-10-15 20:50:00.028107+00
301	sla_violation	2	{}	2025-10-15 20:50:00.029988+00
302	sla_violation	2	{}	2025-10-15 20:50:00.030452+00
303	sla_violation	2	{}	2025-10-15 20:50:00.030559+00
304	sla_violation	2	{}	2025-10-15 20:50:00.030623+00
305	memory_usage	26.808547973632812	{}	2025-10-15 20:55:00.018769+00
306	memory_usage	26.808500289916992	{}	2025-10-15 20:55:00.019609+00
307	memory_usage	26.811552047729492	{}	2025-10-15 20:55:00.019799+00
308	disk_usage	7	{}	2025-10-15 20:55:00.02561+00
310	disk_usage	7	{}	2025-10-15 20:55:00.026151+00
309	disk_usage	7	{}	2025-10-15 20:55:00.026152+00
311	memory_usage	26.854610443115234	{}	2025-10-15 20:55:00.028292+00
312	whatsapp_success_rate	100	{}	2025-10-15 20:55:00.029082+00
313	whatsapp_success_rate	100	{}	2025-10-15 20:55:00.029206+00
314	whatsapp_success_rate	100	{}	2025-10-15 20:55:00.029294+00
315	sla_violation	2	{}	2025-10-15 20:55:00.032723+00
316	sla_violation	2	{}	2025-10-15 20:55:00.032743+00
317	sla_violation	2	{}	2025-10-15 20:55:00.032752+00
318	disk_usage	7	{}	2025-10-15 20:55:00.034865+00
319	whatsapp_success_rate	100	{}	2025-10-15 20:55:00.037751+00
320	sla_violation	2	{}	2025-10-15 20:55:00.041279+00
321	memory_usage	26.83858871459961	{}	2025-10-15 21:00:00.027995+00
322	memory_usage	26.83858871459961	{}	2025-10-15 21:00:00.028669+00
323	memory_usage	26.89347267150879	{}	2025-10-15 21:00:00.032468+00
324	memory_usage	26.874065399169922	{}	2025-10-15 21:00:00.032987+00
325	disk_usage	7	{}	2025-10-15 21:00:00.035357+00
326	whatsapp_success_rate	100	{}	2025-10-15 21:00:00.038261+00
327	disk_usage	7	{}	2025-10-15 21:00:00.038696+00
328	sla_violation	2	{}	2025-10-15 21:00:00.040634+00
329	disk_usage	7	{}	2025-10-15 21:00:00.040658+00
330	disk_usage	7	{}	2025-10-15 21:00:00.041103+00
331	whatsapp_success_rate	100	{}	2025-10-15 21:00:00.044794+00
332	whatsapp_success_rate	100	{}	2025-10-15 21:00:00.045082+00
333	whatsapp_success_rate	100	{}	2025-10-15 21:00:00.045636+00
334	sla_violation	2	{}	2025-10-15 21:00:00.04699+00
335	sla_violation	2	{}	2025-10-15 21:00:00.047584+00
336	sla_violation	2	{}	2025-10-15 21:00:00.049579+00
337	memory_usage	26.84803009033203	{}	2025-10-15 21:05:00.018221+00
338	memory_usage	26.84803009033203	{}	2025-10-15 21:05:00.019276+00
339	memory_usage	26.84803009033203	{}	2025-10-15 21:05:00.020558+00
340	disk_usage	7	{}	2025-10-15 21:05:00.025356+00
341	memory_usage	26.87816619873047	{}	2025-10-15 21:05:00.025387+00
342	disk_usage	7	{}	2025-10-15 21:05:00.026296+00
343	disk_usage	7	{}	2025-10-15 21:05:00.026457+00
344	whatsapp_success_rate	100	{}	2025-10-15 21:05:00.028041+00
345	whatsapp_success_rate	100	{}	2025-10-15 21:05:00.028747+00
346	whatsapp_success_rate	100	{}	2025-10-15 21:05:00.029801+00
347	sla_violation	2	{}	2025-10-15 21:05:00.030301+00
348	sla_violation	2	{}	2025-10-15 21:05:00.030806+00
349	disk_usage	7	{}	2025-10-15 21:05:00.030935+00
350	sla_violation	2	{}	2025-10-15 21:05:00.033009+00
351	whatsapp_success_rate	100	{}	2025-10-15 21:05:00.033959+00
352	sla_violation	2	{}	2025-10-15 21:05:00.036169+00
353	memory_usage	26.91659927368164	{}	2025-10-15 21:10:00.018358+00
354	memory_usage	26.91965103149414	{}	2025-10-15 21:10:00.019426+00
355	memory_usage	26.94525718688965	{}	2025-10-15 21:10:00.022566+00
356	memory_usage	26.944875717163086	{}	2025-10-15 21:10:00.023105+00
357	disk_usage	7	{}	2025-10-15 21:10:00.02637+00
358	disk_usage	7	{}	2025-10-15 21:10:00.026461+00
359	disk_usage	7	{}	2025-10-15 21:10:00.028527+00
360	whatsapp_success_rate	100	{}	2025-10-15 21:10:00.028964+00
361	whatsapp_success_rate	100	{}	2025-10-15 21:10:00.029247+00
362	disk_usage	7	{}	2025-10-15 21:10:00.029457+00
363	whatsapp_success_rate	100	{}	2025-10-15 21:10:00.030993+00
364	sla_violation	2	{}	2025-10-15 21:10:00.031188+00
365	whatsapp_success_rate	100	{}	2025-10-15 21:10:00.031755+00
366	sla_violation	2	{}	2025-10-15 21:10:00.031785+00
367	sla_violation	2	{}	2025-10-15 21:10:00.033265+00
368	sla_violation	2	{}	2025-10-15 21:10:00.034202+00
369	memory_usage	26.940107345581055	{}	2025-10-15 21:15:00.026067+00
370	memory_usage	26.93343162536621	{}	2025-10-15 21:15:00.027007+00
371	memory_usage	26.943302154541016	{}	2025-10-15 21:15:00.029798+00
372	disk_usage	7	{}	2025-10-15 21:15:00.034243+00
373	disk_usage	7	{}	2025-10-15 21:15:00.034469+00
374	memory_usage	27.009868621826172	{}	2025-10-15 21:15:00.035319+00
375	disk_usage	7	{}	2025-10-15 21:15:00.036409+00
376	whatsapp_success_rate	100	{}	2025-10-15 21:15:00.038071+00
377	whatsapp_success_rate	100	{}	2025-10-15 21:15:00.038397+00
378	whatsapp_success_rate	100	{}	2025-10-15 21:15:00.039602+00
379	sla_violation	2	{}	2025-10-15 21:15:00.041156+00
380	sla_violation	2	{}	2025-10-15 21:15:00.041176+00
381	disk_usage	7	{}	2025-10-15 21:15:00.041614+00
382	sla_violation	2	{}	2025-10-15 21:15:00.04196+00
383	whatsapp_success_rate	100	{}	2025-10-15 21:15:00.046483+00
384	sla_violation	2	{}	2025-10-15 21:15:00.048631+00
385	memory_usage	26.85985565185547	{}	2025-10-15 21:20:00.018012+00
386	memory_usage	26.85985565185547	{}	2025-10-15 21:20:00.01836+00
387	memory_usage	26.858997344970703	{}	2025-10-15 21:20:00.019507+00
388	memory_usage	26.882362365722656	{}	2025-10-15 21:20:00.020286+00
389	disk_usage	7	{}	2025-10-15 21:20:00.024815+00
390	disk_usage	7	{}	2025-10-15 21:20:00.024967+00
391	disk_usage	7	{}	2025-10-15 21:20:00.02608+00
392	disk_usage	7	{}	2025-10-15 21:20:00.026175+00
393	whatsapp_success_rate	100	{}	2025-10-15 21:20:00.027557+00
394	whatsapp_success_rate	100	{}	2025-10-15 21:20:00.027806+00
395	whatsapp_success_rate	100	{}	2025-10-15 21:20:00.028575+00
396	whatsapp_success_rate	100	{}	2025-10-15 21:20:00.028769+00
397	sla_violation	2	{}	2025-10-15 21:20:00.029887+00
398	sla_violation	2	{}	2025-10-15 21:20:00.030709+00
399	sla_violation	2	{}	2025-10-15 21:20:00.030958+00
400	sla_violation	2	{}	2025-10-15 21:20:00.031162+00
401	memory_usage	26.94101333618164	{}	2025-10-15 21:25:00.016962+00
402	memory_usage	26.94101333618164	{}	2025-10-15 21:25:00.016921+00
403	memory_usage	26.945924758911133	{}	2025-10-15 21:25:00.01881+00
404	memory_usage	26.945924758911133	{}	2025-10-15 21:25:00.018824+00
405	disk_usage	7	{}	2025-10-15 21:25:00.022997+00
406	disk_usage	7	{}	2025-10-15 21:25:00.023628+00
407	disk_usage	7	{}	2025-10-15 21:25:00.024447+00
408	disk_usage	7	{}	2025-10-15 21:25:00.025477+00
409	whatsapp_success_rate	100	{}	2025-10-15 21:25:00.025753+00
410	whatsapp_success_rate	100	{}	2025-10-15 21:25:00.026014+00
411	whatsapp_success_rate	100	{}	2025-10-15 21:25:00.027128+00
412	sla_violation	2	{}	2025-10-15 21:25:00.028489+00
413	whatsapp_success_rate	100	{}	2025-10-15 21:25:00.028683+00
414	sla_violation	2	{}	2025-10-15 21:25:00.028971+00
415	sla_violation	2	{}	2025-10-15 21:25:00.029746+00
416	sla_violation	2	{}	2025-10-15 21:25:00.0319+00
417	memory_usage	26.8186092376709	{}	2025-10-15 21:30:00.02399+00
418	memory_usage	26.834440231323242	{}	2025-10-15 21:30:00.026253+00
419	memory_usage	26.833295822143555	{}	2025-10-15 21:30:00.029658+00
420	disk_usage	7	{}	2025-10-15 21:30:00.034446+00
421	whatsapp_success_rate	100	{}	2025-10-15 21:30:00.037853+00
423	disk_usage	7	{}	2025-10-15 21:30:00.03829+00
422	memory_usage	26.90725326538086	{}	2025-10-15 21:30:00.037686+00
424	disk_usage	7	{}	2025-10-15 21:30:00.039048+00
425	sla_violation	2	{}	2025-10-15 21:30:00.040681+00
426	whatsapp_success_rate	100	{}	2025-10-15 21:30:00.041501+00
427	whatsapp_success_rate	100	{}	2025-10-15 21:30:00.041993+00
428	sla_violation	2	{}	2025-10-15 21:30:00.044077+00
429	disk_usage	7	{}	2025-10-15 21:30:00.044406+00
430	sla_violation	2	{}	2025-10-15 21:30:00.044901+00
431	whatsapp_success_rate	100	{}	2025-10-15 21:30:00.047673+00
432	sla_violation	2	{}	2025-10-15 21:30:00.050652+00
433	memory_usage	26.876068115234375	{}	2025-10-15 21:35:00.017175+00
434	memory_usage	26.873254776000977	{}	2025-10-15 21:35:00.018639+00
435	memory_usage	26.876068115234375	{}	2025-10-15 21:35:00.018597+00
436	memory_usage	26.873254776000977	{}	2025-10-15 21:35:00.019419+00
437	disk_usage	7	{}	2025-10-15 21:35:00.023952+00
438	disk_usage	7	{}	2025-10-15 21:35:00.024165+00
439	disk_usage	7	{}	2025-10-15 21:35:00.025343+00
440	disk_usage	7	{}	2025-10-15 21:35:00.025699+00
441	whatsapp_success_rate	100	{}	2025-10-15 21:35:00.027378+00
442	whatsapp_success_rate	100	{}	2025-10-15 21:35:00.028455+00
443	whatsapp_success_rate	100	{}	2025-10-15 21:35:00.029636+00
444	whatsapp_success_rate	100	{}	2025-10-15 21:35:00.029683+00
445	sla_violation	2	{}	2025-10-15 21:35:00.030172+00
446	sla_violation	2	{}	2025-10-15 21:35:00.031012+00
447	sla_violation	2	{}	2025-10-15 21:35:00.031932+00
448	sla_violation	2	{}	2025-10-15 21:35:00.032374+00
449	memory_usage	26.863956451416016	{}	2025-10-15 21:40:00.016923+00
450	memory_usage	26.863956451416016	{}	2025-10-15 21:40:00.016929+00
451	memory_usage	26.88298225402832	{}	2025-10-15 21:40:00.020293+00
452	disk_usage	7	{}	2025-10-15 21:40:00.02355+00
453	memory_usage	26.905155181884766	{}	2025-10-15 21:40:00.02376+00
454	disk_usage	7	{}	2025-10-15 21:40:00.024594+00
455	whatsapp_success_rate	100	{}	2025-10-15 21:40:00.026242+00
456	disk_usage	7	{}	2025-10-15 21:40:00.026795+00
457	whatsapp_success_rate	100	{}	2025-10-15 21:40:00.027165+00
458	sla_violation	2	{}	2025-10-15 21:40:00.028557+00
459	disk_usage	7	{}	2025-10-15 21:40:00.028878+00
460	sla_violation	2	{}	2025-10-15 21:40:00.029363+00
461	whatsapp_success_rate	100	{}	2025-10-15 21:40:00.029398+00
462	whatsapp_success_rate	100	{}	2025-10-15 21:40:00.031672+00
463	sla_violation	2	{}	2025-10-15 21:40:00.032+00
464	sla_violation	2	{}	2025-10-15 21:40:00.033902+00
465	memory_usage	26.96537971496582	{}	2025-10-15 21:45:00.030755+00
466	memory_usage	26.971101760864258	{}	2025-10-15 21:45:00.031015+00
467	memory_usage	26.967763900756836	{}	2025-10-15 21:45:00.031419+00
468	memory_usage	26.993370056152344	{}	2025-10-15 21:45:00.035887+00
470	disk_usage	7	{}	2025-10-15 21:45:00.038638+00
471	disk_usage	7	{}	2025-10-15 21:45:00.039208+00
472	disk_usage	7	{}	2025-10-15 21:45:00.041645+00
474	whatsapp_success_rate	100	{}	2025-10-15 21:45:00.042731+00
475	whatsapp_success_rate	100	{}	2025-10-15 21:45:00.042771+00
476	whatsapp_success_rate	100	{}	2025-10-15 21:45:00.044032+00
478	sla_violation	2	{}	2025-10-15 21:45:00.045533+00
479	sla_violation	2	{}	2025-10-15 21:45:00.045739+00
480	sla_violation	2	{}	2025-10-15 21:45:00.046213+00
1251	memory_usage	29.74996566772461	{}	2025-10-16 00:55:00.013817+00
1255	disk_usage	7	{}	2025-10-16 00:55:00.02009+00
1257	whatsapp_success_rate	100	{}	2025-10-16 00:55:00.022454+00
1260	sla_violation	2	{}	2025-10-16 00:55:00.02448+00
1348	memory_usage	30.412912368774414	{}	2025-10-16 01:10:00.014812+00
1352	disk_usage	7	{}	2025-10-16 01:10:00.021509+00
1356	whatsapp_success_rate	100	{}	2025-10-16 01:10:00.023793+00
1360	sla_violation	2	{}	2025-10-16 01:10:00.026543+00
1457	memory_usage	30.785512924194336	{}	2025-10-16 01:30:00.018443+00
1461	disk_usage	7	{}	2025-10-16 01:30:00.026249+00
1465	whatsapp_success_rate	100	{}	2025-10-16 01:30:00.028576+00
1469	sla_violation	2	{}	2025-10-16 01:30:00.03068+00
1554	memory_usage	30.266141891479492	{}	2025-10-16 01:50:00.010522+00
1558	disk_usage	7	{}	2025-10-16 01:50:00.017565+00
1562	whatsapp_success_rate	100	{}	2025-10-16 01:50:00.021085+00
1566	sla_violation	2	{}	2025-10-16 01:50:00.024109+00
1651	memory_usage	29.723215103149414	{}	2025-10-16 02:15:00.022347+00
1654	disk_usage	7	{}	2025-10-16 02:15:00.030857+00
1658	whatsapp_success_rate	100	{}	2025-10-16 02:15:00.033875+00
1663	sla_violation	2	{}	2025-10-16 02:15:00.036427+00
1748	memory_usage	29.47831153869629	{}	2025-10-16 02:45:00.033591+00
1753	disk_usage	7	{}	2025-10-16 02:45:00.040458+00
1757	whatsapp_success_rate	100	{}	2025-10-16 02:45:00.043066+00
1760	sla_violation	3	{}	2025-10-16 02:45:00.046766+00
1857	memory_usage	29.494333267211914	{}	2025-10-16 03:20:00.019075+00
1861	disk_usage	7	{}	2025-10-16 03:20:00.026222+00
1863	whatsapp_success_rate	100	{}	2025-10-16 03:20:00.028837+00
1867	sla_violation	3	{}	2025-10-16 03:20:00.031132+00
1954	memory_usage	29.85978126525879	{}	2025-10-16 03:45:00.020408+00
1958	disk_usage	7	{}	2025-10-16 03:45:00.027354+00
1960	whatsapp_success_rate	100	{}	2025-10-16 03:45:00.029446+00
1963	sla_violation	3	{}	2025-10-16 03:45:00.031738+00
2051	memory_usage	30.114364624023438	{}	2025-10-16 04:15:00.022666+00
2056	disk_usage	7	{}	2025-10-16 04:15:00.032079+00
2059	whatsapp_success_rate	100	{}	2025-10-16 04:15:00.034962+00
2062	sla_violation	3	{}	2025-10-16 04:15:00.037475+00
2148	memory_usage	30.10091781616211	{}	2025-10-16 04:40:00.014536+00
2155	disk_usage	7	{}	2025-10-16 04:40:00.019961+00
2159	whatsapp_success_rate	100	{}	2025-10-16 04:40:00.022189+00
2160	sla_violation	3	{}	2025-10-16 04:40:00.02606+00
2257	memory_usage	29.86464500427246	{}	2025-10-16 05:15:00.026698+00
2259	disk_usage	7	{}	2025-10-16 05:15:00.034883+00
2263	whatsapp_success_rate	100	{}	2025-10-16 05:15:00.03792+00
2266	sla_violation	3	{}	2025-10-16 05:15:00.041674+00
2354	memory_usage	18.356943130493164	{}	2025-10-16 05:45:00.030722+00
2358	disk_usage	7	{}	2025-10-16 05:45:00.038287+00
2362	whatsapp_success_rate	100	{}	2025-10-16 05:45:00.041053+00
2366	sla_violation	3	{}	2025-10-16 05:45:00.043599+00
2451	memory_usage	18.312883377075195	{}	2025-10-16 06:15:00.029332+00
2455	disk_usage	7	{}	2025-10-16 06:15:00.037459+00
2459	whatsapp_success_rate	100	{}	2025-10-16 06:15:00.040086+00
2463	sla_violation	3	{}	2025-10-16 06:15:00.043663+00
2548	memory_usage	18.295717239379883	{}	2025-10-16 06:45:00.035619+00
2555	disk_usage	7	{}	2025-10-16 06:45:00.043891+00
2559	whatsapp_success_rate	100	{}	2025-10-16 06:45:00.047018+00
2560	sla_violation	3	{}	2025-10-16 06:45:00.049517+00
2657	memory_usage	18.346595764160156	{}	2025-10-16 07:20:00.017512+00
2661	disk_usage	7	{}	2025-10-16 07:20:00.024533+00
2664	whatsapp_success_rate	100	{}	2025-10-16 07:20:00.028185+00
2668	sla_violation	3	{}	2025-10-16 07:20:00.030458+00
2755	memory_usage	18.320608139038086	{}	2025-10-16 07:50:00.018372+00
2757	disk_usage	7	{}	2025-10-16 07:50:00.024743+00
2761	whatsapp_success_rate	100	{}	2025-10-16 07:50:00.027269+00
2765	sla_violation	3	{}	2025-10-16 07:50:00.029874+00
2852	memory_usage	18.36676597595215	{}	2025-10-16 08:20:00.01928+00
2854	disk_usage	7	{}	2025-10-16 08:20:00.025484+00
2859	whatsapp_success_rate	100	{}	2025-10-16 08:20:00.028347+00
2863	sla_violation	3	{}	2025-10-16 08:20:00.030943+00
2961	memory_usage	18.38531494140625	{}	2025-10-16 08:55:00.018691+00
2965	disk_usage	7	{}	2025-10-16 08:55:00.025674+00
2969	whatsapp_success_rate	100	{}	2025-10-16 08:55:00.028217+00
2973	sla_violation	3	{}	2025-10-16 08:55:00.030524+00
3058	memory_usage	18.489646911621094	{}	2025-10-16 09:25:00.022844+00
3062	disk_usage	7	{}	2025-10-16 09:25:00.03192+00
3064	whatsapp_success_rate	100	{}	2025-10-16 09:25:00.035145+00
3067	sla_violation	3	{}	2025-10-16 09:25:00.037447+00
3153	memory_usage	18.47710609436035	{}	2025-10-16 09:55:00.018437+00
3157	disk_usage	7	{}	2025-10-16 09:55:00.025939+00
3161	whatsapp_success_rate	100	{}	2025-10-16 09:55:00.028736+00
3165	sla_violation	3	{}	2025-10-16 09:55:00.03116+00
3220	memory_usage	18.493080139160156	{}	2025-10-16 10:15:00.034228+00
3227	disk_usage	7	{}	2025-10-16 10:15:00.041572+00
3230	whatsapp_success_rate	100	{}	2025-10-16 10:15:00.045691+00
3232	sla_violation	3	{}	2025-10-16 10:15:00.047889+00
3267	memory_usage	18.48468780517578	{}	2025-10-16 10:30:00.030088+00
3272	disk_usage	7	{}	2025-10-16 10:30:00.036911+00
3276	whatsapp_success_rate	100	{}	2025-10-16 10:30:00.039677+00
3279	sla_violation	3	{}	2025-10-16 10:30:00.04192+00
3292	sla_violation	3	{}	2025-10-16 10:35:00.030923+00
3313	memory_usage	18.461227416992188	{}	2025-10-16 10:45:00.029712+00
3317	disk_usage	7	{}	2025-10-16 10:45:00.038308+00
3319	whatsapp_success_rate	100	{}	2025-10-16 10:45:00.041484+00
3323	sla_violation	3	{}	2025-10-16 10:45:00.043904+00
3330	memory_usage	18.457365036010742	{}	2025-10-16 10:50:00.01767+00
3333	disk_usage	7	{}	2025-10-16 10:50:00.024281+00
3337	whatsapp_success_rate	100	{}	2025-10-16 10:50:00.027305+00
3341	sla_violation	3	{}	2025-10-16 10:50:00.030683+00
3349	memory_usage	18.468475341796875	{}	2025-10-16 10:55:00.026743+00
3356	disk_usage	7	{}	2025-10-16 10:55:00.034176+00
3358	whatsapp_success_rate	100	{}	2025-10-16 10:55:00.036493+00
3360	sla_violation	3	{}	2025-10-16 10:55:00.03874+00
469	disk_usage	7	{}	2025-10-15 21:45:00.038235+00
473	whatsapp_success_rate	100	{}	2025-10-15 21:45:00.042367+00
477	sla_violation	2	{}	2025-10-15 21:45:00.044514+00
481	memory_usage	26.895761489868164	{}	2025-10-15 21:50:00.021768+00
482	memory_usage	26.912260055541992	{}	2025-10-15 21:50:00.026719+00
483	memory_usage	26.899194717407227	{}	2025-10-15 21:50:00.027109+00
484	memory_usage	26.912260055541992	{}	2025-10-15 21:50:00.027234+00
485	disk_usage	7	{}	2025-10-15 21:50:00.029158+00
486	whatsapp_success_rate	100	{}	2025-10-15 21:50:00.031957+00
487	disk_usage	7	{}	2025-10-15 21:50:00.034181+00
488	disk_usage	7	{}	2025-10-15 21:50:00.034293+00
489	sla_violation	2	{}	2025-10-15 21:50:00.034378+00
490	disk_usage	7	{}	2025-10-15 21:50:00.034612+00
491	whatsapp_success_rate	100	{}	2025-10-15 21:50:00.036883+00
492	whatsapp_success_rate	100	{}	2025-10-15 21:50:00.037108+00
493	whatsapp_success_rate	100	{}	2025-10-15 21:50:00.037129+00
494	sla_violation	2	{}	2025-10-15 21:50:00.039379+00
495	sla_violation	2	{}	2025-10-15 21:50:00.04007+00
496	sla_violation	2	{}	2025-10-15 21:50:00.040091+00
498	memory_usage	26.98521614074707	{}	2025-10-15 21:55:00.017766+00
497	memory_usage	26.982736587524414	{}	2025-10-15 21:55:00.017487+00
499	memory_usage	26.997041702270508	{}	2025-10-15 21:55:00.020187+00
500	disk_usage	7	{}	2025-10-15 21:55:00.023948+00
501	disk_usage	7	{}	2025-10-15 21:55:00.024524+00
502	disk_usage	7	{}	2025-10-15 21:55:00.026172+00
503	whatsapp_success_rate	100	{}	2025-10-15 21:55:00.027117+00
505	whatsapp_success_rate	100	{}	2025-10-15 21:55:00.027214+00
504	memory_usage	27.0416259765625	{}	2025-10-15 21:55:00.026786+00
506	whatsapp_success_rate	100	{}	2025-10-15 21:55:00.028967+00
507	sla_violation	2	{}	2025-10-15 21:55:00.029549+00
508	sla_violation	2	{}	2025-10-15 21:55:00.030013+00
509	sla_violation	2	{}	2025-10-15 21:55:00.032533+00
510	disk_usage	7	{}	2025-10-15 21:55:00.032684+00
511	whatsapp_success_rate	100	{}	2025-10-15 21:55:00.035828+00
512	sla_violation	2	{}	2025-10-15 21:55:00.039169+00
513	memory_usage	26.989269256591797	{}	2025-10-15 22:00:00.027446+00
514	memory_usage	26.986074447631836	{}	2025-10-15 22:00:00.028408+00
515	memory_usage	27.030563354492188	{}	2025-10-15 22:00:00.033375+00
516	memory_usage	27.024459838867188	{}	2025-10-15 22:00:00.034044+00
517	disk_usage	7	{}	2025-10-15 22:00:00.035979+00
518	disk_usage	7	{}	2025-10-15 22:00:00.036192+00
519	whatsapp_success_rate	100	{}	2025-10-15 22:00:00.040016+00
520	disk_usage	7	{}	2025-10-15 22:00:00.040683+00
521	whatsapp_success_rate	100	{}	2025-10-15 22:00:00.041436+00
522	disk_usage	7	{}	2025-10-15 22:00:00.041886+00
523	whatsapp_success_rate	100	{}	2025-10-15 22:00:00.044287+00
524	sla_violation	2	{}	2025-10-15 22:00:00.045297+00
525	sla_violation	2	{}	2025-10-15 22:00:00.04548+00
526	whatsapp_success_rate	100	{}	2025-10-15 22:00:00.045649+00
527	sla_violation	2	{}	2025-10-15 22:00:00.047674+00
528	sla_violation	2	{}	2025-10-15 22:00:00.049662+00
529	memory_usage	26.971101760864258	{}	2025-10-15 22:05:00.016856+00
530	memory_usage	26.971101760864258	{}	2025-10-15 22:05:00.017794+00
531	memory_usage	26.971101760864258	{}	2025-10-15 22:05:00.017959+00
532	memory_usage	26.981449127197266	{}	2025-10-15 22:05:00.01919+00
533	disk_usage	7	{}	2025-10-15 22:05:00.024046+00
534	disk_usage	7	{}	2025-10-15 22:05:00.024629+00
535	disk_usage	7	{}	2025-10-15 22:05:00.024771+00
536	disk_usage	7	{}	2025-10-15 22:05:00.025141+00
537	whatsapp_success_rate	100	{}	2025-10-15 22:05:00.0267+00
538	whatsapp_success_rate	100	{}	2025-10-15 22:05:00.027239+00
539	whatsapp_success_rate	100	{}	2025-10-15 22:05:00.027467+00
540	whatsapp_success_rate	100	{}	2025-10-15 22:05:00.027932+00
541	sla_violation	2	{}	2025-10-15 22:05:00.028913+00
542	sla_violation	2	{}	2025-10-15 22:05:00.02948+00
543	sla_violation	2	{}	2025-10-15 22:05:00.0298+00
544	sla_violation	2	{}	2025-10-15 22:05:00.030234+00
545	memory_usage	26.983261108398438	{}	2025-10-15 22:10:00.017456+00
546	memory_usage	26.983261108398438	{}	2025-10-15 22:10:00.018691+00
547	memory_usage	26.983261108398438	{}	2025-10-15 22:10:00.01882+00
548	memory_usage	27.018308639526367	{}	2025-10-15 22:10:00.021786+00
549	disk_usage	7	{}	2025-10-15 22:10:00.024854+00
550	disk_usage	7	{}	2025-10-15 22:10:00.025716+00
551	disk_usage	7	{}	2025-10-15 22:10:00.025725+00
552	disk_usage	7	{}	2025-10-15 22:10:00.027634+00
553	whatsapp_success_rate	100	{}	2025-10-15 22:10:00.028362+00
554	whatsapp_success_rate	100	{}	2025-10-15 22:10:00.029057+00
555	whatsapp_success_rate	100	{}	2025-10-15 22:10:00.029386+00
556	whatsapp_success_rate	100	{}	2025-10-15 22:10:00.031294+00
557	sla_violation	2	{}	2025-10-15 22:10:00.032274+00
558	sla_violation	2	{}	2025-10-15 22:10:00.032292+00
559	sla_violation	2	{}	2025-10-15 22:10:00.032463+00
560	sla_violation	2	{}	2025-10-15 22:10:00.033466+00
561	memory_usage	26.987171173095703	{}	2025-10-15 22:15:00.024737+00
562	memory_usage	26.987171173095703	{}	2025-10-15 22:15:00.025189+00
563	memory_usage	27.011537551879883	{}	2025-10-15 22:15:00.028246+00
564	disk_usage	7	{}	2025-10-15 22:15:00.032792+00
565	disk_usage	7	{}	2025-10-15 22:15:00.032836+00
567	disk_usage	7	{}	2025-10-15 22:15:00.034627+00
566	memory_usage	27.03542709350586	{}	2025-10-15 22:15:00.033652+00
568	whatsapp_success_rate	100	{}	2025-10-15 22:15:00.036125+00
569	whatsapp_success_rate	100	{}	2025-10-15 22:15:00.03628+00
570	whatsapp_success_rate	100	{}	2025-10-15 22:15:00.037681+00
571	sla_violation	2	{}	2025-10-15 22:15:00.038482+00
572	sla_violation	2	{}	2025-10-15 22:15:00.040088+00
573	sla_violation	2	{}	2025-10-15 22:15:00.040262+00
574	disk_usage	7	{}	2025-10-15 22:15:00.041195+00
575	whatsapp_success_rate	100	{}	2025-10-15 22:15:00.044541+00
576	sla_violation	2	{}	2025-10-15 22:15:00.046753+00
577	memory_usage	26.978015899658203	{}	2025-10-15 22:20:00.017676+00
578	memory_usage	26.978015899658203	{}	2025-10-15 22:20:00.017786+00
579	memory_usage	26.966238021850586	{}	2025-10-15 22:20:00.018993+00
580	memory_usage	26.966238021850586	{}	2025-10-15 22:20:00.019026+00
581	disk_usage	7	{}	2025-10-15 22:20:00.024859+00
582	disk_usage	7	{}	2025-10-15 22:20:00.024875+00
583	disk_usage	7	{}	2025-10-15 22:20:00.024999+00
584	disk_usage	7	{}	2025-10-15 22:20:00.025041+00
585	whatsapp_success_rate	100	{}	2025-10-15 22:20:00.027842+00
586	whatsapp_success_rate	100	{}	2025-10-15 22:20:00.02801+00
587	whatsapp_success_rate	100	{}	2025-10-15 22:20:00.028301+00
588	whatsapp_success_rate	100	{}	2025-10-15 22:20:00.028316+00
589	sla_violation	2	{}	2025-10-15 22:20:00.030718+00
590	sla_violation	2	{}	2025-10-15 22:20:00.031191+00
591	sla_violation	2	{}	2025-10-15 22:20:00.031193+00
1253	memory_usage	29.763460159301758	{}	2025-10-16 00:55:00.019492+00
1262	disk_usage	7	{}	2025-10-16 00:55:00.025711+00
1263	whatsapp_success_rate	100	{}	2025-10-16 00:55:00.028472+00
1264	sla_violation	2	{}	2025-10-16 00:55:00.030584+00
1361	memory_usage	32.68136978149414	{}	2025-10-16 01:11:20.285276+00
1362	disk_usage	7	{}	2025-10-16 01:11:20.296137+00
1363	whatsapp_success_rate	100	{}	2025-10-16 01:11:20.299177+00
1364	sla_violation	2	{}	2025-10-16 01:11:20.301763+00
1458	memory_usage	30.78465461730957	{}	2025-10-16 01:30:00.018526+00
1463	disk_usage	7	{}	2025-10-16 01:30:00.026827+00
1468	whatsapp_success_rate	100	{}	2025-10-16 01:30:00.029799+00
1472	sla_violation	2	{}	2025-10-16 01:30:00.032057+00
1555	memory_usage	30.272245407104492	{}	2025-10-16 01:50:00.010905+00
1559	disk_usage	7	{}	2025-10-16 01:50:00.01776+00
1561	whatsapp_success_rate	100	{}	2025-10-16 01:50:00.020495+00
1565	sla_violation	2	{}	2025-10-16 01:50:00.023173+00
1652	memory_usage	29.720449447631836	{}	2025-10-16 02:15:00.023893+00
1656	disk_usage	7	{}	2025-10-16 02:15:00.032462+00
1659	whatsapp_success_rate	100	{}	2025-10-16 02:15:00.034778+00
1661	sla_violation	2	{}	2025-10-16 02:15:00.036156+00
1761	memory_usage	29.407644271850586	{}	2025-10-16 02:50:00.017287+00
1765	disk_usage	7	{}	2025-10-16 02:50:00.024862+00
1769	whatsapp_success_rate	100	{}	2025-10-16 02:50:00.027546+00
1773	sla_violation	3	{}	2025-10-16 02:50:00.029952+00
1858	memory_usage	29.494333267211914	{}	2025-10-16 03:20:00.020272+00
1862	disk_usage	7	{}	2025-10-16 03:20:00.026832+00
1864	whatsapp_success_rate	100	{}	2025-10-16 03:20:00.029361+00
1868	sla_violation	3	{}	2025-10-16 03:20:00.031675+00
1955	memory_usage	29.880714416503906	{}	2025-10-16 03:45:00.023571+00
1961	disk_usage	7	{}	2025-10-16 03:45:00.031133+00
1965	whatsapp_success_rate	100	{}	2025-10-16 03:45:00.034864+00
1967	sla_violation	3	{}	2025-10-16 03:45:00.038211+00
2054	memory_usage	30.129432678222656	{}	2025-10-16 04:15:00.02753+00
2060	disk_usage	7	{}	2025-10-16 04:15:00.03667+00
2063	whatsapp_success_rate	100	{}	2025-10-16 04:15:00.040996+00
2064	sla_violation	3	{}	2025-10-16 04:15:00.043646+00
2161	memory_usage	30.215740203857422	{}	2025-10-16 04:45:00.020487+00
2165	disk_usage	7	{}	2025-10-16 04:45:00.032342+00
2168	whatsapp_success_rate	100	{}	2025-10-16 04:45:00.035366+00
2171	sla_violation	3	{}	2025-10-16 04:45:00.037996+00
2258	memory_usage	29.86459732055664	{}	2025-10-16 05:15:00.029342+00
2261	disk_usage	7	{}	2025-10-16 05:15:00.035841+00
2264	whatsapp_success_rate	100	{}	2025-10-16 05:15:00.040267+00
2267	sla_violation	3	{}	2025-10-16 05:15:00.042758+00
2355	memory_usage	18.360137939453125	{}	2025-10-16 05:45:00.031224+00
2359	disk_usage	7	{}	2025-10-16 05:45:00.03842+00
2363	whatsapp_success_rate	100	{}	2025-10-16 05:45:00.042206+00
2368	sla_violation	3	{}	2025-10-16 05:45:00.045177+00
2452	memory_usage	18.31369400024414	{}	2025-10-16 06:15:00.030841+00
2457	disk_usage	7	{}	2025-10-16 06:15:00.039053+00
2461	whatsapp_success_rate	100	{}	2025-10-16 06:15:00.042594+00
2464	sla_violation	3	{}	2025-10-16 06:15:00.045254+00
2561	memory_usage	18.27244758605957	{}	2025-10-16 06:50:00.017864+00
2566	disk_usage	7	{}	2025-10-16 06:50:00.025489+00
2568	whatsapp_success_rate	100	{}	2025-10-16 06:50:00.028342+00
2571	sla_violation	3	{}	2025-10-16 06:50:00.030488+00
2658	memory_usage	18.346357345581055	{}	2025-10-16 07:20:00.018014+00
2662	disk_usage	7	{}	2025-10-16 07:20:00.024715+00
2666	whatsapp_success_rate	100	{}	2025-10-16 07:20:00.028899+00
2670	sla_violation	3	{}	2025-10-16 07:20:00.031187+00
2756	memory_usage	18.312597274780273	{}	2025-10-16 07:50:00.018959+00
2760	disk_usage	7	{}	2025-10-16 07:50:00.026111+00
2764	whatsapp_success_rate	100	{}	2025-10-16 07:50:00.028848+00
2768	sla_violation	3	{}	2025-10-16 07:50:00.031349+00
2865	memory_usage	18.39776039123535	{}	2025-10-16 08:25:00.017574+00
2869	disk_usage	7	{}	2025-10-16 08:25:00.025026+00
2873	whatsapp_success_rate	100	{}	2025-10-16 08:25:00.028065+00
2877	sla_violation	3	{}	2025-10-16 08:25:00.030646+00
2962	memory_usage	18.38226318359375	{}	2025-10-16 08:55:00.018754+00
2966	disk_usage	7	{}	2025-10-16 08:55:00.025773+00
2970	whatsapp_success_rate	100	{}	2025-10-16 08:55:00.028448+00
2974	sla_violation	3	{}	2025-10-16 08:55:00.030787+00
3059	memory_usage	18.489646911621094	{}	2025-10-16 09:25:00.02521+00
3063	disk_usage	7	{}	2025-10-16 09:25:00.032841+00
3066	whatsapp_success_rate	100	{}	2025-10-16 09:25:00.035838+00
3070	sla_violation	3	{}	2025-10-16 09:25:00.039021+00
3154	memory_usage	18.47710609436035	{}	2025-10-16 09:55:00.018868+00
3159	disk_usage	7	{}	2025-10-16 09:55:00.026404+00
3162	whatsapp_success_rate	100	{}	2025-10-16 09:55:00.028954+00
3166	sla_violation	3	{}	2025-10-16 09:55:00.03146+00
3233	memory_usage	18.483257293701172	{}	2025-10-16 10:20:00.019615+00
3236	disk_usage	7	{}	2025-10-16 10:20:00.027008+00
3240	whatsapp_success_rate	100	{}	2025-10-16 10:20:00.030913+00
3243	sla_violation	3	{}	2025-10-16 10:20:00.033319+00
3268	memory_usage	18.48583221435547	{}	2025-10-16 10:30:00.030691+00
3273	disk_usage	7	{}	2025-10-16 10:30:00.037663+00
3277	whatsapp_success_rate	100	{}	2025-10-16 10:30:00.040755+00
3280	sla_violation	3	{}	2025-10-16 10:30:00.043295+00
3297	memory_usage	18.501996994018555	{}	2025-10-16 10:40:00.017332+00
3301	disk_usage	7	{}	2025-10-16 10:40:00.024236+00
3305	whatsapp_success_rate	100	{}	2025-10-16 10:40:00.026897+00
3309	sla_violation	3	{}	2025-10-16 10:40:00.029464+00
3314	memory_usage	18.461227416992188	{}	2025-10-16 10:45:00.030351+00
3318	disk_usage	7	{}	2025-10-16 10:45:00.039086+00
3320	whatsapp_success_rate	100	{}	2025-10-16 10:45:00.041668+00
3324	sla_violation	3	{}	2025-10-16 10:45:00.044278+00
3331	memory_usage	18.450260162353516	{}	2025-10-16 10:50:00.018176+00
3335	disk_usage	7	{}	2025-10-16 10:50:00.025586+00
3338	whatsapp_success_rate	100	{}	2025-10-16 10:50:00.02823+00
3342	sla_violation	3	{}	2025-10-16 10:50:00.030704+00
3350	memory_usage	18.488454818725586	{}	2025-10-16 10:55:00.026779+00
3355	disk_usage	7	{}	2025-10-16 10:55:00.033561+00
3357	whatsapp_success_rate	100	{}	2025-10-16 10:55:00.035999+00
3359	sla_violation	3	{}	2025-10-16 10:55:00.038286+00
3362	memory_usage	18.471479415893555	{}	2025-10-16 11:00:00.030038+00
3366	disk_usage	7	{}	2025-10-16 11:00:00.03693+00
3367	whatsapp_success_rate	100	{}	2025-10-16 11:00:00.039652+00
3369	sla_violation	3	{}	2025-10-16 11:00:00.041944+00
3377	memory_usage	18.46323013305664	{}	2025-10-16 11:05:00.017935+00
3380	memory_usage	18.46323013305664	{}	2025-10-16 11:05:00.019823+00
3383	disk_usage	7	{}	2025-10-16 11:05:00.025956+00
3384	disk_usage	7	{}	2025-10-16 11:05:00.026+00
593	memory_usage	26.978254318237305	{}	2025-10-15 22:25:00.017455+00
597	disk_usage	7	{}	2025-10-15 22:25:00.024571+00
601	whatsapp_success_rate	100	{}	2025-10-15 22:25:00.027461+00
605	sla_violation	2	{}	2025-10-15 22:25:00.029784+00
673	memory_usage	28.644990921020508	{}	2025-10-15 22:43:21.558651+00
674	disk_usage	7	{}	2025-10-15 22:43:21.565728+00
675	whatsapp_success_rate	100	{}	2025-10-15 22:43:21.568059+00
676	sla_violation	2	{}	2025-10-15 22:43:21.569733+00
753	memory_usage	30.460071563720703	{}	2025-10-15 22:55:20.088317+00
754	disk_usage	7	{}	2025-10-15 22:55:20.095793+00
755	whatsapp_success_rate	100	{}	2025-10-15 22:55:20.09829+00
756	sla_violation	2	{}	2025-10-15 22:55:20.099843+00
833	memory_usage	30.14359474182129	{}	2025-10-15 23:06:54.824944+00
834	disk_usage	7	{}	2025-10-15 23:06:54.832299+00
835	whatsapp_success_rate	100	{}	2025-10-15 23:06:54.835117+00
836	sla_violation	2	{}	2025-10-15 23:06:54.837457+00
913	memory_usage	27.89015769958496	{}	2025-10-15 23:25:00.013669+00
916	disk_usage	7	{}	2025-10-15 23:25:00.02226+00
919	whatsapp_success_rate	100	{}	2025-10-15 23:25:00.026177+00
923	sla_violation	2	{}	2025-10-15 23:25:00.030873+00
993	memory_usage	28.31110954284668	{}	2025-10-15 23:50:00.01245+00
995	disk_usage	7	{}	2025-10-15 23:50:00.018847+00
998	whatsapp_success_rate	100	{}	2025-10-15 23:50:00.021167+00
1001	sla_violation	2	{}	2025-10-15 23:50:00.022798+00
1073	memory_usage	31.798505783081055	{}	2025-10-16 00:14:56.283853+00
1074	disk_usage	7	{}	2025-10-16 00:14:56.291475+00
1075	whatsapp_success_rate	100	{}	2025-10-16 00:14:56.29378+00
1076	sla_violation	2	{}	2025-10-16 00:14:56.295458+00
1156	memory_usage	29.91199493408203	{}	2025-10-16 00:35:00.015606+00
1164	disk_usage	7	{}	2025-10-16 00:35:00.021166+00
1167	whatsapp_success_rate	100	{}	2025-10-16 00:35:00.025257+00
1168	sla_violation	2	{}	2025-10-16 00:35:00.028454+00
1265	memory_usage	32.15165138244629	{}	2025-10-16 00:56:13.493196+00
1267	disk_usage	7	{}	2025-10-16 00:56:13.501665+00
1268	whatsapp_success_rate	100	{}	2025-10-16 00:56:13.504374+00
1270	sla_violation	2	{}	2025-10-16 00:56:13.506546+00
1365	memory_usage	32.73673057556152	{}	2025-10-16 01:11:20.308665+00
1366	disk_usage	7	{}	2025-10-16 01:11:20.31547+00
1367	whatsapp_success_rate	100	{}	2025-10-16 01:11:20.317839+00
1368	sla_violation	2	{}	2025-10-16 01:11:20.319441+00
1459	memory_usage	30.785512924194336	{}	2025-10-16 01:30:00.018596+00
1462	disk_usage	7	{}	2025-10-16 01:30:00.026669+00
1466	whatsapp_success_rate	100	{}	2025-10-16 01:30:00.028896+00
1471	sla_violation	2	{}	2025-10-16 01:30:00.031093+00
1556	memory_usage	30.28879165649414	{}	2025-10-16 01:50:00.015305+00
1563	disk_usage	7	{}	2025-10-16 01:50:00.021555+00
1567	whatsapp_success_rate	100	{}	2025-10-16 01:50:00.025416+00
1568	sla_violation	2	{}	2025-10-16 01:50:00.027637+00
1665	memory_usage	29.63266372680664	{}	2025-10-16 02:20:00.010201+00
1669	disk_usage	7	{}	2025-10-16 02:20:00.017198+00
1674	whatsapp_success_rate	100	{}	2025-10-16 02:20:00.020529+00
1676	sla_violation	2	{}	2025-10-16 02:20:00.023826+00
1762	memory_usage	29.40692901611328	{}	2025-10-16 02:50:00.017811+00
1766	disk_usage	7	{}	2025-10-16 02:50:00.024985+00
1770	whatsapp_success_rate	100	{}	2025-10-16 02:50:00.027726+00
1774	sla_violation	3	{}	2025-10-16 02:50:00.030648+00
1859	memory_usage	29.5194149017334	{}	2025-10-16 03:20:00.023556+00
1865	disk_usage	7	{}	2025-10-16 03:20:00.030475+00
1869	whatsapp_success_rate	100	{}	2025-10-16 03:20:00.033122+00
1871	sla_violation	3	{}	2025-10-16 03:20:00.035531+00
1956	memory_usage	29.874038696289062	{}	2025-10-16 03:45:00.025823+00
1964	disk_usage	7	{}	2025-10-16 03:45:00.03211+00
1966	whatsapp_success_rate	100	{}	2025-10-16 03:45:00.035531+00
1968	sla_violation	3	{}	2025-10-16 03:45:00.038982+00
2065	memory_usage	30.13129234313965	{}	2025-10-16 04:20:00.008827+00
2067	disk_usage	7	{}	2025-10-16 04:20:00.015277+00
2071	whatsapp_success_rate	100	{}	2025-10-16 04:20:00.018177+00
2074	sla_violation	3	{}	2025-10-16 04:20:00.020928+00
2162	memory_usage	30.212736129760742	{}	2025-10-16 04:45:00.022019+00
2167	disk_usage	7	{}	2025-10-16 04:45:00.033127+00
2170	whatsapp_success_rate	100	{}	2025-10-16 04:45:00.03681+00
2174	sla_violation	3	{}	2025-10-16 04:45:00.039737+00
2260	memory_usage	29.895448684692383	{}	2025-10-16 05:15:00.034588+00
2265	disk_usage	7	{}	2025-10-16 05:15:00.041512+00
2269	whatsapp_success_rate	100	{}	2025-10-16 05:15:00.043924+00
2270	sla_violation	3	{}	2025-10-16 05:15:00.046954+00
2356	memory_usage	18.357467651367188	{}	2025-10-16 05:45:00.032621+00
2361	disk_usage	7	{}	2025-10-16 05:45:00.039585+00
2364	whatsapp_success_rate	100	{}	2025-10-16 05:45:00.042754+00
2367	sla_violation	3	{}	2025-10-16 05:45:00.044963+00
2465	memory_usage	18.281841278076172	{}	2025-10-16 06:20:00.017443+00
2469	disk_usage	7	{}	2025-10-16 06:20:00.024693+00
2473	whatsapp_success_rate	100	{}	2025-10-16 06:20:00.027232+00
2477	sla_violation	3	{}	2025-10-16 06:20:00.029415+00
2562	memory_usage	18.27249526977539	{}	2025-10-16 06:50:00.01797+00
2565	disk_usage	7	{}	2025-10-16 06:50:00.025114+00
2567	whatsapp_success_rate	100	{}	2025-10-16 06:50:00.027755+00
2570	sla_violation	3	{}	2025-10-16 06:50:00.029972+00
2659	memory_usage	18.346357345581055	{}	2025-10-16 07:20:00.020852+00
2663	disk_usage	7	{}	2025-10-16 07:20:00.027309+00
2667	whatsapp_success_rate	100	{}	2025-10-16 07:20:00.029966+00
2671	sla_violation	3	{}	2025-10-16 07:20:00.032252+00
2769	memory_usage	18.33491325378418	{}	2025-10-16 07:55:00.01841+00
2776	disk_usage	7	{}	2025-10-16 07:55:00.026588+00
2779	whatsapp_success_rate	100	{}	2025-10-16 07:55:00.029539+00
2783	sla_violation	3	{}	2025-10-16 07:55:00.031687+00
2866	memory_usage	18.39776039123535	{}	2025-10-16 08:25:00.0178+00
2871	disk_usage	7	{}	2025-10-16 08:25:00.025703+00
2875	whatsapp_success_rate	100	{}	2025-10-16 08:25:00.029389+00
2879	sla_violation	3	{}	2025-10-16 08:25:00.032649+00
2963	memory_usage	18.38679313659668	{}	2025-10-16 08:55:00.01927+00
2968	disk_usage	7	{}	2025-10-16 08:55:00.026564+00
2972	whatsapp_success_rate	100	{}	2025-10-16 08:55:00.029915+00
2976	sla_violation	3	{}	2025-10-16 08:55:00.03271+00
3060	memory_usage	18.489646911621094	{}	2025-10-16 09:25:00.031189+00
3068	disk_usage	7	{}	2025-10-16 09:25:00.037482+00
3071	whatsapp_success_rate	100	{}	2025-10-16 09:25:00.041041+00
3072	sla_violation	3	{}	2025-10-16 09:25:00.043189+00
3155	memory_usage	18.47710609436035	{}	2025-10-16 09:55:00.019315+00
3158	disk_usage	7	{}	2025-10-16 09:55:00.026005+00
3163	whatsapp_success_rate	100	{}	2025-10-16 09:55:00.029044+00
3167	sla_violation	3	{}	2025-10-16 09:55:00.03159+00
3234	memory_usage	18.483257293701172	{}	2025-10-16 10:20:00.019448+00
594	memory_usage	26.978254318237305	{}	2025-10-15 22:25:00.01807+00
598	disk_usage	7	{}	2025-10-15 22:25:00.024937+00
603	whatsapp_success_rate	100	{}	2025-10-15 22:25:00.02786+00
607	sla_violation	2	{}	2025-10-15 22:25:00.030286+00
677	memory_usage	28.647804260253906	{}	2025-10-15 22:43:21.608764+00
678	disk_usage	7	{}	2025-10-15 22:43:21.617059+00
679	whatsapp_success_rate	100	{}	2025-10-15 22:43:21.6202+00
680	sla_violation	2	{}	2025-10-15 22:43:21.622803+00
757	memory_usage	30.479955673217773	{}	2025-10-15 22:55:20.105985+00
758	disk_usage	7	{}	2025-10-15 22:55:20.112827+00
759	whatsapp_success_rate	100	{}	2025-10-15 22:55:20.115277+00
760	sla_violation	2	{}	2025-10-15 22:55:20.117019+00
837	memory_usage	30.15604019165039	{}	2025-10-15 23:06:54.83802+00
838	disk_usage	7	{}	2025-10-15 23:06:54.845036+00
839	whatsapp_success_rate	100	{}	2025-10-15 23:06:54.847419+00
840	sla_violation	2	{}	2025-10-15 23:06:54.848964+00
914	memory_usage	27.900028228759766	{}	2025-10-15 23:25:00.015648+00
918	disk_usage	7	{}	2025-10-15 23:25:00.026118+00
920	whatsapp_success_rate	100	{}	2025-10-15 23:25:00.028529+00
922	sla_violation	2	{}	2025-10-15 23:25:00.030874+00
994	memory_usage	28.316831588745117	{}	2025-10-15 23:50:00.012885+00
996	disk_usage	7	{}	2025-10-15 23:50:00.019255+00
999	whatsapp_success_rate	100	{}	2025-10-15 23:50:00.021303+00
1002	sla_violation	2	{}	2025-10-15 23:50:00.023142+00
1077	memory_usage	31.805801391601562	{}	2025-10-16 00:14:56.333673+00
1078	disk_usage	7	{}	2025-10-16 00:14:56.341997+00
1079	whatsapp_success_rate	100	{}	2025-10-16 00:14:56.344987+00
1080	sla_violation	2	{}	2025-10-16 00:14:56.347554+00
1090	memory_usage	31.93187713623047	{}	2025-10-16 00:15:00.021582+00
1094	disk_usage	7	{}	2025-10-16 00:15:00.02954+00
1097	whatsapp_success_rate	100	{}	2025-10-16 00:15:00.031339+00
1100	sla_violation	2	{}	2025-10-16 00:15:00.032629+00
1169	memory_usage	32.036638259887695	{}	2025-10-16 00:39:44.179536+00
1171	disk_usage	7	{}	2025-10-16 00:39:44.191708+00
1172	whatsapp_success_rate	100	{}	2025-10-16 00:39:44.196231+00
1174	sla_violation	2	{}	2025-10-16 00:39:44.199248+00
1266	memory_usage	32.14874267578125	{}	2025-10-16 00:56:13.496935+00
1269	disk_usage	7	{}	2025-10-16 00:56:13.504551+00
1271	whatsapp_success_rate	100	{}	2025-10-16 00:56:13.507585+00
1272	sla_violation	2	{}	2025-10-16 00:56:13.509826+00
1369	memory_usage	32.79547691345215	{}	2025-10-16 01:11:20.430526+00
1370	disk_usage	7	{}	2025-10-16 01:11:20.437553+00
1371	whatsapp_success_rate	100	{}	2025-10-16 01:11:20.439869+00
1372	sla_violation	2	{}	2025-10-16 01:11:20.441355+00
1460	memory_usage	30.793476104736328	{}	2025-10-16 01:30:00.019756+00
1464	disk_usage	7	{}	2025-10-16 01:30:00.026882+00
1467	whatsapp_success_rate	100	{}	2025-10-16 01:30:00.029528+00
1470	sla_violation	2	{}	2025-10-16 01:30:00.030984+00
1569	memory_usage	29.474639892578125	{}	2025-10-16 01:55:00.011056+00
1573	disk_usage	7	{}	2025-10-16 01:55:00.017245+00
1576	whatsapp_success_rate	100	{}	2025-10-16 01:55:00.019648+00
1579	sla_violation	2	{}	2025-10-16 01:55:00.021958+00
1666	memory_usage	29.63266372680664	{}	2025-10-16 02:20:00.010546+00
1668	disk_usage	7	{}	2025-10-16 02:20:00.017091+00
1672	whatsapp_success_rate	100	{}	2025-10-16 02:20:00.020166+00
1675	sla_violation	2	{}	2025-10-16 02:20:00.022523+00
1763	memory_usage	29.40692901611328	{}	2025-10-16 02:50:00.01782+00
1768	disk_usage	7	{}	2025-10-16 02:50:00.025937+00
1772	whatsapp_success_rate	100	{}	2025-10-16 02:50:00.028699+00
1775	sla_violation	3	{}	2025-10-16 02:50:00.031274+00
1860	memory_usage	29.520559310913086	{}	2025-10-16 03:20:00.023627+00
1866	disk_usage	7	{}	2025-10-16 03:20:00.030804+00
1870	whatsapp_success_rate	100	{}	2025-10-16 03:20:00.033377+00
1872	sla_violation	3	{}	2025-10-16 03:20:00.036096+00
1969	memory_usage	29.74071502685547	{}	2025-10-16 03:50:00.011354+00
1971	disk_usage	7	{}	2025-10-16 03:50:00.018617+00
1974	whatsapp_success_rate	100	{}	2025-10-16 03:50:00.021189+00
1976	sla_violation	3	{}	2025-10-16 03:50:00.026478+00
2066	memory_usage	30.13439178466797	{}	2025-10-16 04:20:00.009461+00
2068	disk_usage	7	{}	2025-10-16 04:20:00.015369+00
2070	whatsapp_success_rate	100	{}	2025-10-16 04:20:00.01786+00
2072	sla_violation	3	{}	2025-10-16 04:20:00.020306+00
2163	memory_usage	30.212736129760742	{}	2025-10-16 04:45:00.022238+00
2166	disk_usage	7	{}	2025-10-16 04:45:00.03266+00
2169	whatsapp_success_rate	100	{}	2025-10-16 04:45:00.036102+00
2172	sla_violation	3	{}	2025-10-16 04:45:00.038959+00
2262	memory_usage	29.90412712097168	{}	2025-10-16 05:15:00.037102+00
2268	disk_usage	7	{}	2025-10-16 05:15:00.043919+00
2271	whatsapp_success_rate	100	{}	2025-10-16 05:15:00.047369+00
2272	sla_violation	3	{}	2025-10-16 05:15:00.051056+00
2369	memory_usage	18.15347671508789	{}	2025-10-16 05:50:00.022509+00
2371	disk_usage	7	{}	2025-10-16 05:50:00.031808+00
2375	whatsapp_success_rate	100	{}	2025-10-16 05:50:00.03569+00
2377	sla_violation	3	{}	2025-10-16 05:50:00.037997+00
2466	memory_usage	18.281841278076172	{}	2025-10-16 06:20:00.018243+00
2470	disk_usage	7	{}	2025-10-16 06:20:00.025003+00
2474	whatsapp_success_rate	100	{}	2025-10-16 06:20:00.028203+00
2478	sla_violation	3	{}	2025-10-16 06:20:00.030526+00
2563	memory_usage	18.300962448120117	{}	2025-10-16 06:50:00.023123+00
2569	disk_usage	7	{}	2025-10-16 06:50:00.029889+00
2573	whatsapp_success_rate	100	{}	2025-10-16 06:50:00.032478+00
2575	sla_violation	3	{}	2025-10-16 06:50:00.034766+00
2660	memory_usage	18.348169326782227	{}	2025-10-16 07:20:00.022119+00
2665	disk_usage	7	{}	2025-10-16 07:20:00.028292+00
2669	whatsapp_success_rate	100	{}	2025-10-16 07:20:00.031028+00
2672	sla_violation	3	{}	2025-10-16 07:20:00.03368+00
2770	memory_usage	18.33491325378418	{}	2025-10-16 07:55:00.018411+00
2773	disk_usage	7	{}	2025-10-16 07:55:00.025615+00
2777	whatsapp_success_rate	100	{}	2025-10-16 07:55:00.028361+00
2781	sla_violation	3	{}	2025-10-16 07:55:00.030641+00
2867	memory_usage	18.39776039123535	{}	2025-10-16 08:25:00.018434+00
2870	disk_usage	7	{}	2025-10-16 08:25:00.025512+00
2874	whatsapp_success_rate	100	{}	2025-10-16 08:25:00.028682+00
2878	sla_violation	3	{}	2025-10-16 08:25:00.03123+00
2964	memory_usage	18.38679313659668	{}	2025-10-16 08:55:00.020159+00
2967	disk_usage	7	{}	2025-10-16 08:55:00.026603+00
2971	whatsapp_success_rate	100	{}	2025-10-16 08:55:00.02892+00
2975	sla_violation	3	{}	2025-10-16 08:55:00.031168+00
3073	memory_usage	18.47095489501953	{}	2025-10-16 09:30:00.026976+00
3076	disk_usage	7	{}	2025-10-16 09:30:00.034873+00
3079	whatsapp_success_rate	100	{}	2025-10-16 09:30:00.03767+00
3081	sla_violation	3	{}	2025-10-16 09:30:00.040317+00
3156	memory_usage	18.47710609436035	{}	2025-10-16 09:55:00.021365+00
595	memory_usage	26.98383331298828	{}	2025-10-15 22:25:00.018705+00
599	disk_usage	7	{}	2025-10-15 22:25:00.02512+00
602	whatsapp_success_rate	100	{}	2025-10-15 22:25:00.027843+00
606	sla_violation	2	{}	2025-10-15 22:25:00.030282+00
681	memory_usage	28.71551513671875	{}	2025-10-15 22:43:21.687547+00
682	disk_usage	7	{}	2025-10-15 22:43:21.694709+00
683	whatsapp_success_rate	100	{}	2025-10-15 22:43:21.697646+00
684	sla_violation	2	{}	2025-10-15 22:43:21.70062+00
761	memory_usage	30.501556396484375	{}	2025-10-15 22:55:20.25638+00
763	disk_usage	7	{}	2025-10-15 22:55:20.264929+00
764	whatsapp_success_rate	100	{}	2025-10-15 22:55:20.268044+00
765	sla_violation	2	{}	2025-10-15 22:55:20.270565+00
841	memory_usage	30.212783813476562	{}	2025-10-15 23:06:54.96362+00
842	disk_usage	7	{}	2025-10-15 23:06:54.971514+00
843	whatsapp_success_rate	100	{}	2025-10-15 23:06:54.974495+00
844	sla_violation	2	{}	2025-10-15 23:06:54.977141+00
915	memory_usage	27.873992919921875	{}	2025-10-15 23:25:00.021389+00
921	disk_usage	7	{}	2025-10-15 23:25:00.030822+00
925	whatsapp_success_rate	100	{}	2025-10-15 23:25:00.033853+00
927	sla_violation	2	{}	2025-10-15 23:25:00.036415+00
997	memory_usage	28.31110954284668	{}	2025-10-15 23:50:00.019951+00
1003	disk_usage	7	{}	2025-10-15 23:50:00.026589+00
1005	whatsapp_success_rate	100	{}	2025-10-15 23:50:00.029095+00
1007	sla_violation	2	{}	2025-10-15 23:50:00.031446+00
1081	memory_usage	31.891393661499023	{}	2025-10-16 00:14:56.39725+00
1082	disk_usage	7	{}	2025-10-16 00:14:56.405703+00
1084	whatsapp_success_rate	100	{}	2025-10-16 00:14:56.409284+00
1085	sla_violation	2	{}	2025-10-16 00:14:56.4124+00
1089	memory_usage	31.936931610107422	{}	2025-10-16 00:15:00.020651+00
1092	disk_usage	7	{}	2025-10-16 00:15:00.028985+00
1095	whatsapp_success_rate	100	{}	2025-10-16 00:15:00.030428+00
1098	sla_violation	2	{}	2025-10-16 00:15:00.031715+00
1170	memory_usage	32.03239440917969	{}	2025-10-16 00:39:44.188726+00
1173	disk_usage	7	{}	2025-10-16 00:39:44.198425+00
1175	whatsapp_success_rate	100	{}	2025-10-16 00:39:44.202751+00
1176	sla_violation	2	{}	2025-10-16 00:39:44.206434+00
1273	memory_usage	32.196903228759766	{}	2025-10-16 00:56:13.618322+00
1274	disk_usage	7	{}	2025-10-16 00:56:13.630212+00
1275	whatsapp_success_rate	100	{}	2025-10-16 00:56:13.632758+00
1277	sla_violation	2	{}	2025-10-16 00:56:13.63431+00
1373	memory_usage	32.790184020996094	{}	2025-10-16 01:11:20.477135+00
1374	disk_usage	7	{}	2025-10-16 01:11:20.487757+00
1375	whatsapp_success_rate	100	{}	2025-10-16 01:11:20.490729+00
1376	sla_violation	2	{}	2025-10-16 01:11:20.493231+00
1473	memory_usage	32.96775817871094	{}	2025-10-16 01:31:34.375737+00
1474	disk_usage	7	{}	2025-10-16 01:31:34.383964+00
1475	whatsapp_success_rate	100	{}	2025-10-16 01:31:34.387546+00
1476	sla_violation	2	{}	2025-10-16 01:31:34.389984+00
1570	memory_usage	29.474687576293945	{}	2025-10-16 01:55:00.011047+00
1574	disk_usage	7	{}	2025-10-16 01:55:00.018091+00
1577	whatsapp_success_rate	100	{}	2025-10-16 01:55:00.020647+00
1581	sla_violation	2	{}	2025-10-16 01:55:00.022724+00
1667	memory_usage	29.63266372680664	{}	2025-10-16 02:20:00.010456+00
1670	disk_usage	7	{}	2025-10-16 02:20:00.017486+00
1673	whatsapp_success_rate	100	{}	2025-10-16 02:20:00.020519+00
1677	sla_violation	2	{}	2025-10-16 02:20:00.023831+00
1764	memory_usage	29.40692901611328	{}	2025-10-16 02:50:00.019918+00
1767	disk_usage	7	{}	2025-10-16 02:50:00.025847+00
1771	whatsapp_success_rate	100	{}	2025-10-16 02:50:00.028445+00
1776	sla_violation	3	{}	2025-10-16 02:50:00.03189+00
1873	memory_usage	29.52437400817871	{}	2025-10-16 03:25:00.017252+00
1876	disk_usage	7	{}	2025-10-16 03:25:00.024538+00
1880	whatsapp_success_rate	100	{}	2025-10-16 03:25:00.027559+00
1883	sla_violation	3	{}	2025-10-16 03:25:00.029896+00
1970	memory_usage	29.749011993408203	{}	2025-10-16 03:50:00.015404+00
1975	disk_usage	7	{}	2025-10-16 03:50:00.022354+00
1978	whatsapp_success_rate	100	{}	2025-10-16 03:50:00.026896+00
1980	sla_violation	3	{}	2025-10-16 03:50:00.03091+00
2069	memory_usage	30.13129234313965	{}	2025-10-16 04:20:00.016915+00
2075	disk_usage	7	{}	2025-10-16 04:20:00.023912+00
2076	whatsapp_success_rate	100	{}	2025-10-16 04:20:00.026416+00
2078	sla_violation	3	{}	2025-10-16 04:20:00.028659+00
2164	memory_usage	30.22313117980957	{}	2025-10-16 04:45:00.027351+00
2173	disk_usage	7	{}	2025-10-16 04:45:00.039585+00
2175	whatsapp_success_rate	100	{}	2025-10-16 04:45:00.044578+00
2176	sla_violation	3	{}	2025-10-16 04:45:00.05123+00
2273	memory_usage	29.836606979370117	{}	2025-10-16 05:20:00.018798+00
2276	disk_usage	7	{}	2025-10-16 05:20:00.027179+00
2278	whatsapp_success_rate	100	{}	2025-10-16 05:20:00.029926+00
2282	sla_violation	3	{}	2025-10-16 05:20:00.032416+00
2370	memory_usage	18.16701889038086	{}	2025-10-16 05:50:00.027939+00
2374	disk_usage	7	{}	2025-10-16 05:50:00.03524+00
2376	whatsapp_success_rate	100	{}	2025-10-16 05:50:00.037999+00
2379	sla_violation	3	{}	2025-10-16 05:50:00.040454+00
2467	memory_usage	18.281841278076172	{}	2025-10-16 06:20:00.018802+00
2472	disk_usage	7	{}	2025-10-16 06:20:00.026109+00
2476	whatsapp_success_rate	100	{}	2025-10-16 06:20:00.028877+00
2480	sla_violation	3	{}	2025-10-16 06:20:00.031196+00
2564	memory_usage	18.301105499267578	{}	2025-10-16 06:50:00.024662+00
2572	disk_usage	7	{}	2025-10-16 06:50:00.030635+00
2574	whatsapp_success_rate	100	{}	2025-10-16 06:50:00.033305+00
2576	sla_violation	3	{}	2025-10-16 06:50:00.036007+00
2673	memory_usage	18.326473236083984	{}	2025-10-16 07:25:00.017872+00
2677	disk_usage	7	{}	2025-10-16 07:25:00.024976+00
2680	whatsapp_success_rate	100	{}	2025-10-16 07:25:00.02836+00
2684	sla_violation	3	{}	2025-10-16 07:25:00.030687+00
2771	memory_usage	18.33491325378418	{}	2025-10-16 07:55:00.019239+00
2774	disk_usage	7	{}	2025-10-16 07:55:00.026448+00
2778	whatsapp_success_rate	100	{}	2025-10-16 07:55:00.028932+00
2782	sla_violation	3	{}	2025-10-16 07:55:00.031021+00
2868	memory_usage	18.40214729309082	{}	2025-10-16 08:25:00.018889+00
2872	disk_usage	7	{}	2025-10-16 08:25:00.027009+00
2876	whatsapp_success_rate	100	{}	2025-10-16 08:25:00.029704+00
2880	sla_violation	3	{}	2025-10-16 08:25:00.032668+00
2977	memory_usage	18.399333953857422	{}	2025-10-16 09:00:00.026072+00
2980	disk_usage	7	{}	2025-10-16 09:00:00.035544+00
2982	whatsapp_success_rate	100	{}	2025-10-16 09:00:00.039105+00
2985	sla_violation	3	{}	2025-10-16 09:00:00.041675+00
3074	memory_usage	18.467330932617188	{}	2025-10-16 09:30:00.029464+00
3077	disk_usage	7	{}	2025-10-16 09:30:00.036608+00
3080	whatsapp_success_rate	100	{}	2025-10-16 09:30:00.040265+00
3083	sla_violation	3	{}	2025-10-16 09:30:00.043079+00
3160	disk_usage	7	{}	2025-10-16 09:55:00.027338+00
596	memory_usage	26.978254318237305	{}	2025-10-15 22:25:00.018843+00
600	disk_usage	7	{}	2025-10-15 22:25:00.025509+00
604	whatsapp_success_rate	100	{}	2025-10-15 22:25:00.028059+00
608	sla_violation	2	{}	2025-10-15 22:25:00.030571+00
685	memory_usage	28.7442684173584	{}	2025-10-15 22:43:21.70271+00
686	disk_usage	7	{}	2025-10-15 22:43:21.713674+00
687	whatsapp_success_rate	100	{}	2025-10-15 22:43:21.716658+00
688	sla_violation	2	{}	2025-10-15 22:43:21.71971+00
762	memory_usage	30.548667907714844	{}	2025-10-15 22:55:20.262722+00
766	disk_usage	7	{}	2025-10-15 22:55:20.270918+00
767	whatsapp_success_rate	100	{}	2025-10-15 22:55:20.273571+00
768	sla_violation	2	{}	2025-10-15 22:55:20.275405+00
845	memory_usage	30.24277687072754	{}	2025-10-15 23:06:54.98423+00
846	disk_usage	7	{}	2025-10-15 23:06:54.99179+00
847	whatsapp_success_rate	100	{}	2025-10-15 23:06:54.995134+00
848	sla_violation	2	{}	2025-10-15 23:06:54.997575+00
917	memory_usage	27.870941162109375	{}	2025-10-15 23:25:00.023664+00
924	disk_usage	7	{}	2025-10-15 23:25:00.031805+00
926	whatsapp_success_rate	100	{}	2025-10-15 23:25:00.035891+00
928	sla_violation	2	{}	2025-10-15 23:25:00.039071+00
1000	memory_usage	28.31110954284668	{}	2025-10-15 23:50:00.021009+00
1004	disk_usage	7	{}	2025-10-15 23:50:00.028371+00
1006	whatsapp_success_rate	100	{}	2025-10-15 23:50:00.030901+00
1008	sla_violation	2	{}	2025-10-15 23:50:00.033241+00
1083	memory_usage	31.904888153076172	{}	2025-10-16 00:14:56.408952+00
1086	disk_usage	7	{}	2025-10-16 00:14:56.416384+00
1087	whatsapp_success_rate	100	{}	2025-10-16 00:14:56.419017+00
1088	sla_violation	2	{}	2025-10-16 00:14:56.420946+00
1091	memory_usage	31.935501098632812	{}	2025-10-16 00:15:00.022156+00
1093	disk_usage	7	{}	2025-10-16 00:15:00.029195+00
1096	whatsapp_success_rate	100	{}	2025-10-16 00:15:00.030811+00
1099	sla_violation	2	{}	2025-10-16 00:15:00.032083+00
1177	memory_usage	32.135963439941406	{}	2025-10-16 00:39:44.280121+00
1179	disk_usage	7	{}	2025-10-16 00:39:44.288603+00
1180	whatsapp_success_rate	100	{}	2025-10-16 00:39:44.291671+00
1181	sla_violation	2	{}	2025-10-16 00:39:44.294228+00
1187	memory_usage	30.40332794189453	{}	2025-10-16 00:40:00.014254+00
1191	disk_usage	7	{}	2025-10-16 00:40:00.020767+00
1195	whatsapp_success_rate	100	{}	2025-10-16 00:40:00.023049+00
1199	sla_violation	2	{}	2025-10-16 00:40:00.024619+00
1276	memory_usage	32.181406021118164	{}	2025-10-16 00:56:13.632436+00
1278	disk_usage	7	{}	2025-10-16 00:56:13.640358+00
1279	whatsapp_success_rate	100	{}	2025-10-16 00:56:13.643563+00
1280	sla_violation	2	{}	2025-10-16 00:56:13.646553+00
1377	memory_usage	32.620906829833984	{}	2025-10-16 01:13:54.853094+00
1379	disk_usage	7	{}	2025-10-16 01:13:54.861255+00
1380	whatsapp_success_rate	100	{}	2025-10-16 01:13:54.863577+00
1381	sla_violation	2	{}	2025-10-16 01:13:54.865366+00
1477	memory_usage	33.01444053649902	{}	2025-10-16 01:31:34.39217+00
1478	disk_usage	7	{}	2025-10-16 01:31:34.399038+00
1479	whatsapp_success_rate	100	{}	2025-10-16 01:31:34.401349+00
1480	sla_violation	2	{}	2025-10-16 01:31:34.403063+00
1571	memory_usage	29.482269287109375	{}	2025-10-16 01:55:00.01184+00
1575	disk_usage	7	{}	2025-10-16 01:55:00.01869+00
1578	whatsapp_success_rate	100	{}	2025-10-16 01:55:00.020998+00
1582	sla_violation	2	{}	2025-10-16 01:55:00.023989+00
1671	memory_usage	29.649639129638672	{}	2025-10-16 02:20:00.018391+00
1678	disk_usage	7	{}	2025-10-16 02:20:00.02502+00
1679	whatsapp_success_rate	100	{}	2025-10-16 02:20:00.028034+00
1680	sla_violation	2	{}	2025-10-16 02:20:00.030255+00
1777	memory_usage	29.411983489990234	{}	2025-10-16 02:55:00.018752+00
1781	disk_usage	7	{}	2025-10-16 02:55:00.026161+00
1784	whatsapp_success_rate	100	{}	2025-10-16 02:55:00.030029+00
1788	sla_violation	3	{}	2025-10-16 02:55:00.032382+00
1874	memory_usage	29.52437400817871	{}	2025-10-16 03:25:00.018332+00
1877	disk_usage	7	{}	2025-10-16 03:25:00.024901+00
1881	whatsapp_success_rate	100	{}	2025-10-16 03:25:00.027868+00
1884	sla_violation	3	{}	2025-10-16 03:25:00.030147+00
1972	memory_usage	29.74071502685547	{}	2025-10-16 03:50:00.019649+00
1977	disk_usage	7	{}	2025-10-16 03:50:00.026513+00
1981	whatsapp_success_rate	100	{}	2025-10-16 03:50:00.031257+00
1983	sla_violation	3	{}	2025-10-16 03:50:00.03519+00
2073	memory_usage	30.138635635375977	{}	2025-10-16 04:20:00.020308+00
2077	disk_usage	7	{}	2025-10-16 04:20:00.02859+00
2079	whatsapp_success_rate	100	{}	2025-10-16 04:20:00.031373+00
2080	sla_violation	3	{}	2025-10-16 04:20:00.033663+00
2177	memory_usage	30.1760196685791	{}	2025-10-16 04:50:00.009967+00
2181	disk_usage	7	{}	2025-10-16 04:50:00.016336+00
2184	whatsapp_success_rate	100	{}	2025-10-16 04:50:00.019642+00
2188	sla_violation	3	{}	2025-10-16 04:50:00.022047+00
2274	memory_usage	29.836606979370117	{}	2025-10-16 05:20:00.020625+00
2277	disk_usage	7	{}	2025-10-16 05:20:00.027778+00
2279	whatsapp_success_rate	100	{}	2025-10-16 05:20:00.030365+00
2283	sla_violation	3	{}	2025-10-16 05:20:00.03283+00
2373	memory_usage	18.176651000976562	{}	2025-10-16 05:50:00.032235+00
2380	disk_usage	7	{}	2025-10-16 05:50:00.041227+00
2382	whatsapp_success_rate	100	{}	2025-10-16 05:50:00.0448+00
2384	sla_violation	3	{}	2025-10-16 05:50:00.047611+00
2468	memory_usage	18.281841278076172	{}	2025-10-16 06:20:00.019988+00
2471	disk_usage	7	{}	2025-10-16 06:20:00.026095+00
2475	whatsapp_success_rate	100	{}	2025-10-16 06:20:00.028395+00
2479	sla_violation	3	{}	2025-10-16 06:20:00.030865+00
2577	memory_usage	18.28451156616211	{}	2025-10-16 06:55:00.019043+00
2581	disk_usage	7	{}	2025-10-16 06:55:00.025383+00
2585	whatsapp_success_rate	100	{}	2025-10-16 06:55:00.028133+00
2589	sla_violation	3	{}	2025-10-16 06:55:00.03054+00
2674	memory_usage	18.328332901000977	{}	2025-10-16 07:25:00.018897+00
2678	disk_usage	7	{}	2025-10-16 07:25:00.025644+00
2681	whatsapp_success_rate	100	{}	2025-10-16 07:25:00.029253+00
2685	sla_violation	3	{}	2025-10-16 07:25:00.031981+00
2772	memory_usage	18.34430694580078	{}	2025-10-16 07:55:00.02059+00
2775	disk_usage	7	{}	2025-10-16 07:55:00.026521+00
2780	whatsapp_success_rate	100	{}	2025-10-16 07:55:00.029596+00
2784	sla_violation	3	{}	2025-10-16 07:55:00.032196+00
2881	memory_usage	18.39728355407715	{}	2025-10-16 08:30:00.024893+00
2885	disk_usage	7	{}	2025-10-16 08:30:00.033263+00
2888	whatsapp_success_rate	100	{}	2025-10-16 08:30:00.036445+00
2891	sla_violation	3	{}	2025-10-16 08:30:00.038875+00
2978	memory_usage	18.41754913330078	{}	2025-10-16 09:00:00.031997+00
2984	disk_usage	7	{}	2025-10-16 09:00:00.040648+00
2988	whatsapp_success_rate	100	{}	2025-10-16 09:00:00.045192+00
2990	sla_violation	3	{}	2025-10-16 09:00:00.047571+00
3075	memory_usage	18.472671508789062	{}	2025-10-16 09:30:00.032544+00
609	memory_usage	27.915000915527344	{}	2025-10-15 22:30:00.033971+00
611	disk_usage	7	{}	2025-10-15 22:30:00.042998+00
612	whatsapp_success_rate	100	{}	2025-10-15 22:30:00.046187+00
615	sla_violation	2	{}	2025-10-15 22:30:00.05191+00
689	memory_usage	26.095294952392578	{}	2025-10-15 22:45:00.02428+00
690	disk_usage	7	{}	2025-10-15 22:45:00.034321+00
691	whatsapp_success_rate	100	{}	2025-10-15 22:45:00.038615+00
694	sla_violation	2	{}	2025-10-15 22:45:00.042851+00
769	memory_usage	30.542421340942383	{}	2025-10-15 22:56:14.042829+00
771	disk_usage	7	{}	2025-10-15 22:56:14.050333+00
772	whatsapp_success_rate	100	{}	2025-10-15 22:56:14.053187+00
774	sla_violation	2	{}	2025-10-15 22:56:14.055573+00
849	memory_usage	30.22780418395996	{}	2025-10-15 23:08:20.827799+00
850	disk_usage	7	{}	2025-10-15 23:08:20.841862+00
851	whatsapp_success_rate	100	{}	2025-10-15 23:08:20.844921+00
852	sla_violation	2	{}	2025-10-15 23:08:20.847026+00
929	memory_usage	27.8994083404541	{}	2025-10-15 23:30:00.017717+00
931	disk_usage	7	{}	2025-10-15 23:30:00.024721+00
933	whatsapp_success_rate	100	{}	2025-10-15 23:30:00.027162+00
937	sla_violation	2	{}	2025-10-15 23:30:00.029453+00
1009	memory_usage	28.581762313842773	{}	2025-10-15 23:55:00.011283+00
1013	disk_usage	7	{}	2025-10-15 23:55:00.017309+00
1017	whatsapp_success_rate	100	{}	2025-10-15 23:55:00.01939+00
1021	sla_violation	2	{}	2025-10-15 23:55:00.020772+00
1101	memory_usage	31.93659782409668	{}	2025-10-16 00:15:00.036181+00
1102	disk_usage	7	{}	2025-10-16 00:15:00.042111+00
1103	whatsapp_success_rate	100	{}	2025-10-16 00:15:00.044944+00
1104	sla_violation	2	{}	2025-10-16 00:15:00.047528+00
1178	memory_usage	32.15746879577637	{}	2025-10-16 00:39:44.283442+00
1182	disk_usage	7	{}	2025-10-16 00:39:44.298529+00
1183	whatsapp_success_rate	100	{}	2025-10-16 00:39:44.301486+00
1184	sla_violation	2	{}	2025-10-16 00:39:44.303768+00
1185	memory_usage	30.40332794189453	{}	2025-10-16 00:40:00.013856+00
1190	disk_usage	7	{}	2025-10-16 00:40:00.020268+00
1194	whatsapp_success_rate	100	{}	2025-10-16 00:40:00.022507+00
1198	sla_violation	2	{}	2025-10-16 00:40:00.024098+00
1281	memory_usage	29.71515655517578	{}	2025-10-16 01:00:00.030014+00
1283	disk_usage	7	{}	2025-10-16 01:00:00.038757+00
1285	whatsapp_success_rate	100	{}	2025-10-16 01:00:00.042447+00
1287	sla_violation	2	{}	2025-10-16 01:00:00.045809+00
1378	memory_usage	32.63497352600098	{}	2025-10-16 01:13:54.860095+00
1382	disk_usage	7	{}	2025-10-16 01:13:54.867896+00
1383	whatsapp_success_rate	100	{}	2025-10-16 01:13:54.870262+00
1384	sla_violation	2	{}	2025-10-16 01:13:54.871945+00
1481	memory_usage	33.04634094238281	{}	2025-10-16 01:31:34.501082+00
1482	disk_usage	7	{}	2025-10-16 01:31:34.509504+00
1483	whatsapp_success_rate	100	{}	2025-10-16 01:31:34.51195+00
1484	sla_violation	2	{}	2025-10-16 01:31:34.513622+00
1572	memory_usage	29.47859764099121	{}	2025-10-16 01:55:00.016443+00
1580	disk_usage	7	{}	2025-10-16 01:55:00.022101+00
1583	whatsapp_success_rate	100	{}	2025-10-16 01:55:00.02502+00
1584	sla_violation	2	{}	2025-10-16 01:55:00.027469+00
1681	memory_usage	29.863357543945312	{}	2025-10-16 02:25:00.009861+00
1686	disk_usage	7	{}	2025-10-16 02:25:00.016488+00
1692	whatsapp_success_rate	100	{}	2025-10-16 02:25:00.019213+00
1696	sla_violation	2	{}	2025-10-16 02:25:00.022617+00
1778	memory_usage	29.411983489990234	{}	2025-10-16 02:55:00.020405+00
1783	disk_usage	7	{}	2025-10-16 02:55:00.028087+00
1785	whatsapp_success_rate	100	{}	2025-10-16 02:55:00.030547+00
1789	sla_violation	3	{}	2025-10-16 02:55:00.032647+00
1875	memory_usage	29.53195571899414	{}	2025-10-16 03:25:00.019999+00
1879	disk_usage	7	{}	2025-10-16 03:25:00.026244+00
1882	whatsapp_success_rate	100	{}	2025-10-16 03:25:00.029041+00
1885	sla_violation	3	{}	2025-10-16 03:25:00.031296+00
1973	memory_usage	29.74071502685547	{}	2025-10-16 03:50:00.019688+00
1979	disk_usage	7	{}	2025-10-16 03:50:00.02912+00
1982	whatsapp_success_rate	100	{}	2025-10-16 03:50:00.032388+00
1984	sla_violation	3	{}	2025-10-16 03:50:00.035245+00
2081	memory_usage	31.971263885498047	{}	2025-10-16 04:22:50.869362+00
2082	disk_usage	7	{}	2025-10-16 04:22:50.876981+00
2083	whatsapp_success_rate	100	{}	2025-10-16 04:22:50.879495+00
2084	sla_violation	3	{}	2025-10-16 04:22:50.881447+00
2178	memory_usage	30.1760196685791	{}	2025-10-16 04:50:00.010362+00
2182	disk_usage	7	{}	2025-10-16 04:50:00.01738+00
2185	whatsapp_success_rate	100	{}	2025-10-16 04:50:00.019923+00
2189	sla_violation	3	{}	2025-10-16 04:50:00.022692+00
2275	memory_usage	29.85687255859375	{}	2025-10-16 05:20:00.02414+00
2281	disk_usage	7	{}	2025-10-16 05:20:00.031134+00
2284	whatsapp_success_rate	100	{}	2025-10-16 05:20:00.033992+00
2285	sla_violation	3	{}	2025-10-16 05:20:00.036258+00
2372	memory_usage	18.15347671508789	{}	2025-10-16 05:50:00.032108+00
2378	disk_usage	7	{}	2025-10-16 05:50:00.040408+00
2381	whatsapp_success_rate	100	{}	2025-10-16 05:50:00.043115+00
2383	sla_violation	3	{}	2025-10-16 05:50:00.045288+00
2481	memory_usage	18.325185775756836	{}	2025-10-16 06:25:00.018729+00
2487	disk_usage	7	{}	2025-10-16 06:25:00.026622+00
2491	whatsapp_success_rate	100	{}	2025-10-16 06:25:00.029698+00
2495	sla_violation	3	{}	2025-10-16 06:25:00.032298+00
2578	memory_usage	18.282699584960938	{}	2025-10-16 06:55:00.019415+00
2582	disk_usage	7	{}	2025-10-16 06:55:00.026232+00
2586	whatsapp_success_rate	100	{}	2025-10-16 06:55:00.028701+00
2590	sla_violation	3	{}	2025-10-16 06:55:00.03091+00
2675	memory_usage	18.326473236083984	{}	2025-10-16 07:25:00.01905+00
2679	disk_usage	7	{}	2025-10-16 07:25:00.025945+00
2682	whatsapp_success_rate	100	{}	2025-10-16 07:25:00.029712+00
2687	sla_violation	3	{}	2025-10-16 07:25:00.033892+00
2785	memory_usage	18.399858474731445	{}	2025-10-16 08:00:00.023677+00
2789	disk_usage	7	{}	2025-10-16 08:00:00.032109+00
2790	whatsapp_success_rate	100	{}	2025-10-16 08:00:00.034951+00
2794	sla_violation	3	{}	2025-10-16 08:00:00.03764+00
2882	memory_usage	18.386220932006836	{}	2025-10-16 08:30:00.026201+00
2884	disk_usage	7	{}	2025-10-16 08:30:00.032909+00
2887	whatsapp_success_rate	100	{}	2025-10-16 08:30:00.036154+00
2890	sla_violation	3	{}	2025-10-16 08:30:00.038428+00
2979	memory_usage	18.41754913330078	{}	2025-10-16 09:00:00.032258+00
2983	disk_usage	7	{}	2025-10-16 09:00:00.040046+00
2986	whatsapp_success_rate	100	{}	2025-10-16 09:00:00.043252+00
2989	sla_violation	3	{}	2025-10-16 09:00:00.045717+00
3078	memory_usage	18.520212173461914	{}	2025-10-16 09:30:00.036246+00
3085	disk_usage	7	{}	2025-10-16 09:30:00.043426+00
3087	whatsapp_success_rate	100	{}	2025-10-16 09:30:00.046339+00
3088	sla_violation	3	{}	2025-10-16 09:30:00.048703+00
3164	whatsapp_success_rate	100	{}	2025-10-16 09:55:00.030181+00
610	memory_usage	27.899837493896484	{}	2025-10-15 22:30:00.038968+00
613	disk_usage	7	{}	2025-10-15 22:30:00.046604+00
614	whatsapp_success_rate	100	{}	2025-10-15 22:30:00.04993+00
616	sla_violation	2	{}	2025-10-15 22:30:00.052206+00
693	memory_usage	26.10788345336914	{}	2025-10-15 22:45:00.04178+00
695	disk_usage	7	{}	2025-10-15 22:45:00.048439+00
698	whatsapp_success_rate	100	{}	2025-10-15 22:45:00.051724+00
701	sla_violation	2	{}	2025-10-15 22:45:00.05676+00
770	memory_usage	30.545854568481445	{}	2025-10-15 22:56:14.047028+00
773	disk_usage	7	{}	2025-10-15 22:56:14.055106+00
775	whatsapp_success_rate	100	{}	2025-10-15 22:56:14.057652+00
776	sla_violation	2	{}	2025-10-15 22:56:14.059352+00
853	memory_usage	30.245304107666016	{}	2025-10-15 23:08:20.849257+00
854	disk_usage	7	{}	2025-10-15 23:08:20.86486+00
855	whatsapp_success_rate	100	{}	2025-10-15 23:08:20.868827+00
856	sla_violation	2	{}	2025-10-15 23:08:20.870795+00
930	memory_usage	27.887392044067383	{}	2025-10-15 23:30:00.017971+00
932	disk_usage	7	{}	2025-10-15 23:30:00.024917+00
935	whatsapp_success_rate	100	{}	2025-10-15 23:30:00.027585+00
936	sla_violation	2	{}	2025-10-15 23:30:00.029239+00
1010	memory_usage	28.581762313842773	{}	2025-10-15 23:55:00.011416+00
1016	disk_usage	7	{}	2025-10-15 23:55:00.018155+00
1019	whatsapp_success_rate	100	{}	2025-10-15 23:55:00.020136+00
1024	sla_violation	2	{}	2025-10-15 23:55:00.022243+00
1105	memory_usage	29.494047164916992	{}	2025-10-16 00:20:00.019849+00
1111	disk_usage	7	{}	2025-10-16 00:20:00.028675+00
1114	whatsapp_success_rate	100	{}	2025-10-16 00:20:00.031316+00
1120	sla_violation	2	{}	2025-10-16 00:20:00.034205+00
1186	memory_usage	30.40332794189453	{}	2025-10-16 00:40:00.013864+00
1192	disk_usage	7	{}	2025-10-16 00:40:00.020929+00
1197	whatsapp_success_rate	100	{}	2025-10-16 00:40:00.024058+00
1200	sla_violation	2	{}	2025-10-16 00:40:00.026028+00
1282	memory_usage	29.754352569580078	{}	2025-10-16 01:00:00.038137+00
1288	disk_usage	7	{}	2025-10-16 01:00:00.046029+00
1290	whatsapp_success_rate	100	{}	2025-10-16 01:00:00.049029+00
1292	sla_violation	2	{}	2025-10-16 01:00:00.051314+00
1385	memory_usage	32.67054557800293	{}	2025-10-16 01:13:54.977645+00
1387	disk_usage	7	{}	2025-10-16 01:13:54.985242+00
1389	whatsapp_success_rate	100	{}	2025-10-16 01:13:54.988337+00
1391	sla_violation	2	{}	2025-10-16 01:13:54.990863+00
1485	memory_usage	33.07523727416992	{}	2025-10-16 01:31:34.56859+00
1486	disk_usage	7	{}	2025-10-16 01:31:34.578984+00
1487	whatsapp_success_rate	100	{}	2025-10-16 01:31:34.588082+00
1488	sla_violation	2	{}	2025-10-16 01:31:34.590757+00
1585	memory_usage	34.18450355529785	{}	2025-10-16 02:00:00.016282+00
1588	disk_usage	7	{}	2025-10-16 02:00:00.025462+00
1592	whatsapp_success_rate	100	{}	2025-10-16 02:00:00.030059+00
1595	sla_violation	2	{}	2025-10-16 02:00:00.032257+00
1682	memory_usage	29.863357543945312	{}	2025-10-16 02:25:00.010043+00
1687	disk_usage	7	{}	2025-10-16 02:25:00.016566+00
1691	whatsapp_success_rate	100	{}	2025-10-16 02:25:00.019094+00
1695	sla_violation	2	{}	2025-10-16 02:25:00.02211+00
1779	memory_usage	29.411983489990234	{}	2025-10-16 02:55:00.02078+00
1782	disk_usage	7	{}	2025-10-16 02:55:00.026905+00
1787	whatsapp_success_rate	100	{}	2025-10-16 02:55:00.030775+00
1791	sla_violation	3	{}	2025-10-16 02:55:00.034195+00
1878	memory_usage	29.56714630126953	{}	2025-10-16 03:25:00.02547+00
1886	disk_usage	7	{}	2025-10-16 03:25:00.032263+00
1887	whatsapp_success_rate	100	{}	2025-10-16 03:25:00.035302+00
1888	sla_violation	3	{}	2025-10-16 03:25:00.037798+00
1985	memory_usage	30.06753921508789	{}	2025-10-16 03:55:00.010815+00
1989	disk_usage	7	{}	2025-10-16 03:55:00.016987+00
1992	whatsapp_success_rate	100	{}	2025-10-16 03:55:00.019597+00
1995	sla_violation	3	{}	2025-10-16 03:55:00.021977+00
2085	memory_usage	31.974172592163086	{}	2025-10-16 04:22:50.89626+00
2086	disk_usage	7	{}	2025-10-16 04:22:50.904422+00
2087	whatsapp_success_rate	100	{}	2025-10-16 04:22:50.9077+00
2088	sla_violation	3	{}	2025-10-16 04:22:50.910327+00
2179	memory_usage	30.18021583557129	{}	2025-10-16 04:50:00.010746+00
2183	disk_usage	7	{}	2025-10-16 04:50:00.017694+00
2186	whatsapp_success_rate	100	{}	2025-10-16 04:50:00.020199+00
2190	sla_violation	3	{}	2025-10-16 04:50:00.022886+00
2280	memory_usage	29.893064498901367	{}	2025-10-16 05:20:00.030488+00
2286	disk_usage	7	{}	2025-10-16 05:20:00.036813+00
2287	whatsapp_success_rate	100	{}	2025-10-16 05:20:00.039304+00
2288	sla_violation	3	{}	2025-10-16 05:20:00.041457+00
2385	memory_usage	18.101119995117188	{}	2025-10-16 05:55:00.018725+00
2389	disk_usage	7	{}	2025-10-16 05:55:00.024989+00
2393	whatsapp_success_rate	100	{}	2025-10-16 05:55:00.03001+00
2397	sla_violation	3	{}	2025-10-16 05:55:00.03222+00
2482	memory_usage	18.323802947998047	{}	2025-10-16 06:25:00.018682+00
2488	disk_usage	7	{}	2025-10-16 06:25:00.026664+00
2492	whatsapp_success_rate	100	{}	2025-10-16 06:25:00.030048+00
2496	sla_violation	3	{}	2025-10-16 06:25:00.033663+00
2579	memory_usage	18.28751564025879	{}	2025-10-16 06:55:00.019404+00
2584	disk_usage	7	{}	2025-10-16 06:55:00.027176+00
2588	whatsapp_success_rate	100	{}	2025-10-16 06:55:00.030203+00
2592	sla_violation	3	{}	2025-10-16 06:55:00.03278+00
2676	memory_usage	18.366336822509766	{}	2025-10-16 07:25:00.023529+00
2683	disk_usage	7	{}	2025-10-16 07:25:00.030006+00
2686	whatsapp_success_rate	100	{}	2025-10-16 07:25:00.033441+00
2688	sla_violation	3	{}	2025-10-16 07:25:00.035879+00
2786	memory_usage	18.41273307800293	{}	2025-10-16 08:00:00.026361+00
2791	disk_usage	7	{}	2025-10-16 08:00:00.0353+00
2795	whatsapp_success_rate	100	{}	2025-10-16 08:00:00.037903+00
2798	sla_violation	3	{}	2025-10-16 08:00:00.040716+00
2883	memory_usage	18.43132972717285	{}	2025-10-16 08:30:00.03156+00
2889	disk_usage	7	{}	2025-10-16 08:30:00.037916+00
2893	whatsapp_success_rate	100	{}	2025-10-16 08:30:00.040605+00
2895	sla_violation	3	{}	2025-10-16 08:30:00.044051+00
2981	memory_usage	18.433856964111328	{}	2025-10-16 09:00:00.036078+00
2987	disk_usage	7	{}	2025-10-16 09:00:00.044839+00
2991	whatsapp_success_rate	100	{}	2025-10-16 09:00:00.047791+00
2992	sla_violation	3	{}	2025-10-16 09:00:00.050571+00
3082	disk_usage	7	{}	2025-10-16 09:30:00.040352+00
3084	whatsapp_success_rate	100	{}	2025-10-16 09:30:00.043329+00
3086	sla_violation	3	{}	2025-10-16 09:30:00.046006+00
3168	sla_violation	3	{}	2025-10-16 09:55:00.032608+00
3235	memory_usage	18.483257293701172	{}	2025-10-16 10:20:00.019735+00
3238	disk_usage	7	{}	2025-10-16 10:20:00.027125+00
3242	whatsapp_success_rate	100	{}	2025-10-16 10:20:00.031611+00
3245	sla_violation	3	{}	2025-10-16 10:20:00.03425+00
3281	memory_usage	18.4722900390625	{}	2025-10-16 10:35:00.017662+00
617	memory_usage	27.95720100402832	{}	2025-10-15 22:30:00.053344+00
619	disk_usage	7	{}	2025-10-15 22:30:00.063808+00
621	whatsapp_success_rate	100	{}	2025-10-15 22:30:00.067085+00
623	sla_violation	2	{}	2025-10-15 22:30:00.069621+00
692	memory_usage	26.100730895996094	{}	2025-10-15 22:45:00.041743+00
696	disk_usage	7	{}	2025-10-15 22:45:00.050994+00
699	whatsapp_success_rate	100	{}	2025-10-15 22:45:00.05398+00
700	sla_violation	2	{}	2025-10-15 22:45:00.056342+00
777	memory_usage	30.585861206054688	{}	2025-10-15 22:56:14.169657+00
778	disk_usage	7	{}	2025-10-15 22:56:14.176277+00
779	whatsapp_success_rate	100	{}	2025-10-15 22:56:14.178624+00
780	sla_violation	2	{}	2025-10-15 22:56:14.180258+00
857	memory_usage	30.31926155090332	{}	2025-10-15 23:08:20.993742+00
858	disk_usage	7	{}	2025-10-15 23:08:21.001485+00
860	whatsapp_success_rate	100	{}	2025-10-15 23:08:21.004413+00
861	sla_violation	2	{}	2025-10-15 23:08:21.005977+00
934	memory_usage	27.887392044067383	{}	2025-10-15 23:30:00.027067+00
939	disk_usage	7	{}	2025-10-15 23:30:00.034223+00
940	whatsapp_success_rate	100	{}	2025-10-15 23:30:00.037166+00
941	sla_violation	2	{}	2025-10-15 23:30:00.039557+00
1011	memory_usage	28.581762313842773	{}	2025-10-15 23:55:00.011452+00
1015	disk_usage	7	{}	2025-10-15 23:55:00.017974+00
1020	whatsapp_success_rate	100	{}	2025-10-15 23:55:00.020277+00
1022	sla_violation	2	{}	2025-10-15 23:55:00.021949+00
1106	memory_usage	29.494047164916992	{}	2025-10-16 00:20:00.020642+00
1109	disk_usage	7	{}	2025-10-16 00:20:00.028224+00
1113	whatsapp_success_rate	100	{}	2025-10-16 00:20:00.031138+00
1117	sla_violation	2	{}	2025-10-16 00:20:00.033665+00
1188	memory_usage	30.40332794189453	{}	2025-10-16 00:40:00.014124+00
1189	disk_usage	7	{}	2025-10-16 00:40:00.020234+00
1193	whatsapp_success_rate	100	{}	2025-10-16 00:40:00.02231+00
1196	sla_violation	2	{}	2025-10-16 00:40:00.023716+00
1284	memory_usage	29.71515655517578	{}	2025-10-16 01:00:00.04117+00
1289	disk_usage	7	{}	2025-10-16 01:00:00.048459+00
1291	whatsapp_success_rate	100	{}	2025-10-16 01:00:00.051029+00
1294	sla_violation	2	{}	2025-10-16 01:00:00.053244+00
1386	memory_usage	32.69391059875488	{}	2025-10-16 01:13:54.980727+00
1388	disk_usage	7	{}	2025-10-16 01:13:54.987575+00
1390	whatsapp_success_rate	100	{}	2025-10-16 01:13:54.989867+00
1392	sla_violation	2	{}	2025-10-16 01:13:54.991506+00
1489	memory_usage	30.629920959472656	{}	2025-10-16 01:35:00.013556+00
1494	disk_usage	7	{}	2025-10-16 01:35:00.020497+00
1498	whatsapp_success_rate	100	{}	2025-10-16 01:35:00.02295+00
1504	sla_violation	2	{}	2025-10-16 01:35:00.02615+00
1586	memory_usage	34.186697006225586	{}	2025-10-16 02:00:00.017462+00
1589	disk_usage	7	{}	2025-10-16 02:00:00.02574+00
1593	whatsapp_success_rate	100	{}	2025-10-16 02:00:00.030664+00
1596	sla_violation	2	{}	2025-10-16 02:00:00.032776+00
1683	memory_usage	29.863357543945312	{}	2025-10-16 02:25:00.010272+00
1685	disk_usage	7	{}	2025-10-16 02:25:00.01641+00
1689	whatsapp_success_rate	100	{}	2025-10-16 02:25:00.018759+00
1693	sla_violation	2	{}	2025-10-16 02:25:00.020923+00
1780	memory_usage	29.45384979248047	{}	2025-10-16 02:55:00.024321+00
1786	disk_usage	7	{}	2025-10-16 02:55:00.030639+00
1790	whatsapp_success_rate	100	{}	2025-10-16 02:55:00.033891+00
1792	sla_violation	3	{}	2025-10-16 02:55:00.036449+00
1889	memory_usage	29.999399185180664	{}	2025-10-16 03:30:00.018116+00
1893	disk_usage	7	{}	2025-10-16 03:30:00.028947+00
1895	whatsapp_success_rate	100	{}	2025-10-16 03:30:00.031452+00
1900	sla_violation	3	{}	2025-10-16 03:30:00.035865+00
1986	memory_usage	30.06443977355957	{}	2025-10-16 03:55:00.011136+00
1990	disk_usage	7	{}	2025-10-16 03:55:00.017361+00
1993	whatsapp_success_rate	100	{}	2025-10-16 03:55:00.02001+00
1996	sla_violation	3	{}	2025-10-16 03:55:00.022404+00
2089	memory_usage	32.009124755859375	{}	2025-10-16 04:22:50.988646+00
2091	disk_usage	7	{}	2025-10-16 04:22:50.999441+00
2092	whatsapp_success_rate	100	{}	2025-10-16 04:22:51.002161+00
2093	sla_violation	3	{}	2025-10-16 04:22:51.00401+00
2180	memory_usage	30.200862884521484	{}	2025-10-16 04:50:00.015901+00
2187	disk_usage	7	{}	2025-10-16 04:50:00.021336+00
2191	whatsapp_success_rate	100	{}	2025-10-16 04:50:00.02414+00
2192	sla_violation	3	{}	2025-10-16 04:50:00.026478+00
2289	memory_usage	29.862165451049805	{}	2025-10-16 05:25:00.017493+00
2293	disk_usage	7	{}	2025-10-16 05:25:00.024645+00
2296	whatsapp_success_rate	100	{}	2025-10-16 05:25:00.02746+00
2300	sla_violation	3	{}	2025-10-16 05:25:00.029921+00
2386	memory_usage	18.101119995117188	{}	2025-10-16 05:55:00.019534+00
2390	disk_usage	7	{}	2025-10-16 05:55:00.026941+00
2394	whatsapp_success_rate	100	{}	2025-10-16 05:55:00.030456+00
2398	sla_violation	3	{}	2025-10-16 05:55:00.034582+00
2483	memory_usage	18.325185775756836	{}	2025-10-16 06:25:00.018742+00
2486	disk_usage	7	{}	2025-10-16 06:25:00.026091+00
2490	whatsapp_success_rate	100	{}	2025-10-16 06:25:00.029219+00
2494	sla_violation	3	{}	2025-10-16 06:25:00.031847+00
2580	memory_usage	18.28451156616211	{}	2025-10-16 06:55:00.019709+00
2583	disk_usage	7	{}	2025-10-16 06:55:00.027143+00
2587	whatsapp_success_rate	100	{}	2025-10-16 06:55:00.029866+00
2591	sla_violation	3	{}	2025-10-16 06:55:00.032414+00
2689	memory_usage	18.35041046142578	{}	2025-10-16 07:30:00.028404+00
2693	disk_usage	7	{}	2025-10-16 07:30:00.03822+00
2697	whatsapp_success_rate	100	{}	2025-10-16 07:30:00.042364+00
2701	sla_violation	3	{}	2025-10-16 07:30:00.045022+00
2787	memory_usage	18.402385711669922	{}	2025-10-16 08:00:00.026662+00
2792	disk_usage	7	{}	2025-10-16 08:00:00.035673+00
2796	whatsapp_success_rate	100	{}	2025-10-16 08:00:00.038193+00
2799	sla_violation	3	{}	2025-10-16 08:00:00.041423+00
2886	memory_usage	18.442678451538086	{}	2025-10-16 08:30:00.033947+00
2892	disk_usage	7	{}	2025-10-16 08:30:00.040665+00
2894	whatsapp_success_rate	100	{}	2025-10-16 08:30:00.04336+00
2896	sla_violation	3	{}	2025-10-16 08:30:00.046014+00
2993	memory_usage	18.423748016357422	{}	2025-10-16 09:05:00.017596+00
2998	disk_usage	7	{}	2025-10-16 09:05:00.026179+00
3002	whatsapp_success_rate	100	{}	2025-10-16 09:05:00.028582+00
3005	sla_violation	3	{}	2025-10-16 09:05:00.030821+00
3089	memory_usage	18.447589874267578	{}	2025-10-16 09:35:00.017226+00
3095	disk_usage	7	{}	2025-10-16 09:35:00.024769+00
3097	whatsapp_success_rate	100	{}	2025-10-16 09:35:00.027975+00
3101	sla_violation	3	{}	2025-10-16 09:35:00.030364+00
3169	memory_usage	18.500661849975586	{}	2025-10-16 10:00:00.027373+00
3172	disk_usage	7	{}	2025-10-16 10:00:00.035456+00
3176	whatsapp_success_rate	100	{}	2025-10-16 10:00:00.038367+00
3179	sla_violation	3	{}	2025-10-16 10:00:00.041084+00
3237	disk_usage	7	{}	2025-10-16 10:20:00.027097+00
618	memory_usage	27.991008758544922	{}	2025-10-15 22:30:00.059825+00
620	disk_usage	7	{}	2025-10-15 22:30:00.066851+00
622	whatsapp_success_rate	100	{}	2025-10-15 22:30:00.069198+00
624	sla_violation	2	{}	2025-10-15 22:30:00.071343+00
697	memory_usage	26.157808303833008	{}	2025-10-15 22:45:00.050712+00
702	disk_usage	7	{}	2025-10-15 22:45:00.058017+00
703	whatsapp_success_rate	100	{}	2025-10-15 22:45:00.063117+00
704	sla_violation	2	{}	2025-10-15 22:45:00.066343+00
781	memory_usage	30.556440353393555	{}	2025-10-15 22:56:14.200257+00
782	disk_usage	7	{}	2025-10-15 22:56:14.208141+00
783	whatsapp_success_rate	100	{}	2025-10-15 22:56:14.211572+00
784	sla_violation	2	{}	2025-10-15 22:56:14.214478+00
859	memory_usage	30.305004119873047	{}	2025-10-15 23:08:21.001857+00
862	disk_usage	7	{}	2025-10-15 23:08:21.010428+00
863	whatsapp_success_rate	100	{}	2025-10-15 23:08:21.013321+00
864	sla_violation	2	{}	2025-10-15 23:08:21.015822+00
938	memory_usage	27.922582626342773	{}	2025-10-15 23:30:00.033119+00
942	disk_usage	7	{}	2025-10-15 23:30:00.039966+00
943	whatsapp_success_rate	100	{}	2025-10-15 23:30:00.042698+00
944	sla_violation	2	{}	2025-10-15 23:30:00.045294+00
1012	memory_usage	28.588533401489258	{}	2025-10-15 23:55:00.01201+00
1014	disk_usage	7	{}	2025-10-15 23:55:00.017947+00
1018	whatsapp_success_rate	100	{}	2025-10-15 23:55:00.019712+00
1023	sla_violation	2	{}	2025-10-15 23:55:00.022118+00
1107	memory_usage	29.494047164916992	{}	2025-10-16 00:20:00.020814+00
1110	disk_usage	7	{}	2025-10-16 00:20:00.028391+00
1116	whatsapp_success_rate	100	{}	2025-10-16 00:20:00.031436+00
1119	sla_violation	2	{}	2025-10-16 00:20:00.034198+00
1201	memory_usage	29.71515655517578	{}	2025-10-16 00:45:00.018747+00
1205	disk_usage	7	{}	2025-10-16 00:45:00.026443+00
1208	whatsapp_success_rate	100	{}	2025-10-16 00:45:00.029175+00
1211	sla_violation	2	{}	2025-10-16 00:45:00.031294+00
1286	memory_usage	29.74867820739746	{}	2025-10-16 01:00:00.045345+00
1293	disk_usage	7	{}	2025-10-16 01:00:00.05264+00
1295	whatsapp_success_rate	100	{}	2025-10-16 01:00:00.055289+00
1296	sla_violation	2	{}	2025-10-16 01:00:00.057815+00
1393	memory_usage	30.20477294921875	{}	2025-10-16 01:15:00.020857+00
1395	disk_usage	7	{}	2025-10-16 01:15:00.028462+00
1397	whatsapp_success_rate	100	{}	2025-10-16 01:15:00.031056+00
1400	sla_violation	2	{}	2025-10-16 01:15:00.033696+00
1490	memory_usage	30.629920959472656	{}	2025-10-16 01:35:00.013548+00
1496	disk_usage	7	{}	2025-10-16 01:35:00.020566+00
1499	whatsapp_success_rate	100	{}	2025-10-16 01:35:00.023249+00
1503	sla_violation	2	{}	2025-10-16 01:35:00.026114+00
1587	memory_usage	34.18750762939453	{}	2025-10-16 02:00:00.022134+00
1591	disk_usage	7	{}	2025-10-16 02:00:00.029247+00
1594	whatsapp_success_rate	100	{}	2025-10-16 02:00:00.031752+00
1597	sla_violation	2	{}	2025-10-16 02:00:00.033129+00
1684	memory_usage	29.871845245361328	{}	2025-10-16 02:25:00.011368+00
1688	disk_usage	7	{}	2025-10-16 02:25:00.016904+00
1690	whatsapp_success_rate	100	{}	2025-10-16 02:25:00.019056+00
1694	sla_violation	2	{}	2025-10-16 02:25:00.021322+00
1793	memory_usage	29.450321197509766	{}	2025-10-16 03:00:00.028723+00
1797	disk_usage	7	{}	2025-10-16 03:00:00.036678+00
1802	whatsapp_success_rate	100	{}	2025-10-16 03:00:00.042663+00
1806	sla_violation	3	{}	2025-10-16 03:00:00.046013+00
1890	memory_usage	29.999923706054688	{}	2025-10-16 03:30:00.018917+00
1894	disk_usage	7	{}	2025-10-16 03:30:00.029+00
1896	whatsapp_success_rate	100	{}	2025-10-16 03:30:00.032221+00
1899	sla_violation	3	{}	2025-10-16 03:30:00.035286+00
1987	memory_usage	30.07493019104004	{}	2025-10-16 03:55:00.011801+00
1991	disk_usage	7	{}	2025-10-16 03:55:00.018737+00
1994	whatsapp_success_rate	100	{}	2025-10-16 03:55:00.021144+00
1998	sla_violation	3	{}	2025-10-16 03:55:00.02355+00
2090	memory_usage	32.007551193237305	{}	2025-10-16 04:22:50.996856+00
2094	disk_usage	7	{}	2025-10-16 04:22:51.004482+00
2095	whatsapp_success_rate	100	{}	2025-10-16 04:22:51.007133+00
2096	sla_violation	3	{}	2025-10-16 04:22:51.009123+00
2193	memory_usage	30.188274383544922	{}	2025-10-16 04:55:00.011008+00
2197	disk_usage	7	{}	2025-10-16 04:55:00.01741+00
2199	whatsapp_success_rate	100	{}	2025-10-16 04:55:00.020048+00
2203	sla_violation	3	{}	2025-10-16 04:55:00.024143+00
2290	memory_usage	29.8642635345459	{}	2025-10-16 05:25:00.017477+00
2295	disk_usage	7	{}	2025-10-16 05:25:00.025885+00
2298	whatsapp_success_rate	100	{}	2025-10-16 05:25:00.028776+00
2302	sla_violation	3	{}	2025-10-16 05:25:00.032047+00
2387	memory_usage	18.101119995117188	{}	2025-10-16 05:55:00.020668+00
2391	disk_usage	7	{}	2025-10-16 05:55:00.027099+00
2396	whatsapp_success_rate	100	{}	2025-10-16 05:55:00.030606+00
2399	sla_violation	3	{}	2025-10-16 05:55:00.036343+00
2484	memory_usage	18.326854705810547	{}	2025-10-16 06:25:00.01962+00
2485	disk_usage	7	{}	2025-10-16 06:25:00.026031+00
2489	whatsapp_success_rate	100	{}	2025-10-16 06:25:00.028893+00
2493	sla_violation	3	{}	2025-10-16 06:25:00.031516+00
2593	memory_usage	18.307828903198242	{}	2025-10-16 07:00:00.023296+00
2595	disk_usage	7	{}	2025-10-16 07:00:00.031154+00
2598	whatsapp_success_rate	100	{}	2025-10-16 07:00:00.034961+00
2601	sla_violation	3	{}	2025-10-16 07:00:00.037737+00
2690	memory_usage	18.35036277770996	{}	2025-10-16 07:30:00.030463+00
2694	disk_usage	7	{}	2025-10-16 07:30:00.039185+00
2698	whatsapp_success_rate	100	{}	2025-10-16 07:30:00.042983+00
2702	sla_violation	3	{}	2025-10-16 07:30:00.045789+00
2788	memory_usage	18.427038192749023	{}	2025-10-16 08:00:00.030105+00
2793	disk_usage	7	{}	2025-10-16 08:00:00.037116+00
2797	whatsapp_success_rate	100	{}	2025-10-16 08:00:00.039705+00
2800	sla_violation	3	{}	2025-10-16 08:00:00.042547+00
2897	memory_usage	18.385696411132812	{}	2025-10-16 08:35:00.017811+00
2901	disk_usage	7	{}	2025-10-16 08:35:00.025799+00
2905	whatsapp_success_rate	100	{}	2025-10-16 08:35:00.028501+00
2909	sla_violation	3	{}	2025-10-16 08:35:00.030858+00
2994	memory_usage	18.423748016357422	{}	2025-10-16 09:05:00.018527+00
2997	disk_usage	7	{}	2025-10-16 09:05:00.025061+00
3000	whatsapp_success_rate	100	{}	2025-10-16 09:05:00.027771+00
3004	sla_violation	3	{}	2025-10-16 09:05:00.030559+00
3091	memory_usage	18.447589874267578	{}	2025-10-16 09:35:00.017512+00
3094	disk_usage	7	{}	2025-10-16 09:35:00.024724+00
3098	whatsapp_success_rate	100	{}	2025-10-16 09:35:00.028199+00
3102	sla_violation	3	{}	2025-10-16 09:35:00.030719+00
3170	memory_usage	18.506431579589844	{}	2025-10-16 10:00:00.027469+00
3174	disk_usage	7	{}	2025-10-16 10:00:00.036508+00
3178	whatsapp_success_rate	100	{}	2025-10-16 10:00:00.039306+00
3181	sla_violation	3	{}	2025-10-16 10:00:00.041432+00
3239	memory_usage	18.512487411499023	{}	2025-10-16 10:20:00.027615+00
625	memory_usage	30.209827423095703	{}	2025-10-15 22:30:11.437198+00
626	disk_usage	7	{}	2025-10-15 22:30:11.446315+00
627	whatsapp_success_rate	100	{}	2025-10-15 22:30:11.449302+00
628	sla_violation	2	{}	2025-10-15 22:30:11.451461+00
705	memory_usage	26.29384994506836	{}	2025-10-15 22:50:00.010986+00
706	disk_usage	7	{}	2025-10-15 22:50:00.017413+00
708	whatsapp_success_rate	100	{}	2025-10-15 22:50:00.020082+00
710	sla_violation	2	{}	2025-10-15 22:50:00.023509+00
785	memory_usage	27.944087982177734	{}	2025-10-15 23:00:00.021458+00
786	disk_usage	7	{}	2025-10-15 23:00:00.028784+00
788	whatsapp_success_rate	100	{}	2025-10-15 23:00:00.031256+00
790	sla_violation	2	{}	2025-10-15 23:00:00.033993+00
865	memory_usage	27.596426010131836	{}	2025-10-15 23:10:00.014737+00
866	disk_usage	7	{}	2025-10-15 23:10:00.02052+00
869	whatsapp_success_rate	100	{}	2025-10-15 23:10:00.022931+00
871	sla_violation	2	{}	2025-10-15 23:10:00.025948+00
945	memory_usage	28.168821334838867	{}	2025-10-15 23:35:00.010094+00
949	disk_usage	7	{}	2025-10-15 23:35:00.0168+00
952	whatsapp_success_rate	100	{}	2025-10-15 23:35:00.019234+00
956	sla_violation	2	{}	2025-10-15 23:35:00.021501+00
1025	memory_usage	28.19976806640625	{}	2025-10-16 00:00:00.016962+00
1026	disk_usage	7	{}	2025-10-16 00:00:00.024293+00
1028	whatsapp_success_rate	100	{}	2025-10-16 00:00:00.026689+00
1029	sla_violation	2	{}	2025-10-16 00:00:00.029293+00
1108	memory_usage	29.495954513549805	{}	2025-10-16 00:20:00.021515+00
1112	disk_usage	7	{}	2025-10-16 00:20:00.02876+00
1115	whatsapp_success_rate	100	{}	2025-10-16 00:20:00.031422+00
1118	sla_violation	2	{}	2025-10-16 00:20:00.034192+00
1202	memory_usage	29.715299606323242	{}	2025-10-16 00:45:00.019039+00
1206	disk_usage	7	{}	2025-10-16 00:45:00.026576+00
1209	whatsapp_success_rate	100	{}	2025-10-16 00:45:00.030086+00
1212	sla_violation	2	{}	2025-10-16 00:45:00.032433+00
1297	memory_usage	32.547712326049805	{}	2025-10-16 01:03:50.021082+00
1298	disk_usage	7	{}	2025-10-16 01:03:50.028073+00
1299	whatsapp_success_rate	100	{}	2025-10-16 01:03:50.030856+00
1300	sla_violation	2	{}	2025-10-16 01:03:50.032497+00
1394	memory_usage	30.201053619384766	{}	2025-10-16 01:15:00.02278+00
1396	disk_usage	7	{}	2025-10-16 01:15:00.029458+00
1398	whatsapp_success_rate	100	{}	2025-10-16 01:15:00.031781+00
1401	sla_violation	2	{}	2025-10-16 01:15:00.034021+00
1491	memory_usage	30.629920959472656	{}	2025-10-16 01:35:00.013849+00
1493	disk_usage	7	{}	2025-10-16 01:35:00.020221+00
1497	whatsapp_success_rate	100	{}	2025-10-16 01:35:00.022565+00
1501	sla_violation	2	{}	2025-10-16 01:35:00.025319+00
1590	memory_usage	34.155893325805664	{}	2025-10-16 02:00:00.025744+00
1598	disk_usage	7	{}	2025-10-16 02:00:00.033699+00
1599	whatsapp_success_rate	100	{}	2025-10-16 02:00:00.036982+00
1600	sla_violation	2	{}	2025-10-16 02:00:00.039817+00
1697	memory_usage	29.523038864135742	{}	2025-10-16 02:30:00.02705+00
1701	disk_usage	7	{}	2025-10-16 02:30:00.036014+00
1704	whatsapp_success_rate	100	{}	2025-10-16 02:30:00.038734+00
1708	sla_violation	2	{}	2025-10-16 02:30:00.041109+00
1794	memory_usage	29.453611373901367	{}	2025-10-16 03:00:00.029706+00
1798	disk_usage	7	{}	2025-10-16 03:00:00.037062+00
1801	whatsapp_success_rate	100	{}	2025-10-16 03:00:00.040819+00
1805	sla_violation	3	{}	2025-10-16 03:00:00.044534+00
1891	memory_usage	29.998254776000977	{}	2025-10-16 03:30:00.023012+00
1897	disk_usage	7	{}	2025-10-16 03:30:00.034007+00
1901	whatsapp_success_rate	100	{}	2025-10-16 03:30:00.037354+00
1904	sla_violation	3	{}	2025-10-16 03:30:00.047618+00
1988	memory_usage	30.083322525024414	{}	2025-10-16 03:55:00.016725+00
1997	disk_usage	7	{}	2025-10-16 03:55:00.022542+00
1999	whatsapp_success_rate	100	{}	2025-10-16 03:55:00.025543+00
2000	sla_violation	3	{}	2025-10-16 03:55:00.027739+00
2097	memory_usage	29.62946891784668	{}	2025-10-16 04:25:00.012126+00
2101	disk_usage	7	{}	2025-10-16 04:25:00.018642+00
2105	whatsapp_success_rate	100	{}	2025-10-16 04:25:00.020892+00
2109	sla_violation	3	{}	2025-10-16 04:25:00.022482+00
2194	memory_usage	30.188274383544922	{}	2025-10-16 04:55:00.011242+00
2198	disk_usage	7	{}	2025-10-16 04:55:00.018251+00
2200	whatsapp_success_rate	100	{}	2025-10-16 04:55:00.020375+00
2204	sla_violation	3	{}	2025-10-16 04:55:00.025575+00
2291	memory_usage	29.86454963684082	{}	2025-10-16 05:25:00.018314+00
2294	disk_usage	7	{}	2025-10-16 05:25:00.02498+00
2297	whatsapp_success_rate	100	{}	2025-10-16 05:25:00.027662+00
2301	sla_violation	3	{}	2025-10-16 05:25:00.030132+00
2388	memory_usage	18.121910095214844	{}	2025-10-16 05:55:00.021591+00
2392	disk_usage	7	{}	2025-10-16 05:55:00.027296+00
2395	whatsapp_success_rate	100	{}	2025-10-16 05:55:00.030579+00
2400	sla_violation	3	{}	2025-10-16 05:55:00.036464+00
2497	memory_usage	18.305015563964844	{}	2025-10-16 06:30:00.035221+00
2501	disk_usage	7	{}	2025-10-16 06:30:00.044195+00
2503	whatsapp_success_rate	100	{}	2025-10-16 06:30:00.046985+00
2507	sla_violation	3	{}	2025-10-16 06:30:00.049282+00
2594	memory_usage	18.320226669311523	{}	2025-10-16 07:00:00.026454+00
2596	disk_usage	7	{}	2025-10-16 07:00:00.033209+00
2599	whatsapp_success_rate	100	{}	2025-10-16 07:00:00.036039+00
2602	sla_violation	3	{}	2025-10-16 07:00:00.039452+00
2691	memory_usage	18.35041046142578	{}	2025-10-16 07:30:00.03254+00
2695	disk_usage	7	{}	2025-10-16 07:30:00.040938+00
2699	whatsapp_success_rate	100	{}	2025-10-16 07:30:00.043482+00
2703	sla_violation	3	{}	2025-10-16 07:30:00.046452+00
2801	memory_usage	18.381881713867188	{}	2025-10-16 08:05:00.016931+00
2805	disk_usage	7	{}	2025-10-16 08:05:00.024047+00
2809	whatsapp_success_rate	100	{}	2025-10-16 08:05:00.027108+00
2813	sla_violation	3	{}	2025-10-16 08:05:00.02965+00
2898	memory_usage	18.385696411132812	{}	2025-10-16 08:35:00.017811+00
2902	disk_usage	7	{}	2025-10-16 08:35:00.026273+00
2906	whatsapp_success_rate	100	{}	2025-10-16 08:35:00.028693+00
2910	sla_violation	3	{}	2025-10-16 08:35:00.031033+00
2995	memory_usage	18.43104362487793	{}	2025-10-16 09:05:00.018988+00
2999	disk_usage	7	{}	2025-10-16 09:05:00.026285+00
3003	whatsapp_success_rate	100	{}	2025-10-16 09:05:00.029603+00
3007	sla_violation	3	{}	2025-10-16 09:05:00.031942+00
3090	memory_usage	18.44792366027832	{}	2025-10-16 09:35:00.017452+00
3093	disk_usage	7	{}	2025-10-16 09:35:00.024753+00
3096	whatsapp_success_rate	100	{}	2025-10-16 09:35:00.027258+00
3100	sla_violation	3	{}	2025-10-16 09:35:00.029643+00
3171	memory_usage	18.4999942779541	{}	2025-10-16 10:00:00.028378+00
3173	disk_usage	7	{}	2025-10-16 10:00:00.035841+00
3177	whatsapp_success_rate	100	{}	2025-10-16 10:00:00.038485+00
3180	sla_violation	3	{}	2025-10-16 10:00:00.041092+00
3241	whatsapp_success_rate	100	{}	2025-10-16 10:20:00.031212+00
629	memory_usage	30.21068572998047	{}	2025-10-15 22:30:11.459578+00
630	disk_usage	7	{}	2025-10-15 22:30:11.470629+00
631	whatsapp_success_rate	100	{}	2025-10-15 22:30:11.475032+00
632	sla_violation	2	{}	2025-10-15 22:30:11.477653+00
707	memory_usage	26.29079818725586	{}	2025-10-15 22:50:00.019049+00
712	disk_usage	7	{}	2025-10-15 22:50:00.02561+00
714	whatsapp_success_rate	100	{}	2025-10-15 22:50:00.028608+00
717	sla_violation	2	{}	2025-10-15 22:50:00.031243+00
787	memory_usage	27.966594696044922	{}	2025-10-15 23:00:00.028755+00
792	disk_usage	7	{}	2025-10-15 23:00:00.03653+00
794	whatsapp_success_rate	100	{}	2025-10-15 23:00:00.040285+00
797	sla_violation	2	{}	2025-10-15 23:00:00.043438+00
867	memory_usage	27.59251594543457	{}	2025-10-15 23:10:00.021958+00
872	disk_usage	7	{}	2025-10-15 23:10:00.029027+00
875	whatsapp_success_rate	100	{}	2025-10-15 23:10:00.03219+00
878	sla_violation	2	{}	2025-10-15 23:10:00.03454+00
946	memory_usage	28.173017501831055	{}	2025-10-15 23:35:00.011163+00
950	disk_usage	7	{}	2025-10-15 23:35:00.017738+00
953	whatsapp_success_rate	100	{}	2025-10-15 23:35:00.019992+00
957	sla_violation	2	{}	2025-10-15 23:35:00.021539+00
1027	memory_usage	28.19976806640625	{}	2025-10-16 00:00:00.025976+00
1030	disk_usage	7	{}	2025-10-16 00:00:00.032217+00
1032	whatsapp_success_rate	100	{}	2025-10-16 00:00:00.035283+00
1034	sla_violation	2	{}	2025-10-16 00:00:00.037991+00
1121	memory_usage	29.639863967895508	{}	2025-10-16 00:25:00.018193+00
1125	disk_usage	7	{}	2025-10-16 00:25:00.025252+00
1128	whatsapp_success_rate	100	{}	2025-10-16 00:25:00.027903+00
1132	sla_violation	2	{}	2025-10-16 00:25:00.030211+00
1203	memory_usage	29.715299606323242	{}	2025-10-16 00:45:00.020499+00
1207	disk_usage	7	{}	2025-10-16 00:45:00.028597+00
1210	whatsapp_success_rate	100	{}	2025-10-16 00:45:00.03083+00
1213	sla_violation	2	{}	2025-10-16 00:45:00.03308+00
1301	memory_usage	32.57088661193848	{}	2025-10-16 01:03:50.077585+00
1302	disk_usage	7	{}	2025-10-16 01:03:50.08708+00
1303	whatsapp_success_rate	100	{}	2025-10-16 01:03:50.090673+00
1304	sla_violation	2	{}	2025-10-16 01:03:50.093614+00
1399	memory_usage	30.204057693481445	{}	2025-10-16 01:15:00.032943+00
1403	disk_usage	7	{}	2025-10-16 01:15:00.039114+00
1405	whatsapp_success_rate	100	{}	2025-10-16 01:15:00.04195+00
1407	sla_violation	2	{}	2025-10-16 01:15:00.044547+00
1492	memory_usage	30.629920959472656	{}	2025-10-16 01:35:00.014049+00
1495	disk_usage	7	{}	2025-10-16 01:35:00.020516+00
1500	whatsapp_success_rate	100	{}	2025-10-16 01:35:00.02326+00
1502	sla_violation	2	{}	2025-10-16 01:35:00.026083+00
1601	memory_usage	29.700136184692383	{}	2025-10-16 02:05:00.010434+00
1606	disk_usage	7	{}	2025-10-16 02:05:00.017397+00
1610	whatsapp_success_rate	100	{}	2025-10-16 02:05:00.020554+00
1614	sla_violation	2	{}	2025-10-16 02:05:00.022976+00
1698	memory_usage	29.521942138671875	{}	2025-10-16 02:30:00.02768+00
1702	disk_usage	7	{}	2025-10-16 02:30:00.036695+00
1706	whatsapp_success_rate	100	{}	2025-10-16 02:30:00.040288+00
1710	sla_violation	2	{}	2025-10-16 02:30:00.042621+00
1795	memory_usage	29.450607299804688	{}	2025-10-16 03:00:00.030435+00
1799	disk_usage	7	{}	2025-10-16 03:00:00.037399+00
1800	whatsapp_success_rate	100	{}	2025-10-16 03:00:00.04023+00
1803	sla_violation	3	{}	2025-10-16 03:00:00.042907+00
1892	memory_usage	30.00631332397461	{}	2025-10-16 03:30:00.027024+00
1898	disk_usage	7	{}	2025-10-16 03:30:00.034965+00
1902	whatsapp_success_rate	100	{}	2025-10-16 03:30:00.038344+00
1903	sla_violation	3	{}	2025-10-16 03:30:00.041577+00
2001	memory_usage	29.964828491210938	{}	2025-10-16 04:00:00.026838+00
2003	disk_usage	7	{}	2025-10-16 04:00:00.035318+00
2004	whatsapp_success_rate	100	{}	2025-10-16 04:00:00.040111+00
2005	sla_violation	3	{}	2025-10-16 04:00:00.045371+00
2098	memory_usage	29.62946891784668	{}	2025-10-16 04:25:00.012184+00
2102	disk_usage	7	{}	2025-10-16 04:25:00.019249+00
2106	whatsapp_success_rate	100	{}	2025-10-16 04:25:00.021231+00
2110	sla_violation	3	{}	2025-10-16 04:25:00.023467+00
2195	memory_usage	30.1969051361084	{}	2025-10-16 04:55:00.016321+00
2202	disk_usage	7	{}	2025-10-16 04:55:00.022714+00
2205	whatsapp_success_rate	100	{}	2025-10-16 04:55:00.026344+00
2208	sla_violation	3	{}	2025-10-16 04:55:00.030122+00
2292	memory_usage	29.870128631591797	{}	2025-10-16 05:25:00.021022+00
2299	disk_usage	7	{}	2025-10-16 05:25:00.028947+00
2303	whatsapp_success_rate	100	{}	2025-10-16 05:25:00.03238+00
2304	sla_violation	3	{}	2025-10-16 05:25:00.034995+00
2401	memory_usage	18.039608001708984	{}	2025-10-16 06:00:00.027595+00
2404	disk_usage	7	{}	2025-10-16 06:00:00.035153+00
2405	whatsapp_success_rate	100	{}	2025-10-16 06:00:00.039339+00
2409	sla_violation	3	{}	2025-10-16 06:00:00.042457+00
2498	memory_usage	18.321847915649414	{}	2025-10-16 06:30:00.035677+00
2502	disk_usage	7	{}	2025-10-16 06:30:00.045274+00
2505	whatsapp_success_rate	100	{}	2025-10-16 06:30:00.048136+00
2509	sla_violation	3	{}	2025-10-16 06:30:00.050511+00
2597	memory_usage	18.381690979003906	{}	2025-10-16 07:00:00.033472+00
2603	disk_usage	7	{}	2025-10-16 07:00:00.040023+00
2605	whatsapp_success_rate	100	{}	2025-10-16 07:00:00.043122+00
2607	sla_violation	3	{}	2025-10-16 07:00:00.046965+00
2692	memory_usage	18.419551849365234	{}	2025-10-16 07:30:00.03565+00
2696	disk_usage	7	{}	2025-10-16 07:30:00.042186+00
2700	whatsapp_success_rate	100	{}	2025-10-16 07:30:00.044665+00
2704	sla_violation	3	{}	2025-10-16 07:30:00.047016+00
2802	memory_usage	18.381881713867188	{}	2025-10-16 08:05:00.017354+00
2808	disk_usage	7	{}	2025-10-16 08:05:00.025044+00
2811	whatsapp_success_rate	100	{}	2025-10-16 08:05:00.027384+00
2816	sla_violation	3	{}	2025-10-16 08:05:00.031418+00
2899	memory_usage	18.384790420532227	{}	2025-10-16 08:35:00.019389+00
2903	disk_usage	7	{}	2025-10-16 08:35:00.02663+00
2907	whatsapp_success_rate	100	{}	2025-10-16 08:35:00.02971+00
2911	sla_violation	3	{}	2025-10-16 08:35:00.03223+00
2996	memory_usage	18.43104362487793	{}	2025-10-16 09:05:00.021042+00
3001	disk_usage	7	{}	2025-10-16 09:05:00.027817+00
3006	whatsapp_success_rate	100	{}	2025-10-16 09:05:00.031102+00
3008	sla_violation	3	{}	2025-10-16 09:05:00.034004+00
3092	memory_usage	18.48454475402832	{}	2025-10-16 09:35:00.022918+00
3099	disk_usage	7	{}	2025-10-16 09:35:00.028287+00
3103	whatsapp_success_rate	100	{}	2025-10-16 09:35:00.030816+00
3104	sla_violation	3	{}	2025-10-16 09:35:00.033364+00
3175	memory_usage	18.574094772338867	{}	2025-10-16 10:00:00.036564+00
3182	disk_usage	7	{}	2025-10-16 10:00:00.0439+00
3183	whatsapp_success_rate	100	{}	2025-10-16 10:00:00.046449+00
3184	sla_violation	3	{}	2025-10-16 10:00:00.048806+00
3244	sla_violation	3	{}	2025-10-16 10:20:00.033769+00
633	memory_usage	30.306053161621094	{}	2025-10-15 22:30:11.57268+00
635	disk_usage	7	{}	2025-10-15 22:30:11.581809+00
636	whatsapp_success_rate	100	{}	2025-10-15 22:30:11.584925+00
639	sla_violation	2	{}	2025-10-15 22:30:11.592136+00
709	memory_usage	26.320266723632812	{}	2025-10-15 22:50:00.022562+00
713	disk_usage	7	{}	2025-10-15 22:50:00.02844+00
716	whatsapp_success_rate	100	{}	2025-10-15 22:50:00.031025+00
719	sla_violation	2	{}	2025-10-15 22:50:00.033184+00
789	memory_usage	27.944087982177734	{}	2025-10-15 23:00:00.031542+00
793	disk_usage	7	{}	2025-10-15 23:00:00.03936+00
795	whatsapp_success_rate	100	{}	2025-10-15 23:00:00.042334+00
798	sla_violation	2	{}	2025-10-15 23:00:00.045081+00
868	memory_usage	27.59251594543457	{}	2025-10-15 23:10:00.022117+00
873	disk_usage	7	{}	2025-10-15 23:10:00.029146+00
876	whatsapp_success_rate	100	{}	2025-10-15 23:10:00.032212+00
879	sla_violation	2	{}	2025-10-15 23:10:00.034926+00
947	memory_usage	28.17540168762207	{}	2025-10-15 23:35:00.011804+00
951	disk_usage	7	{}	2025-10-15 23:35:00.0182+00
954	whatsapp_success_rate	100	{}	2025-10-15 23:35:00.020333+00
959	sla_violation	2	{}	2025-10-15 23:35:00.022992+00
1031	memory_usage	28.283262252807617	{}	2025-10-16 00:00:00.033156+00
1035	disk_usage	7	{}	2025-10-16 00:00:00.039713+00
1037	whatsapp_success_rate	100	{}	2025-10-16 00:00:00.043044+00
1039	sla_violation	2	{}	2025-10-16 00:00:00.045994+00
1123	memory_usage	29.639863967895508	{}	2025-10-16 00:25:00.018728+00
1127	disk_usage	7	{}	2025-10-16 00:25:00.025923+00
1131	whatsapp_success_rate	100	{}	2025-10-16 00:25:00.028696+00
1134	sla_violation	2	{}	2025-10-16 00:25:00.031175+00
1204	memory_usage	29.74228858947754	{}	2025-10-16 00:45:00.025831+00
1214	disk_usage	7	{}	2025-10-16 00:45:00.033122+00
1215	whatsapp_success_rate	100	{}	2025-10-16 00:45:00.036864+00
1216	sla_violation	2	{}	2025-10-16 00:45:00.039024+00
1305	memory_usage	32.61075019836426	{}	2025-10-16 01:03:50.15287+00
1306	disk_usage	7	{}	2025-10-16 01:03:50.160336+00
1307	whatsapp_success_rate	100	{}	2025-10-16 01:03:50.162848+00
1308	sla_violation	2	{}	2025-10-16 01:03:50.164616+00
1402	memory_usage	30.216121673583984	{}	2025-10-16 01:15:00.033826+00
1404	disk_usage	7	{}	2025-10-16 01:15:00.040087+00
1406	whatsapp_success_rate	100	{}	2025-10-16 01:15:00.042731+00
1408	sla_violation	2	{}	2025-10-16 01:15:00.04523+00
1505	memory_usage	30.927038192749023	{}	2025-10-16 01:40:00.010348+00
1511	disk_usage	7	{}	2025-10-16 01:40:00.017845+00
1515	whatsapp_success_rate	100	{}	2025-10-16 01:40:00.020002+00
1519	sla_violation	2	{}	2025-10-16 01:40:00.022274+00
1602	memory_usage	29.700851440429688	{}	2025-10-16 02:05:00.011072+00
1605	disk_usage	7	{}	2025-10-16 02:05:00.017409+00
1608	whatsapp_success_rate	100	{}	2025-10-16 02:05:00.020285+00
1612	sla_violation	2	{}	2025-10-16 02:05:00.022684+00
1699	memory_usage	29.521942138671875	{}	2025-10-16 02:30:00.028557+00
1703	disk_usage	7	{}	2025-10-16 02:30:00.037362+00
1707	whatsapp_success_rate	100	{}	2025-10-16 02:30:00.040993+00
1711	sla_violation	2	{}	2025-10-16 02:30:00.043812+00
1796	memory_usage	29.520273208618164	{}	2025-10-16 03:00:00.035206+00
1804	disk_usage	7	{}	2025-10-16 03:00:00.043601+00
1807	whatsapp_success_rate	100	{}	2025-10-16 03:00:00.046499+00
1808	sla_violation	3	{}	2025-10-16 03:00:00.051047+00
1905	memory_usage	29.84185218811035	{}	2025-10-16 03:35:00.009621+00
1909	disk_usage	7	{}	2025-10-16 03:35:00.018249+00
1912	whatsapp_success_rate	100	{}	2025-10-16 03:35:00.022797+00
1916	sla_violation	3	{}	2025-10-16 03:35:00.025768+00
2002	memory_usage	29.998350143432617	{}	2025-10-16 04:00:00.032222+00
2006	disk_usage	7	{}	2025-10-16 04:00:00.046998+00
2010	whatsapp_success_rate	100	{}	2025-10-16 04:00:00.058461+00
2015	sla_violation	3	{}	2025-10-16 04:00:00.065927+00
2099	memory_usage	29.64034080505371	{}	2025-10-16 04:25:00.013063+00
2103	disk_usage	7	{}	2025-10-16 04:25:00.019237+00
2107	whatsapp_success_rate	100	{}	2025-10-16 04:25:00.02181+00
2111	sla_violation	3	{}	2025-10-16 04:25:00.02396+00
2196	memory_usage	30.20172119140625	{}	2025-10-16 04:55:00.016976+00
2201	disk_usage	7	{}	2025-10-16 04:55:00.02267+00
2206	whatsapp_success_rate	100	{}	2025-10-16 04:55:00.026455+00
2207	sla_violation	3	{}	2025-10-16 04:55:00.030091+00
2305	memory_usage	30.010986328125	{}	2025-10-16 05:30:00.02755+00
2308	disk_usage	7	{}	2025-10-16 05:30:00.035026+00
2312	whatsapp_success_rate	100	{}	2025-10-16 05:30:00.037634+00
2315	sla_violation	3	{}	2025-10-16 05:30:00.040723+00
2402	memory_usage	18.027496337890625	{}	2025-10-16 06:00:00.027716+00
2407	disk_usage	7	{}	2025-10-16 06:00:00.041077+00
2411	whatsapp_success_rate	100	{}	2025-10-16 06:00:00.04543+00
2414	sla_violation	3	{}	2025-10-16 06:00:00.048648+00
2499	memory_usage	18.32098960876465	{}	2025-10-16 06:30:00.037249+00
2504	disk_usage	7	{}	2025-10-16 06:30:00.047292+00
2508	whatsapp_success_rate	100	{}	2025-10-16 06:30:00.050244+00
2511	sla_violation	3	{}	2025-10-16 06:30:00.052817+00
2600	memory_usage	18.40043067932129	{}	2025-10-16 07:00:00.03662+00
2604	disk_usage	7	{}	2025-10-16 07:00:00.043108+00
2606	whatsapp_success_rate	100	{}	2025-10-16 07:00:00.045653+00
2608	sla_violation	3	{}	2025-10-16 07:00:00.047772+00
2705	memory_usage	18.303823471069336	{}	2025-10-16 07:35:00.018308+00
2709	disk_usage	7	{}	2025-10-16 07:35:00.02585+00
2713	whatsapp_success_rate	100	{}	2025-10-16 07:35:00.029072+00
2717	sla_violation	3	{}	2025-10-16 07:35:00.031615+00
2803	memory_usage	18.381881713867188	{}	2025-10-16 08:05:00.017285+00
2806	disk_usage	7	{}	2025-10-16 08:05:00.024489+00
2810	whatsapp_success_rate	100	{}	2025-10-16 08:05:00.027219+00
2814	sla_violation	3	{}	2025-10-16 08:05:00.031402+00
2900	memory_usage	18.387842178344727	{}	2025-10-16 08:35:00.020805+00
2904	disk_usage	7	{}	2025-10-16 08:35:00.027943+00
2908	whatsapp_success_rate	100	{}	2025-10-16 08:35:00.030646+00
2912	sla_violation	3	{}	2025-10-16 08:35:00.033106+00
3009	memory_usage	18.42207908630371	{}	2025-10-16 09:10:00.017038+00
3015	disk_usage	7	{}	2025-10-16 09:10:00.02521+00
3016	whatsapp_success_rate	100	{}	2025-10-16 09:10:00.028171+00
3019	sla_violation	3	{}	2025-10-16 09:10:00.03061+00
3105	memory_usage	18.515634536743164	{}	2025-10-16 09:40:00.017641+00
3109	disk_usage	7	{}	2025-10-16 09:40:00.026175+00
3113	whatsapp_success_rate	100	{}	2025-10-16 09:40:00.028799+00
3115	sla_violation	3	{}	2025-10-16 09:40:00.031187+00
3185	memory_usage	18.480968475341797	{}	2025-10-16 10:05:00.017073+00
3189	disk_usage	7	{}	2025-10-16 10:05:00.02423+00
3192	whatsapp_success_rate	100	{}	2025-10-16 10:05:00.026845+00
3196	sla_violation	3	{}	2025-10-16 10:05:00.029174+00
3246	disk_usage	7	{}	2025-10-16 10:20:00.034666+00
634	memory_usage	30.317306518554688	{}	2025-10-15 22:30:11.577583+00
637	disk_usage	7	{}	2025-10-15 22:30:11.586355+00
638	whatsapp_success_rate	100	{}	2025-10-15 22:30:11.589793+00
640	sla_violation	2	{}	2025-10-15 22:30:11.593415+00
711	memory_usage	26.320266723632812	{}	2025-10-15 22:50:00.023621+00
715	disk_usage	7	{}	2025-10-15 22:50:00.029835+00
718	whatsapp_success_rate	100	{}	2025-10-15 22:50:00.033185+00
720	sla_violation	2	{}	2025-10-15 22:50:00.035917+00
791	memory_usage	27.937698364257812	{}	2025-10-15 23:00:00.034257+00
796	disk_usage	7	{}	2025-10-15 23:00:00.042449+00
799	whatsapp_success_rate	100	{}	2025-10-15 23:00:00.045979+00
800	sla_violation	2	{}	2025-10-15 23:00:00.049008+00
870	memory_usage	27.599573135375977	{}	2025-10-15 23:10:00.023684+00
874	disk_usage	7	{}	2025-10-15 23:10:00.029961+00
877	whatsapp_success_rate	100	{}	2025-10-15 23:10:00.032604+00
880	sla_violation	2	{}	2025-10-15 23:10:00.035119+00
948	memory_usage	28.18140983581543	{}	2025-10-15 23:35:00.015463+00
955	disk_usage	7	{}	2025-10-15 23:35:00.021134+00
958	whatsapp_success_rate	100	{}	2025-10-15 23:35:00.022934+00
960	sla_violation	2	{}	2025-10-15 23:35:00.025599+00
1033	memory_usage	28.240442276000977	{}	2025-10-16 00:00:00.035391+00
1036	disk_usage	7	{}	2025-10-16 00:00:00.042336+00
1038	whatsapp_success_rate	100	{}	2025-10-16 00:00:00.044925+00
1040	sla_violation	2	{}	2025-10-16 00:00:00.047142+00
1122	memory_usage	29.639863967895508	{}	2025-10-16 00:25:00.018533+00
1126	disk_usage	7	{}	2025-10-16 00:25:00.025465+00
1130	whatsapp_success_rate	100	{}	2025-10-16 00:25:00.028423+00
1135	sla_violation	2	{}	2025-10-16 00:25:00.031224+00
1217	memory_usage	31.85405731201172	{}	2025-10-16 00:49:51.909216+00
1219	disk_usage	7	{}	2025-10-16 00:49:51.91714+00
1220	whatsapp_success_rate	100	{}	2025-10-16 00:49:51.92007+00
1222	sla_violation	2	{}	2025-10-16 00:49:51.9225+00
1239	memory_usage	32.07216262817383	{}	2025-10-16 00:50:00.021319+00
1245	disk_usage	7	{}	2025-10-16 00:50:00.027233+00
1247	whatsapp_success_rate	100	{}	2025-10-16 00:50:00.028564+00
1248	sla_violation	2	{}	2025-10-16 00:50:00.030072+00
1309	memory_usage	32.6291561126709	{}	2025-10-16 01:03:50.179427+00
1310	disk_usage	7	{}	2025-10-16 01:03:50.186664+00
1311	whatsapp_success_rate	100	{}	2025-10-16 01:03:50.189929+00
1312	sla_violation	2	{}	2025-10-16 01:03:50.192422+00
1409	memory_usage	32.66782760620117	{}	2025-10-16 01:19:02.326846+00
1410	disk_usage	7	{}	2025-10-16 01:19:02.335493+00
1411	whatsapp_success_rate	100	{}	2025-10-16 01:19:02.339003+00
1412	sla_violation	2	{}	2025-10-16 01:19:02.341694+00
1506	memory_usage	30.927038192749023	{}	2025-10-16 01:40:00.01046+00
1509	disk_usage	7	{}	2025-10-16 01:40:00.017317+00
1513	whatsapp_success_rate	100	{}	2025-10-16 01:40:00.01968+00
1517	sla_violation	2	{}	2025-10-16 01:40:00.021889+00
1603	memory_usage	29.709768295288086	{}	2025-10-16 02:05:00.01232+00
1607	disk_usage	7	{}	2025-10-16 02:05:00.018774+00
1611	whatsapp_success_rate	100	{}	2025-10-16 02:05:00.021137+00
1615	sla_violation	2	{}	2025-10-16 02:05:00.023577+00
1700	memory_usage	29.576444625854492	{}	2025-10-16 02:30:00.033217+00
1705	disk_usage	7	{}	2025-10-16 02:30:00.039556+00
1709	whatsapp_success_rate	100	{}	2025-10-16 02:30:00.042405+00
1712	sla_violation	2	{}	2025-10-16 02:30:00.045179+00
1809	memory_usage	29.453134536743164	{}	2025-10-16 03:05:00.017839+00
1812	disk_usage	7	{}	2025-10-16 03:05:00.024067+00
1815	whatsapp_success_rate	100	{}	2025-10-16 03:05:00.026807+00
1818	sla_violation	3	{}	2025-10-16 03:05:00.029061+00
1906	memory_usage	29.85215187072754	{}	2025-10-16 03:35:00.011788+00
1910	disk_usage	7	{}	2025-10-16 03:35:00.019412+00
1914	whatsapp_success_rate	100	{}	2025-10-16 03:35:00.02495+00
1918	sla_violation	3	{}	2025-10-16 03:35:00.027153+00
2007	memory_usage	29.9652099609375	{}	2025-10-16 04:00:00.050407+00
2009	disk_usage	7	{}	2025-10-16 04:00:00.058278+00
2012	whatsapp_success_rate	100	{}	2025-10-16 04:00:00.063535+00
2014	sla_violation	3	{}	2025-10-16 04:00:00.065918+00
2100	memory_usage	29.64034080505371	{}	2025-10-16 04:25:00.013235+00
2104	disk_usage	7	{}	2025-10-16 04:25:00.019873+00
2108	whatsapp_success_rate	100	{}	2025-10-16 04:25:00.022334+00
2112	sla_violation	3	{}	2025-10-16 04:25:00.02434+00
2209	memory_usage	30.280017852783203	{}	2025-10-16 05:00:00.021952+00
2213	disk_usage	7	{}	2025-10-16 05:00:00.031789+00
2217	whatsapp_success_rate	100	{}	2025-10-16 05:00:00.034994+00
2221	sla_violation	3	{}	2025-10-16 05:00:00.037648+00
2306	memory_usage	29.99706268310547	{}	2025-10-16 05:30:00.027676+00
2311	disk_usage	7	{}	2025-10-16 05:30:00.036303+00
2314	whatsapp_success_rate	100	{}	2025-10-16 05:30:00.03976+00
2318	sla_violation	3	{}	2025-10-16 05:30:00.042948+00
2403	memory_usage	18.066072463989258	{}	2025-10-16 06:00:00.031675+00
2406	disk_usage	7	{}	2025-10-16 06:00:00.04053+00
2410	whatsapp_success_rate	100	{}	2025-10-16 06:00:00.043855+00
2412	sla_violation	3	{}	2025-10-16 06:00:00.047212+00
2500	memory_usage	18.317699432373047	{}	2025-10-16 06:30:00.040431+00
2506	disk_usage	7	{}	2025-10-16 06:30:00.04924+00
2510	whatsapp_success_rate	100	{}	2025-10-16 06:30:00.051985+00
2512	sla_violation	3	{}	2025-10-16 06:30:00.05456+00
2609	memory_usage	18.311738967895508	{}	2025-10-16 07:05:00.017013+00
2614	disk_usage	7	{}	2025-10-16 07:05:00.024134+00
2616	whatsapp_success_rate	100	{}	2025-10-16 07:05:00.027117+00
2620	sla_violation	3	{}	2025-10-16 07:05:00.029999+00
2707	memory_usage	18.303823471069336	{}	2025-10-16 07:35:00.019455+00
2706	memory_usage	18.303823471069336	{}	2025-10-16 07:35:00.019283+00
2711	disk_usage	7	{}	2025-10-16 07:35:00.027277+00
2712	disk_usage	7	{}	2025-10-16 07:35:00.027397+00
2715	whatsapp_success_rate	100	{}	2025-10-16 07:35:00.031054+00
2716	whatsapp_success_rate	100	{}	2025-10-16 07:35:00.031232+00
2719	sla_violation	3	{}	2025-10-16 07:35:00.034131+00
2720	sla_violation	3	{}	2025-10-16 07:35:00.034942+00
2804	memory_usage	18.384933471679688	{}	2025-10-16 08:05:00.01819+00
2807	disk_usage	7	{}	2025-10-16 08:05:00.024904+00
2812	whatsapp_success_rate	100	{}	2025-10-16 08:05:00.027442+00
2815	sla_violation	3	{}	2025-10-16 08:05:00.031408+00
2913	memory_usage	18.35322380065918	{}	2025-10-16 08:40:00.01758+00
2916	disk_usage	7	{}	2025-10-16 08:40:00.023627+00
2920	whatsapp_success_rate	100	{}	2025-10-16 08:40:00.026362+00
2923	sla_violation	3	{}	2025-10-16 08:40:00.028536+00
3010	memory_usage	18.42207908630371	{}	2025-10-16 09:10:00.017283+00
3012	disk_usage	7	{}	2025-10-16 09:10:00.024738+00
3018	whatsapp_success_rate	100	{}	2025-10-16 09:10:00.02885+00
3022	sla_violation	3	{}	2025-10-16 09:10:00.032241+00
3106	memory_usage	18.515634536743164	{}	2025-10-16 09:40:00.018439+00
641	memory_usage	28.373050689697266	{}	2025-10-15 22:35:00.011937+00
647	disk_usage	7	{}	2025-10-15 22:35:00.019391+00
651	whatsapp_success_rate	100	{}	2025-10-15 22:35:00.021683+00
655	sla_violation	2	{}	2025-10-15 22:35:00.02411+00
721	memory_usage	28.7106990814209	{}	2025-10-15 22:53:31.000467+00
722	disk_usage	7	{}	2025-10-15 22:53:31.007982+00
723	whatsapp_success_rate	100	{}	2025-10-15 22:53:31.010425+00
724	sla_violation	2	{}	2025-10-15 22:53:31.012097+00
801	memory_usage	27.850055694580078	{}	2025-10-15 23:05:00.012375+00
803	disk_usage	7	{}	2025-10-15 23:05:00.021053+00
806	whatsapp_success_rate	100	{}	2025-10-15 23:05:00.024652+00
809	sla_violation	2	{}	2025-10-15 23:05:00.02913+00
881	memory_usage	27.74052619934082	{}	2025-10-15 23:15:00.018937+00
882	disk_usage	7	{}	2025-10-15 23:15:00.02612+00
883	whatsapp_success_rate	100	{}	2025-10-15 23:15:00.028755+00
887	sla_violation	2	{}	2025-10-15 23:15:00.031015+00
961	memory_usage	28.353309631347656	{}	2025-10-15 23:40:00.014907+00
965	disk_usage	7	{}	2025-10-15 23:40:00.021755+00
966	whatsapp_success_rate	100	{}	2025-10-15 23:40:00.023705+00
970	sla_violation	2	{}	2025-10-15 23:40:00.025187+00
1041	memory_usage	28.599262237548828	{}	2025-10-16 00:05:00.007914+00
1043	disk_usage	7	{}	2025-10-16 00:05:00.015042+00
1045	whatsapp_success_rate	100	{}	2025-10-16 00:05:00.017416+00
1048	sla_violation	2	{}	2025-10-16 00:05:00.019567+00
1124	memory_usage	29.681873321533203	{}	2025-10-16 00:25:00.022257+00
1129	disk_usage	7	{}	2025-10-16 00:25:00.028005+00
1133	whatsapp_success_rate	100	{}	2025-10-16 00:25:00.030768+00
1136	sla_violation	2	{}	2025-10-16 00:25:00.033201+00
1218	memory_usage	31.880998611450195	{}	2025-10-16 00:49:51.913144+00
1221	disk_usage	7	{}	2025-10-16 00:49:51.920896+00
1223	whatsapp_success_rate	100	{}	2025-10-16 00:49:51.924112+00
1224	sla_violation	2	{}	2025-10-16 00:49:51.92756+00
1234	memory_usage	32.07569122314453	{}	2025-10-16 00:50:00.014202+00
1237	disk_usage	7	{}	2025-10-16 00:50:00.019875+00
1238	whatsapp_success_rate	100	{}	2025-10-16 00:50:00.021254+00
1241	sla_violation	2	{}	2025-10-16 00:50:00.022677+00
1313	memory_usage	30.2828311920166	{}	2025-10-16 01:05:00.012834+00
1318	disk_usage	7	{}	2025-10-16 01:05:00.019719+00
1323	whatsapp_success_rate	100	{}	2025-10-16 01:05:00.02226+00
1328	sla_violation	2	{}	2025-10-16 01:05:00.024741+00
1413	memory_usage	32.69920349121094	{}	2025-10-16 01:19:02.347313+00
1414	disk_usage	7	{}	2025-10-16 01:19:02.355558+00
1415	whatsapp_success_rate	100	{}	2025-10-16 01:19:02.358619+00
1416	sla_violation	2	{}	2025-10-16 01:19:02.361126+00
1507	memory_usage	30.927038192749023	{}	2025-10-16 01:40:00.010666+00
1510	disk_usage	7	{}	2025-10-16 01:40:00.017383+00
1514	whatsapp_success_rate	100	{}	2025-10-16 01:40:00.019895+00
1518	sla_violation	2	{}	2025-10-16 01:40:00.022221+00
1604	memory_usage	29.71038818359375	{}	2025-10-16 02:05:00.013953+00
1609	disk_usage	7	{}	2025-10-16 02:05:00.02045+00
1613	whatsapp_success_rate	100	{}	2025-10-16 02:05:00.022864+00
1616	sla_violation	2	{}	2025-10-16 02:05:00.025662+00
1713	memory_usage	29.490995407104492	{}	2025-10-16 02:35:00.018562+00
1717	disk_usage	7	{}	2025-10-16 02:35:00.025925+00
1721	whatsapp_success_rate	100	{}	2025-10-16 02:35:00.028993+00
1724	sla_violation	2	{}	2025-10-16 02:35:00.031687+00
1810	memory_usage	29.453134536743164	{}	2025-10-16 03:05:00.017954+00
1813	disk_usage	7	{}	2025-10-16 03:05:00.025163+00
1816	whatsapp_success_rate	100	{}	2025-10-16 03:05:00.027698+00
1820	sla_violation	3	{}	2025-10-16 03:05:00.029848+00
1907	memory_usage	29.857778549194336	{}	2025-10-16 03:35:00.012411+00
1911	disk_usage	7	{}	2025-10-16 03:35:00.021101+00
1915	whatsapp_success_rate	100	{}	2025-10-16 03:35:00.025316+00
1919	sla_violation	3	{}	2025-10-16 03:35:00.027879+00
2008	memory_usage	29.974842071533203	{}	2025-10-16 04:00:00.050388+00
2011	disk_usage	7	{}	2025-10-16 04:00:00.060179+00
2013	whatsapp_success_rate	100	{}	2025-10-16 04:00:00.063563+00
2016	sla_violation	3	{}	2025-10-16 04:00:00.066334+00
2113	memory_usage	30.017375946044922	{}	2025-10-16 04:30:00.015229+00
2115	disk_usage	7	{}	2025-10-16 04:30:00.024007+00
2117	whatsapp_success_rate	100	{}	2025-10-16 04:30:00.026725+00
2119	sla_violation	3	{}	2025-10-16 04:30:00.028803+00
2210	memory_usage	30.280017852783203	{}	2025-10-16 05:00:00.022076+00
2215	disk_usage	7	{}	2025-10-16 05:00:00.032652+00
2219	whatsapp_success_rate	100	{}	2025-10-16 05:00:00.035356+00
2223	sla_violation	3	{}	2025-10-16 05:00:00.037877+00
2307	memory_usage	29.997873306274414	{}	2025-10-16 05:30:00.028157+00
2309	disk_usage	7	{}	2025-10-16 05:30:00.035345+00
2313	whatsapp_success_rate	100	{}	2025-10-16 05:30:00.03804+00
2316	sla_violation	3	{}	2025-10-16 05:30:00.041293+00
2408	memory_usage	18.097400665283203	{}	2025-10-16 06:00:00.041029+00
2413	disk_usage	7	{}	2025-10-16 06:00:00.048293+00
2415	whatsapp_success_rate	100	{}	2025-10-16 06:00:00.050826+00
2416	sla_violation	3	{}	2025-10-16 06:00:00.053683+00
2513	memory_usage	18.29395294189453	{}	2025-10-16 06:35:00.018146+00
2518	disk_usage	7	{}	2025-10-16 06:35:00.026371+00
2522	whatsapp_success_rate	100	{}	2025-10-16 06:35:00.029613+00
2525	sla_violation	3	{}	2025-10-16 06:35:00.031838+00
2610	memory_usage	18.311738967895508	{}	2025-10-16 07:05:00.01701+00
2613	disk_usage	7	{}	2025-10-16 07:05:00.023847+00
2618	whatsapp_success_rate	100	{}	2025-10-16 07:05:00.028081+00
2622	sla_violation	3	{}	2025-10-16 07:05:00.03232+00
2708	memory_usage	18.303823471069336	{}	2025-10-16 07:35:00.019753+00
2710	disk_usage	7	{}	2025-10-16 07:35:00.026908+00
2714	whatsapp_success_rate	100	{}	2025-10-16 07:35:00.029363+00
2718	sla_violation	3	{}	2025-10-16 07:35:00.03189+00
2817	memory_usage	18.354320526123047	{}	2025-10-16 08:10:00.017559+00
2821	disk_usage	7	{}	2025-10-16 08:10:00.024506+00
2825	whatsapp_success_rate	100	{}	2025-10-16 08:10:00.02711+00
2829	sla_violation	3	{}	2025-10-16 08:10:00.029434+00
2914	memory_usage	18.35322380065918	{}	2025-10-16 08:40:00.01775+00
2917	disk_usage	7	{}	2025-10-16 08:40:00.024428+00
2921	whatsapp_success_rate	100	{}	2025-10-16 08:40:00.02726+00
2924	sla_violation	3	{}	2025-10-16 08:40:00.029286+00
3011	memory_usage	18.42207908630371	{}	2025-10-16 09:10:00.01864+00
3013	disk_usage	7	{}	2025-10-16 09:10:00.02479+00
3017	whatsapp_success_rate	100	{}	2025-10-16 09:10:00.028212+00
3021	sla_violation	3	{}	2025-10-16 09:10:00.031503+00
3107	memory_usage	18.515634536743164	{}	2025-10-16 09:40:00.020483+00
3110	disk_usage	7	{}	2025-10-16 09:40:00.028404+00
3114	whatsapp_success_rate	100	{}	2025-10-16 09:40:00.03099+00
3118	sla_violation	3	{}	2025-10-16 09:40:00.033245+00
3186	memory_usage	18.480968475341797	{}	2025-10-16 10:05:00.017093+00
642	memory_usage	28.37371826171875	{}	2025-10-15 22:35:00.012685+00
646	disk_usage	7	{}	2025-10-15 22:35:00.019197+00
652	whatsapp_success_rate	100	{}	2025-10-15 22:35:00.021763+00
656	sla_violation	2	{}	2025-10-15 22:35:00.024451+00
725	memory_usage	28.73101234436035	{}	2025-10-15 22:53:31.059875+00
726	disk_usage	7	{}	2025-10-15 22:53:31.067753+00
727	whatsapp_success_rate	100	{}	2025-10-15 22:53:31.070749+00
728	sla_violation	2	{}	2025-10-15 22:53:31.07341+00
802	memory_usage	27.850055694580078	{}	2025-10-15 23:05:00.012832+00
804	disk_usage	7	{}	2025-10-15 23:05:00.021707+00
808	whatsapp_success_rate	100	{}	2025-10-15 23:05:00.026228+00
810	sla_violation	2	{}	2025-10-15 23:05:00.029691+00
884	memory_usage	27.743244171142578	{}	2025-10-15 23:15:00.028949+00
888	disk_usage	7	{}	2025-10-15 23:15:00.034758+00
891	whatsapp_success_rate	100	{}	2025-10-15 23:15:00.037522+00
894	sla_violation	2	{}	2025-10-15 23:15:00.040268+00
962	memory_usage	28.318214416503906	{}	2025-10-15 23:40:00.017818+00
967	disk_usage	7	{}	2025-10-15 23:40:00.023778+00
971	whatsapp_success_rate	100	{}	2025-10-15 23:40:00.026617+00
974	sla_violation	2	{}	2025-10-15 23:40:00.02976+00
1042	memory_usage	28.600788116455078	{}	2025-10-16 00:05:00.011071+00
1044	disk_usage	7	{}	2025-10-16 00:05:00.016753+00
1047	whatsapp_success_rate	100	{}	2025-10-16 00:05:00.018558+00
1049	sla_violation	2	{}	2025-10-16 00:05:00.020294+00
1137	memory_usage	29.639911651611328	{}	2025-10-16 00:30:00.026595+00
1139	disk_usage	7	{}	2025-10-16 00:30:00.033568+00
1142	whatsapp_success_rate	100	{}	2025-10-16 00:30:00.036488+00
1144	sla_violation	2	{}	2025-10-16 00:30:00.03941+00
1225	memory_usage	31.97193145751953	{}	2025-10-16 00:49:52.02312+00
1226	disk_usage	7	{}	2025-10-16 00:49:52.031215+00
1227	whatsapp_success_rate	100	{}	2025-10-16 00:49:52.03423+00
1228	sla_violation	2	{}	2025-10-16 00:49:52.036731+00
1314	memory_usage	30.2828311920166	{}	2025-10-16 01:05:00.013115+00
1317	disk_usage	7	{}	2025-10-16 01:05:00.019683+00
1321	whatsapp_success_rate	100	{}	2025-10-16 01:05:00.021876+00
1325	sla_violation	2	{}	2025-10-16 01:05:00.023418+00
1417	memory_usage	32.76925086975098	{}	2025-10-16 01:19:02.454803+00
1418	disk_usage	7	{}	2025-10-16 01:19:02.462793+00
1419	whatsapp_success_rate	100	{}	2025-10-16 01:19:02.46575+00
1420	sla_violation	2	{}	2025-10-16 01:19:02.468426+00
1508	memory_usage	30.941343307495117	{}	2025-10-16 01:40:00.011941+00
1512	disk_usage	7	{}	2025-10-16 01:40:00.018444+00
1516	whatsapp_success_rate	100	{}	2025-10-16 01:40:00.02078+00
1520	sla_violation	2	{}	2025-10-16 01:40:00.022908+00
1617	memory_usage	29.33197021484375	{}	2025-10-16 02:10:00.009602+00
1620	disk_usage	7	{}	2025-10-16 02:10:00.015962+00
1623	whatsapp_success_rate	100	{}	2025-10-16 02:10:00.018998+00
1627	sla_violation	2	{}	2025-10-16 02:10:00.021123+00
1714	memory_usage	29.490995407104492	{}	2025-10-16 02:35:00.018381+00
1716	disk_usage	7	{}	2025-10-16 02:35:00.025728+00
1722	whatsapp_success_rate	100	{}	2025-10-16 02:35:00.028995+00
1725	sla_violation	2	{}	2025-10-16 02:35:00.031695+00
1811	memory_usage	29.441261291503906	{}	2025-10-16 03:05:00.018854+00
1814	disk_usage	7	{}	2025-10-16 03:05:00.026322+00
1819	whatsapp_success_rate	100	{}	2025-10-16 03:05:00.029226+00
1821	sla_violation	3	{}	2025-10-16 03:05:00.032206+00
1908	memory_usage	29.86125946044922	{}	2025-10-16 03:35:00.01583+00
1913	disk_usage	7	{}	2025-10-16 03:35:00.022819+00
1917	whatsapp_success_rate	100	{}	2025-10-16 03:35:00.026033+00
1920	sla_violation	3	{}	2025-10-16 03:35:00.029175+00
2017	memory_usage	30.071687698364258	{}	2025-10-16 04:05:00.0105+00
2019	disk_usage	7	{}	2025-10-16 04:05:00.017395+00
2023	whatsapp_success_rate	100	{}	2025-10-16 04:05:00.019922+00
2025	sla_violation	3	{}	2025-10-16 04:05:00.022111+00
2114	memory_usage	30.014324188232422	{}	2025-10-16 04:30:00.021655+00
2120	disk_usage	7	{}	2025-10-16 04:30:00.029353+00
2121	whatsapp_success_rate	100	{}	2025-10-16 04:30:00.032469+00
2123	sla_violation	3	{}	2025-10-16 04:30:00.033816+00
2211	memory_usage	30.306434631347656	{}	2025-10-16 05:00:00.025153+00
2214	disk_usage	7	{}	2025-10-16 05:00:00.032377+00
2218	whatsapp_success_rate	100	{}	2025-10-16 05:00:00.035007+00
2222	sla_violation	3	{}	2025-10-16 05:00:00.037808+00
2310	memory_usage	30.04288673400879	{}	2025-10-16 05:30:00.035095+00
2317	disk_usage	7	{}	2025-10-16 05:30:00.041999+00
2319	whatsapp_success_rate	100	{}	2025-10-16 05:30:00.045362+00
2320	sla_violation	3	{}	2025-10-16 05:30:00.047689+00
2417	memory_usage	18.280315399169922	{}	2025-10-16 06:05:00.017678+00
2421	disk_usage	7	{}	2025-10-16 06:05:00.025728+00
2423	whatsapp_success_rate	100	{}	2025-10-16 06:05:00.028944+00
2427	sla_violation	3	{}	2025-10-16 06:05:00.031637+00
2514	memory_usage	18.294954299926758	{}	2025-10-16 06:35:00.01905+00
2517	disk_usage	7	{}	2025-10-16 06:35:00.026332+00
2520	whatsapp_success_rate	100	{}	2025-10-16 06:35:00.029166+00
2524	sla_violation	3	{}	2025-10-16 06:35:00.031596+00
2611	memory_usage	18.31188201904297	{}	2025-10-16 07:05:00.017929+00
2615	disk_usage	7	{}	2025-10-16 07:05:00.024781+00
2617	whatsapp_success_rate	100	{}	2025-10-16 07:05:00.027676+00
2621	sla_violation	3	{}	2025-10-16 07:05:00.030209+00
2721	memory_usage	18.322277069091797	{}	2025-10-16 07:40:00.020534+00
2726	disk_usage	7	{}	2025-10-16 07:40:00.028919+00
2730	whatsapp_success_rate	100	{}	2025-10-16 07:40:00.031744+00
2734	sla_violation	3	{}	2025-10-16 07:40:00.034041+00
2818	memory_usage	18.354320526123047	{}	2025-10-16 08:10:00.01752+00
2822	disk_usage	7	{}	2025-10-16 08:10:00.024904+00
2827	whatsapp_success_rate	100	{}	2025-10-16 08:10:00.027399+00
2830	sla_violation	3	{}	2025-10-16 08:10:00.029825+00
2915	memory_usage	18.35489273071289	{}	2025-10-16 08:40:00.018675+00
2919	disk_usage	7	{}	2025-10-16 08:40:00.025574+00
2922	whatsapp_success_rate	100	{}	2025-10-16 08:40:00.02842+00
2926	sla_violation	3	{}	2025-10-16 08:40:00.030821+00
3014	memory_usage	18.46599578857422	{}	2025-10-16 09:10:00.024626+00
3020	disk_usage	7	{}	2025-10-16 09:10:00.030941+00
3023	whatsapp_success_rate	100	{}	2025-10-16 09:10:00.034008+00
3024	sla_violation	3	{}	2025-10-16 09:10:00.036367+00
3108	memory_usage	18.515634536743164	{}	2025-10-16 09:40:00.020731+00
3112	disk_usage	7	{}	2025-10-16 09:40:00.028767+00
3117	whatsapp_success_rate	100	{}	2025-10-16 09:40:00.031357+00
3120	sla_violation	3	{}	2025-10-16 09:40:00.033741+00
3187	memory_usage	18.477916717529297	{}	2025-10-16 10:05:00.01858+00
3191	disk_usage	7	{}	2025-10-16 10:05:00.025491+00
3195	whatsapp_success_rate	100	{}	2025-10-16 10:05:00.028565+00
3199	sla_violation	3	{}	2025-10-16 10:05:00.03079+00
3247	whatsapp_success_rate	100	{}	2025-10-16 10:20:00.038398+00
643	memory_usage	28.37371826171875	{}	2025-10-15 22:35:00.013095+00
645	disk_usage	7	{}	2025-10-15 22:35:00.018982+00
649	whatsapp_success_rate	100	{}	2025-10-15 22:35:00.021267+00
653	sla_violation	2	{}	2025-10-15 22:35:00.022748+00
729	memory_usage	28.8144588470459	{}	2025-10-15 22:53:31.138208+00
730	disk_usage	7	{}	2025-10-15 22:53:31.146128+00
732	whatsapp_success_rate	100	{}	2025-10-15 22:53:31.149101+00
733	sla_violation	2	{}	2025-10-15 22:53:31.151708+00
805	memory_usage	27.850055694580078	{}	2025-10-15 23:05:00.022503+00
811	disk_usage	7	{}	2025-10-15 23:05:00.031018+00
814	whatsapp_success_rate	100	{}	2025-10-15 23:05:00.036127+00
816	sla_violation	2	{}	2025-10-15 23:05:00.040838+00
885	memory_usage	27.74052619934082	{}	2025-10-15 23:15:00.029034+00
889	disk_usage	7	{}	2025-10-15 23:15:00.035787+00
892	whatsapp_success_rate	100	{}	2025-10-15 23:15:00.038419+00
895	sla_violation	2	{}	2025-10-15 23:15:00.040661+00
963	memory_usage	28.318214416503906	{}	2025-10-15 23:40:00.017736+00
969	disk_usage	7	{}	2025-10-15 23:40:00.024255+00
973	whatsapp_success_rate	100	{}	2025-10-15 23:40:00.027514+00
976	sla_violation	2	{}	2025-10-15 23:40:00.030367+00
1046	memory_usage	28.625011444091797	{}	2025-10-16 00:05:00.017852+00
1050	disk_usage	7	{}	2025-10-16 00:05:00.023885+00
1052	whatsapp_success_rate	100	{}	2025-10-16 00:05:00.026264+00
1053	sla_violation	2	{}	2025-10-16 00:05:00.028553+00
1138	memory_usage	29.63247299194336	{}	2025-10-16 00:30:00.026378+00
1141	disk_usage	7	{}	2025-10-16 00:30:00.035596+00
1145	whatsapp_success_rate	100	{}	2025-10-16 00:30:00.039812+00
1146	sla_violation	2	{}	2025-10-16 00:30:00.042489+00
1229	memory_usage	32.011985778808594	{}	2025-10-16 00:49:52.081679+00
1230	disk_usage	7	{}	2025-10-16 00:49:52.089354+00
1231	whatsapp_success_rate	100	{}	2025-10-16 00:49:52.092681+00
1232	sla_violation	2	{}	2025-10-16 00:49:52.095607+00
1315	memory_usage	30.28120994567871	{}	2025-10-16 01:05:00.013369+00
1319	disk_usage	7	{}	2025-10-16 01:05:00.020043+00
1322	whatsapp_success_rate	100	{}	2025-10-16 01:05:00.022044+00
1326	sla_violation	2	{}	2025-10-16 01:05:00.023683+00
1421	memory_usage	32.79547691345215	{}	2025-10-16 01:19:02.484175+00
1422	disk_usage	7	{}	2025-10-16 01:19:02.493266+00
1423	whatsapp_success_rate	100	{}	2025-10-16 01:19:02.496722+00
1424	sla_violation	2	{}	2025-10-16 01:19:02.499652+00
1521	memory_usage	32.32426643371582	{}	2025-10-16 01:40:33.230621+00
1523	disk_usage	7	{}	2025-10-16 01:40:33.237693+00
1527	whatsapp_success_rate	100	{}	2025-10-16 01:40:33.244784+00
1528	sla_violation	2	{}	2025-10-16 01:40:33.246314+00
1618	memory_usage	29.335784912109375	{}	2025-10-16 02:10:00.010582+00
1621	disk_usage	7	{}	2025-10-16 02:10:00.017414+00
1625	whatsapp_success_rate	100	{}	2025-10-16 02:10:00.02015+00
1628	sla_violation	2	{}	2025-10-16 02:10:00.022992+00
1715	memory_usage	29.490995407104492	{}	2025-10-16 02:35:00.018985+00
1718	disk_usage	7	{}	2025-10-16 02:35:00.026058+00
1720	whatsapp_success_rate	100	{}	2025-10-16 02:35:00.028982+00
1723	sla_violation	2	{}	2025-10-16 02:35:00.031262+00
1817	memory_usage	29.494619369506836	{}	2025-10-16 03:05:00.028484+00
1822	disk_usage	7	{}	2025-10-16 03:05:00.034943+00
1823	whatsapp_success_rate	100	{}	2025-10-16 03:05:00.0384+00
1824	sla_violation	3	{}	2025-10-16 03:05:00.041714+00
1921	memory_usage	31.76898956298828	{}	2025-10-16 03:35:54.218974+00
1922	disk_usage	7	{}	2025-10-16 03:35:54.226722+00
1923	whatsapp_success_rate	100	{}	2025-10-16 03:35:54.229197+00
1924	sla_violation	3	{}	2025-10-16 03:35:54.230962+00
2018	memory_usage	30.06916046142578	{}	2025-10-16 04:05:00.011943+00
2022	disk_usage	7	{}	2025-10-16 04:05:00.018559+00
2024	whatsapp_success_rate	100	{}	2025-10-16 04:05:00.021018+00
2026	sla_violation	3	{}	2025-10-16 04:05:00.023273+00
2116	memory_usage	30.013179779052734	{}	2025-10-16 04:30:00.026211+00
2122	disk_usage	7	{}	2025-10-16 04:30:00.032736+00
2125	whatsapp_success_rate	100	{}	2025-10-16 04:30:00.0347+00
2128	sla_violation	3	{}	2025-10-16 04:30:00.038915+00
2212	memory_usage	30.253934860229492	{}	2025-10-16 05:00:00.028289+00
2216	disk_usage	7	{}	2025-10-16 05:00:00.03471+00
2220	whatsapp_success_rate	100	{}	2025-10-16 05:00:00.037069+00
2224	sla_violation	3	{}	2025-10-16 05:00:00.039295+00
2321	memory_usage	20.355987548828125	{}	2025-10-16 05:35:00.020198+00
2325	disk_usage	7	{}	2025-10-16 05:35:00.028439+00
2328	whatsapp_success_rate	100	{}	2025-10-16 05:35:00.031466+00
2332	sla_violation	3	{}	2025-10-16 05:35:00.033783+00
2418	memory_usage	18.280315399169922	{}	2025-10-16 06:05:00.020495+00
2424	disk_usage	7	{}	2025-10-16 06:05:00.029071+00
2428	whatsapp_success_rate	100	{}	2025-10-16 06:05:00.031945+00
2430	sla_violation	3	{}	2025-10-16 06:05:00.034218+00
2515	memory_usage	18.297958374023438	{}	2025-10-16 06:35:00.019765+00
2519	disk_usage	7	{}	2025-10-16 06:35:00.026859+00
2523	whatsapp_success_rate	100	{}	2025-10-16 06:35:00.029788+00
2527	sla_violation	3	{}	2025-10-16 06:35:00.032584+00
2612	memory_usage	18.3474063873291	{}	2025-10-16 07:05:00.022691+00
2619	disk_usage	7	{}	2025-10-16 07:05:00.0288+00
2623	whatsapp_success_rate	100	{}	2025-10-16 07:05:00.033154+00
2624	sla_violation	3	{}	2025-10-16 07:05:00.035639+00
2722	memory_usage	18.315458297729492	{}	2025-10-16 07:40:00.021546+00
2725	disk_usage	7	{}	2025-10-16 07:40:00.02883+00
2729	whatsapp_success_rate	100	{}	2025-10-16 07:40:00.031478+00
2733	sla_violation	3	{}	2025-10-16 07:40:00.033668+00
2819	memory_usage	18.354320526123047	{}	2025-10-16 08:10:00.017926+00
2823	disk_usage	7	{}	2025-10-16 08:10:00.024994+00
2826	whatsapp_success_rate	100	{}	2025-10-16 08:10:00.027347+00
2831	sla_violation	3	{}	2025-10-16 08:10:00.02991+00
2918	memory_usage	18.372821807861328	{}	2025-10-16 08:40:00.024495+00
2925	disk_usage	7	{}	2025-10-16 08:40:00.030136+00
2927	whatsapp_success_rate	100	{}	2025-10-16 08:40:00.033846+00
2928	sla_violation	3	{}	2025-10-16 08:40:00.036494+00
3025	memory_usage	18.444061279296875	{}	2025-10-16 09:15:00.027904+00
3028	disk_usage	7	{}	2025-10-16 09:15:00.036172+00
3031	whatsapp_success_rate	100	{}	2025-10-16 09:15:00.039121+00
3035	sla_violation	3	{}	2025-10-16 09:15:00.041454+00
3111	disk_usage	7	{}	2025-10-16 09:40:00.028535+00
3116	whatsapp_success_rate	100	{}	2025-10-16 09:40:00.031336+00
3119	sla_violation	3	{}	2025-10-16 09:40:00.03371+00
3188	memory_usage	18.477916717529297	{}	2025-10-16 10:05:00.020991+00
3194	disk_usage	7	{}	2025-10-16 10:05:00.027392+00
3198	whatsapp_success_rate	100	{}	2025-10-16 10:05:00.030176+00
3200	sla_violation	3	{}	2025-10-16 10:05:00.032617+00
3248	sla_violation	3	{}	2025-10-16 10:20:00.041852+00
3282	memory_usage	18.475341796875	{}	2025-10-16 10:35:00.020782+00
644	memory_usage	28.37371826171875	{}	2025-10-15 22:35:00.013032+00
648	disk_usage	7	{}	2025-10-15 22:35:00.019391+00
650	whatsapp_success_rate	100	{}	2025-10-15 22:35:00.021559+00
654	sla_violation	2	{}	2025-10-15 22:35:00.024022+00
731	memory_usage	28.81455421447754	{}	2025-10-15 22:53:31.147863+00
734	disk_usage	7	{}	2025-10-15 22:53:31.156922+00
735	whatsapp_success_rate	100	{}	2025-10-15 22:53:31.15988+00
736	sla_violation	2	{}	2025-10-15 22:53:31.162362+00
807	memory_usage	27.856016159057617	{}	2025-10-15 23:05:00.02514+00
812	disk_usage	7	{}	2025-10-15 23:05:00.033366+00
813	whatsapp_success_rate	100	{}	2025-10-15 23:05:00.036152+00
815	sla_violation	2	{}	2025-10-15 23:05:00.039343+00
886	memory_usage	27.748870849609375	{}	2025-10-15 23:15:00.030395+00
890	disk_usage	7	{}	2025-10-15 23:15:00.036859+00
893	whatsapp_success_rate	100	{}	2025-10-15 23:15:00.039816+00
896	sla_violation	2	{}	2025-10-15 23:15:00.042124+00
964	memory_usage	28.318214416503906	{}	2025-10-15 23:40:00.017904+00
968	disk_usage	7	{}	2025-10-15 23:40:00.023975+00
972	whatsapp_success_rate	100	{}	2025-10-15 23:40:00.026775+00
975	sla_violation	2	{}	2025-10-15 23:40:00.029821+00
1051	memory_usage	28.612899780273438	{}	2025-10-16 00:05:00.023693+00
1054	disk_usage	7	{}	2025-10-16 00:05:00.029311+00
1055	whatsapp_success_rate	100	{}	2025-10-16 00:05:00.031984+00
1056	sla_violation	2	{}	2025-10-16 00:05:00.034264+00
1140	memory_usage	29.63690757751465	{}	2025-10-16 00:30:00.033961+00
1147	disk_usage	7	{}	2025-10-16 00:30:00.042646+00
1149	whatsapp_success_rate	100	{}	2025-10-16 00:30:00.046065+00
1151	sla_violation	2	{}	2025-10-16 00:30:00.048562+00
1233	memory_usage	32.07192420959473	{}	2025-10-16 00:50:00.013117+00
1236	disk_usage	7	{}	2025-10-16 00:50:00.019101+00
1240	whatsapp_success_rate	100	{}	2025-10-16 00:50:00.02146+00
1242	sla_violation	2	{}	2025-10-16 00:50:00.0231+00
1316	memory_usage	30.29007911682129	{}	2025-10-16 01:05:00.014413+00
1320	disk_usage	7	{}	2025-10-16 01:05:00.020967+00
1324	whatsapp_success_rate	100	{}	2025-10-16 01:05:00.022889+00
1327	sla_violation	2	{}	2025-10-16 01:05:00.024589+00
1425	memory_usage	30.2553653717041	{}	2025-10-16 01:20:00.01275+00
1429	disk_usage	7	{}	2025-10-16 01:20:00.019387+00
1434	whatsapp_success_rate	100	{}	2025-10-16 01:20:00.022224+00
1438	sla_violation	2	{}	2025-10-16 01:20:00.024893+00
1522	memory_usage	32.33051300048828	{}	2025-10-16 01:40:33.232383+00
1524	disk_usage	7	{}	2025-10-16 01:40:33.239307+00
1525	whatsapp_success_rate	100	{}	2025-10-16 01:40:33.241744+00
1526	sla_violation	2	{}	2025-10-16 01:40:33.243425+00
1619	memory_usage	29.337453842163086	{}	2025-10-16 02:10:00.01212+00
1622	disk_usage	7	{}	2025-10-16 02:10:00.018132+00
1626	whatsapp_success_rate	100	{}	2025-10-16 02:10:00.020225+00
1629	sla_violation	2	{}	2025-10-16 02:10:00.023097+00
1719	memory_usage	29.522037506103516	{}	2025-10-16 02:35:00.026013+00
1726	disk_usage	7	{}	2025-10-16 02:35:00.033481+00
1727	whatsapp_success_rate	100	{}	2025-10-16 02:35:00.036611+00
1728	sla_violation	2	{}	2025-10-16 02:35:00.039012+00
1825	memory_usage	29.461145401000977	{}	2025-10-16 03:10:00.01666+00
1828	disk_usage	7	{}	2025-10-16 03:10:00.024009+00
1831	whatsapp_success_rate	100	{}	2025-10-16 03:10:00.026801+00
1834	sla_violation	3	{}	2025-10-16 03:10:00.029123+00
1925	memory_usage	31.787919998168945	{}	2025-10-16 03:35:54.318951+00
1926	disk_usage	7	{}	2025-10-16 03:35:54.328352+00
1927	whatsapp_success_rate	100	{}	2025-10-16 03:35:54.331336+00
1928	sla_violation	3	{}	2025-10-16 03:35:54.333291+00
2020	memory_usage	30.071544647216797	{}	2025-10-16 04:05:00.017515+00
2027	disk_usage	7	{}	2025-10-16 04:05:00.024223+00
2029	whatsapp_success_rate	100	{}	2025-10-16 04:05:00.026979+00
2031	sla_violation	3	{}	2025-10-16 04:05:00.029168+00
2118	memory_usage	30.02324104309082	{}	2025-10-16 04:30:00.026822+00
2124	disk_usage	7	{}	2025-10-16 04:30:00.033954+00
2126	whatsapp_success_rate	100	{}	2025-10-16 04:30:00.036708+00
2127	sla_violation	3	{}	2025-10-16 04:30:00.038347+00
2225	memory_usage	30.00035285949707	{}	2025-10-16 05:05:00.017971+00
2230	disk_usage	7	{}	2025-10-16 05:05:00.025398+00
2234	whatsapp_success_rate	100	{}	2025-10-16 05:05:00.028265+00
2239	sla_violation	3	{}	2025-10-16 05:05:00.030963+00
2322	memory_usage	20.36123275756836	{}	2025-10-16 05:35:00.022787+00
2326	disk_usage	7	{}	2025-10-16 05:35:00.029451+00
2329	whatsapp_success_rate	100	{}	2025-10-16 05:35:00.031708+00
2333	sla_violation	3	{}	2025-10-16 05:35:00.034083+00
2419	memory_usage	18.306350708007812	{}	2025-10-16 06:05:00.02066+00
2422	disk_usage	7	{}	2025-10-16 06:05:00.028519+00
2425	whatsapp_success_rate	100	{}	2025-10-16 06:05:00.031067+00
2429	sla_violation	3	{}	2025-10-16 06:05:00.033258+00
2516	memory_usage	18.33486557006836	{}	2025-10-16 06:35:00.02292+00
2521	disk_usage	7	{}	2025-10-16 06:35:00.029549+00
2526	whatsapp_success_rate	100	{}	2025-10-16 06:35:00.032125+00
2528	sla_violation	3	{}	2025-10-16 06:35:00.035119+00
2625	memory_usage	18.288564682006836	{}	2025-10-16 07:10:00.018022+00
2628	disk_usage	7	{}	2025-10-16 07:10:00.024371+00
2631	whatsapp_success_rate	100	{}	2025-10-16 07:10:00.027228+00
2633	sla_violation	3	{}	2025-10-16 07:10:00.029986+00
2723	memory_usage	18.3135986328125	{}	2025-10-16 07:40:00.02245+00
2728	disk_usage	7	{}	2025-10-16 07:40:00.030054+00
2732	whatsapp_success_rate	100	{}	2025-10-16 07:40:00.032603+00
2736	sla_violation	3	{}	2025-10-16 07:40:00.034985+00
2820	memory_usage	18.354320526123047	{}	2025-10-16 08:10:00.019317+00
2824	disk_usage	7	{}	2025-10-16 08:10:00.025469+00
2828	whatsapp_success_rate	100	{}	2025-10-16 08:10:00.028684+00
2832	sla_violation	3	{}	2025-10-16 08:10:00.031375+00
2929	memory_usage	18.43700408935547	{}	2025-10-16 08:45:00.027849+00
2933	disk_usage	7	{}	2025-10-16 08:45:00.036725+00
2936	whatsapp_success_rate	100	{}	2025-10-16 08:45:00.039292+00
2940	sla_violation	3	{}	2025-10-16 08:45:00.041518+00
3026	memory_usage	18.444061279296875	{}	2025-10-16 09:15:00.03008+00
3029	disk_usage	7	{}	2025-10-16 09:15:00.03693+00
3033	whatsapp_success_rate	100	{}	2025-10-16 09:15:00.03983+00
3036	sla_violation	3	{}	2025-10-16 09:15:00.043442+00
3121	memory_usage	18.478012084960938	{}	2025-10-16 09:45:00.028298+00
3127	disk_usage	7	{}	2025-10-16 09:45:00.041117+00
3134	whatsapp_success_rate	100	{}	2025-10-16 09:45:00.045217+00
3136	sla_violation	3	{}	2025-10-16 09:45:00.047756+00
3190	disk_usage	7	{}	2025-10-16 10:05:00.024683+00
3193	whatsapp_success_rate	100	{}	2025-10-16 10:05:00.027102+00
3197	sla_violation	3	{}	2025-10-16 10:05:00.029434+00
3249	memory_usage	18.49689483642578	{}	2025-10-16 10:25:00.017296+00
3253	disk_usage	7	{}	2025-10-16 10:25:00.024567+00
657	memory_usage	26.649904251098633	{}	2025-10-15 22:40:00.010486+00
658	disk_usage	7	{}	2025-10-15 22:40:00.016437+00
661	whatsapp_success_rate	100	{}	2025-10-15 22:40:00.019059+00
663	sla_violation	2	{}	2025-10-15 22:40:00.021864+00
737	memory_usage	26.33500099182129	{}	2025-10-15 22:55:00.019346+00
740	disk_usage	7	{}	2025-10-15 22:55:00.026007+00
741	whatsapp_success_rate	100	{}	2025-10-15 22:55:00.028589+00
745	sla_violation	2	{}	2025-10-15 22:55:00.030863+00
817	memory_usage	30.132198333740234	{}	2025-10-15 23:05:59.053733+00
818	disk_usage	7	{}	2025-10-15 23:05:59.061111+00
819	whatsapp_success_rate	100	{}	2025-10-15 23:05:59.063484+00
820	sla_violation	2	{}	2025-10-15 23:05:59.065228+00
897	memory_usage	27.931499481201172	{}	2025-10-15 23:20:00.009558+00
901	disk_usage	7	{}	2025-10-15 23:20:00.016381+00
905	whatsapp_success_rate	100	{}	2025-10-15 23:20:00.018734+00
909	sla_violation	2	{}	2025-10-15 23:20:00.020208+00
977	memory_usage	28.035402297973633	{}	2025-10-15 23:45:00.026249+00
981	disk_usage	7	{}	2025-10-15 23:45:00.032567+00
983	whatsapp_success_rate	100	{}	2025-10-15 23:45:00.035147+00
987	sla_violation	2	{}	2025-10-15 23:45:00.037915+00
1057	memory_usage	29.660511016845703	{}	2025-10-16 00:10:00.009229+00
1060	disk_usage	7	{}	2025-10-16 00:10:00.015652+00
1062	whatsapp_success_rate	100	{}	2025-10-16 00:10:00.018518+00
1065	sla_violation	2	{}	2025-10-16 00:10:00.021119+00
1143	memory_usage	29.71186637878418	{}	2025-10-16 00:30:00.036233+00
1148	disk_usage	7	{}	2025-10-16 00:30:00.044254+00
1150	whatsapp_success_rate	100	{}	2025-10-16 00:30:00.046813+00
1152	sla_violation	2	{}	2025-10-16 00:30:00.049114+00
1235	memory_usage	32.080698013305664	{}	2025-10-16 00:50:00.018756+00
1243	disk_usage	7	{}	2025-10-16 00:50:00.02361+00
1244	whatsapp_success_rate	100	{}	2025-10-16 00:50:00.026168+00
1246	sla_violation	2	{}	2025-10-16 00:50:00.027509+00
1329	memory_usage	32.69801139831543	{}	2025-10-16 01:06:07.755242+00
1331	disk_usage	7	{}	2025-10-16 01:06:07.764911+00
1333	whatsapp_success_rate	100	{}	2025-10-16 01:06:07.767309+00
1335	sla_violation	2	{}	2025-10-16 01:06:07.769999+00
1426	memory_usage	30.2553653717041	{}	2025-10-16 01:20:00.013094+00
1431	disk_usage	7	{}	2025-10-16 01:20:00.019713+00
1433	whatsapp_success_rate	100	{}	2025-10-16 01:20:00.02223+00
1437	sla_violation	2	{}	2025-10-16 01:20:00.024826+00
1529	memory_usage	32.260990142822266	{}	2025-10-16 01:40:33.422553+00
1531	disk_usage	7	{}	2025-10-16 01:40:33.429671+00
1532	whatsapp_success_rate	100	{}	2025-10-16 01:40:33.432516+00
1533	sla_violation	2	{}	2025-10-16 01:40:33.434138+00
1624	memory_usage	29.34408187866211	{}	2025-10-16 02:10:00.019657+00
1630	disk_usage	7	{}	2025-10-16 02:10:00.026831+00
1631	whatsapp_success_rate	100	{}	2025-10-16 02:10:00.029045+00
1632	sla_violation	2	{}	2025-10-16 02:10:00.032041+00
1729	memory_usage	29.511499404907227	{}	2025-10-16 02:40:00.017657+00
1733	disk_usage	7	{}	2025-10-16 02:40:00.025204+00
1737	whatsapp_success_rate	100	{}	2025-10-16 02:40:00.028283+00
1740	sla_violation	3	{}	2025-10-16 02:40:00.031318+00
1826	memory_usage	29.461145401000977	{}	2025-10-16 03:10:00.016921+00
1829	disk_usage	7	{}	2025-10-16 03:10:00.025152+00
1832	whatsapp_success_rate	100	{}	2025-10-16 03:10:00.027633+00
1835	sla_violation	3	{}	2025-10-16 03:10:00.029719+00
1929	memory_usage	31.83450698852539	{}	2025-10-16 03:35:54.348501+00
1930	disk_usage	7	{}	2025-10-16 03:35:54.356117+00
1931	whatsapp_success_rate	100	{}	2025-10-16 03:35:54.358641+00
1932	sla_violation	3	{}	2025-10-16 03:35:54.360523+00
2021	memory_usage	30.07335662841797	{}	2025-10-16 04:05:00.017843+00
2028	disk_usage	7	{}	2025-10-16 04:05:00.025133+00
2030	whatsapp_success_rate	100	{}	2025-10-16 04:05:00.027738+00
2032	sla_violation	3	{}	2025-10-16 04:05:00.029867+00
2129	memory_usage	30.05499839782715	{}	2025-10-16 04:35:00.009228+00
2132	disk_usage	7	{}	2025-10-16 04:35:00.014981+00
2136	whatsapp_success_rate	100	{}	2025-10-16 04:35:00.017237+00
2140	sla_violation	3	{}	2025-10-16 04:35:00.020088+00
2226	memory_usage	30.00035285949707	{}	2025-10-16 05:05:00.018228+00
2229	disk_usage	7	{}	2025-10-16 05:05:00.025286+00
2233	whatsapp_success_rate	100	{}	2025-10-16 05:05:00.027994+00
2237	sla_violation	3	{}	2025-10-16 05:05:00.030386+00
2323	memory_usage	20.35512924194336	{}	2025-10-16 05:35:00.022867+00
2327	disk_usage	7	{}	2025-10-16 05:35:00.030313+00
2330	whatsapp_success_rate	100	{}	2025-10-16 05:35:00.032898+00
2334	sla_violation	3	{}	2025-10-16 05:35:00.035163+00
2420	memory_usage	18.319225311279297	{}	2025-10-16 06:05:00.024199+00
2426	disk_usage	7	{}	2025-10-16 06:05:00.031389+00
2431	whatsapp_success_rate	100	{}	2025-10-16 06:05:00.034569+00
2432	sla_violation	3	{}	2025-10-16 06:05:00.037733+00
2529	memory_usage	18.26314926147461	{}	2025-10-16 06:40:00.018577+00
2534	disk_usage	7	{}	2025-10-16 06:40:00.027198+00
2537	whatsapp_success_rate	100	{}	2025-10-16 06:40:00.030438+00
2539	sla_violation	3	{}	2025-10-16 06:40:00.033033+00
2626	memory_usage	18.285512924194336	{}	2025-10-16 07:10:00.019142+00
2630	disk_usage	7	{}	2025-10-16 07:10:00.027034+00
2634	whatsapp_success_rate	100	{}	2025-10-16 07:10:00.030152+00
2637	sla_violation	3	{}	2025-10-16 07:10:00.033071+00
2724	memory_usage	18.318510055541992	{}	2025-10-16 07:40:00.023083+00
2727	disk_usage	7	{}	2025-10-16 07:40:00.029545+00
2731	whatsapp_success_rate	100	{}	2025-10-16 07:40:00.032146+00
2735	sla_violation	3	{}	2025-10-16 07:40:00.034581+00
2833	memory_usage	18.390846252441406	{}	2025-10-16 08:15:00.025912+00
2837	disk_usage	7	{}	2025-10-16 08:15:00.033897+00
2840	whatsapp_success_rate	100	{}	2025-10-16 08:15:00.038552+00
2843	sla_violation	3	{}	2025-10-16 08:15:00.040888+00
2930	memory_usage	18.434619903564453	{}	2025-10-16 08:45:00.029813+00
2934	disk_usage	7	{}	2025-10-16 08:45:00.037825+00
2938	whatsapp_success_rate	100	{}	2025-10-16 08:45:00.041154+00
2942	sla_violation	3	{}	2025-10-16 08:45:00.043446+00
3027	memory_usage	18.444061279296875	{}	2025-10-16 09:15:00.031608+00
3030	disk_usage	7	{}	2025-10-16 09:15:00.038253+00
3034	whatsapp_success_rate	100	{}	2025-10-16 09:15:00.041251+00
3037	sla_violation	3	{}	2025-10-16 09:15:00.044556+00
3122	memory_usage	18.47395896911621	{}	2025-10-16 09:45:00.028983+00
3125	disk_usage	7	{}	2025-10-16 09:45:00.037045+00
3128	whatsapp_success_rate	100	{}	2025-10-16 09:45:00.041173+00
3131	sla_violation	3	{}	2025-10-16 09:45:00.044163+00
3201	memory_usage	18.49503517150879	{}	2025-10-16 10:10:00.016946+00
3206	disk_usage	7	{}	2025-10-16 10:10:00.024279+00
3210	whatsapp_success_rate	100	{}	2025-10-16 10:10:00.027171+00
3214	sla_violation	3	{}	2025-10-16 10:10:00.030536+00
3250	memory_usage	18.49689483642578	{}	2025-10-16 10:25:00.017387+00
660	memory_usage	26.652812957763672	{}	2025-10-15 22:40:00.018062+00
664	disk_usage	7	{}	2025-10-15 22:40:00.024523+00
667	whatsapp_success_rate	100	{}	2025-10-15 22:40:00.02703+00
670	sla_violation	2	{}	2025-10-15 22:40:00.029272+00
738	memory_usage	26.315975189208984	{}	2025-10-15 22:55:00.022745+00
743	disk_usage	7	{}	2025-10-15 22:55:00.029735+00
747	whatsapp_success_rate	100	{}	2025-10-15 22:55:00.032774+00
749	sla_violation	2	{}	2025-10-15 22:55:00.035259+00
821	memory_usage	30.140399932861328	{}	2025-10-15 23:05:59.068791+00
822	disk_usage	7	{}	2025-10-15 23:05:59.076295+00
823	whatsapp_success_rate	100	{}	2025-10-15 23:05:59.082754+00
824	sla_violation	2	{}	2025-10-15 23:05:59.084553+00
898	memory_usage	27.933406829833984	{}	2025-10-15 23:20:00.010175+00
902	disk_usage	7	{}	2025-10-15 23:20:00.016937+00
906	whatsapp_success_rate	100	{}	2025-10-15 23:20:00.019136+00
911	sla_violation	2	{}	2025-10-15 23:20:00.021495+00
978	memory_usage	28.045129776000977	{}	2025-10-15 23:45:00.026792+00
982	disk_usage	7	{}	2025-10-15 23:45:00.034981+00
986	whatsapp_success_rate	100	{}	2025-10-15 23:45:00.037429+00
990	sla_violation	2	{}	2025-10-15 23:45:00.041303+00
1058	memory_usage	29.66179847717285	{}	2025-10-16 00:10:00.012256+00
1063	disk_usage	7	{}	2025-10-16 00:10:00.019522+00
1066	whatsapp_success_rate	100	{}	2025-10-16 00:10:00.021386+00
1068	sla_violation	2	{}	2025-10-16 00:10:00.023341+00
1153	memory_usage	29.877376556396484	{}	2025-10-16 00:35:00.009306+00
1157	disk_usage	7	{}	2025-10-16 00:35:00.01605+00
1160	whatsapp_success_rate	100	{}	2025-10-16 00:35:00.018804+00
1163	sla_violation	2	{}	2025-10-16 00:35:00.021072+00
1330	memory_usage	32.68027305603027	{}	2025-10-16 01:06:07.756815+00
1332	disk_usage	7	{}	2025-10-16 01:06:07.765965+00
1334	whatsapp_success_rate	100	{}	2025-10-16 01:06:07.768713+00
1336	sla_violation	2	{}	2025-10-16 01:06:07.771568+00
1427	memory_usage	30.255651473999023	{}	2025-10-16 01:20:00.013226+00
1430	disk_usage	7	{}	2025-10-16 01:20:00.019458+00
1432	whatsapp_success_rate	100	{}	2025-10-16 01:20:00.022064+00
1436	sla_violation	2	{}	2025-10-16 01:20:00.024392+00
1530	memory_usage	32.25278854370117	{}	2025-10-16 01:40:33.429256+00
1534	disk_usage	7	{}	2025-10-16 01:40:33.436515+00
1535	whatsapp_success_rate	100	{}	2025-10-16 01:40:33.438764+00
1536	sla_violation	2	{}	2025-10-16 01:40:33.440184+00
1633	memory_usage	31.60538673400879	{}	2025-10-16 02:11:53.280743+00
1634	disk_usage	7	{}	2025-10-16 02:11:53.288828+00
1635	whatsapp_success_rate	100	{}	2025-10-16 02:11:53.291452+00
1636	sla_violation	2	{}	2025-10-16 02:11:53.293143+00
1730	memory_usage	29.51502799987793	{}	2025-10-16 02:40:00.018128+00
1734	disk_usage	7	{}	2025-10-16 02:40:00.025259+00
1738	whatsapp_success_rate	100	{}	2025-10-16 02:40:00.029946+00
1742	sla_violation	3	{}	2025-10-16 02:40:00.033214+00
1827	memory_usage	29.480743408203125	{}	2025-10-16 03:10:00.021915+00
1833	disk_usage	7	{}	2025-10-16 03:10:00.028436+00
1836	whatsapp_success_rate	100	{}	2025-10-16 03:10:00.030918+00
1838	sla_violation	3	{}	2025-10-16 03:10:00.033148+00
1933	memory_usage	31.8514347076416	{}	2025-10-16 03:35:54.409256+00
1934	disk_usage	7	{}	2025-10-16 03:35:54.41746+00
1935	whatsapp_success_rate	100	{}	2025-10-16 03:35:54.420654+00
1936	sla_violation	3	{}	2025-10-16 03:35:54.42345+00
2033	memory_usage	30.190086364746094	{}	2025-10-16 04:10:00.009352+00
2037	disk_usage	7	{}	2025-10-16 04:10:00.015568+00
2039	whatsapp_success_rate	100	{}	2025-10-16 04:10:00.017827+00
2043	sla_violation	3	{}	2025-10-16 04:10:00.019973+00
2130	memory_usage	30.05194664001465	{}	2025-10-16 04:35:00.009496+00
2133	disk_usage	7	{}	2025-10-16 04:35:00.016492+00
2137	whatsapp_success_rate	100	{}	2025-10-16 04:35:00.018304+00
2139	sla_violation	3	{}	2025-10-16 04:35:00.019934+00
2227	memory_usage	30.00040054321289	{}	2025-10-16 05:05:00.018472+00
2232	disk_usage	7	{}	2025-10-16 05:05:00.026056+00
2236	whatsapp_success_rate	100	{}	2025-10-16 05:05:00.029109+00
2240	sla_violation	3	{}	2025-10-16 05:05:00.03147+00
2324	memory_usage	20.37506103515625	{}	2025-10-16 05:35:00.027045+00
2331	disk_usage	7	{}	2025-10-16 05:35:00.033692+00
2335	whatsapp_success_rate	100	{}	2025-10-16 05:35:00.036018+00
2336	sla_violation	3	{}	2025-10-16 05:35:00.038186+00
2433	memory_usage	18.271160125732422	{}	2025-10-16 06:10:00.019547+00
2437	disk_usage	7	{}	2025-10-16 06:10:00.027635+00
2442	whatsapp_success_rate	100	{}	2025-10-16 06:10:00.03097+00
2446	sla_violation	3	{}	2025-10-16 06:10:00.033775+00
2530	memory_usage	18.26314926147461	{}	2025-10-16 06:40:00.018941+00
2533	disk_usage	7	{}	2025-10-16 06:40:00.027056+00
2536	whatsapp_success_rate	100	{}	2025-10-16 06:40:00.030236+00
2540	sla_violation	3	{}	2025-10-16 06:40:00.03308+00
2627	memory_usage	18.288564682006836	{}	2025-10-16 07:10:00.019387+00
2632	disk_usage	7	{}	2025-10-16 07:10:00.027237+00
2636	whatsapp_success_rate	100	{}	2025-10-16 07:10:00.031408+00
2639	sla_violation	3	{}	2025-10-16 07:10:00.034146+00
2737	memory_usage	18.300199508666992	{}	2025-10-16 07:45:00.02716+00
2741	disk_usage	7	{}	2025-10-16 07:45:00.036532+00
2742	whatsapp_success_rate	100	{}	2025-10-16 07:45:00.040177+00
2746	sla_violation	3	{}	2025-10-16 07:45:00.042866+00
2834	memory_usage	18.38827133178711	{}	2025-10-16 08:15:00.026412+00
2836	disk_usage	7	{}	2025-10-16 08:15:00.033804+00
2839	whatsapp_success_rate	100	{}	2025-10-16 08:15:00.037878+00
2842	sla_violation	3	{}	2025-10-16 08:15:00.040203+00
2931	memory_usage	18.466615676879883	{}	2025-10-16 08:45:00.032265+00
2935	disk_usage	7	{}	2025-10-16 08:45:00.03833+00
2939	whatsapp_success_rate	100	{}	2025-10-16 08:45:00.041175+00
2943	sla_violation	3	{}	2025-10-16 08:45:00.044331+00
3032	memory_usage	18.550825119018555	{}	2025-10-16 09:15:00.0392+00
3038	disk_usage	7	{}	2025-10-16 09:15:00.044662+00
3039	whatsapp_success_rate	100	{}	2025-10-16 09:15:00.047498+00
3040	sla_violation	3	{}	2025-10-16 09:15:00.049741+00
3123	memory_usage	18.5089111328125	{}	2025-10-16 09:45:00.032728+00
3126	disk_usage	7	{}	2025-10-16 09:45:00.039322+00
3130	whatsapp_success_rate	100	{}	2025-10-16 09:45:00.04292+00
3133	sla_violation	3	{}	2025-10-16 09:45:00.045062+00
3202	memory_usage	18.49508285522461	{}	2025-10-16 10:10:00.016954+00
3205	disk_usage	7	{}	2025-10-16 10:10:00.024276+00
3209	whatsapp_success_rate	100	{}	2025-10-16 10:10:00.026903+00
3213	sla_violation	3	{}	2025-10-16 10:10:00.029611+00
3251	memory_usage	18.49689483642578	{}	2025-10-16 10:25:00.019296+00
3255	disk_usage	7	{}	2025-10-16 10:25:00.025374+00
3259	whatsapp_success_rate	100	{}	2025-10-16 10:25:00.028235+00
3264	sla_violation	3	{}	2025-10-16 10:25:00.031056+00
3283	memory_usage	18.503618240356445	{}	2025-10-16 10:35:00.022489+00
659	memory_usage	26.652812957763672	{}	2025-10-15 22:40:00.018067+00
665	disk_usage	7	{}	2025-10-15 22:40:00.024631+00
668	whatsapp_success_rate	100	{}	2025-10-15 22:40:00.027302+00
671	sla_violation	2	{}	2025-10-15 22:40:00.029626+00
739	memory_usage	26.315975189208984	{}	2025-10-15 22:55:00.022764+00
742	disk_usage	7	{}	2025-10-15 22:55:00.029213+00
746	whatsapp_success_rate	100	{}	2025-10-15 22:55:00.031735+00
748	sla_violation	2	{}	2025-10-15 22:55:00.034073+00
825	memory_usage	30.181503295898438	{}	2025-10-15 23:05:59.169062+00
826	disk_usage	7	{}	2025-10-15 23:05:59.176378+00
827	whatsapp_success_rate	100	{}	2025-10-15 23:05:59.179183+00
828	sla_violation	2	{}	2025-10-15 23:05:59.181739+00
899	memory_usage	27.933406829833984	{}	2025-10-15 23:20:00.010373+00
903	disk_usage	7	{}	2025-10-15 23:20:00.017044+00
908	whatsapp_success_rate	100	{}	2025-10-15 23:20:00.019463+00
910	sla_violation	2	{}	2025-10-15 23:20:00.021084+00
979	memory_usage	28.042984008789062	{}	2025-10-15 23:45:00.029342+00
984	disk_usage	7	{}	2025-10-15 23:45:00.035692+00
988	whatsapp_success_rate	100	{}	2025-10-15 23:45:00.03897+00
991	sla_violation	2	{}	2025-10-15 23:45:00.042048+00
1059	memory_usage	29.676389694213867	{}	2025-10-16 00:10:00.015352+00
1064	disk_usage	7	{}	2025-10-16 00:10:00.020828+00
1067	whatsapp_success_rate	100	{}	2025-10-16 00:10:00.022976+00
1070	sla_violation	2	{}	2025-10-16 00:10:00.025299+00
1154	memory_usage	29.877376556396484	{}	2025-10-16 00:35:00.009544+00
1159	disk_usage	7	{}	2025-10-16 00:35:00.016427+00
1162	whatsapp_success_rate	100	{}	2025-10-16 00:35:00.019029+00
1166	sla_violation	2	{}	2025-10-16 00:35:00.021682+00
1337	memory_usage	32.76243209838867	{}	2025-10-16 01:06:07.878259+00
1338	disk_usage	7	{}	2025-10-16 01:06:07.885343+00
1339	whatsapp_success_rate	100	{}	2025-10-16 01:06:07.887736+00
1340	sla_violation	2	{}	2025-10-16 01:06:07.889846+00
1428	memory_usage	30.282974243164062	{}	2025-10-16 01:20:00.018636+00
1435	disk_usage	7	{}	2025-10-16 01:20:00.023983+00
1439	whatsapp_success_rate	100	{}	2025-10-16 01:20:00.026245+00
1440	sla_violation	2	{}	2025-10-16 01:20:00.02874+00
1537	memory_usage	29.96048927307129	{}	2025-10-16 01:45:00.022021+00
1539	disk_usage	7	{}	2025-10-16 01:45:00.029421+00
1541	whatsapp_success_rate	100	{}	2025-10-16 01:45:00.031774+00
1545	sla_violation	2	{}	2025-10-16 01:45:00.035135+00
1637	memory_usage	31.64825439453125	{}	2025-10-16 02:11:53.307302+00
1638	disk_usage	7	{}	2025-10-16 02:11:53.314657+00
1639	whatsapp_success_rate	100	{}	2025-10-16 02:11:53.317741+00
1640	sla_violation	2	{}	2025-10-16 02:11:53.319291+00
1731	memory_usage	29.51502799987793	{}	2025-10-16 02:40:00.020371+00
1736	disk_usage	7	{}	2025-10-16 02:40:00.028258+00
1741	whatsapp_success_rate	100	{}	2025-10-16 02:40:00.031348+00
1744	sla_violation	3	{}	2025-10-16 02:40:00.034404+00
1830	memory_usage	29.508161544799805	{}	2025-10-16 03:10:00.025034+00
1837	disk_usage	7	{}	2025-10-16 03:10:00.031352+00
1839	whatsapp_success_rate	100	{}	2025-10-16 03:10:00.033985+00
1840	sla_violation	3	{}	2025-10-16 03:10:00.036281+00
1937	memory_usage	29.842710494995117	{}	2025-10-16 03:40:00.012616+00
1941	disk_usage	7	{}	2025-10-16 03:40:00.019455+00
1944	whatsapp_success_rate	100	{}	2025-10-16 03:40:00.021553+00
1947	sla_violation	3	{}	2025-10-16 03:40:00.022964+00
2034	memory_usage	30.190086364746094	{}	2025-10-16 04:10:00.009814+00
2038	disk_usage	7	{}	2025-10-16 04:10:00.016554+00
2041	whatsapp_success_rate	100	{}	2025-10-16 04:10:00.018984+00
2045	sla_violation	3	{}	2025-10-16 04:10:00.021244+00
2131	memory_usage	30.059099197387695	{}	2025-10-16 04:35:00.010526+00
2134	disk_usage	7	{}	2025-10-16 04:35:00.016964+00
2138	whatsapp_success_rate	100	{}	2025-10-16 04:35:00.019603+00
2141	sla_violation	3	{}	2025-10-16 04:35:00.021223+00
2228	memory_usage	30.00040054321289	{}	2025-10-16 05:05:00.018679+00
2231	disk_usage	7	{}	2025-10-16 05:05:00.025686+00
2235	whatsapp_success_rate	100	{}	2025-10-16 05:05:00.028298+00
2238	sla_violation	3	{}	2025-10-16 05:05:00.030949+00
2337	memory_usage	18.064212799072266	{}	2025-10-16 05:40:00.018219+00
2341	disk_usage	7	{}	2025-10-16 05:40:00.025851+00
2345	whatsapp_success_rate	100	{}	2025-10-16 05:40:00.028678+00
2349	sla_violation	3	{}	2025-10-16 05:40:00.030989+00
2434	memory_usage	18.271160125732422	{}	2025-10-16 06:10:00.02027+00
2440	disk_usage	7	{}	2025-10-16 06:10:00.028507+00
2443	whatsapp_success_rate	100	{}	2025-10-16 06:10:00.031832+00
2447	sla_violation	3	{}	2025-10-16 06:10:00.034427+00
2531	memory_usage	18.29204559326172	{}	2025-10-16 06:40:00.023003+00
2535	disk_usage	7	{}	2025-10-16 06:40:00.029895+00
2541	whatsapp_success_rate	100	{}	2025-10-16 06:40:00.033483+00
2544	sla_violation	3	{}	2025-10-16 06:40:00.037158+00
2629	memory_usage	18.326187133789062	{}	2025-10-16 07:10:00.025094+00
2635	disk_usage	7	{}	2025-10-16 07:10:00.030667+00
2638	whatsapp_success_rate	100	{}	2025-10-16 07:10:00.033717+00
2640	sla_violation	3	{}	2025-10-16 07:10:00.036344+00
2738	memory_usage	18.326330184936523	{}	2025-10-16 07:45:00.031286+00
2743	disk_usage	7	{}	2025-10-16 07:45:00.040188+00
2747	whatsapp_success_rate	100	{}	2025-10-16 07:45:00.043735+00
2750	sla_violation	3	{}	2025-10-16 07:45:00.046087+00
2835	memory_usage	18.434524536132812	{}	2025-10-16 08:15:00.032635+00
2841	disk_usage	7	{}	2025-10-16 08:15:00.039382+00
2845	whatsapp_success_rate	100	{}	2025-10-16 08:15:00.04175+00
2847	sla_violation	3	{}	2025-10-16 08:15:00.044315+00
2932	memory_usage	18.429899215698242	{}	2025-10-16 08:45:00.032906+00
2937	disk_usage	7	{}	2025-10-16 08:45:00.039682+00
2941	whatsapp_success_rate	100	{}	2025-10-16 08:45:00.042515+00
2944	sla_violation	3	{}	2025-10-16 08:45:00.044758+00
3041	memory_usage	18.437480926513672	{}	2025-10-16 09:20:00.017046+00
3045	disk_usage	7	{}	2025-10-16 09:20:00.024002+00
3049	whatsapp_success_rate	100	{}	2025-10-16 09:20:00.02663+00
3053	sla_violation	3	{}	2025-10-16 09:20:00.028777+00
3124	memory_usage	18.498659133911133	{}	2025-10-16 09:45:00.035508+00
3129	disk_usage	7	{}	2025-10-16 09:45:00.041884+00
3132	whatsapp_success_rate	100	{}	2025-10-16 09:45:00.0449+00
3135	sla_violation	3	{}	2025-10-16 09:45:00.047019+00
3203	memory_usage	18.50285530090332	{}	2025-10-16 10:10:00.017948+00
3208	disk_usage	7	{}	2025-10-16 10:10:00.025207+00
3212	whatsapp_success_rate	100	{}	2025-10-16 10:10:00.028298+00
3216	sla_violation	3	{}	2025-10-16 10:10:00.031756+00
3252	memory_usage	18.49689483642578	{}	2025-10-16 10:25:00.019051+00
3256	disk_usage	7	{}	2025-10-16 10:25:00.025388+00
3260	whatsapp_success_rate	100	{}	2025-10-16 10:25:00.028242+00
3263	sla_violation	3	{}	2025-10-16 10:25:00.031034+00
3284	memory_usage	18.503618240356445	{}	2025-10-16 10:35:00.0234+00
662	memory_usage	26.649904251098633	{}	2025-10-15 22:40:00.019349+00
666	disk_usage	7	{}	2025-10-15 22:40:00.025179+00
669	whatsapp_success_rate	100	{}	2025-10-15 22:40:00.027739+00
672	sla_violation	2	{}	2025-10-15 22:40:00.030011+00
744	memory_usage	26.337432861328125	{}	2025-10-15 22:55:00.029896+00
750	disk_usage	7	{}	2025-10-15 22:55:00.037146+00
751	whatsapp_success_rate	100	{}	2025-10-15 22:55:00.039562+00
752	sla_violation	2	{}	2025-10-15 22:55:00.041796+00
829	memory_usage	30.223512649536133	{}	2025-10-15 23:05:59.241909+00
830	disk_usage	7	{}	2025-10-15 23:05:59.250561+00
831	whatsapp_success_rate	100	{}	2025-10-15 23:05:59.253555+00
832	sla_violation	2	{}	2025-10-15 23:05:59.256044+00
900	memory_usage	27.933406829833984	{}	2025-10-15 23:20:00.010619+00
904	disk_usage	7	{}	2025-10-15 23:20:00.017123+00
907	whatsapp_success_rate	100	{}	2025-10-15 23:20:00.019213+00
912	sla_violation	2	{}	2025-10-15 23:20:00.021892+00
980	memory_usage	28.045129776000977	{}	2025-10-15 23:45:00.0306+00
985	disk_usage	7	{}	2025-10-15 23:45:00.037378+00
989	whatsapp_success_rate	100	{}	2025-10-15 23:45:00.039922+00
992	sla_violation	2	{}	2025-10-15 23:45:00.042575+00
1061	memory_usage	29.660511016845703	{}	2025-10-16 00:10:00.016971+00
1069	disk_usage	7	{}	2025-10-16 00:10:00.023757+00
1071	whatsapp_success_rate	100	{}	2025-10-16 00:10:00.026522+00
1072	sla_violation	2	{}	2025-10-16 00:10:00.02871+00
1155	memory_usage	29.885292053222656	{}	2025-10-16 00:35:00.010058+00
1158	disk_usage	7	{}	2025-10-16 00:35:00.016116+00
1161	whatsapp_success_rate	100	{}	2025-10-16 00:35:00.01882+00
1165	sla_violation	2	{}	2025-10-16 00:35:00.021427+00
1341	memory_usage	32.77897834777832	{}	2025-10-16 01:06:07.951934+00
1342	disk_usage	7	{}	2025-10-16 01:06:07.960145+00
1343	whatsapp_success_rate	100	{}	2025-10-16 01:06:07.963191+00
1344	sla_violation	2	{}	2025-10-16 01:06:07.965781+00
1441	memory_usage	30.53765296936035	{}	2025-10-16 01:25:00.009274+00
1445	disk_usage	7	{}	2025-10-16 01:25:00.016168+00
1448	whatsapp_success_rate	100	{}	2025-10-16 01:25:00.018711+00
1451	sla_violation	2	{}	2025-10-16 01:25:00.02084+00
1538	memory_usage	29.96354103088379	{}	2025-10-16 01:45:00.022242+00
1540	disk_usage	7	{}	2025-10-16 01:45:00.029477+00
1542	whatsapp_success_rate	100	{}	2025-10-16 01:45:00.032167+00
1546	sla_violation	2	{}	2025-10-16 01:45:00.035472+00
1641	memory_usage	31.686115264892578	{}	2025-10-16 02:11:53.442702+00
1643	disk_usage	7	{}	2025-10-16 02:11:53.450827+00
1645	whatsapp_success_rate	100	{}	2025-10-16 02:11:53.453403+00
1646	sla_violation	2	{}	2025-10-16 02:11:53.455165+00
1732	memory_usage	29.52108383178711	{}	2025-10-16 02:40:00.020849+00
1735	disk_usage	7	{}	2025-10-16 02:40:00.028245+00
1739	whatsapp_success_rate	100	{}	2025-10-16 02:40:00.031008+00
1743	sla_violation	3	{}	2025-10-16 02:40:00.033395+00
1841	memory_usage	29.50143814086914	{}	2025-10-16 03:15:00.026212+00
1845	disk_usage	7	{}	2025-10-16 03:15:00.035685+00
1849	whatsapp_success_rate	100	{}	2025-10-16 03:15:00.039216+00
1852	sla_violation	3	{}	2025-10-16 03:15:00.042439+00
1938	memory_usage	29.846620559692383	{}	2025-10-16 03:40:00.013107+00
1942	disk_usage	7	{}	2025-10-16 03:40:00.019728+00
1945	whatsapp_success_rate	100	{}	2025-10-16 03:40:00.022217+00
1948	sla_violation	3	{}	2025-10-16 03:40:00.02441+00
2035	memory_usage	30.199718475341797	{}	2025-10-16 04:10:00.011937+00
2040	disk_usage	7	{}	2025-10-16 04:10:00.018339+00
2044	whatsapp_success_rate	100	{}	2025-10-16 04:10:00.020786+00
2047	sla_violation	3	{}	2025-10-16 04:10:00.023219+00
2135	memory_usage	30.06143569946289	{}	2025-10-16 04:35:00.017+00
2142	disk_usage	7	{}	2025-10-16 04:35:00.025029+00
2143	whatsapp_success_rate	100	{}	2025-10-16 04:35:00.027469+00
2144	sla_violation	3	{}	2025-10-16 04:35:00.028854+00
2241	memory_usage	29.996633529663086	{}	2025-10-16 05:10:00.018522+00
2245	disk_usage	7	{}	2025-10-16 05:10:00.02557+00
2247	whatsapp_success_rate	100	{}	2025-10-16 05:10:00.028867+00
2251	sla_violation	3	{}	2025-10-16 05:10:00.031212+00
2338	memory_usage	18.062877655029297	{}	2025-10-16 05:40:00.019501+00
2342	disk_usage	7	{}	2025-10-16 05:40:00.026566+00
2346	whatsapp_success_rate	100	{}	2025-10-16 05:40:00.02903+00
2350	sla_violation	3	{}	2025-10-16 05:40:00.031281+00
2435	memory_usage	18.276596069335938	{}	2025-10-16 06:10:00.020228+00
2439	disk_usage	7	{}	2025-10-16 06:10:00.028528+00
2444	whatsapp_success_rate	100	{}	2025-10-16 06:10:00.031906+00
2448	sla_violation	3	{}	2025-10-16 06:10:00.035221+00
2532	memory_usage	18.2924747467041	{}	2025-10-16 06:40:00.023942+00
2538	disk_usage	7	{}	2025-10-16 06:40:00.03119+00
2542	whatsapp_success_rate	100	{}	2025-10-16 06:40:00.033817+00
2543	sla_violation	3	{}	2025-10-16 06:40:00.036771+00
2641	memory_usage	18.341970443725586	{}	2025-10-16 07:15:00.028587+00
2645	disk_usage	7	{}	2025-10-16 07:15:00.036542+00
2647	whatsapp_success_rate	100	{}	2025-10-16 07:15:00.040071+00
2651	sla_violation	3	{}	2025-10-16 07:15:00.04285+00
2739	memory_usage	18.314123153686523	{}	2025-10-16 07:45:00.03135+00
2745	disk_usage	7	{}	2025-10-16 07:45:00.04141+00
2749	whatsapp_success_rate	100	{}	2025-10-16 07:45:00.045621+00
2752	sla_violation	3	{}	2025-10-16 07:45:00.047979+00
2838	memory_usage	18.434524536132812	{}	2025-10-16 08:15:00.034132+00
2844	disk_usage	7	{}	2025-10-16 08:15:00.041346+00
2846	whatsapp_success_rate	100	{}	2025-10-16 08:15:00.04384+00
2848	sla_violation	3	{}	2025-10-16 08:15:00.046201+00
2945	memory_usage	18.396472930908203	{}	2025-10-16 08:50:00.018113+00
2949	disk_usage	7	{}	2025-10-16 08:50:00.025183+00
2954	whatsapp_success_rate	100	{}	2025-10-16 08:50:00.02875+00
2958	sla_violation	3	{}	2025-10-16 08:50:00.031966+00
3042	memory_usage	18.437767028808594	{}	2025-10-16 09:20:00.017271+00
3047	disk_usage	7	{}	2025-10-16 09:20:00.024702+00
3050	whatsapp_success_rate	100	{}	2025-10-16 09:20:00.027312+00
3054	sla_violation	3	{}	2025-10-16 09:20:00.029295+00
3137	memory_usage	18.480587005615234	{}	2025-10-16 09:50:00.018676+00
3141	disk_usage	7	{}	2025-10-16 09:50:00.026075+00
3145	whatsapp_success_rate	100	{}	2025-10-16 09:50:00.030001+00
3150	sla_violation	3	{}	2025-10-16 09:50:00.034265+00
3204	memory_usage	18.500471115112305	{}	2025-10-16 10:10:00.018333+00
3207	disk_usage	7	{}	2025-10-16 10:10:00.024882+00
3211	whatsapp_success_rate	100	{}	2025-10-16 10:10:00.028066+00
3215	sla_violation	3	{}	2025-10-16 10:10:00.031571+00
3254	disk_usage	7	{}	2025-10-16 10:25:00.025202+00
3257	whatsapp_success_rate	100	{}	2025-10-16 10:25:00.027584+00
3261	sla_violation	3	{}	2025-10-16 10:25:00.029743+00
3285	disk_usage	7	{}	2025-10-16 10:35:00.025439+00
3288	whatsapp_success_rate	100	{}	2025-10-16 10:35:00.028446+00
592	sla_violation	2	{}	2025-10-15 22:20:00.031204+00
1345	memory_usage	30.405712127685547	{}	2025-10-16 01:10:00.012594+00
1349	disk_usage	7	{}	2025-10-16 01:10:00.019294+00
1353	whatsapp_success_rate	100	{}	2025-10-16 01:10:00.021747+00
1357	sla_violation	2	{}	2025-10-16 01:10:00.024253+00
1442	memory_usage	30.539894104003906	{}	2025-10-16 01:25:00.009832+00
1447	disk_usage	7	{}	2025-10-16 01:25:00.016656+00
1449	whatsapp_success_rate	100	{}	2025-10-16 01:25:00.018964+00
1453	sla_violation	2	{}	2025-10-16 01:25:00.021224+00
1543	memory_usage	29.95615005493164	{}	2025-10-16 01:45:00.032649+00
1548	disk_usage	7	{}	2025-10-16 01:45:00.041707+00
1550	whatsapp_success_rate	100	{}	2025-10-16 01:45:00.044819+00
1552	sla_violation	2	{}	2025-10-16 01:45:00.046977+00
1642	memory_usage	31.69088363647461	{}	2025-10-16 02:11:53.444057+00
1644	disk_usage	7	{}	2025-10-16 02:11:53.452004+00
1647	whatsapp_success_rate	100	{}	2025-10-16 02:11:53.455223+00
1648	sla_violation	2	{}	2025-10-16 02:11:53.458218+00
1745	memory_usage	29.420137405395508	{}	2025-10-16 02:45:00.02673+00
1749	disk_usage	7	{}	2025-10-16 02:45:00.036295+00
1754	whatsapp_success_rate	100	{}	2025-10-16 02:45:00.042177+00
1758	sla_violation	3	{}	2025-10-16 02:45:00.045441+00
1842	memory_usage	29.50882911682129	{}	2025-10-16 03:15:00.026921+00
1844	disk_usage	7	{}	2025-10-16 03:15:00.03525+00
1847	whatsapp_success_rate	100	{}	2025-10-16 03:15:00.038389+00
1850	sla_violation	3	{}	2025-10-16 03:15:00.040857+00
1939	memory_usage	29.851484298706055	{}	2025-10-16 03:40:00.013852+00
1943	disk_usage	7	{}	2025-10-16 03:40:00.020378+00
1946	whatsapp_success_rate	100	{}	2025-10-16 03:40:00.022725+00
1949	sla_violation	3	{}	2025-10-16 03:40:00.024856+00
2036	memory_usage	30.20029067993164	{}	2025-10-16 04:10:00.013784+00
2042	disk_usage	7	{}	2025-10-16 04:10:00.019489+00
2046	whatsapp_success_rate	100	{}	2025-10-16 04:10:00.021784+00
2048	sla_violation	3	{}	2025-10-16 04:10:00.024348+00
2145	memory_usage	30.083227157592773	{}	2025-10-16 04:40:00.010157+00
2149	disk_usage	7	{}	2025-10-16 04:40:00.016822+00
2152	whatsapp_success_rate	100	{}	2025-10-16 04:40:00.019174+00
2156	sla_violation	3	{}	2025-10-16 04:40:00.02139+00
2242	memory_usage	29.99567985534668	{}	2025-10-16 05:10:00.021334+00
2246	disk_usage	7	{}	2025-10-16 05:10:00.02763+00
2250	whatsapp_success_rate	100	{}	2025-10-16 05:10:00.030348+00
2254	sla_violation	3	{}	2025-10-16 05:10:00.032916+00
2339	memory_usage	18.068790435791016	{}	2025-10-16 05:40:00.019947+00
2343	disk_usage	7	{}	2025-10-16 05:40:00.027121+00
2347	whatsapp_success_rate	100	{}	2025-10-16 05:40:00.029479+00
2351	sla_violation	3	{}	2025-10-16 05:40:00.03215+00
2436	memory_usage	18.271160125732422	{}	2025-10-16 06:10:00.021035+00
2438	disk_usage	7	{}	2025-10-16 06:10:00.028056+00
2441	whatsapp_success_rate	100	{}	2025-10-16 06:10:00.030966+00
2445	sla_violation	3	{}	2025-10-16 06:10:00.033395+00
2545	memory_usage	18.251705169677734	{}	2025-10-16 06:45:00.027626+00
2549	disk_usage	7	{}	2025-10-16 06:45:00.036755+00
2552	whatsapp_success_rate	100	{}	2025-10-16 06:45:00.041637+00
2556	sla_violation	3	{}	2025-10-16 06:45:00.044696+00
2642	memory_usage	18.341779708862305	{}	2025-10-16 07:15:00.028777+00
2646	disk_usage	7	{}	2025-10-16 07:15:00.038274+00
2650	whatsapp_success_rate	100	{}	2025-10-16 07:15:00.04121+00
2654	sla_violation	3	{}	2025-10-16 07:15:00.044358+00
2740	memory_usage	18.332576751708984	{}	2025-10-16 07:45:00.032176+00
2744	disk_usage	7	{}	2025-10-16 07:45:00.040967+00
2748	whatsapp_success_rate	100	{}	2025-10-16 07:45:00.044057+00
2751	sla_violation	3	{}	2025-10-16 07:45:00.04654+00
2849	memory_usage	18.36676597595215	{}	2025-10-16 08:20:00.01771+00
2853	disk_usage	7	{}	2025-10-16 08:20:00.025207+00
2857	whatsapp_success_rate	100	{}	2025-10-16 08:20:00.02801+00
2861	sla_violation	3	{}	2025-10-16 08:20:00.030314+00
2946	memory_usage	18.396472930908203	{}	2025-10-16 08:50:00.01849+00
2950	disk_usage	7	{}	2025-10-16 08:50:00.026035+00
2953	whatsapp_success_rate	100	{}	2025-10-16 08:50:00.028748+00
2957	sla_violation	3	{}	2025-10-16 08:50:00.031019+00
3043	memory_usage	18.437480926513672	{}	2025-10-16 09:20:00.017307+00
3046	disk_usage	7	{}	2025-10-16 09:20:00.024392+00
3051	whatsapp_success_rate	100	{}	2025-10-16 09:20:00.027646+00
3055	sla_violation	3	{}	2025-10-16 09:20:00.030463+00
3138	memory_usage	18.480587005615234	{}	2025-10-16 09:50:00.019471+00
3142	disk_usage	7	{}	2025-10-16 09:50:00.026453+00
3143	whatsapp_success_rate	100	{}	2025-10-16 09:50:00.029273+00
3147	sla_violation	3	{}	2025-10-16 09:50:00.031632+00
3217	memory_usage	18.474102020263672	{}	2025-10-16 10:15:00.028619+00
3221	disk_usage	7	{}	2025-10-16 10:15:00.036261+00
3223	whatsapp_success_rate	100	{}	2025-10-16 10:15:00.03889+00
3226	sla_violation	3	{}	2025-10-16 10:15:00.041199+00
3258	whatsapp_success_rate	100	{}	2025-10-16 10:25:00.027769+00
3262	sla_violation	3	{}	2025-10-16 10:25:00.030917+00
3286	disk_usage	7	{}	2025-10-16 10:35:00.027965+00
3290	whatsapp_success_rate	100	{}	2025-10-16 10:35:00.030622+00
3294	sla_violation	3	{}	2025-10-16 10:35:00.03286+00
3298	memory_usage	18.501996994018555	{}	2025-10-16 10:40:00.017315+00
3302	disk_usage	7	{}	2025-10-16 10:40:00.024838+00
3306	whatsapp_success_rate	100	{}	2025-10-16 10:40:00.027112+00
3310	sla_violation	3	{}	2025-10-16 10:40:00.029796+00
3315	memory_usage	18.458271026611328	{}	2025-10-16 10:45:00.031727+00
3321	disk_usage	7	{}	2025-10-16 10:45:00.04168+00
3325	whatsapp_success_rate	100	{}	2025-10-16 10:45:00.044479+00
3327	sla_violation	3	{}	2025-10-16 10:45:00.047243+00
3334	memory_usage	18.494272232055664	{}	2025-10-16 10:50:00.024418+00
3339	disk_usage	7	{}	2025-10-16 10:50:00.030427+00
3343	whatsapp_success_rate	100	{}	2025-10-16 10:50:00.033032+00
3344	sla_violation	3	{}	2025-10-16 10:50:00.035791+00
3351	whatsapp_success_rate	100	{}	2025-10-16 10:55:00.028067+00
3353	sla_violation	3	{}	2025-10-16 10:55:00.030984+00
3364	memory_usage	18.47686767578125	{}	2025-10-16 11:00:00.034464+00
3371	disk_usage	7	{}	2025-10-16 11:00:00.043091+00
3374	whatsapp_success_rate	100	{}	2025-10-16 11:00:00.046093+00
3376	sla_violation	3	{}	2025-10-16 11:00:00.048146+00
3378	memory_usage	18.459796905517578	{}	2025-10-16 11:05:00.019153+00
3381	disk_usage	7	{}	2025-10-16 11:05:00.025571+00
3382	disk_usage	7	{}	2025-10-16 11:05:00.025687+00
3385	whatsapp_success_rate	100	{}	2025-10-16 11:05:00.02852+00
3386	whatsapp_success_rate	100	{}	2025-10-16 11:05:00.028654+00
3387	whatsapp_success_rate	100	{}	2025-10-16 11:05:00.028663+00
3388	whatsapp_success_rate	100	{}	2025-10-16 11:05:00.028683+00
3389	sla_violation	3	{}	2025-10-16 11:05:00.031015+00
3390	sla_violation	3	{}	2025-10-16 11:05:00.0313+00
3391	sla_violation	3	{}	2025-10-16 11:05:00.031452+00
4641	memory_usage	19.00339126586914	{}	2025-10-16 17:40:00.018206+00
4645	disk_usage	7	{}	2025-10-16 17:40:00.02637+00
4649	whatsapp_success_rate	100	{}	2025-10-16 17:40:00.029659+00
4653	sla_violation	4	{}	2025-10-16 17:40:00.032417+00
4660	memory_usage	19.037437438964844	{}	2025-10-16 17:45:00.034047+00
4668	disk_usage	7	{}	2025-10-16 17:45:00.042124+00
4671	whatsapp_success_rate	100	{}	2025-10-16 17:45:00.045072+00
4672	sla_violation	4	{}	2025-10-16 17:45:00.048557+00
4691	memory_usage	19.08249855041504	{}	2025-10-16 17:55:00.023472+00
4696	disk_usage	7	{}	2025-10-16 17:55:00.029263+00
4700	whatsapp_success_rate	100	{}	2025-10-16 17:55:00.031831+00
4703	sla_violation	4	{}	2025-10-16 17:55:00.034142+00
4722	memory_usage	19.34366226196289	{}	2025-10-16 18:05:00.017773+00
4723	disk_usage	7	{}	2025-10-16 18:05:00.024154+00
4727	whatsapp_success_rate	100	{}	2025-10-16 18:05:00.027234+00
4729	sla_violation	4	{}	2025-10-16 18:05:00.029616+00
4753	memory_usage	19.39263343811035	{}	2025-10-16 18:15:00.024509+00
4757	disk_usage	7	{}	2025-10-16 18:15:00.032656+00
4760	whatsapp_success_rate	100	{}	2025-10-16 18:15:00.036265+00
4763	sla_violation	4	{}	2025-10-16 18:15:00.040046+00
4774	memory_usage	19.40455436706543	{}	2025-10-16 18:20:00.024236+00
4781	disk_usage	7	{}	2025-10-16 18:20:00.030062+00
4783	whatsapp_success_rate	100	{}	2025-10-16 18:20:00.032777+00
4784	sla_violation	4	{}	2025-10-16 18:20:00.034845+00
4803	memory_usage	19.388103485107422	{}	2025-10-16 18:30:00.031121+00
4807	disk_usage	7	{}	2025-10-16 18:30:00.037043+00
4811	whatsapp_success_rate	100	{}	2025-10-16 18:30:00.039695+00
4815	sla_violation	4	{}	2025-10-16 18:30:00.04293+00
4834	memory_usage	19.364213943481445	{}	2025-10-16 18:40:00.01778+00
4838	disk_usage	7	{}	2025-10-16 18:40:00.024819+00
4841	whatsapp_success_rate	100	{}	2025-10-16 18:40:00.027253+00
4847	sla_violation	4	{}	2025-10-16 18:40:00.030762+00
4865	memory_usage	19.394302368164062	{}	2025-10-16 18:50:00.017828+00
4869	disk_usage	7	{}	2025-10-16 18:50:00.025038+00
4873	whatsapp_success_rate	100	{}	2025-10-16 18:50:00.027696+00
4877	sla_violation	4	{}	2025-10-16 18:50:00.030559+00
4883	memory_usage	19.402408599853516	{}	2025-10-16 18:55:00.019374+00
4886	disk_usage	7	{}	2025-10-16 18:55:00.025504+00
4888	whatsapp_success_rate	100	{}	2025-10-16 18:55:00.027941+00
4892	sla_violation	4	{}	2025-10-16 18:55:00.030231+00
4913	memory_usage	19.425582885742188	{}	2025-10-16 19:05:00.017987+00
4917	disk_usage	7	{}	2025-10-16 19:05:00.025135+00
4921	whatsapp_success_rate	100	{}	2025-10-16 19:05:00.029123+00
4925	sla_violation	4	{}	2025-10-16 19:05:00.033137+00
4931	memory_usage	19.440174102783203	{}	2025-10-16 19:10:00.018766+00
4935	disk_usage	7	{}	2025-10-16 19:10:00.025973+00
4940	whatsapp_success_rate	100	{}	2025-10-16 19:10:00.030186+00
4943	sla_violation	4	{}	2025-10-16 19:10:00.033467+00
4961	memory_usage	19.405651092529297	{}	2025-10-16 19:20:00.016711+00
4966	disk_usage	7	{}	2025-10-16 19:20:00.026545+00
4970	whatsapp_success_rate	100	{}	2025-10-16 19:20:00.028935+00
4974	sla_violation	4	{}	2025-10-16 19:20:00.031101+00
4979	memory_usage	19.39229965209961	{}	2025-10-16 19:25:00.018187+00
4982	disk_usage	7	{}	2025-10-16 19:25:00.024703+00
4986	whatsapp_success_rate	100	{}	2025-10-16 19:25:00.0273+00
4990	sla_violation	4	{}	2025-10-16 19:25:00.029596+00
5009	memory_usage	19.402360916137695	{}	2025-10-16 19:35:00.01771+00
5013	disk_usage	7	{}	2025-10-16 19:35:00.025088+00
5017	whatsapp_success_rate	100	{}	2025-10-16 19:35:00.027654+00
5021	sla_violation	4	{}	2025-10-16 19:35:00.03024+00
5027	memory_usage	19.37880516052246	{}	2025-10-16 19:40:00.019224+00
5032	disk_usage	7	{}	2025-10-16 19:40:00.027362+00
5035	whatsapp_success_rate	100	{}	2025-10-16 19:40:00.030131+00
5039	sla_violation	4	{}	2025-10-16 19:40:00.032407+00
5058	memory_usage	19.344329833984375	{}	2025-10-16 19:50:00.018287+00
5062	disk_usage	7	{}	2025-10-16 19:50:00.025904+00
5066	whatsapp_success_rate	100	{}	2025-10-16 19:50:00.028772+00
5070	sla_violation	4	{}	2025-10-16 19:50:00.031673+00
5077	memory_usage	19.370555877685547	{}	2025-10-16 19:55:00.028258+00
5083	disk_usage	7	{}	2025-10-16 19:55:00.035792+00
5085	whatsapp_success_rate	100	{}	2025-10-16 19:55:00.039127+00
5087	sla_violation	4	{}	2025-10-16 19:55:00.042099+00
5105	memory_usage	19.332361221313477	{}	2025-10-16 20:05:00.017868+00
5109	disk_usage	7	{}	2025-10-16 20:05:00.024287+00
5113	whatsapp_success_rate	100	{}	2025-10-16 20:05:00.027829+00
5117	sla_violation	4	{}	2025-10-16 20:05:00.031695+00
5123	memory_usage	19.332122802734375	{}	2025-10-16 20:10:00.021105+00
5128	disk_usage	7	{}	2025-10-16 20:10:00.027816+00
5132	whatsapp_success_rate	100	{}	2025-10-16 20:10:00.030712+00
5136	sla_violation	4	{}	2025-10-16 20:10:00.033193+00
5153	memory_usage	19.378185272216797	{}	2025-10-16 20:20:00.020523+00
5155	disk_usage	7	{}	2025-10-16 20:20:00.027395+00
5157	whatsapp_success_rate	100	{}	2025-10-16 20:20:00.030202+00
5159	sla_violation	4	{}	2025-10-16 20:20:00.033293+00
5171	memory_usage	19.379711151123047	{}	2025-10-16 20:25:00.018482+00
5174	disk_usage	7	{}	2025-10-16 20:25:00.024671+00
5178	whatsapp_success_rate	100	{}	2025-10-16 20:25:00.027033+00
5182	sla_violation	4	{}	2025-10-16 20:25:00.029303+00
5201	memory_usage	19.431400299072266	{}	2025-10-16 20:35:00.01002+00
5204	disk_usage	7	{}	2025-10-16 20:35:00.017093+00
5207	whatsapp_success_rate	100	{}	2025-10-16 20:35:00.019612+00
5210	sla_violation	4	{}	2025-10-16 20:35:00.022198+00
5219	memory_usage	19.38338279724121	{}	2025-10-16 20:40:00.019162+00
5223	disk_usage	7	{}	2025-10-16 20:40:00.0268+00
5225	whatsapp_success_rate	100	{}	2025-10-16 20:40:00.030042+00
5228	sla_violation	4	{}	2025-10-16 20:40:00.032319+00
5249	memory_usage	19.378280639648438	{}	2025-10-16 20:50:00.016793+00
5253	disk_usage	7	{}	2025-10-16 20:50:00.023708+00
5256	whatsapp_success_rate	100	{}	2025-10-16 20:50:00.027442+00
5260	sla_violation	4	{}	2025-10-16 20:50:00.029893+00
5267	memory_usage	19.388294219970703	{}	2025-10-16 20:55:00.023513+00
5273	disk_usage	7	{}	2025-10-16 20:55:00.029944+00
5277	whatsapp_success_rate	100	{}	2025-10-16 20:55:00.033039+00
5279	sla_violation	4	{}	2025-10-16 20:55:00.035788+00
5284	memory_usage	19.459152221679688	{}	2025-10-16 21:00:00.033375+00
5291	disk_usage	7	{}	2025-10-16 21:00:00.040656+00
5293	whatsapp_success_rate	100	{}	2025-10-16 21:00:00.043181+00
5296	sla_violation	4	{}	2025-10-16 21:00:00.046665+00
5297	memory_usage	19.41051483154297	{}	2025-10-16 21:05:00.020597+00
5300	disk_usage	7	{}	2025-10-16 21:05:00.028246+00
5303	memory_usage	19.422006607055664	{}	2025-10-16 21:05:00.028365+00
5304	whatsapp_success_rate	100	{}	2025-10-16 21:05:00.031039+00
3392	sla_violation	3	{}	2025-10-16 11:05:00.031521+00
3393	memory_usage	18.480968475341797	{}	2025-10-16 11:10:00.017502+00
3394	memory_usage	18.480968475341797	{}	2025-10-16 11:10:00.017972+00
3395	memory_usage	18.47076416015625	{}	2025-10-16 11:10:00.018922+00
3396	memory_usage	18.504619598388672	{}	2025-10-16 11:10:00.023315+00
3397	disk_usage	7	{}	2025-10-16 11:10:00.024624+00
3398	disk_usage	7	{}	2025-10-16 11:10:00.024666+00
3399	disk_usage	7	{}	2025-10-16 11:10:00.025539+00
3400	whatsapp_success_rate	100	{}	2025-10-16 11:10:00.027098+00
3401	whatsapp_success_rate	100	{}	2025-10-16 11:10:00.027774+00
3402	whatsapp_success_rate	100	{}	2025-10-16 11:10:00.028305+00
3403	disk_usage	7	{}	2025-10-16 11:10:00.028725+00
3404	sla_violation	3	{}	2025-10-16 11:10:00.029375+00
3405	sla_violation	3	{}	2025-10-16 11:10:00.030183+00
3406	sla_violation	3	{}	2025-10-16 11:10:00.030731+00
3407	whatsapp_success_rate	100	{}	2025-10-16 11:10:00.031031+00
3408	sla_violation	3	{}	2025-10-16 11:10:00.033832+00
3409	memory_usage	18.485593795776367	{}	2025-10-16 11:15:00.026107+00
3410	memory_usage	18.50123405456543	{}	2025-10-16 11:15:00.027977+00
3411	memory_usage	18.501901626586914	{}	2025-10-16 11:15:00.029011+00
3412	memory_usage	18.50428581237793	{}	2025-10-16 11:15:00.030851+00
3413	disk_usage	7	{}	2025-10-16 11:15:00.03361+00
3414	disk_usage	7	{}	2025-10-16 11:15:00.035304+00
3415	whatsapp_success_rate	100	{}	2025-10-16 11:15:00.036278+00
3416	disk_usage	7	{}	2025-10-16 11:15:00.037146+00
3417	disk_usage	7	{}	2025-10-16 11:15:00.037136+00
3418	whatsapp_success_rate	100	{}	2025-10-16 11:15:00.038035+00
3419	sla_violation	3	{}	2025-10-16 11:15:00.039819+00
3420	whatsapp_success_rate	100	{}	2025-10-16 11:15:00.039915+00
3421	sla_violation	3	{}	2025-10-16 11:15:00.040403+00
3422	whatsapp_success_rate	100	{}	2025-10-16 11:15:00.040863+00
3423	sla_violation	3	{}	2025-10-16 11:15:00.042648+00
3424	sla_violation	3	{}	2025-10-16 11:15:00.044832+00
3425	memory_usage	18.459033966064453	{}	2025-10-16 11:20:00.016845+00
3426	memory_usage	18.459033966064453	{}	2025-10-16 11:20:00.018074+00
3427	memory_usage	18.486356735229492	{}	2025-10-16 11:20:00.018878+00
3428	disk_usage	7	{}	2025-10-16 11:20:00.023538+00
3429	memory_usage	18.504953384399414	{}	2025-10-16 11:20:00.023342+00
3430	disk_usage	7	{}	2025-10-16 11:20:00.02435+00
3431	disk_usage	7	{}	2025-10-16 11:20:00.025159+00
3432	whatsapp_success_rate	100	{}	2025-10-16 11:20:00.026115+00
3433	whatsapp_success_rate	100	{}	2025-10-16 11:20:00.026901+00
3434	whatsapp_success_rate	100	{}	2025-10-16 11:20:00.027598+00
3435	sla_violation	3	{}	2025-10-16 11:20:00.028342+00
3436	sla_violation	3	{}	2025-10-16 11:20:00.029017+00
3437	disk_usage	7	{}	2025-10-16 11:20:00.029063+00
3438	sla_violation	3	{}	2025-10-16 11:20:00.029972+00
3439	whatsapp_success_rate	100	{}	2025-10-16 11:20:00.032045+00
3440	sla_violation	3	{}	2025-10-16 11:20:00.034256+00
3441	memory_usage	18.48907470703125	{}	2025-10-16 11:25:00.017162+00
3443	memory_usage	18.48907470703125	{}	2025-10-16 11:25:00.01735+00
3442	memory_usage	18.48907470703125	{}	2025-10-16 11:25:00.017111+00
3444	memory_usage	18.48907470703125	{}	2025-10-16 11:25:00.017823+00
3445	disk_usage	7	{}	2025-10-16 11:25:00.023908+00
3446	disk_usage	7	{}	2025-10-16 11:25:00.024526+00
3447	disk_usage	7	{}	2025-10-16 11:25:00.024846+00
3448	disk_usage	7	{}	2025-10-16 11:25:00.024919+00
3449	whatsapp_success_rate	100	{}	2025-10-16 11:25:00.026431+00
3450	whatsapp_success_rate	100	{}	2025-10-16 11:25:00.027116+00
3451	whatsapp_success_rate	100	{}	2025-10-16 11:25:00.027663+00
3452	whatsapp_success_rate	100	{}	2025-10-16 11:25:00.027745+00
3453	sla_violation	3	{}	2025-10-16 11:25:00.028597+00
3454	sla_violation	3	{}	2025-10-16 11:25:00.029075+00
3455	sla_violation	3	{}	2025-10-16 11:25:00.030074+00
3456	sla_violation	3	{}	2025-10-16 11:25:00.030398+00
3457	memory_usage	18.532609939575195	{}	2025-10-16 11:30:00.026949+00
3458	memory_usage	18.532419204711914	{}	2025-10-16 11:30:00.027774+00
3459	memory_usage	18.556499481201172	{}	2025-10-16 11:30:00.032689+00
3460	disk_usage	7	{}	2025-10-16 11:30:00.035064+00
3461	memory_usage	18.569087982177734	{}	2025-10-16 11:30:00.035538+00
3462	disk_usage	7	{}	2025-10-16 11:30:00.036582+00
3463	disk_usage	7	{}	2025-10-16 11:30:00.039618+00
3464	whatsapp_success_rate	100	{}	2025-10-16 11:30:00.039712+00
3465	whatsapp_success_rate	100	{}	2025-10-16 11:30:00.039999+00
3466	disk_usage	7	{}	2025-10-16 11:30:00.042533+00
3467	whatsapp_success_rate	100	{}	2025-10-16 11:30:00.042586+00
3468	sla_violation	4	{}	2025-10-16 11:30:00.043489+00
3469	sla_violation	4	{}	2025-10-16 11:30:00.044172+00
3470	sla_violation	4	{}	2025-10-16 11:30:00.046116+00
3471	whatsapp_success_rate	100	{}	2025-10-16 11:30:00.046144+00
3472	sla_violation	4	{}	2025-10-16 11:30:00.048925+00
3473	memory_usage	18.5335636138916	{}	2025-10-16 11:35:00.018746+00
3474	memory_usage	18.5335636138916	{}	2025-10-16 11:35:00.019892+00
3475	memory_usage	18.5335636138916	{}	2025-10-16 11:35:00.020612+00
3476	memory_usage	18.558740615844727	{}	2025-10-16 11:35:00.022212+00
3477	disk_usage	7	{}	2025-10-16 11:35:00.026001+00
3478	disk_usage	7	{}	2025-10-16 11:35:00.02612+00
3479	disk_usage	7	{}	2025-10-16 11:35:00.026374+00
3480	disk_usage	7	{}	2025-10-16 11:35:00.027607+00
3481	whatsapp_success_rate	100	{}	2025-10-16 11:35:00.028897+00
3482	whatsapp_success_rate	100	{}	2025-10-16 11:35:00.029013+00
3483	whatsapp_success_rate	100	{}	2025-10-16 11:35:00.029104+00
3484	whatsapp_success_rate	100	{}	2025-10-16 11:35:00.030047+00
3485	sla_violation	4	{}	2025-10-16 11:35:00.031746+00
3486	sla_violation	4	{}	2025-10-16 11:35:00.0319+00
3487	sla_violation	4	{}	2025-10-16 11:35:00.031927+00
3488	sla_violation	4	{}	2025-10-16 11:35:00.032239+00
3489	memory_usage	18.49384307861328	{}	2025-10-16 11:40:00.018261+00
3490	memory_usage	18.49384307861328	{}	2025-10-16 11:40:00.018769+00
3491	memory_usage	18.49384307861328	{}	2025-10-16 11:40:00.01884+00
3492	memory_usage	18.49832534790039	{}	2025-10-16 11:40:00.019129+00
3493	disk_usage	7	{}	2025-10-16 11:40:00.024984+00
3494	disk_usage	7	{}	2025-10-16 11:40:00.025133+00
3495	disk_usage	7	{}	2025-10-16 11:40:00.025365+00
3496	disk_usage	7	{}	2025-10-16 11:40:00.025788+00
3497	whatsapp_success_rate	100	{}	2025-10-16 11:40:00.027521+00
3498	whatsapp_success_rate	100	{}	2025-10-16 11:40:00.027802+00
3499	whatsapp_success_rate	100	{}	2025-10-16 11:40:00.028215+00
3500	whatsapp_success_rate	100	{}	2025-10-16 11:40:00.028343+00
3501	sla_violation	4	{}	2025-10-16 11:40:00.029829+00
3502	sla_violation	4	{}	2025-10-16 11:40:00.030149+00
3503	sla_violation	4	{}	2025-10-16 11:40:00.031028+00
3504	sla_violation	4	{}	2025-10-16 11:40:00.031055+00
3505	memory_usage	18.53032112121582	{}	2025-10-16 11:45:00.027085+00
3506	memory_usage	18.53032112121582	{}	2025-10-16 11:45:00.031369+00
3507	memory_usage	18.531322479248047	{}	2025-10-16 11:45:00.032954+00
3508	memory_usage	18.531131744384766	{}	2025-10-16 11:45:00.033407+00
3509	disk_usage	7	{}	2025-10-16 11:45:00.03422+00
3510	whatsapp_success_rate	100	{}	2025-10-16 11:45:00.037068+00
3511	disk_usage	7	{}	2025-10-16 11:45:00.038285+00
3512	sla_violation	4	{}	2025-10-16 11:45:00.039679+00
3513	disk_usage	7	{}	2025-10-16 11:45:00.040067+00
3514	disk_usage	7	{}	2025-10-16 11:45:00.040444+00
3515	whatsapp_success_rate	100	{}	2025-10-16 11:45:00.041054+00
3516	whatsapp_success_rate	100	{}	2025-10-16 11:45:00.043038+00
3517	whatsapp_success_rate	100	{}	2025-10-16 11:45:00.043156+00
3518	sla_violation	4	{}	2025-10-16 11:45:00.043431+00
3519	sla_violation	4	{}	2025-10-16 11:45:00.045465+00
3520	sla_violation	4	{}	2025-10-16 11:45:00.046146+00
3521	memory_usage	18.4903621673584	{}	2025-10-16 11:50:00.017498+00
3522	memory_usage	18.4934139251709	{}	2025-10-16 11:50:00.017763+00
3523	memory_usage	18.495941162109375	{}	2025-10-16 11:50:00.018362+00
3524	memory_usage	18.509244918823242	{}	2025-10-16 11:50:00.019925+00
3525	disk_usage	7	{}	2025-10-16 11:50:00.024523+00
3526	disk_usage	7	{}	2025-10-16 11:50:00.024592+00
3527	disk_usage	7	{}	2025-10-16 11:50:00.026407+00
3528	disk_usage	7	{}	2025-10-16 11:50:00.027145+00
3529	whatsapp_success_rate	100	{}	2025-10-16 11:50:00.02722+00
3530	whatsapp_success_rate	100	{}	2025-10-16 11:50:00.027384+00
3531	whatsapp_success_rate	100	{}	2025-10-16 11:50:00.029194+00
3532	whatsapp_success_rate	100	{}	2025-10-16 11:50:00.029568+00
3533	sla_violation	4	{}	2025-10-16 11:50:00.02999+00
3534	sla_violation	4	{}	2025-10-16 11:50:00.0304+00
3535	sla_violation	4	{}	2025-10-16 11:50:00.031802+00
3536	sla_violation	4	{}	2025-10-16 11:50:00.032045+00
3537	memory_usage	18.503761291503906	{}	2025-10-16 11:55:00.018646+00
3539	memory_usage	18.503761291503906	{}	2025-10-16 11:55:00.018928+00
3538	memory_usage	18.505573272705078	{}	2025-10-16 11:55:00.01901+00
3540	memory_usage	18.505573272705078	{}	2025-10-16 11:55:00.019505+00
3541	disk_usage	7	{}	2025-10-16 11:55:00.02614+00
3542	disk_usage	7	{}	2025-10-16 11:55:00.026277+00
3543	disk_usage	7	{}	2025-10-16 11:55:00.026591+00
3544	disk_usage	7	{}	2025-10-16 11:55:00.027744+00
3545	whatsapp_success_rate	100	{}	2025-10-16 11:55:00.029187+00
3546	whatsapp_success_rate	100	{}	2025-10-16 11:55:00.029219+00
3547	whatsapp_success_rate	100	{}	2025-10-16 11:55:00.029941+00
3548	whatsapp_success_rate	100	{}	2025-10-16 11:55:00.03125+00
3549	sla_violation	4	{}	2025-10-16 11:55:00.032+00
3550	sla_violation	4	{}	2025-10-16 11:55:00.032393+00
3551	sla_violation	4	{}	2025-10-16 11:55:00.033168+00
3552	sla_violation	4	{}	2025-10-16 11:55:00.033539+00
3553	memory_usage	18.50152015686035	{}	2025-10-16 12:00:00.027539+00
3554	memory_usage	18.496084213256836	{}	2025-10-16 12:00:00.030051+00
3555	memory_usage	18.50719451904297	{}	2025-10-16 12:00:00.031198+00
3556	memory_usage	18.509531021118164	{}	2025-10-16 12:00:00.03271+00
3557	disk_usage	7	{}	2025-10-16 12:00:00.035673+00
3558	disk_usage	7	{}	2025-10-16 12:00:00.037389+00
3559	disk_usage	7	{}	2025-10-16 12:00:00.037709+00
3560	whatsapp_success_rate	100	{}	2025-10-16 12:00:00.038589+00
3561	disk_usage	7	{}	2025-10-16 12:00:00.039994+00
3562	sla_violation	4	{}	2025-10-16 12:00:00.041694+00
3563	whatsapp_success_rate	100	{}	2025-10-16 12:00:00.04198+00
3564	whatsapp_success_rate	100	{}	2025-10-16 12:00:00.04201+00
3565	whatsapp_success_rate	100	{}	2025-10-16 12:00:00.042739+00
3566	sla_violation	4	{}	2025-10-16 12:00:00.044905+00
3567	sla_violation	4	{}	2025-10-16 12:00:00.04524+00
3568	sla_violation	4	{}	2025-10-16 12:00:00.045293+00
3569	memory_usage	18.729305267333984	{}	2025-10-16 12:05:00.018024+00
3570	memory_usage	18.729305267333984	{}	2025-10-16 12:05:00.018603+00
3571	memory_usage	18.72882843017578	{}	2025-10-16 12:05:00.018796+00
3572	memory_usage	18.729305267333984	{}	2025-10-16 12:05:00.018894+00
3573	disk_usage	7	{}	2025-10-16 12:05:00.025722+00
3574	disk_usage	7	{}	2025-10-16 12:05:00.025851+00
3575	disk_usage	7	{}	2025-10-16 12:05:00.026117+00
3576	disk_usage	7	{}	2025-10-16 12:05:00.026197+00
3577	whatsapp_success_rate	100	{}	2025-10-16 12:05:00.028489+00
3578	whatsapp_success_rate	100	{}	2025-10-16 12:05:00.029286+00
3579	whatsapp_success_rate	100	{}	2025-10-16 12:05:00.029293+00
3580	whatsapp_success_rate	100	{}	2025-10-16 12:05:00.029297+00
3581	sla_violation	4	{}	2025-10-16 12:05:00.031469+00
3582	sla_violation	4	{}	2025-10-16 12:05:00.031884+00
3583	sla_violation	4	{}	2025-10-16 12:05:00.031919+00
3584	sla_violation	4	{}	2025-10-16 12:05:00.032016+00
3585	memory_usage	18.73612403869629	{}	2025-10-16 12:10:00.017248+00
3586	memory_usage	18.73455047607422	{}	2025-10-16 12:10:00.017717+00
3587	memory_usage	18.73455047607422	{}	2025-10-16 12:10:00.017925+00
3588	memory_usage	18.73307228088379	{}	2025-10-16 12:10:00.018498+00
3589	disk_usage	7	{}	2025-10-16 12:10:00.023662+00
3590	disk_usage	7	{}	2025-10-16 12:10:00.025771+00
3591	whatsapp_success_rate	100	{}	2025-10-16 12:10:00.02629+00
3592	disk_usage	7	{}	2025-10-16 12:10:00.026207+00
3593	disk_usage	7	{}	2025-10-16 12:10:00.027111+00
3594	sla_violation	4	{}	2025-10-16 12:10:00.028571+00
3595	whatsapp_success_rate	100	{}	2025-10-16 12:10:00.028622+00
3596	whatsapp_success_rate	100	{}	2025-10-16 12:10:00.030109+00
3597	whatsapp_success_rate	100	{}	2025-10-16 12:10:00.030499+00
3598	sla_violation	4	{}	2025-10-16 12:10:00.032109+00
3599	sla_violation	4	{}	2025-10-16 12:10:00.032841+00
3600	sla_violation	4	{}	2025-10-16 12:10:00.03385+00
3601	memory_usage	18.755483627319336	{}	2025-10-16 12:15:00.028309+00
3602	memory_usage	18.755483627319336	{}	2025-10-16 12:15:00.029052+00
3603	memory_usage	18.755483627319336	{}	2025-10-16 12:15:00.029266+00
3604	disk_usage	7	{}	2025-10-16 12:15:00.035266+00
3605	memory_usage	18.797016143798828	{}	2025-10-16 12:15:00.035677+00
3606	disk_usage	7	{}	2025-10-16 12:15:00.037318+00
3607	disk_usage	7	{}	2025-10-16 12:15:00.037387+00
3608	whatsapp_success_rate	100	{}	2025-10-16 12:15:00.038422+00
3609	whatsapp_success_rate	100	{}	2025-10-16 12:15:00.040247+00
3610	sla_violation	4	{}	2025-10-16 12:15:00.040794+00
3611	whatsapp_success_rate	100	{}	2025-10-16 12:15:00.041075+00
3612	disk_usage	7	{}	2025-10-16 12:15:00.041889+00
3613	sla_violation	4	{}	2025-10-16 12:15:00.042914+00
3614	sla_violation	4	{}	2025-10-16 12:15:00.043796+00
3615	whatsapp_success_rate	100	{}	2025-10-16 12:15:00.044871+00
3616	sla_violation	4	{}	2025-10-16 12:15:00.047666+00
3617	memory_usage	18.779373168945312	{}	2025-10-16 12:20:00.017968+00
3618	memory_usage	18.779373168945312	{}	2025-10-16 12:20:00.018741+00
3619	memory_usage	18.786191940307617	{}	2025-10-16 12:20:00.01912+00
3620	memory_usage	18.804597854614258	{}	2025-10-16 12:20:00.024638+00
3622	disk_usage	7	{}	2025-10-16 12:20:00.026057+00
3623	disk_usage	7	{}	2025-10-16 12:20:00.02654+00
3625	whatsapp_success_rate	100	{}	2025-10-16 12:20:00.029121+00
3626	whatsapp_success_rate	100	{}	2025-10-16 12:20:00.029206+00
3627	disk_usage	7	{}	2025-10-16 12:20:00.030707+00
3629	sla_violation	4	{}	2025-10-16 12:20:00.031708+00
3630	sla_violation	4	{}	2025-10-16 12:20:00.031741+00
3631	whatsapp_success_rate	100	{}	2025-10-16 12:20:00.032979+00
3632	sla_violation	4	{}	2025-10-16 12:20:00.035189+00
4642	memory_usage	19.00339126586914	{}	2025-10-16 17:40:00.018256+00
4646	disk_usage	7	{}	2025-10-16 17:40:00.027539+00
4652	whatsapp_success_rate	100	{}	2025-10-16 17:40:00.030521+00
4656	sla_violation	4	{}	2025-10-16 17:40:00.035294+00
4673	memory_usage	19.025468826293945	{}	2025-10-16 17:50:00.018578+00
4678	disk_usage	7	{}	2025-10-16 17:50:00.025798+00
4681	whatsapp_success_rate	100	{}	2025-10-16 17:50:00.028653+00
4686	sla_violation	4	{}	2025-10-16 17:50:00.031255+00
4692	memory_usage	19.08249855041504	{}	2025-10-16 17:55:00.02442+00
4698	disk_usage	7	{}	2025-10-16 17:55:00.031069+00
4702	whatsapp_success_rate	100	{}	2025-10-16 17:55:00.033451+00
4704	sla_violation	4	{}	2025-10-16 17:55:00.035702+00
4725	memory_usage	19.378185272216797	{}	2025-10-16 18:05:00.024643+00
4732	disk_usage	7	{}	2025-10-16 18:05:00.031321+00
4734	whatsapp_success_rate	100	{}	2025-10-16 18:05:00.034544+00
4736	sla_violation	4	{}	2025-10-16 18:05:00.037604+00
4754	memory_usage	19.396543502807617	{}	2025-10-16 18:15:00.026839+00
4758	disk_usage	7	{}	2025-10-16 18:15:00.034049+00
4761	whatsapp_success_rate	100	{}	2025-10-16 18:15:00.037555+00
4765	sla_violation	4	{}	2025-10-16 18:15:00.040437+00
4785	memory_usage	19.359159469604492	{}	2025-10-16 18:25:00.01697+00
4790	disk_usage	7	{}	2025-10-16 18:25:00.024685+00
4793	whatsapp_success_rate	100	{}	2025-10-16 18:25:00.027316+00
4796	sla_violation	4	{}	2025-10-16 18:25:00.030331+00
4804	memory_usage	19.385051727294922	{}	2025-10-16 18:30:00.031538+00
4810	disk_usage	7	{}	2025-10-16 18:30:00.038861+00
4814	whatsapp_success_rate	100	{}	2025-10-16 18:30:00.042009+00
4816	sla_violation	4	{}	2025-10-16 18:30:00.045005+00
4835	memory_usage	19.364213943481445	{}	2025-10-16 18:40:00.019001+00
4839	disk_usage	7	{}	2025-10-16 18:40:00.025773+00
4843	whatsapp_success_rate	100	{}	2025-10-16 18:40:00.02804+00
4846	sla_violation	4	{}	2025-10-16 18:40:00.030537+00
4866	memory_usage	19.401168823242188	{}	2025-10-16 18:50:00.018607+00
4870	disk_usage	7	{}	2025-10-16 18:50:00.025374+00
4874	whatsapp_success_rate	100	{}	2025-10-16 18:50:00.028027+00
4876	sla_violation	4	{}	2025-10-16 18:50:00.030463+00
4884	memory_usage	19.403076171875	{}	2025-10-16 18:55:00.022055+00
4891	disk_usage	7	{}	2025-10-16 18:55:00.029133+00
4895	whatsapp_success_rate	100	{}	2025-10-16 18:55:00.033437+00
4896	sla_violation	4	{}	2025-10-16 18:55:00.036182+00
4914	memory_usage	19.426918029785156	{}	2025-10-16 19:05:00.018088+00
4918	disk_usage	7	{}	2025-10-16 19:05:00.025595+00
4923	whatsapp_success_rate	100	{}	2025-10-16 19:05:00.029264+00
4926	sla_violation	4	{}	2025-10-16 19:05:00.033276+00
4932	memory_usage	19.464683532714844	{}	2025-10-16 19:10:00.022123+00
4938	disk_usage	7	{}	2025-10-16 19:10:00.02852+00
4942	whatsapp_success_rate	100	{}	2025-10-16 19:10:00.032069+00
4944	sla_violation	4	{}	2025-10-16 19:10:00.034652+00
4962	memory_usage	19.405651092529297	{}	2025-10-16 19:20:00.017477+00
4967	disk_usage	7	{}	2025-10-16 19:20:00.026852+00
4971	whatsapp_success_rate	100	{}	2025-10-16 19:20:00.029315+00
4975	sla_violation	4	{}	2025-10-16 19:20:00.031518+00
4980	memory_usage	19.39229965209961	{}	2025-10-16 19:25:00.018615+00
4984	disk_usage	7	{}	2025-10-16 19:25:00.025688+00
4988	whatsapp_success_rate	100	{}	2025-10-16 19:25:00.028361+00
4992	sla_violation	4	{}	2025-10-16 19:25:00.03102+00
5010	memory_usage	19.402694702148438	{}	2025-10-16 19:35:00.01801+00
5015	disk_usage	7	{}	2025-10-16 19:35:00.025179+00
5019	whatsapp_success_rate	100	{}	2025-10-16 19:35:00.027949+00
5022	sla_violation	4	{}	2025-10-16 19:35:00.030592+00
5028	memory_usage	19.38481330871582	{}	2025-10-16 19:40:00.02015+00
5031	disk_usage	7	{}	2025-10-16 19:40:00.027296+00
5036	whatsapp_success_rate	100	{}	2025-10-16 19:40:00.030548+00
5040	sla_violation	4	{}	2025-10-16 19:40:00.033033+00
5057	memory_usage	19.344329833984375	{}	2025-10-16 19:50:00.018368+00
5061	disk_usage	7	{}	2025-10-16 19:50:00.025278+00
5065	whatsapp_success_rate	100	{}	2025-10-16 19:50:00.028166+00
5069	sla_violation	4	{}	2025-10-16 19:50:00.030771+00
5078	memory_usage	19.370555877685547	{}	2025-10-16 19:55:00.029269+00
5084	disk_usage	7	{}	2025-10-16 19:55:00.038457+00
5086	whatsapp_success_rate	100	{}	2025-10-16 19:55:00.041037+00
5088	sla_violation	4	{}	2025-10-16 19:55:00.043404+00
5106	memory_usage	19.332361221313477	{}	2025-10-16 20:05:00.018165+00
5112	disk_usage	7	{}	2025-10-16 20:05:00.026277+00
5116	whatsapp_success_rate	100	{}	2025-10-16 20:05:00.030043+00
5120	sla_violation	4	{}	2025-10-16 20:05:00.032988+00
5124	memory_usage	19.363975524902344	{}	2025-10-16 20:10:00.021787+00
5127	disk_usage	7	{}	2025-10-16 20:10:00.027704+00
5131	whatsapp_success_rate	100	{}	2025-10-16 20:10:00.030385+00
5135	sla_violation	4	{}	2025-10-16 20:10:00.032936+00
5154	memory_usage	19.376707077026367	{}	2025-10-16 20:20:00.025486+00
5158	disk_usage	7	{}	2025-10-16 20:20:00.032917+00
5162	whatsapp_success_rate	100	{}	2025-10-16 20:20:00.03561+00
5164	sla_violation	4	{}	2025-10-16 20:20:00.03812+00
5172	memory_usage	19.38009262084961	{}	2025-10-16 20:25:00.018546+00
5175	disk_usage	7	{}	2025-10-16 20:25:00.024895+00
5180	whatsapp_success_rate	100	{}	2025-10-16 20:25:00.027788+00
5184	sla_violation	4	{}	2025-10-16 20:25:00.030514+00
5202	memory_usage	19.431400299072266	{}	2025-10-16 20:35:00.010037+00
5203	disk_usage	7	{}	2025-10-16 20:35:00.016717+00
5206	whatsapp_success_rate	100	{}	2025-10-16 20:35:00.019429+00
5209	sla_violation	4	{}	2025-10-16 20:35:00.021844+00
5221	memory_usage	19.426774978637695	{}	2025-10-16 20:40:00.026083+00
5229	disk_usage	7	{}	2025-10-16 20:40:00.032568+00
5231	whatsapp_success_rate	100	{}	2025-10-16 20:40:00.035188+00
5232	sla_violation	4	{}	2025-10-16 20:40:00.038619+00
5250	memory_usage	19.382667541503906	{}	2025-10-16 20:50:00.01783+00
5255	disk_usage	7	{}	2025-10-16 20:50:00.024611+00
5258	whatsapp_success_rate	100	{}	2025-10-16 20:50:00.027907+00
5262	sla_violation	4	{}	2025-10-16 20:50:00.030413+00
5268	memory_usage	19.388294219970703	{}	2025-10-16 20:55:00.023545+00
3621	disk_usage	7	{}	2025-10-16 12:20:00.025974+00
3624	whatsapp_success_rate	100	{}	2025-10-16 12:20:00.028677+00
3628	sla_violation	4	{}	2025-10-16 12:20:00.031178+00
3633	memory_usage	18.742990493774414	{}	2025-10-16 12:25:00.018385+00
3634	memory_usage	18.742990493774414	{}	2025-10-16 12:25:00.018374+00
3635	memory_usage	18.746042251586914	{}	2025-10-16 12:25:00.019126+00
3636	memory_usage	18.755245208740234	{}	2025-10-16 12:25:00.019788+00
3637	disk_usage	7	{}	2025-10-16 12:25:00.025795+00
3638	disk_usage	7	{}	2025-10-16 12:25:00.02593+00
3639	disk_usage	7	{}	2025-10-16 12:25:00.026957+00
3640	disk_usage	7	{}	2025-10-16 12:25:00.027033+00
3641	whatsapp_success_rate	100	{}	2025-10-16 12:25:00.028273+00
3642	whatsapp_success_rate	100	{}	2025-10-16 12:25:00.028681+00
3643	whatsapp_success_rate	100	{}	2025-10-16 12:25:00.029193+00
3644	whatsapp_success_rate	100	{}	2025-10-16 12:25:00.029906+00
3645	sla_violation	4	{}	2025-10-16 12:25:00.030542+00
3646	sla_violation	4	{}	2025-10-16 12:25:00.030858+00
3647	sla_violation	4	{}	2025-10-16 12:25:00.031252+00
3648	sla_violation	4	{}	2025-10-16 12:25:00.03202+00
3649	memory_usage	18.73798370361328	{}	2025-10-16 12:30:00.026815+00
3650	memory_usage	18.73798370361328	{}	2025-10-16 12:30:00.030485+00
3651	memory_usage	18.76044273376465	{}	2025-10-16 12:30:00.031536+00
3652	memory_usage	18.78666877746582	{}	2025-10-16 12:30:00.034768+00
3653	disk_usage	7	{}	2025-10-16 12:30:00.035838+00
3654	disk_usage	7	{}	2025-10-16 12:30:00.039243+00
3655	whatsapp_success_rate	100	{}	2025-10-16 12:30:00.040341+00
3656	disk_usage	7	{}	2025-10-16 12:30:00.04082+00
3657	disk_usage	7	{}	2025-10-16 12:30:00.04171+00
3658	sla_violation	4	{}	2025-10-16 12:30:00.042624+00
3659	whatsapp_success_rate	100	{}	2025-10-16 12:30:00.043168+00
3660	whatsapp_success_rate	100	{}	2025-10-16 12:30:00.044133+00
3661	whatsapp_success_rate	100	{}	2025-10-16 12:30:00.04418+00
3662	sla_violation	4	{}	2025-10-16 12:30:00.045782+00
3663	sla_violation	4	{}	2025-10-16 12:30:00.046235+00
3664	sla_violation	4	{}	2025-10-16 12:30:00.046885+00
3665	memory_usage	18.76959800720215	{}	2025-10-16 12:35:00.017298+00
3666	memory_usage	18.76959800720215	{}	2025-10-16 12:35:00.017978+00
3667	memory_usage	18.76959800720215	{}	2025-10-16 12:35:00.01876+00
3668	memory_usage	18.79401206970215	{}	2025-10-16 12:35:00.020004+00
3670	disk_usage	7	{}	2025-10-16 12:35:00.025426+00
3669	disk_usage	7	{}	2025-10-16 12:35:00.025465+00
3671	disk_usage	7	{}	2025-10-16 12:35:00.025444+00
3672	disk_usage	7	{}	2025-10-16 12:35:00.026005+00
3673	whatsapp_success_rate	100	{}	2025-10-16 12:35:00.028164+00
3674	whatsapp_success_rate	100	{}	2025-10-16 12:35:00.028253+00
3675	whatsapp_success_rate	100	{}	2025-10-16 12:35:00.02832+00
3676	whatsapp_success_rate	100	{}	2025-10-16 12:35:00.029054+00
3677	sla_violation	4	{}	2025-10-16 12:35:00.03041+00
3678	sla_violation	4	{}	2025-10-16 12:35:00.030752+00
3679	sla_violation	4	{}	2025-10-16 12:35:00.030782+00
3680	sla_violation	4	{}	2025-10-16 12:35:00.031755+00
3681	memory_usage	18.728113174438477	{}	2025-10-16 12:40:00.016715+00
3682	memory_usage	18.731212615966797	{}	2025-10-16 12:40:00.017156+00
3683	memory_usage	18.732213973999023	{}	2025-10-16 12:40:00.017393+00
3684	disk_usage	7	{}	2025-10-16 12:40:00.023918+00
3685	disk_usage	7	{}	2025-10-16 12:40:00.024022+00
3687	disk_usage	7	{}	2025-10-16 12:40:00.024473+00
3686	memory_usage	18.76654624938965	{}	2025-10-16 12:40:00.023838+00
3688	whatsapp_success_rate	100	{}	2025-10-16 12:40:00.026586+00
3689	whatsapp_success_rate	100	{}	2025-10-16 12:40:00.026838+00
3690	whatsapp_success_rate	100	{}	2025-10-16 12:40:00.02695+00
3691	sla_violation	4	{}	2025-10-16 12:40:00.028865+00
3692	sla_violation	4	{}	2025-10-16 12:40:00.029288+00
3693	sla_violation	4	{}	2025-10-16 12:40:00.029465+00
3694	disk_usage	7	{}	2025-10-16 12:40:00.030575+00
3695	whatsapp_success_rate	100	{}	2025-10-16 12:40:00.033223+00
3696	sla_violation	4	{}	2025-10-16 12:40:00.035514+00
3697	memory_usage	18.733882904052734	{}	2025-10-16 12:45:00.028723+00
3698	memory_usage	18.733882904052734	{}	2025-10-16 12:45:00.029421+00
3699	memory_usage	18.726062774658203	{}	2025-10-16 12:45:00.031335+00
3700	memory_usage	18.726062774658203	{}	2025-10-16 12:45:00.032798+00
3701	disk_usage	7	{}	2025-10-16 12:45:00.039467+00
3702	disk_usage	7	{}	2025-10-16 12:45:00.039486+00
3703	disk_usage	7	{}	2025-10-16 12:45:00.039686+00
3704	whatsapp_success_rate	100	{}	2025-10-16 12:45:00.041829+00
3705	whatsapp_success_rate	100	{}	2025-10-16 12:45:00.042182+00
3706	whatsapp_success_rate	100	{}	2025-10-16 12:45:00.042255+00
3707	disk_usage	7	{}	2025-10-16 12:45:00.042545+00
3708	sla_violation	4	{}	2025-10-16 12:45:00.044878+00
3709	sla_violation	4	{}	2025-10-16 12:45:00.044902+00
3710	whatsapp_success_rate	100	{}	2025-10-16 12:45:00.045106+00
3711	sla_violation	4	{}	2025-10-16 12:45:00.045112+00
3712	sla_violation	4	{}	2025-10-16 12:45:00.049279+00
3713	memory_usage	18.727397918701172	{}	2025-10-16 12:50:00.017809+00
3714	memory_usage	18.730449676513672	{}	2025-10-16 12:50:00.018151+00
3715	memory_usage	18.727397918701172	{}	2025-10-16 12:50:00.018125+00
3716	memory_usage	18.766403198242188	{}	2025-10-16 12:50:00.023241+00
3717	disk_usage	7	{}	2025-10-16 12:50:00.025505+00
3718	disk_usage	7	{}	2025-10-16 12:50:00.026307+00
3719	disk_usage	7	{}	2025-10-16 12:50:00.026342+00
3720	whatsapp_success_rate	100	{}	2025-10-16 12:50:00.028771+00
3721	whatsapp_success_rate	100	{}	2025-10-16 12:50:00.028964+00
3722	whatsapp_success_rate	100	{}	2025-10-16 12:50:00.029285+00
3723	disk_usage	7	{}	2025-10-16 12:50:00.030927+00
3724	sla_violation	4	{}	2025-10-16 12:50:00.031255+00
3725	sla_violation	4	{}	2025-10-16 12:50:00.031618+00
3726	sla_violation	4	{}	2025-10-16 12:50:00.032011+00
3727	whatsapp_success_rate	100	{}	2025-10-16 12:50:00.033706+00
3728	sla_violation	4	{}	2025-10-16 12:50:00.035912+00
3729	memory_usage	18.71180534362793	{}	2025-10-16 12:55:00.017975+00
3730	memory_usage	18.70880126953125	{}	2025-10-16 12:55:00.018022+00
3731	memory_usage	18.713808059692383	{}	2025-10-16 12:55:00.021044+00
3732	memory_usage	18.737506866455078	{}	2025-10-16 12:55:00.022539+00
3733	disk_usage	7	{}	2025-10-16 12:55:00.025906+00
3734	disk_usage	7	{}	2025-10-16 12:55:00.026219+00
3735	disk_usage	7	{}	2025-10-16 12:55:00.027185+00
3736	whatsapp_success_rate	100	{}	2025-10-16 12:55:00.028532+00
3737	disk_usage	7	{}	2025-10-16 12:55:00.028684+00
3738	whatsapp_success_rate	100	{}	2025-10-16 12:55:00.028712+00
3739	whatsapp_success_rate	100	{}	2025-10-16 12:55:00.02998+00
3740	sla_violation	4	{}	2025-10-16 12:55:00.030813+00
3741	sla_violation	4	{}	2025-10-16 12:55:00.031042+00
3742	whatsapp_success_rate	100	{}	2025-10-16 12:55:00.031228+00
3743	sla_violation	4	{}	2025-10-16 12:55:00.03262+00
4643	memory_usage	19.00339126586914	{}	2025-10-16 17:40:00.018757+00
4647	disk_usage	7	{}	2025-10-16 17:40:00.027595+00
4650	whatsapp_success_rate	100	{}	2025-10-16 17:40:00.029936+00
4654	sla_violation	4	{}	2025-10-16 17:40:00.033059+00
4674	memory_usage	19.025468826293945	{}	2025-10-16 17:50:00.019059+00
4677	disk_usage	7	{}	2025-10-16 17:50:00.025837+00
4680	whatsapp_success_rate	100	{}	2025-10-16 17:50:00.028406+00
4685	sla_violation	4	{}	2025-10-16 17:50:00.031227+00
4705	memory_usage	19.13771629333496	{}	2025-10-16 18:00:00.026658+00
4708	disk_usage	7	{}	2025-10-16 18:00:00.03477+00
4711	whatsapp_success_rate	100	{}	2025-10-16 18:00:00.037685+00
4715	sla_violation	4	{}	2025-10-16 18:00:00.040881+00
4726	memory_usage	19.378662109375	{}	2025-10-16 18:05:00.025115+00
4731	disk_usage	7	{}	2025-10-16 18:05:00.031302+00
4733	whatsapp_success_rate	100	{}	2025-10-16 18:05:00.034408+00
4735	sla_violation	4	{}	2025-10-16 18:05:00.036652+00
4755	memory_usage	19.39396858215332	{}	2025-10-16 18:15:00.028772+00
4759	disk_usage	7	{}	2025-10-16 18:15:00.03556+00
4764	whatsapp_success_rate	100	{}	2025-10-16 18:15:00.040174+00
4767	sla_violation	4	{}	2025-10-16 18:15:00.043465+00
4786	memory_usage	19.359159469604492	{}	2025-10-16 18:25:00.017033+00
4789	disk_usage	7	{}	2025-10-16 18:25:00.024457+00
4794	whatsapp_success_rate	100	{}	2025-10-16 18:25:00.027534+00
4797	sla_violation	4	{}	2025-10-16 18:25:00.030397+00
4817	memory_usage	19.359350204467773	{}	2025-10-16 18:35:00.017763+00
4821	disk_usage	7	{}	2025-10-16 18:35:00.024922+00
4824	whatsapp_success_rate	100	{}	2025-10-16 18:35:00.027591+00
4828	sla_violation	4	{}	2025-10-16 18:35:00.030023+00
4836	memory_usage	19.408226013183594	{}	2025-10-16 18:40:00.022058+00
4842	disk_usage	7	{}	2025-10-16 18:40:00.02763+00
4845	whatsapp_success_rate	100	{}	2025-10-16 18:40:00.030158+00
4848	sla_violation	4	{}	2025-10-16 18:40:00.032584+00
4867	memory_usage	19.4061279296875	{}	2025-10-16 18:50:00.019706+00
4871	disk_usage	7	{}	2025-10-16 18:50:00.025928+00
4875	whatsapp_success_rate	100	{}	2025-10-16 18:50:00.028802+00
4879	sla_violation	4	{}	2025-10-16 18:50:00.031074+00
4897	memory_usage	19.397783279418945	{}	2025-10-16 19:00:00.037747+00
4900	disk_usage	7	{}	2025-10-16 19:00:00.049758+00
4904	whatsapp_success_rate	100	{}	2025-10-16 19:00:00.054737+00
4908	sla_violation	4	{}	2025-10-16 19:00:00.057219+00
4915	memory_usage	19.426918029785156	{}	2025-10-16 19:05:00.018415+00
4919	disk_usage	7	{}	2025-10-16 19:05:00.025647+00
4922	whatsapp_success_rate	100	{}	2025-10-16 19:05:00.029176+00
4927	sla_violation	4	{}	2025-10-16 19:05:00.033497+00
4945	memory_usage	19.405508041381836	{}	2025-10-16 19:15:00.026898+00
4949	disk_usage	7	{}	2025-10-16 19:15:00.034178+00
4953	whatsapp_success_rate	100	{}	2025-10-16 19:15:00.03727+00
4958	sla_violation	4	{}	2025-10-16 19:15:00.040703+00
4963	memory_usage	19.408702850341797	{}	2025-10-16 19:20:00.017917+00
4968	disk_usage	7	{}	2025-10-16 19:20:00.027283+00
4972	whatsapp_success_rate	100	{}	2025-10-16 19:20:00.029843+00
4976	sla_violation	4	{}	2025-10-16 19:20:00.03349+00
4993	memory_usage	19.379091262817383	{}	2025-10-16 19:30:00.025867+00
4997	disk_usage	7	{}	2025-10-16 19:30:00.032892+00
5001	whatsapp_success_rate	100	{}	2025-10-16 19:30:00.037531+00
5005	sla_violation	4	{}	2025-10-16 19:30:00.040381+00
5011	memory_usage	19.397497177124023	{}	2025-10-16 19:35:00.018273+00
5016	disk_usage	7	{}	2025-10-16 19:35:00.026221+00
5020	whatsapp_success_rate	100	{}	2025-10-16 19:35:00.028924+00
5024	sla_violation	4	{}	2025-10-16 19:35:00.031263+00
5041	memory_usage	19.374465942382812	{}	2025-10-16 19:45:00.027345+00
5044	disk_usage	7	{}	2025-10-16 19:45:00.034625+00
5045	whatsapp_success_rate	100	{}	2025-10-16 19:45:00.037258+00
5049	sla_violation	4	{}	2025-10-16 19:45:00.040113+00
5059	memory_usage	19.342517852783203	{}	2025-10-16 19:50:00.018318+00
5063	disk_usage	7	{}	2025-10-16 19:50:00.026278+00
5067	whatsapp_success_rate	100	{}	2025-10-16 19:50:00.029764+00
5071	sla_violation	4	{}	2025-10-16 19:50:00.032414+00
5089	memory_usage	19.34504508972168	{}	2025-10-16 20:00:00.02596+00
5094	disk_usage	7	{}	2025-10-16 20:00:00.037178+00
5097	whatsapp_success_rate	100	{}	2025-10-16 20:00:00.04103+00
5101	sla_violation	4	{}	2025-10-16 20:00:00.043677+00
5107	memory_usage	19.333934783935547	{}	2025-10-16 20:05:00.018643+00
5111	disk_usage	7	{}	2025-10-16 20:05:00.02578+00
5115	whatsapp_success_rate	100	{}	2025-10-16 20:05:00.029953+00
5118	sla_violation	4	{}	2025-10-16 20:05:00.032441+00
5137	memory_usage	19.373226165771484	{}	2025-10-16 20:15:00.02811+00
5141	disk_usage	7	{}	2025-10-16 20:15:00.036919+00
5146	whatsapp_success_rate	100	{}	2025-10-16 20:15:00.040313+00
5150	sla_violation	4	{}	2025-10-16 20:15:00.043427+00
5156	memory_usage	19.403696060180664	{}	2025-10-16 20:20:00.028375+00
5161	disk_usage	7	{}	2025-10-16 20:20:00.035073+00
5163	whatsapp_success_rate	100	{}	2025-10-16 20:20:00.037769+00
5165	sla_violation	4	{}	2025-10-16 20:20:00.040046+00
5185	memory_usage	19.402647018432617	{}	2025-10-16 20:30:00.02511+00
5188	disk_usage	7	{}	2025-10-16 20:30:00.033192+00
5190	whatsapp_success_rate	100	{}	2025-10-16 20:30:00.037581+00
5193	sla_violation	4	{}	2025-10-16 20:30:00.040163+00
5205	memory_usage	19.431400299072266	{}	2025-10-16 20:35:00.017953+00
5211	disk_usage	7	{}	2025-10-16 20:35:00.024897+00
5213	whatsapp_success_rate	100	{}	2025-10-16 20:35:00.027283+00
5214	sla_violation	4	{}	2025-10-16 20:35:00.029463+00
5233	memory_usage	19.39873695373535	{}	2025-10-16 20:45:00.028061+00
5237	disk_usage	7	{}	2025-10-16 20:45:00.035882+00
5241	whatsapp_success_rate	100	{}	2025-10-16 20:45:00.039358+00
5243	sla_violation	4	{}	2025-10-16 20:45:00.043888+00
5251	memory_usage	19.382667541503906	{}	2025-10-16 20:50:00.018317+00
5254	disk_usage	7	{}	2025-10-16 20:50:00.023996+00
5257	whatsapp_success_rate	100	{}	2025-10-16 20:50:00.027802+00
5261	sla_violation	4	{}	2025-10-16 20:50:00.030166+00
5274	disk_usage	7	{}	2025-10-16 20:55:00.030373+00
5278	whatsapp_success_rate	100	{}	2025-10-16 20:55:00.03333+00
5280	sla_violation	4	{}	2025-10-16 20:55:00.035857+00
5285	disk_usage	7	{}	2025-10-16 21:00:00.035569+00
5288	whatsapp_success_rate	100	{}	2025-10-16 21:00:00.040139+00
5292	sla_violation	4	{}	2025-10-16 21:00:00.042667+00
5298	memory_usage	19.40445899963379	{}	2025-10-16 21:05:00.021352+00
5301	disk_usage	7	{}	2025-10-16 21:05:00.028739+00
5306	whatsapp_success_rate	100	{}	2025-10-16 21:05:00.031767+00
5307	sla_violation	4	{}	2025-10-16 21:05:00.033367+00
5309	sla_violation	4	{}	2025-10-16 21:05:00.034359+00
5311	whatsapp_success_rate	100	{}	2025-10-16 21:05:00.039117+00
3744	sla_violation	4	{}	2025-10-16 12:55:00.034411+00
3745	memory_usage	18.69945526123047	{}	2025-10-16 13:00:00.024981+00
3746	memory_usage	18.708276748657227	{}	2025-10-16 13:00:00.02789+00
3747	memory_usage	18.723440170288086	{}	2025-10-16 13:00:00.028658+00
3748	disk_usage	7	{}	2025-10-16 13:00:00.03405+00
3749	disk_usage	7	{}	2025-10-16 13:00:00.035495+00
3750	memory_usage	18.787145614624023	{}	2025-10-16 13:00:00.035576+00
3751	disk_usage	7	{}	2025-10-16 13:00:00.036739+00
3752	whatsapp_success_rate	100	{}	2025-10-16 13:00:00.037703+00
3753	whatsapp_success_rate	100	{}	2025-10-16 13:00:00.039105+00
3754	whatsapp_success_rate	100	{}	2025-10-16 13:00:00.039301+00
3755	sla_violation	4	{}	2025-10-16 13:00:00.04079+00
3756	disk_usage	7	{}	2025-10-16 13:00:00.041692+00
3757	sla_violation	4	{}	2025-10-16 13:00:00.042183+00
3758	sla_violation	4	{}	2025-10-16 13:00:00.043374+00
3759	whatsapp_success_rate	100	{}	2025-10-16 13:00:00.044768+00
3760	sla_violation	4	{}	2025-10-16 13:00:00.048449+00
3761	memory_usage	18.71509552001953	{}	2025-10-16 13:05:00.017553+00
3762	memory_usage	18.71509552001953	{}	2025-10-16 13:05:00.017819+00
3763	memory_usage	18.71509552001953	{}	2025-10-16 13:05:00.018664+00
3764	disk_usage	7	{}	2025-10-16 13:05:00.024833+00
3766	disk_usage	7	{}	2025-10-16 13:05:00.024945+00
3765	memory_usage	18.748092651367188	{}	2025-10-16 13:05:00.024279+00
3767	disk_usage	7	{}	2025-10-16 13:05:00.025259+00
3768	whatsapp_success_rate	100	{}	2025-10-16 13:05:00.027941+00
3769	whatsapp_success_rate	100	{}	2025-10-16 13:05:00.027999+00
3770	whatsapp_success_rate	100	{}	2025-10-16 13:05:00.02811+00
3771	sla_violation	4	{}	2025-10-16 13:05:00.030464+00
3772	sla_violation	4	{}	2025-10-16 13:05:00.03088+00
3773	disk_usage	7	{}	2025-10-16 13:05:00.031365+00
3774	sla_violation	4	{}	2025-10-16 13:05:00.031386+00
3775	whatsapp_success_rate	100	{}	2025-10-16 13:05:00.034808+00
3776	sla_violation	4	{}	2025-10-16 13:05:00.036916+00
3777	memory_usage	18.694400787353516	{}	2025-10-16 13:10:00.017009+00
3778	memory_usage	18.700122833251953	{}	2025-10-16 13:10:00.017249+00
3779	memory_usage	18.691349029541016	{}	2025-10-16 13:10:00.017253+00
3780	memory_usage	18.700122833251953	{}	2025-10-16 13:10:00.01822+00
3781	disk_usage	7	{}	2025-10-16 13:10:00.023791+00
3782	disk_usage	7	{}	2025-10-16 13:10:00.025594+00
3783	disk_usage	7	{}	2025-10-16 13:10:00.026031+00
3784	disk_usage	7	{}	2025-10-16 13:10:00.026135+00
3785	whatsapp_success_rate	100	{}	2025-10-16 13:10:00.028173+00
3786	whatsapp_success_rate	100	{}	2025-10-16 13:10:00.028943+00
3787	whatsapp_success_rate	100	{}	2025-10-16 13:10:00.029179+00
3788	whatsapp_success_rate	100	{}	2025-10-16 13:10:00.030998+00
3789	sla_violation	4	{}	2025-10-16 13:10:00.031803+00
3790	sla_violation	4	{}	2025-10-16 13:10:00.031827+00
3791	sla_violation	4	{}	2025-10-16 13:10:00.031864+00
3792	sla_violation	4	{}	2025-10-16 13:10:00.03318+00
3793	memory_usage	18.720626831054688	{}	2025-10-16 13:15:00.026041+00
3794	memory_usage	18.717050552368164	{}	2025-10-16 13:15:00.028619+00
3795	memory_usage	18.73025894165039	{}	2025-10-16 13:15:00.030193+00
3796	disk_usage	7	{}	2025-10-16 13:15:00.033956+00
3798	disk_usage	7	{}	2025-10-16 13:15:00.036191+00
3797	memory_usage	18.769121170043945	{}	2025-10-16 13:15:00.035693+00
3799	whatsapp_success_rate	100	{}	2025-10-16 13:15:00.036787+00
3800	disk_usage	7	{}	2025-10-16 13:15:00.036898+00
3801	sla_violation	4	{}	2025-10-16 13:15:00.040662+00
3802	whatsapp_success_rate	100	{}	2025-10-16 13:15:00.041309+00
3803	whatsapp_success_rate	100	{}	2025-10-16 13:15:00.042223+00
3804	sla_violation	4	{}	2025-10-16 13:15:00.043558+00
3805	sla_violation	4	{}	2025-10-16 13:15:00.044422+00
3806	disk_usage	7	{}	2025-10-16 13:15:00.044986+00
3807	whatsapp_success_rate	100	{}	2025-10-16 13:15:00.0479+00
3808	sla_violation	4	{}	2025-10-16 13:15:00.050432+00
3809	memory_usage	18.686723709106445	{}	2025-10-16 13:20:00.016787+00
3810	memory_usage	18.686723709106445	{}	2025-10-16 13:20:00.016833+00
3811	memory_usage	18.686723709106445	{}	2025-10-16 13:20:00.017816+00
3812	disk_usage	7	{}	2025-10-16 13:20:00.023503+00
3813	memory_usage	18.725299835205078	{}	2025-10-16 13:20:00.024197+00
3814	disk_usage	7	{}	2025-10-16 13:20:00.02515+00
3815	disk_usage	7	{}	2025-10-16 13:20:00.026024+00
3816	whatsapp_success_rate	100	{}	2025-10-16 13:20:00.026237+00
3817	whatsapp_success_rate	100	{}	2025-10-16 13:20:00.028478+00
3818	whatsapp_success_rate	100	{}	2025-10-16 13:20:00.028588+00
3819	sla_violation	4	{}	2025-10-16 13:20:00.028853+00
3820	disk_usage	7	{}	2025-10-16 13:20:00.030209+00
3821	sla_violation	4	{}	2025-10-16 13:20:00.030905+00
3822	sla_violation	4	{}	2025-10-16 13:20:00.031032+00
3823	whatsapp_success_rate	100	{}	2025-10-16 13:20:00.032814+00
3824	sla_violation	4	{}	2025-10-16 13:20:00.03522+00
3825	memory_usage	18.692970275878906	{}	2025-10-16 13:25:00.017772+00
3826	memory_usage	18.692970275878906	{}	2025-10-16 13:25:00.018824+00
3827	memory_usage	18.692970275878906	{}	2025-10-16 13:25:00.018823+00
3828	memory_usage	18.692970275878906	{}	2025-10-16 13:25:00.01993+00
3829	disk_usage	7	{}	2025-10-16 13:25:00.024992+00
3830	disk_usage	7	{}	2025-10-16 13:25:00.02573+00
3831	disk_usage	7	{}	2025-10-16 13:25:00.025925+00
3832	disk_usage	7	{}	2025-10-16 13:25:00.02601+00
3833	whatsapp_success_rate	100	{}	2025-10-16 13:25:00.027814+00
3834	whatsapp_success_rate	100	{}	2025-10-16 13:25:00.028379+00
3835	whatsapp_success_rate	100	{}	2025-10-16 13:25:00.028545+00
3836	whatsapp_success_rate	100	{}	2025-10-16 13:25:00.028892+00
3837	sla_violation	4	{}	2025-10-16 13:25:00.029943+00
3838	sla_violation	4	{}	2025-10-16 13:25:00.030628+00
3839	sla_violation	4	{}	2025-10-16 13:25:00.030953+00
3840	sla_violation	4	{}	2025-10-16 13:25:00.032409+00
3841	memory_usage	18.72076988220215	{}	2025-10-16 13:30:00.027085+00
3843	memory_usage	18.713665008544922	{}	2025-10-16 13:30:00.030583+00
3842	memory_usage	18.71929168701172	{}	2025-10-16 13:30:00.029976+00
3844	memory_usage	18.713665008544922	{}	2025-10-16 13:30:00.030833+00
3845	disk_usage	7	{}	2025-10-16 13:30:00.034686+00
3846	whatsapp_success_rate	100	{}	2025-10-16 13:30:00.037863+00
3847	disk_usage	7	{}	2025-10-16 13:30:00.038447+00
3848	disk_usage	7	{}	2025-10-16 13:30:00.038964+00
3849	disk_usage	7	{}	2025-10-16 13:30:00.039022+00
3850	whatsapp_success_rate	100	{}	2025-10-16 13:30:00.041094+00
3851	sla_violation	4	{}	2025-10-16 13:30:00.041206+00
3852	whatsapp_success_rate	100	{}	2025-10-16 13:30:00.041933+00
3853	whatsapp_success_rate	100	{}	2025-10-16 13:30:00.042038+00
3854	sla_violation	4	{}	2025-10-16 13:30:00.043197+00
3855	sla_violation	4	{}	2025-10-16 13:30:00.044654+00
3856	sla_violation	4	{}	2025-10-16 13:30:00.044893+00
3857	memory_usage	18.680667877197266	{}	2025-10-16 13:35:00.017696+00
3858	memory_usage	18.680667877197266	{}	2025-10-16 13:35:00.017697+00
3859	memory_usage	18.704748153686523	{}	2025-10-16 13:35:00.021826+00
3860	memory_usage	18.704748153686523	{}	2025-10-16 13:35:00.022692+00
3861	disk_usage	7	{}	2025-10-16 13:35:00.024579+00
3862	disk_usage	7	{}	2025-10-16 13:35:00.025455+00
3863	whatsapp_success_rate	100	{}	2025-10-16 13:35:00.027125+00
3864	whatsapp_success_rate	100	{}	2025-10-16 13:35:00.027688+00
3865	disk_usage	7	{}	2025-10-16 13:35:00.028519+00
3866	sla_violation	4	{}	2025-10-16 13:35:00.029245+00
3867	disk_usage	7	{}	2025-10-16 13:35:00.029399+00
3868	sla_violation	4	{}	2025-10-16 13:35:00.029703+00
3869	whatsapp_success_rate	100	{}	2025-10-16 13:35:00.031598+00
3870	whatsapp_success_rate	100	{}	2025-10-16 13:35:00.03219+00
3871	sla_violation	4	{}	2025-10-16 13:35:00.03382+00
3872	sla_violation	4	{}	2025-10-16 13:35:00.034364+00
3873	memory_usage	18.686628341674805	{}	2025-10-16 13:40:00.018333+00
3874	memory_usage	18.686628341674805	{}	2025-10-16 13:40:00.019003+00
3875	memory_usage	18.686628341674805	{}	2025-10-16 13:40:00.020037+00
3876	memory_usage	18.724679946899414	{}	2025-10-16 13:40:00.022499+00
3877	disk_usage	7	{}	2025-10-16 13:40:00.025268+00
3878	disk_usage	7	{}	2025-10-16 13:40:00.025961+00
3879	disk_usage	7	{}	2025-10-16 13:40:00.026197+00
3880	whatsapp_success_rate	100	{}	2025-10-16 13:40:00.027911+00
3881	whatsapp_success_rate	100	{}	2025-10-16 13:40:00.028263+00
3882	whatsapp_success_rate	100	{}	2025-10-16 13:40:00.028911+00
3883	disk_usage	7	{}	2025-10-16 13:40:00.02981+00
3884	sla_violation	4	{}	2025-10-16 13:40:00.030334+00
3885	sla_violation	4	{}	2025-10-16 13:40:00.03055+00
3886	sla_violation	4	{}	2025-10-16 13:40:00.03201+00
3887	whatsapp_success_rate	100	{}	2025-10-16 13:40:00.032335+00
3888	sla_violation	4	{}	2025-10-16 13:40:00.03529+00
3889	memory_usage	18.752241134643555	{}	2025-10-16 13:45:00.026495+00
3890	memory_usage	18.757057189941406	{}	2025-10-16 13:45:00.030014+00
3891	disk_usage	7	{}	2025-10-16 13:45:00.033877+00
3892	memory_usage	18.76087188720703	{}	2025-10-16 13:45:00.035077+00
3893	whatsapp_success_rate	100	{}	2025-10-16 13:45:00.037353+00
3894	disk_usage	7	{}	2025-10-16 13:45:00.038309+00
3895	memory_usage	18.816757202148438	{}	2025-10-16 13:45:00.039016+00
3896	sla_violation	4	{}	2025-10-16 13:45:00.040181+00
3897	disk_usage	7	{}	2025-10-16 13:45:00.043542+00
3898	whatsapp_success_rate	100	{}	2025-10-16 13:45:00.044594+00
3899	disk_usage	7	{}	2025-10-16 13:45:00.044991+00
3900	whatsapp_success_rate	100	{}	2025-10-16 13:45:00.048589+00
3901	sla_violation	4	{}	2025-10-16 13:45:00.048826+00
3902	whatsapp_success_rate	100	{}	2025-10-16 13:45:00.048936+00
3903	sla_violation	4	{}	2025-10-16 13:45:00.050773+00
3904	sla_violation	4	{}	2025-10-16 13:45:00.05145+00
3905	memory_usage	18.697738647460938	{}	2025-10-16 13:50:00.018089+00
3906	memory_usage	18.697738647460938	{}	2025-10-16 13:50:00.018438+00
3907	memory_usage	18.697738647460938	{}	2025-10-16 13:50:00.019127+00
3908	memory_usage	18.698692321777344	{}	2025-10-16 13:50:00.021523+00
3909	disk_usage	7	{}	2025-10-16 13:50:00.026057+00
3910	disk_usage	7	{}	2025-10-16 13:50:00.026125+00
3911	disk_usage	7	{}	2025-10-16 13:50:00.02658+00
3912	disk_usage	7	{}	2025-10-16 13:50:00.027775+00
3913	whatsapp_success_rate	100	{}	2025-10-16 13:50:00.029592+00
3914	whatsapp_success_rate	100	{}	2025-10-16 13:50:00.03005+00
3915	whatsapp_success_rate	100	{}	2025-10-16 13:50:00.030056+00
3916	whatsapp_success_rate	100	{}	2025-10-16 13:50:00.030248+00
3917	sla_violation	4	{}	2025-10-16 13:50:00.031939+00
3918	sla_violation	4	{}	2025-10-16 13:50:00.032378+00
3919	sla_violation	4	{}	2025-10-16 13:50:00.032399+00
3920	sla_violation	4	{}	2025-10-16 13:50:00.03269+00
3921	memory_usage	18.724679946899414	{}	2025-10-16 13:55:00.018218+00
3922	memory_usage	18.72696876525879	{}	2025-10-16 13:55:00.019224+00
3923	memory_usage	18.7593936920166	{}	2025-10-16 13:55:00.023548+00
3924	memory_usage	18.7593936920166	{}	2025-10-16 13:55:00.024507+00
3925	disk_usage	7	{}	2025-10-16 13:55:00.025696+00
3926	disk_usage	7	{}	2025-10-16 13:55:00.026182+00
3927	whatsapp_success_rate	100	{}	2025-10-16 13:55:00.028742+00
3928	whatsapp_success_rate	100	{}	2025-10-16 13:55:00.028948+00
3929	disk_usage	7	{}	2025-10-16 13:55:00.029862+00
3930	disk_usage	7	{}	2025-10-16 13:55:00.030381+00
3931	sla_violation	4	{}	2025-10-16 13:55:00.031004+00
3932	sla_violation	4	{}	2025-10-16 13:55:00.031384+00
3933	whatsapp_success_rate	100	{}	2025-10-16 13:55:00.032488+00
3934	whatsapp_success_rate	100	{}	2025-10-16 13:55:00.032702+00
3935	sla_violation	4	{}	2025-10-16 13:55:00.034912+00
3936	sla_violation	4	{}	2025-10-16 13:55:00.035387+00
3937	memory_usage	18.709802627563477	{}	2025-10-16 14:00:00.031777+00
3938	memory_usage	18.722057342529297	{}	2025-10-16 14:00:00.031804+00
3939	memory_usage	18.73040199279785	{}	2025-10-16 14:00:00.032024+00
3940	memory_usage	18.72258186340332	{}	2025-10-16 14:00:00.035102+00
3941	disk_usage	7	{}	2025-10-16 14:00:00.039732+00
3942	disk_usage	7	{}	2025-10-16 14:00:00.040017+00
3943	disk_usage	7	{}	2025-10-16 14:00:00.040049+00
3944	disk_usage	7	{}	2025-10-16 14:00:00.043098+00
3945	whatsapp_success_rate	100	{}	2025-10-16 14:00:00.043278+00
3946	whatsapp_success_rate	100	{}	2025-10-16 14:00:00.044554+00
3947	whatsapp_success_rate	100	{}	2025-10-16 14:00:00.045021+00
3948	whatsapp_success_rate	100	{}	2025-10-16 14:00:00.046012+00
3949	sla_violation	4	{}	2025-10-16 14:00:00.047574+00
3950	sla_violation	4	{}	2025-10-16 14:00:00.048877+00
3951	sla_violation	4	{}	2025-10-16 14:00:00.049078+00
3952	sla_violation	4	{}	2025-10-16 14:00:00.053046+00
3953	memory_usage	18.676090240478516	{}	2025-10-16 14:05:00.017248+00
3954	memory_usage	18.69344711303711	{}	2025-10-16 14:05:00.022402+00
3955	memory_usage	18.694019317626953	{}	2025-10-16 14:05:00.02356+00
3956	memory_usage	18.700122833251953	{}	2025-10-16 14:05:00.024529+00
3957	disk_usage	7	{}	2025-10-16 14:05:00.025536+00
3958	whatsapp_success_rate	100	{}	2025-10-16 14:05:00.028824+00
3959	disk_usage	7	{}	2025-10-16 14:05:00.029938+00
3960	disk_usage	7	{}	2025-10-16 14:05:00.031304+00
3961	disk_usage	7	{}	2025-10-16 14:05:00.031714+00
3962	sla_violation	4	{}	2025-10-16 14:05:00.032856+00
3963	whatsapp_success_rate	100	{}	2025-10-16 14:05:00.034375+00
3964	whatsapp_success_rate	100	{}	2025-10-16 14:05:00.034506+00
3965	whatsapp_success_rate	100	{}	2025-10-16 14:05:00.034654+00
3966	sla_violation	4	{}	2025-10-16 14:05:00.03664+00
3967	sla_violation	4	{}	2025-10-16 14:05:00.037636+00
3968	sla_violation	4	{}	2025-10-16 14:05:00.037839+00
3969	memory_usage	18.734407424926758	{}	2025-10-16 14:10:00.017444+00
3970	memory_usage	18.734407424926758	{}	2025-10-16 14:10:00.017412+00
3971	memory_usage	18.726348876953125	{}	2025-10-16 14:10:00.019024+00
3972	memory_usage	18.759965896606445	{}	2025-10-16 14:10:00.02264+00
3974	disk_usage	7	{}	2025-10-16 14:10:00.024658+00
3975	disk_usage	7	{}	2025-10-16 14:10:00.026744+00
3977	whatsapp_success_rate	100	{}	2025-10-16 14:10:00.027271+00
3978	disk_usage	7	{}	2025-10-16 14:10:00.0284+00
3980	sla_violation	4	{}	2025-10-16 14:10:00.029783+00
3981	whatsapp_success_rate	100	{}	2025-10-16 14:10:00.030499+00
3982	whatsapp_success_rate	100	{}	2025-10-16 14:10:00.030627+00
3983	sla_violation	4	{}	2025-10-16 14:10:00.034703+00
3984	sla_violation	4	{}	2025-10-16 14:10:00.034798+00
4644	memory_usage	19.00339126586914	{}	2025-10-16 17:40:00.019475+00
4648	disk_usage	7	{}	2025-10-16 17:40:00.027706+00
4651	whatsapp_success_rate	100	{}	2025-10-16 17:40:00.030343+00
4655	sla_violation	4	{}	2025-10-16 17:40:00.035082+00
4675	memory_usage	19.04129981994629	{}	2025-10-16 17:50:00.021766+00
4679	disk_usage	7	{}	2025-10-16 17:50:00.028278+00
4683	whatsapp_success_rate	100	{}	2025-10-16 17:50:00.031185+00
4687	sla_violation	4	{}	2025-10-16 17:50:00.033577+00
4706	memory_usage	19.137096405029297	{}	2025-10-16 18:00:00.026829+00
4709	disk_usage	7	{}	2025-10-16 18:00:00.03629+00
4713	whatsapp_success_rate	100	{}	2025-10-16 18:00:00.040563+00
4716	sla_violation	4	{}	2025-10-16 18:00:00.043847+00
4737	memory_usage	19.348621368408203	{}	2025-10-16 18:10:00.019663+00
4741	disk_usage	7	{}	2025-10-16 18:10:00.026416+00
4745	whatsapp_success_rate	100	{}	2025-10-16 18:10:00.029581+00
4749	sla_violation	4	{}	2025-10-16 18:10:00.032028+00
4756	memory_usage	19.425106048583984	{}	2025-10-16 18:15:00.029971+00
4762	disk_usage	7	{}	2025-10-16 18:15:00.037899+00
4766	whatsapp_success_rate	100	{}	2025-10-16 18:15:00.041099+00
4768	sla_violation	4	{}	2025-10-16 18:15:00.043731+00
4787	memory_usage	19.364595413208008	{}	2025-10-16 18:25:00.017962+00
4788	disk_usage	7	{}	2025-10-16 18:25:00.024439+00
4792	whatsapp_success_rate	100	{}	2025-10-16 18:25:00.027053+00
4795	sla_violation	4	{}	2025-10-16 18:25:00.029507+00
4818	memory_usage	19.359350204467773	{}	2025-10-16 18:35:00.018864+00
4822	disk_usage	7	{}	2025-10-16 18:35:00.025114+00
4825	whatsapp_success_rate	100	{}	2025-10-16 18:35:00.02804+00
4830	sla_violation	4	{}	2025-10-16 18:35:00.03035+00
4849	memory_usage	19.369173049926758	{}	2025-10-16 18:45:00.02727+00
4853	disk_usage	7	{}	2025-10-16 18:45:00.035343+00
4855	whatsapp_success_rate	100	{}	2025-10-16 18:45:00.03878+00
4859	sla_violation	4	{}	2025-10-16 18:45:00.041419+00
4868	memory_usage	19.392919540405273	{}	2025-10-16 18:50:00.020903+00
4872	disk_usage	7	{}	2025-10-16 18:50:00.027589+00
4878	whatsapp_success_rate	100	{}	2025-10-16 18:50:00.030756+00
4880	sla_violation	4	{}	2025-10-16 18:50:00.033419+00
4898	memory_usage	19.455718994140625	{}	2025-10-16 19:00:00.04374+00
4902	disk_usage	7	{}	2025-10-16 19:00:00.051943+00
4906	whatsapp_success_rate	100	{}	2025-10-16 19:00:00.054973+00
4910	sla_violation	4	{}	2025-10-16 19:00:00.057678+00
4916	memory_usage	19.467639923095703	{}	2025-10-16 19:05:00.023164+00
4920	disk_usage	7	{}	2025-10-16 19:05:00.029056+00
4924	whatsapp_success_rate	100	{}	2025-10-16 19:05:00.032146+00
4928	sla_violation	4	{}	2025-10-16 19:05:00.034531+00
4946	memory_usage	19.408559799194336	{}	2025-10-16 19:15:00.02729+00
4950	disk_usage	7	{}	2025-10-16 19:15:00.034908+00
4954	whatsapp_success_rate	100	{}	2025-10-16 19:15:00.037985+00
4957	sla_violation	4	{}	2025-10-16 19:15:00.040536+00
4964	memory_usage	19.405651092529297	{}	2025-10-16 19:20:00.018369+00
4965	disk_usage	7	{}	2025-10-16 19:20:00.025435+00
4969	whatsapp_success_rate	100	{}	2025-10-16 19:20:00.028386+00
4973	sla_violation	4	{}	2025-10-16 19:20:00.03075+00
4994	memory_usage	19.379758834838867	{}	2025-10-16 19:30:00.027532+00
4998	disk_usage	7	{}	2025-10-16 19:30:00.033729+00
4999	whatsapp_success_rate	100	{}	2025-10-16 19:30:00.036142+00
5003	sla_violation	4	{}	2025-10-16 19:30:00.038399+00
5012	memory_usage	19.399690628051758	{}	2025-10-16 19:35:00.018826+00
5014	disk_usage	7	{}	2025-10-16 19:35:00.025145+00
5018	whatsapp_success_rate	100	{}	2025-10-16 19:35:00.027864+00
5023	sla_violation	4	{}	2025-10-16 19:35:00.030618+00
5042	memory_usage	19.3723201751709	{}	2025-10-16 19:45:00.030678+00
5047	disk_usage	7	{}	2025-10-16 19:45:00.038284+00
5051	whatsapp_success_rate	100	{}	2025-10-16 19:45:00.04155+00
5054	sla_violation	4	{}	2025-10-16 19:45:00.044942+00
5060	memory_usage	19.379472732543945	{}	2025-10-16 19:50:00.021905+00
5064	disk_usage	7	{}	2025-10-16 19:50:00.027927+00
5068	whatsapp_success_rate	100	{}	2025-10-16 19:50:00.030379+00
5072	sla_violation	4	{}	2025-10-16 19:50:00.032754+00
5090	memory_usage	19.352293014526367	{}	2025-10-16 20:00:00.028541+00
5093	disk_usage	7	{}	2025-10-16 20:00:00.036282+00
5096	whatsapp_success_rate	100	{}	2025-10-16 20:00:00.038922+00
5099	sla_violation	4	{}	2025-10-16 20:00:00.041317+00
5108	memory_usage	19.33584213256836	{}	2025-10-16 20:05:00.018769+00
5110	disk_usage	7	{}	2025-10-16 20:05:00.025535+00
5114	whatsapp_success_rate	100	{}	2025-10-16 20:05:00.02869+00
5119	sla_violation	4	{}	2025-10-16 20:05:00.032496+00
5138	memory_usage	19.373226165771484	{}	2025-10-16 20:15:00.028873+00
5143	disk_usage	7	{}	2025-10-16 20:15:00.037621+00
5147	whatsapp_success_rate	100	{}	2025-10-16 20:15:00.040258+00
5151	sla_violation	4	{}	2025-10-16 20:15:00.043685+00
5160	memory_usage	19.400644302368164	{}	2025-10-16 20:20:00.033731+00
5166	disk_usage	7	{}	2025-10-16 20:20:00.040163+00
5167	whatsapp_success_rate	100	{}	2025-10-16 20:20:00.042938+00
5168	sla_violation	4	{}	2025-10-16 20:20:00.045082+00
5186	memory_usage	19.395828247070312	{}	2025-10-16 20:30:00.02916+00
5191	disk_usage	7	{}	2025-10-16 20:30:00.038351+00
5194	whatsapp_success_rate	100	{}	2025-10-16 20:30:00.041215+00
5196	sla_violation	4	{}	2025-10-16 20:30:00.043629+00
5208	memory_usage	19.431400299072266	{}	2025-10-16 20:35:00.019911+00
5212	disk_usage	7	{}	2025-10-16 20:35:00.026272+00
5215	whatsapp_success_rate	100	{}	2025-10-16 20:35:00.029556+00
5216	sla_violation	4	{}	2025-10-16 20:35:00.032432+00
5234	memory_usage	19.394683837890625	{}	2025-10-16 20:45:00.02872+00
5236	disk_usage	7	{}	2025-10-16 20:45:00.035656+00
5240	whatsapp_success_rate	100	{}	2025-10-16 20:45:00.038253+00
5244	sla_violation	4	{}	2025-10-16 20:45:00.043896+00
5252	memory_usage	19.413280487060547	{}	2025-10-16 20:50:00.022702+00
5259	disk_usage	7	{}	2025-10-16 20:50:00.028238+00
5263	whatsapp_success_rate	100	{}	2025-10-16 20:50:00.030678+00
5264	sla_violation	4	{}	2025-10-16 20:50:00.033255+00
5281	memory_usage	19.4033145904541	{}	2025-10-16 21:00:00.027286+00
3973	disk_usage	7	{}	2025-10-16 14:10:00.024373+00
3976	whatsapp_success_rate	100	{}	2025-10-16 14:10:00.027021+00
3979	sla_violation	4	{}	2025-10-16 14:10:00.029409+00
3985	memory_usage	18.704986572265625	{}	2025-10-16 14:15:00.030921+00
3986	memory_usage	18.697357177734375	{}	2025-10-16 14:15:00.032454+00
3987	memory_usage	18.724966049194336	{}	2025-10-16 14:15:00.035596+00
3988	memory_usage	18.725156784057617	{}	2025-10-16 14:15:00.036686+00
3989	disk_usage	7	{}	2025-10-16 14:15:00.038589+00
3990	disk_usage	7	{}	2025-10-16 14:15:00.040584+00
3991	whatsapp_success_rate	100	{}	2025-10-16 14:15:00.042291+00
3992	disk_usage	7	{}	2025-10-16 14:15:00.043292+00
3993	disk_usage	7	{}	2025-10-16 14:15:00.043925+00
3994	whatsapp_success_rate	100	{}	2025-10-16 14:15:00.044844+00
3995	whatsapp_success_rate	100	{}	2025-10-16 14:15:00.047503+00
3996	sla_violation	4	{}	2025-10-16 14:15:00.047711+00
3997	sla_violation	4	{}	2025-10-16 14:15:00.047701+00
3998	whatsapp_success_rate	100	{}	2025-10-16 14:15:00.049792+00
3999	sla_violation	4	{}	2025-10-16 14:15:00.052099+00
4000	sla_violation	4	{}	2025-10-16 14:15:00.052605+00
4001	memory_usage	18.675851821899414	{}	2025-10-16 14:20:00.017496+00
4002	memory_usage	18.675851821899414	{}	2025-10-16 14:20:00.017362+00
4004	memory_usage	18.682003021240234	{}	2025-10-16 14:20:00.018525+00
4003	memory_usage	18.675851821899414	{}	2025-10-16 14:20:00.018506+00
4005	disk_usage	7	{}	2025-10-16 14:20:00.024842+00
4006	disk_usage	7	{}	2025-10-16 14:20:00.025095+00
4007	disk_usage	7	{}	2025-10-16 14:20:00.026075+00
4008	disk_usage	7	{}	2025-10-16 14:20:00.026382+00
4009	whatsapp_success_rate	100	{}	2025-10-16 14:20:00.02789+00
4010	whatsapp_success_rate	100	{}	2025-10-16 14:20:00.028075+00
4011	whatsapp_success_rate	100	{}	2025-10-16 14:20:00.029234+00
4012	whatsapp_success_rate	100	{}	2025-10-16 14:20:00.029845+00
4013	sla_violation	4	{}	2025-10-16 14:20:00.030193+00
4014	sla_violation	4	{}	2025-10-16 14:20:00.030502+00
4015	sla_violation	4	{}	2025-10-16 14:20:00.031392+00
4016	sla_violation	4	{}	2025-10-16 14:20:00.0321+00
4017	memory_usage	18.669700622558594	{}	2025-10-16 14:25:00.017217+00
4018	memory_usage	18.669700622558594	{}	2025-10-16 14:25:00.017478+00
4019	memory_usage	18.684101104736328	{}	2025-10-16 14:25:00.018304+00
4020	memory_usage	18.677902221679688	{}	2025-10-16 14:25:00.019378+00
4021	disk_usage	7	{}	2025-10-16 14:25:00.02397+00
4022	disk_usage	7	{}	2025-10-16 14:25:00.025425+00
4023	disk_usage	7	{}	2025-10-16 14:25:00.025444+00
4024	disk_usage	7	{}	2025-10-16 14:25:00.025725+00
4025	whatsapp_success_rate	100	{}	2025-10-16 14:25:00.027359+00
4026	whatsapp_success_rate	100	{}	2025-10-16 14:25:00.027799+00
4027	whatsapp_success_rate	100	{}	2025-10-16 14:25:00.028351+00
4028	whatsapp_success_rate	100	{}	2025-10-16 14:25:00.028428+00
4029	sla_violation	4	{}	2025-10-16 14:25:00.029806+00
4030	sla_violation	4	{}	2025-10-16 14:25:00.029998+00
4031	sla_violation	4	{}	2025-10-16 14:25:00.030461+00
4032	sla_violation	4	{}	2025-10-16 14:25:00.030863+00
4033	memory_usage	18.69988441467285	{}	2025-10-16 14:30:00.025574+00
4034	memory_usage	18.70107650756836	{}	2025-10-16 14:30:00.02577+00
4035	memory_usage	18.7375545501709	{}	2025-10-16 14:30:00.030397+00
4036	disk_usage	7	{}	2025-10-16 14:30:00.033719+00
4037	disk_usage	7	{}	2025-10-16 14:30:00.035794+00
4038	whatsapp_success_rate	100	{}	2025-10-16 14:30:00.037677+00
4039	disk_usage	7	{}	2025-10-16 14:30:00.037947+00
4040	memory_usage	18.75739097595215	{}	2025-10-16 14:30:00.037796+00
4041	whatsapp_success_rate	100	{}	2025-10-16 14:30:00.041739+00
4042	sla_violation	4	{}	2025-10-16 14:30:00.042795+00
4043	whatsapp_success_rate	100	{}	2025-10-16 14:30:00.043311+00
4044	sla_violation	4	{}	2025-10-16 14:30:00.043992+00
4045	sla_violation	4	{}	2025-10-16 14:30:00.046689+00
4046	disk_usage	7	{}	2025-10-16 14:30:00.047215+00
4047	whatsapp_success_rate	100	{}	2025-10-16 14:30:00.049589+00
4048	sla_violation	4	{}	2025-10-16 14:30:00.052312+00
4049	memory_usage	18.686914443969727	{}	2025-10-16 14:35:00.017385+00
4050	memory_usage	18.675661087036133	{}	2025-10-16 14:35:00.018031+00
4051	memory_usage	18.68720054626465	{}	2025-10-16 14:35:00.02031+00
4052	disk_usage	7	{}	2025-10-16 14:35:00.024002+00
4053	disk_usage	7	{}	2025-10-16 14:35:00.024147+00
4054	disk_usage	7	{}	2025-10-16 14:35:00.026531+00
4056	whatsapp_success_rate	100	{}	2025-10-16 14:35:00.026845+00
4055	memory_usage	18.709754943847656	{}	2025-10-16 14:35:00.026224+00
4057	whatsapp_success_rate	100	{}	2025-10-16 14:35:00.027099+00
4058	whatsapp_success_rate	100	{}	2025-10-16 14:35:00.029135+00
4059	sla_violation	4	{}	2025-10-16 14:35:00.029386+00
4060	sla_violation	4	{}	2025-10-16 14:35:00.02965+00
4061	sla_violation	4	{}	2025-10-16 14:35:00.031522+00
4062	disk_usage	7	{}	2025-10-16 14:35:00.03213+00
4063	whatsapp_success_rate	100	{}	2025-10-16 14:35:00.034867+00
4064	sla_violation	4	{}	2025-10-16 14:35:00.037207+00
4065	memory_usage	18.69659423828125	{}	2025-10-16 14:40:00.01706+00
4066	memory_usage	18.697690963745117	{}	2025-10-16 14:40:00.018494+00
4067	memory_usage	18.698930740356445	{}	2025-10-16 14:40:00.018764+00
4068	memory_usage	18.714141845703125	{}	2025-10-16 14:40:00.022046+00
4069	disk_usage	7	{}	2025-10-16 14:40:00.02476+00
4070	disk_usage	7	{}	2025-10-16 14:40:00.024888+00
4071	disk_usage	7	{}	2025-10-16 14:40:00.025878+00
4072	whatsapp_success_rate	100	{}	2025-10-16 14:40:00.027393+00
4073	whatsapp_success_rate	100	{}	2025-10-16 14:40:00.028054+00
4074	whatsapp_success_rate	100	{}	2025-10-16 14:40:00.028636+00
4075	disk_usage	7	{}	2025-10-16 14:40:00.029505+00
4076	sla_violation	4	{}	2025-10-16 14:40:00.029662+00
4077	sla_violation	4	{}	2025-10-16 14:40:00.030285+00
4078	sla_violation	4	{}	2025-10-16 14:40:00.030708+00
4079	whatsapp_success_rate	100	{}	2025-10-16 14:40:00.031958+00
4080	sla_violation	4	{}	2025-10-16 14:40:00.034583+00
4081	memory_usage	18.734359741210938	{}	2025-10-16 14:45:00.027145+00
4082	memory_usage	18.734359741210938	{}	2025-10-16 14:45:00.029103+00
4083	memory_usage	18.782663345336914	{}	2025-10-16 14:45:00.032367+00
4084	disk_usage	7	{}	2025-10-16 14:45:00.035597+00
4085	disk_usage	7	{}	2025-10-16 14:45:00.037782+00
4086	whatsapp_success_rate	100	{}	2025-10-16 14:45:00.038461+00
4087	memory_usage	18.79563331604004	{}	2025-10-16 14:45:00.038501+00
4088	disk_usage	7	{}	2025-10-16 14:45:00.041105+00
4089	whatsapp_success_rate	100	{}	2025-10-16 14:45:00.041213+00
4090	sla_violation	4	{}	2025-10-16 14:45:00.04355+00
4091	sla_violation	4	{}	2025-10-16 14:45:00.045672+00
4092	disk_usage	7	{}	2025-10-16 14:45:00.046154+00
4093	whatsapp_success_rate	100	{}	2025-10-16 14:45:00.046633+00
4094	sla_violation	4	{}	2025-10-16 14:45:00.049093+00
4095	whatsapp_success_rate	100	{}	2025-10-16 14:45:00.050395+00
4096	sla_violation	4	{}	2025-10-16 14:45:00.052792+00
4097	memory_usage	18.7744140625	{}	2025-10-16 14:50:00.017595+00
4098	memory_usage	18.7744140625	{}	2025-10-16 14:50:00.018103+00
4099	memory_usage	18.7744140625	{}	2025-10-16 14:50:00.0183+00
4100	memory_usage	18.782711029052734	{}	2025-10-16 14:50:00.020107+00
4101	disk_usage	7	{}	2025-10-16 14:50:00.024644+00
4102	disk_usage	7	{}	2025-10-16 14:50:00.024768+00
4103	disk_usage	7	{}	2025-10-16 14:50:00.025241+00
4104	disk_usage	7	{}	2025-10-16 14:50:00.026647+00
4105	whatsapp_success_rate	100	{}	2025-10-16 14:50:00.027128+00
4106	whatsapp_success_rate	100	{}	2025-10-16 14:50:00.027375+00
4107	whatsapp_success_rate	100	{}	2025-10-16 14:50:00.027944+00
4108	whatsapp_success_rate	100	{}	2025-10-16 14:50:00.029233+00
4109	sla_violation	4	{}	2025-10-16 14:50:00.029349+00
4110	sla_violation	4	{}	2025-10-16 14:50:00.029725+00
4111	sla_violation	4	{}	2025-10-16 14:50:00.030182+00
4112	sla_violation	4	{}	2025-10-16 14:50:00.032014+00
4113	memory_usage	18.79448890686035	{}	2025-10-16 14:55:00.020448+00
4114	memory_usage	18.79448890686035	{}	2025-10-16 14:55:00.020445+00
4115	memory_usage	18.79448890686035	{}	2025-10-16 14:55:00.020638+00
4116	memory_usage	18.79448890686035	{}	2025-10-16 14:55:00.021762+00
4117	disk_usage	7	{}	2025-10-16 14:55:00.02714+00
4118	disk_usage	7	{}	2025-10-16 14:55:00.028234+00
4119	disk_usage	7	{}	2025-10-16 14:55:00.028256+00
4120	disk_usage	7	{}	2025-10-16 14:55:00.028751+00
4121	whatsapp_success_rate	100	{}	2025-10-16 14:55:00.030247+00
4122	whatsapp_success_rate	100	{}	2025-10-16 14:55:00.031359+00
4123	whatsapp_success_rate	100	{}	2025-10-16 14:55:00.031623+00
4124	whatsapp_success_rate	100	{}	2025-10-16 14:55:00.031684+00
4125	sla_violation	4	{}	2025-10-16 14:55:00.032577+00
4126	sla_violation	4	{}	2025-10-16 14:55:00.033632+00
4127	sla_violation	4	{}	2025-10-16 14:55:00.034103+00
4128	sla_violation	4	{}	2025-10-16 14:55:00.034181+00
4129	memory_usage	18.831348419189453	{}	2025-10-16 15:00:00.025984+00
4130	memory_usage	18.826818466186523	{}	2025-10-16 15:00:00.026403+00
4131	memory_usage	18.82338523864746	{}	2025-10-16 15:00:00.028775+00
4132	disk_usage	7	{}	2025-10-16 15:00:00.032764+00
4133	memory_usage	18.860578536987305	{}	2025-10-16 15:00:00.03371+00
4134	disk_usage	7	{}	2025-10-16 15:00:00.036642+00
4135	whatsapp_success_rate	100	{}	2025-10-16 15:00:00.037799+00
4136	disk_usage	7	{}	2025-10-16 15:00:00.037911+00
4137	whatsapp_success_rate	100	{}	2025-10-16 15:00:00.042338+00
4138	disk_usage	7	{}	2025-10-16 15:00:00.042561+00
4139	sla_violation	4	{}	2025-10-16 15:00:00.04281+00
4140	whatsapp_success_rate	100	{}	2025-10-16 15:00:00.043076+00
4141	sla_violation	4	{}	2025-10-16 15:00:00.044918+00
4142	sla_violation	4	{}	2025-10-16 15:00:00.045319+00
4143	whatsapp_success_rate	100	{}	2025-10-16 15:00:00.047546+00
4144	sla_violation	4	{}	2025-10-16 15:00:00.049798+00
4145	memory_usage	18.865299224853516	{}	2025-10-16 15:05:00.019065+00
4146	memory_usage	18.865299224853516	{}	2025-10-16 15:05:00.019502+00
4147	memory_usage	18.865299224853516	{}	2025-10-16 15:05:00.02053+00
4148	memory_usage	18.894577026367188	{}	2025-10-16 15:05:00.023366+00
4149	disk_usage	7	{}	2025-10-16 15:05:00.026888+00
4150	disk_usage	7	{}	2025-10-16 15:05:00.027444+00
4151	disk_usage	7	{}	2025-10-16 15:05:00.02779+00
4152	whatsapp_success_rate	100	{}	2025-10-16 15:05:00.029522+00
4154	whatsapp_success_rate	100	{}	2025-10-16 15:05:00.030109+00
4153	disk_usage	7	{}	2025-10-16 15:05:00.0301+00
4155	whatsapp_success_rate	100	{}	2025-10-16 15:05:00.030583+00
4156	sla_violation	4	{}	2025-10-16 15:05:00.033645+00
4157	sla_violation	4	{}	2025-10-16 15:05:00.033651+00
4158	sla_violation	4	{}	2025-10-16 15:05:00.03367+00
4159	whatsapp_success_rate	100	{}	2025-10-16 15:05:00.034037+00
4160	sla_violation	4	{}	2025-10-16 15:05:00.037571+00
4161	memory_usage	18.90869140625	{}	2025-10-16 15:10:00.018569+00
4162	memory_usage	18.90568733215332	{}	2025-10-16 15:10:00.019448+00
4164	memory_usage	18.91489028930664	{}	2025-10-16 15:10:00.019824+00
4163	memory_usage	18.90869140625	{}	2025-10-16 15:10:00.019527+00
4165	disk_usage	7	{}	2025-10-16 15:10:00.025697+00
4166	disk_usage	7	{}	2025-10-16 15:10:00.026093+00
4167	disk_usage	7	{}	2025-10-16 15:10:00.026399+00
4168	disk_usage	7	{}	2025-10-16 15:10:00.02649+00
4169	whatsapp_success_rate	100	{}	2025-10-16 15:10:00.028827+00
4170	whatsapp_success_rate	100	{}	2025-10-16 15:10:00.029017+00
4171	whatsapp_success_rate	100	{}	2025-10-16 15:10:00.029151+00
4172	whatsapp_success_rate	100	{}	2025-10-16 15:10:00.029156+00
4173	sla_violation	4	{}	2025-10-16 15:10:00.031114+00
4174	sla_violation	4	{}	2025-10-16 15:10:00.031538+00
4175	sla_violation	4	{}	2025-10-16 15:10:00.031771+00
4176	sla_violation	4	{}	2025-10-16 15:10:00.031852+00
4177	memory_usage	18.91312599182129	{}	2025-10-16 15:15:00.030583+00
4178	memory_usage	18.939590454101562	{}	2025-10-16 15:15:00.034423+00
4179	disk_usage	7	{}	2025-10-16 15:15:00.040209+00
4180	disk_usage	7	{}	2025-10-16 15:15:00.041658+00
4181	memory_usage	18.946218490600586	{}	2025-10-16 15:15:00.041892+00
4182	whatsapp_success_rate	100	{}	2025-10-16 15:15:00.043817+00
4183	whatsapp_success_rate	100	{}	2025-10-16 15:15:00.044487+00
4184	memory_usage	18.906497955322266	{}	2025-10-16 15:15:00.045189+00
4185	sla_violation	4	{}	2025-10-16 15:15:00.046773+00
4186	sla_violation	4	{}	2025-10-16 15:15:00.049629+00
4187	disk_usage	7	{}	2025-10-16 15:15:00.051482+00
4188	disk_usage	7	{}	2025-10-16 15:15:00.055461+00
4189	whatsapp_success_rate	100	{}	2025-10-16 15:15:00.056742+00
4190	whatsapp_success_rate	100	{}	2025-10-16 15:15:00.058233+00
4191	sla_violation	4	{}	2025-10-16 15:15:00.058897+00
4192	sla_violation	4	{}	2025-10-16 15:15:00.062204+00
4194	memory_usage	18.892812728881836	{}	2025-10-16 15:20:00.017862+00
4193	memory_usage	18.892812728881836	{}	2025-10-16 15:20:00.017873+00
4196	memory_usage	18.9023494720459	{}	2025-10-16 15:20:00.019702+00
4195	memory_usage	18.892812728881836	{}	2025-10-16 15:20:00.019516+00
4197	disk_usage	7	{}	2025-10-16 15:20:00.024365+00
4198	disk_usage	7	{}	2025-10-16 15:20:00.024751+00
4199	disk_usage	7	{}	2025-10-16 15:20:00.026286+00
4200	whatsapp_success_rate	100	{}	2025-10-16 15:20:00.026991+00
4201	whatsapp_success_rate	100	{}	2025-10-16 15:20:00.027433+00
4202	disk_usage	7	{}	2025-10-16 15:20:00.02762+00
4203	whatsapp_success_rate	100	{}	2025-10-16 15:20:00.028582+00
4204	sla_violation	4	{}	2025-10-16 15:20:00.029177+00
4205	sla_violation	4	{}	2025-10-16 15:20:00.029452+00
4206	sla_violation	4	{}	2025-10-16 15:20:00.03128+00
4207	whatsapp_success_rate	100	{}	2025-10-16 15:20:00.031322+00
4208	sla_violation	4	{}	2025-10-16 15:20:00.034207+00
4209	memory_usage	18.883562088012695	{}	2025-10-16 15:25:00.018485+00
4210	memory_usage	18.883562088012695	{}	2025-10-16 15:25:00.018842+00
4211	memory_usage	18.883991241455078	{}	2025-10-16 15:25:00.023391+00
4212	memory_usage	18.90583038330078	{}	2025-10-16 15:25:00.027709+00
4213	disk_usage	7	{}	2025-10-16 15:25:00.028603+00
4214	disk_usage	7	{}	2025-10-16 15:25:00.029461+00
4215	disk_usage	7	{}	2025-10-16 15:25:00.031684+00
4216	whatsapp_success_rate	100	{}	2025-10-16 15:25:00.032216+00
4217	whatsapp_success_rate	100	{}	2025-10-16 15:25:00.032454+00
4218	whatsapp_success_rate	100	{}	2025-10-16 15:25:00.034436+00
4219	sla_violation	4	{}	2025-10-16 15:25:00.034998+00
4220	sla_violation	4	{}	2025-10-16 15:25:00.034998+00
4221	sla_violation	4	{}	2025-10-16 15:25:00.037614+00
4222	disk_usage	7	{}	2025-10-16 15:25:00.03789+00
4223	whatsapp_success_rate	100	{}	2025-10-16 15:25:00.041547+00
4224	sla_violation	4	{}	2025-10-16 15:25:00.044112+00
4225	memory_usage	18.9267635345459	{}	2025-10-16 15:30:00.027251+00
4226	memory_usage	18.9267635345459	{}	2025-10-16 15:30:00.030493+00
4227	memory_usage	18.954896926879883	{}	2025-10-16 15:30:00.033179+00
4228	disk_usage	7	{}	2025-10-16 15:30:00.036953+00
4229	memory_usage	18.981313705444336	{}	2025-10-16 15:30:00.036865+00
4230	disk_usage	7	{}	2025-10-16 15:30:00.040347+00
4231	disk_usage	7	{}	2025-10-16 15:30:00.041912+00
4232	whatsapp_success_rate	100	{}	2025-10-16 15:30:00.04247+00
4233	whatsapp_success_rate	100	{}	2025-10-16 15:30:00.043275+00
4234	disk_usage	7	{}	2025-10-16 15:30:00.04573+00
4235	sla_violation	4	{}	2025-10-16 15:30:00.04782+00
4236	whatsapp_success_rate	100	{}	2025-10-16 15:30:00.048591+00
4237	sla_violation	4	{}	2025-10-16 15:30:00.049057+00
4238	whatsapp_success_rate	100	{}	2025-10-16 15:30:00.049708+00
4239	sla_violation	4	{}	2025-10-16 15:30:00.051037+00
4240	sla_violation	4	{}	2025-10-16 15:30:00.052015+00
4241	memory_usage	18.886804580688477	{}	2025-10-16 15:35:00.017231+00
4242	memory_usage	18.886804580688477	{}	2025-10-16 15:35:00.018108+00
4243	memory_usage	18.886804580688477	{}	2025-10-16 15:35:00.018723+00
4244	memory_usage	18.927717208862305	{}	2025-10-16 15:35:00.022239+00
4245	disk_usage	7	{}	2025-10-16 15:35:00.024886+00
4246	disk_usage	7	{}	2025-10-16 15:35:00.025251+00
4247	disk_usage	7	{}	2025-10-16 15:35:00.025723+00
4248	whatsapp_success_rate	100	{}	2025-10-16 15:35:00.027507+00
4249	whatsapp_success_rate	100	{}	2025-10-16 15:35:00.027684+00
4250	disk_usage	7	{}	2025-10-16 15:35:00.028046+00
4251	whatsapp_success_rate	100	{}	2025-10-16 15:35:00.02822+00
4252	sla_violation	4	{}	2025-10-16 15:35:00.02981+00
4253	sla_violation	4	{}	2025-10-16 15:35:00.030105+00
4254	sla_violation	4	{}	2025-10-16 15:35:00.03055+00
4255	whatsapp_success_rate	100	{}	2025-10-16 15:35:00.030709+00
4256	sla_violation	4	{}	2025-10-16 15:35:00.033052+00
4257	memory_usage	18.891096115112305	{}	2025-10-16 15:40:00.017494+00
4259	memory_usage	18.891096115112305	{}	2025-10-16 15:40:00.01807+00
4258	memory_usage	18.897247314453125	{}	2025-10-16 15:40:00.018171+00
4260	memory_usage	18.937206268310547	{}	2025-10-16 15:40:00.022654+00
4261	disk_usage	7	{}	2025-10-16 15:40:00.024681+00
4262	disk_usage	7	{}	2025-10-16 15:40:00.024791+00
4263	disk_usage	7	{}	2025-10-16 15:40:00.025099+00
4264	whatsapp_success_rate	100	{}	2025-10-16 15:40:00.027382+00
4265	whatsapp_success_rate	100	{}	2025-10-16 15:40:00.027726+00
4266	whatsapp_success_rate	100	{}	2025-10-16 15:40:00.027729+00
4267	disk_usage	7	{}	2025-10-16 15:40:00.028444+00
4268	sla_violation	4	{}	2025-10-16 15:40:00.030403+00
4269	sla_violation	4	{}	2025-10-16 15:40:00.031107+00
4270	sla_violation	4	{}	2025-10-16 15:40:00.03112+00
4271	whatsapp_success_rate	100	{}	2025-10-16 15:40:00.032172+00
4272	sla_violation	4	{}	2025-10-16 15:40:00.034435+00
4273	memory_usage	18.90406608581543	{}	2025-10-16 15:45:00.028105+00
4274	memory_usage	18.920040130615234	{}	2025-10-16 15:45:00.029012+00
4275	memory_usage	18.90392303466797	{}	2025-10-16 15:45:00.031054+00
4276	disk_usage	7	{}	2025-10-16 15:45:00.037012+00
4277	memory_usage	18.959808349609375	{}	2025-10-16 15:45:00.038399+00
4278	disk_usage	7	{}	2025-10-16 15:45:00.0397+00
4279	disk_usage	7	{}	2025-10-16 15:45:00.042615+00
4280	whatsapp_success_rate	100	{}	2025-10-16 15:45:00.043232+00
4281	whatsapp_success_rate	100	{}	2025-10-16 15:45:00.043808+00
4282	disk_usage	7	{}	2025-10-16 15:45:00.044992+00
4283	whatsapp_success_rate	100	{}	2025-10-16 15:45:00.045121+00
4284	sla_violation	4	{}	2025-10-16 15:45:00.04601+00
4285	sla_violation	4	{}	2025-10-16 15:45:00.046349+00
4286	whatsapp_success_rate	100	{}	2025-10-16 15:45:00.048753+00
4287	sla_violation	4	{}	2025-10-16 15:45:00.049516+00
4288	sla_violation	4	{}	2025-10-16 15:45:00.051969+00
4289	memory_usage	18.92561912536621	{}	2025-10-16 15:50:00.017994+00
4290	memory_usage	18.92561912536621	{}	2025-10-16 15:50:00.018229+00
4291	memory_usage	18.950986862182617	{}	2025-10-16 15:50:00.023592+00
4292	memory_usage	18.950986862182617	{}	2025-10-16 15:50:00.024519+00
4293	disk_usage	7	{}	2025-10-16 15:50:00.02617+00
4294	disk_usage	7	{}	2025-10-16 15:50:00.026709+00
4295	whatsapp_success_rate	100	{}	2025-10-16 15:50:00.029398+00
4296	whatsapp_success_rate	100	{}	2025-10-16 15:50:00.029458+00
4297	disk_usage	7	{}	2025-10-16 15:50:00.031222+00
4298	disk_usage	7	{}	2025-10-16 15:50:00.031395+00
4299	sla_violation	4	{}	2025-10-16 15:50:00.032151+00
4300	sla_violation	4	{}	2025-10-16 15:50:00.032505+00
4301	whatsapp_success_rate	100	{}	2025-10-16 15:50:00.033511+00
4302	whatsapp_success_rate	100	{}	2025-10-16 15:50:00.034059+00
4303	sla_violation	4	{}	2025-10-16 15:50:00.035742+00
4304	sla_violation	4	{}	2025-10-16 15:50:00.036269+00
4305	memory_usage	18.893861770629883	{}	2025-10-16 15:55:00.01892+00
4306	memory_usage	18.893861770629883	{}	2025-10-16 15:55:00.019106+00
4307	memory_usage	18.893861770629883	{}	2025-10-16 15:55:00.019212+00
4308	memory_usage	18.925046920776367	{}	2025-10-16 15:55:00.024768+00
4309	disk_usage	7	{}	2025-10-16 15:55:00.026115+00
4310	disk_usage	7	{}	2025-10-16 15:55:00.026386+00
4311	disk_usage	7	{}	2025-10-16 15:55:00.026578+00
4312	whatsapp_success_rate	100	{}	2025-10-16 15:55:00.028736+00
4313	whatsapp_success_rate	100	{}	2025-10-16 15:55:00.028956+00
4314	whatsapp_success_rate	100	{}	2025-10-16 15:55:00.029224+00
4315	disk_usage	7	{}	2025-10-16 15:55:00.03089+00
4316	sla_violation	4	{}	2025-10-16 15:55:00.030963+00
4317	sla_violation	4	{}	2025-10-16 15:55:00.031289+00
4318	sla_violation	4	{}	2025-10-16 15:55:00.032246+00
4319	whatsapp_success_rate	100	{}	2025-10-16 15:55:00.033237+00
4320	sla_violation	4	{}	2025-10-16 15:55:00.035534+00
4321	memory_usage	18.922805786132812	{}	2025-10-16 16:00:00.025478+00
4322	memory_usage	18.922805786132812	{}	2025-10-16 16:00:00.026656+00
4323	memory_usage	18.918323516845703	{}	2025-10-16 16:00:00.030909+00
4324	memory_usage	18.918371200561523	{}	2025-10-16 16:00:00.032684+00
4325	disk_usage	7	{}	2025-10-16 16:00:00.034146+00
4326	disk_usage	7	{}	2025-10-16 16:00:00.034631+00
4327	whatsapp_success_rate	100	{}	2025-10-16 16:00:00.037398+00
4328	whatsapp_success_rate	100	{}	2025-10-16 16:00:00.037601+00
4329	disk_usage	7	{}	2025-10-16 16:00:00.040411+00
4330	disk_usage	7	{}	2025-10-16 16:00:00.040678+00
4331	sla_violation	4	{}	2025-10-16 16:00:00.041483+00
4332	sla_violation	4	{}	2025-10-16 16:00:00.041909+00
4333	whatsapp_success_rate	100	{}	2025-10-16 16:00:00.04456+00
4334	whatsapp_success_rate	100	{}	2025-10-16 16:00:00.044633+00
4335	sla_violation	4	{}	2025-10-16 16:00:00.048663+00
4336	sla_violation	4	{}	2025-10-16 16:00:00.048896+00
4337	memory_usage	18.906545639038086	{}	2025-10-16 16:05:00.017925+00
4338	memory_usage	18.906545639038086	{}	2025-10-16 16:05:00.01822+00
4339	memory_usage	18.906545639038086	{}	2025-10-16 16:05:00.018021+00
4340	memory_usage	18.909597396850586	{}	2025-10-16 16:05:00.019925+00
4341	disk_usage	7	{}	2025-10-16 16:05:00.02515+00
4342	disk_usage	7	{}	2025-10-16 16:05:00.025529+00
4343	disk_usage	7	{}	2025-10-16 16:05:00.025665+00
4344	disk_usage	7	{}	2025-10-16 16:05:00.026034+00
4345	whatsapp_success_rate	100	{}	2025-10-16 16:05:00.027784+00
4346	whatsapp_success_rate	100	{}	2025-10-16 16:05:00.028317+00
4347	whatsapp_success_rate	100	{}	2025-10-16 16:05:00.028628+00
4348	whatsapp_success_rate	100	{}	2025-10-16 16:05:00.028638+00
4349	sla_violation	4	{}	2025-10-16 16:05:00.02999+00
4350	sla_violation	4	{}	2025-10-16 16:05:00.030569+00
4351	sla_violation	4	{}	2025-10-16 16:05:00.030925+00
4352	sla_violation	4	{}	2025-10-16 16:05:00.031089+00
4353	memory_usage	18.916654586791992	{}	2025-10-16 16:10:00.017119+00
4354	memory_usage	18.916654586791992	{}	2025-10-16 16:10:00.017841+00
4355	memory_usage	18.921804428100586	{}	2025-10-16 16:10:00.0186+00
4356	memory_usage	18.949317932128906	{}	2025-10-16 16:10:00.022048+00
4357	disk_usage	7	{}	2025-10-16 16:10:00.024493+00
4358	disk_usage	7	{}	2025-10-16 16:10:00.024708+00
4359	disk_usage	7	{}	2025-10-16 16:10:00.025594+00
4360	whatsapp_success_rate	100	{}	2025-10-16 16:10:00.02702+00
4361	whatsapp_success_rate	100	{}	2025-10-16 16:10:00.027266+00
4362	whatsapp_success_rate	100	{}	2025-10-16 16:10:00.027754+00
4363	disk_usage	7	{}	2025-10-16 16:10:00.028163+00
4364	sla_violation	4	{}	2025-10-16 16:10:00.029212+00
4365	sla_violation	4	{}	2025-10-16 16:10:00.030462+00
4366	sla_violation	4	{}	2025-10-16 16:10:00.032123+00
4367	whatsapp_success_rate	100	{}	2025-10-16 16:10:00.032422+00
4368	sla_violation	4	{}	2025-10-16 16:10:00.034919+00
4369	memory_usage	19.028377532958984	{}	2025-10-16 16:15:00.015432+00
4370	memory_usage	19.02928352355957	{}	2025-10-16 16:15:00.015792+00
4371	disk_usage	7	{}	2025-10-16 16:15:00.023301+00
4372	disk_usage	7	{}	2025-10-16 16:15:00.023513+00
4373	whatsapp_success_rate	100	{}	2025-10-16 16:15:00.02681+00
4374	whatsapp_success_rate	100	{}	2025-10-16 16:15:00.029+00
4375	memory_usage	19.030094146728516	{}	2025-10-16 16:15:00.029117+00
4376	sla_violation	4	{}	2025-10-16 16:15:00.030968+00
4377	sla_violation	4	{}	2025-10-16 16:15:00.033621+00
4378	memory_usage	19.073152542114258	{}	2025-10-16 16:15:00.033651+00
4379	disk_usage	7	{}	2025-10-16 16:15:00.035317+00
4380	whatsapp_success_rate	100	{}	2025-10-16 16:15:00.037936+00
4381	sla_violation	4	{}	2025-10-16 16:15:00.04042+00
4382	disk_usage	7	{}	2025-10-16 16:15:00.041284+00
4383	whatsapp_success_rate	100	{}	2025-10-16 16:15:00.043809+00
4384	sla_violation	4	{}	2025-10-16 16:15:00.048547+00
4385	memory_usage	18.955469131469727	{}	2025-10-16 16:20:00.016738+00
4387	memory_usage	18.955469131469727	{}	2025-10-16 16:20:00.016744+00
4386	memory_usage	18.951034545898438	{}	2025-10-16 16:20:00.016829+00
4388	memory_usage	18.9633846282959	{}	2025-10-16 16:20:00.018213+00
4389	disk_usage	7	{}	2025-10-16 16:20:00.023783+00
4390	disk_usage	7	{}	2025-10-16 16:20:00.02395+00
4391	disk_usage	7	{}	2025-10-16 16:20:00.024492+00
4392	disk_usage	7	{}	2025-10-16 16:20:00.025099+00
4393	whatsapp_success_rate	100	{}	2025-10-16 16:20:00.02677+00
4394	whatsapp_success_rate	100	{}	2025-10-16 16:20:00.026999+00
4395	whatsapp_success_rate	100	{}	2025-10-16 16:20:00.027023+00
4396	whatsapp_success_rate	100	{}	2025-10-16 16:20:00.027864+00
4397	sla_violation	4	{}	2025-10-16 16:20:00.029195+00
4398	sla_violation	4	{}	2025-10-16 16:20:00.029654+00
4399	sla_violation	4	{}	2025-10-16 16:20:00.029661+00
4400	sla_violation	4	{}	2025-10-16 16:20:00.030109+00
4401	memory_usage	18.97411346435547	{}	2025-10-16 16:25:00.017277+00
4402	memory_usage	18.97411346435547	{}	2025-10-16 16:25:00.017689+00
4403	memory_usage	18.97411346435547	{}	2025-10-16 16:25:00.018019+00
4404	memory_usage	18.97411346435547	{}	2025-10-16 16:25:00.020163+00
4405	disk_usage	7	{}	2025-10-16 16:25:00.024621+00
4406	disk_usage	7	{}	2025-10-16 16:25:00.025401+00
4407	disk_usage	7	{}	2025-10-16 16:25:00.025595+00
4408	disk_usage	7	{}	2025-10-16 16:25:00.026454+00
4409	whatsapp_success_rate	100	{}	2025-10-16 16:25:00.027267+00
4410	whatsapp_success_rate	100	{}	2025-10-16 16:25:00.027693+00
4411	whatsapp_success_rate	100	{}	2025-10-16 16:25:00.028152+00
4412	whatsapp_success_rate	100	{}	2025-10-16 16:25:00.029067+00
4413	sla_violation	4	{}	2025-10-16 16:25:00.029492+00
4414	sla_violation	4	{}	2025-10-16 16:25:00.031588+00
4415	sla_violation	4	{}	2025-10-16 16:25:00.032957+00
4416	sla_violation	4	{}	2025-10-16 16:25:00.033524+00
4417	memory_usage	18.975830078125	{}	2025-10-16 16:30:00.027156+00
4418	memory_usage	18.97721290588379	{}	2025-10-16 16:30:00.028699+00
4419	memory_usage	18.973112106323242	{}	2025-10-16 16:30:00.031681+00
4420	memory_usage	19.00796890258789	{}	2025-10-16 16:30:00.032659+00
4421	disk_usage	7	{}	2025-10-16 16:30:00.034944+00
4422	disk_usage	7	{}	2025-10-16 16:30:00.035818+00
4423	disk_usage	7	{}	2025-10-16 16:30:00.038701+00
4424	whatsapp_success_rate	100	{}	2025-10-16 16:30:00.04082+00
4425	whatsapp_success_rate	100	{}	2025-10-16 16:30:00.041578+00
4426	whatsapp_success_rate	100	{}	2025-10-16 16:30:00.042301+00
4427	disk_usage	7	{}	2025-10-16 16:30:00.042704+00
4428	sla_violation	4	{}	2025-10-16 16:30:00.044189+00
4429	sla_violation	4	{}	2025-10-16 16:30:00.045471+00
4430	sla_violation	4	{}	2025-10-16 16:30:00.046632+00
4431	whatsapp_success_rate	100	{}	2025-10-16 16:30:00.047277+00
4432	sla_violation	4	{}	2025-10-16 16:30:00.049406+00
4433	memory_usage	18.950605392456055	{}	2025-10-16 16:35:00.017646+00
4434	memory_usage	18.950605392456055	{}	2025-10-16 16:35:00.018427+00
4435	memory_usage	18.950605392456055	{}	2025-10-16 16:35:00.019173+00
4436	memory_usage	18.950605392456055	{}	2025-10-16 16:35:00.020046+00
4438	disk_usage	7	{}	2025-10-16 16:35:00.025853+00
4439	disk_usage	7	{}	2025-10-16 16:35:00.026371+00
4440	disk_usage	7	{}	2025-10-16 16:35:00.026576+00
4442	whatsapp_success_rate	100	{}	2025-10-16 16:35:00.029136+00
4443	whatsapp_success_rate	100	{}	2025-10-16 16:35:00.03008+00
4445	whatsapp_success_rate	100	{}	2025-10-16 16:35:00.030937+00
4446	sla_violation	4	{}	2025-10-16 16:35:00.032395+00
4447	sla_violation	4	{}	2025-10-16 16:35:00.033269+00
4448	sla_violation	4	{}	2025-10-16 16:35:00.03359+00
4657	memory_usage	19.015884399414062	{}	2025-10-16 17:45:00.029177+00
4661	disk_usage	7	{}	2025-10-16 17:45:00.035969+00
4664	whatsapp_success_rate	100	{}	2025-10-16 17:45:00.039079+00
4666	sla_violation	4	{}	2025-10-16 17:45:00.041936+00
4676	memory_usage	19.04129981994629	{}	2025-10-16 17:50:00.022176+00
4682	disk_usage	7	{}	2025-10-16 17:50:00.028711+00
4684	whatsapp_success_rate	100	{}	2025-10-16 17:50:00.031204+00
4688	sla_violation	4	{}	2025-10-16 17:50:00.034095+00
4707	memory_usage	19.161224365234375	{}	2025-10-16 18:00:00.029716+00
4712	disk_usage	7	{}	2025-10-16 18:00:00.037943+00
4714	whatsapp_success_rate	100	{}	2025-10-16 18:00:00.040701+00
4717	sla_violation	4	{}	2025-10-16 18:00:00.04412+00
4738	memory_usage	19.348621368408203	{}	2025-10-16 18:10:00.020041+00
4742	disk_usage	7	{}	2025-10-16 18:10:00.027394+00
4746	whatsapp_success_rate	100	{}	2025-10-16 18:10:00.030578+00
4750	sla_violation	4	{}	2025-10-16 18:10:00.032739+00
4769	memory_usage	19.37699317932129	{}	2025-10-16 18:20:00.017068+00
4775	disk_usage	7	{}	2025-10-16 18:20:00.024972+00
4777	whatsapp_success_rate	100	{}	2025-10-16 18:20:00.0277+00
4780	sla_violation	4	{}	2025-10-16 18:20:00.02971+00
4791	memory_usage	19.40135955810547	{}	2025-10-16 18:25:00.025769+00
4798	disk_usage	7	{}	2025-10-16 18:25:00.032512+00
4799	whatsapp_success_rate	100	{}	2025-10-16 18:25:00.035348+00
4800	sla_violation	4	{}	2025-10-16 18:25:00.038367+00
4819	memory_usage	19.362401962280273	{}	2025-10-16 18:35:00.018832+00
4823	disk_usage	7	{}	2025-10-16 18:35:00.025171+00
4826	whatsapp_success_rate	100	{}	2025-10-16 18:35:00.028041+00
4829	sla_violation	4	{}	2025-10-16 18:35:00.030274+00
4850	memory_usage	19.36941146850586	{}	2025-10-16 18:45:00.029399+00
4854	disk_usage	7	{}	2025-10-16 18:45:00.036227+00
4856	whatsapp_success_rate	100	{}	2025-10-16 18:45:00.038816+00
4861	sla_violation	4	{}	2025-10-16 18:45:00.041945+00
4881	memory_usage	19.403076171875	{}	2025-10-16 18:55:00.017725+00
4885	disk_usage	7	{}	2025-10-16 18:55:00.024542+00
4889	whatsapp_success_rate	100	{}	2025-10-16 18:55:00.027985+00
4893	sla_violation	4	{}	2025-10-16 18:55:00.030512+00
4899	memory_usage	19.397878646850586	{}	2025-10-16 19:00:00.045449+00
4903	disk_usage	7	{}	2025-10-16 19:00:00.052154+00
4905	whatsapp_success_rate	100	{}	2025-10-16 19:00:00.054859+00
4909	sla_violation	4	{}	2025-10-16 19:00:00.057515+00
4929	memory_usage	19.439363479614258	{}	2025-10-16 19:10:00.017471+00
4933	disk_usage	7	{}	2025-10-16 19:10:00.024832+00
4936	whatsapp_success_rate	100	{}	2025-10-16 19:10:00.027574+00
4939	sla_violation	4	{}	2025-10-16 19:10:00.030158+00
4947	memory_usage	19.408798217773438	{}	2025-10-16 19:15:00.027828+00
4951	disk_usage	7	{}	2025-10-16 19:15:00.036+00
4955	whatsapp_success_rate	100	{}	2025-10-16 19:15:00.038903+00
4959	sla_violation	4	{}	2025-10-16 19:15:00.041437+00
4977	memory_usage	19.39229965209961	{}	2025-10-16 19:25:00.01757+00
4981	disk_usage	7	{}	2025-10-16 19:25:00.024536+00
4985	whatsapp_success_rate	100	{}	2025-10-16 19:25:00.02707+00
4989	sla_violation	4	{}	2025-10-16 19:25:00.029221+00
4995	memory_usage	19.3911075592041	{}	2025-10-16 19:30:00.029064+00
5002	disk_usage	7	{}	2025-10-16 19:30:00.03824+00
5007	whatsapp_success_rate	100	{}	2025-10-16 19:30:00.041859+00
5008	sla_violation	4	{}	2025-10-16 19:30:00.044583+00
5026	memory_usage	19.378662109375	{}	2025-10-16 19:40:00.017332+00
5030	disk_usage	7	{}	2025-10-16 19:40:00.026226+00
5034	whatsapp_success_rate	100	{}	2025-10-16 19:40:00.028771+00
5038	sla_violation	4	{}	2025-10-16 19:40:00.03121+00
5043	memory_usage	19.374465942382812	{}	2025-10-16 19:45:00.031701+00
5046	disk_usage	7	{}	2025-10-16 19:45:00.038364+00
5050	whatsapp_success_rate	100	{}	2025-10-16 19:45:00.041004+00
5052	sla_violation	4	{}	2025-10-16 19:45:00.043265+00
5073	memory_usage	19.346284866333008	{}	2025-10-16 19:55:00.019309+00
5075	disk_usage	7	{}	2025-10-16 19:55:00.027023+00
5079	whatsapp_success_rate	100	{}	2025-10-16 19:55:00.030064+00
5081	sla_violation	4	{}	2025-10-16 19:55:00.033246+00
5091	memory_usage	19.35582160949707	{}	2025-10-16 20:00:00.028291+00
5095	disk_usage	7	{}	2025-10-16 20:00:00.038153+00
5100	whatsapp_success_rate	100	{}	2025-10-16 20:00:00.042347+00
5103	sla_violation	4	{}	2025-10-16 20:00:00.045382+00
5121	memory_usage	19.332122802734375	{}	2025-10-16 20:10:00.018782+00
5126	disk_usage	7	{}	2025-10-16 20:10:00.027097+00
5129	whatsapp_success_rate	100	{}	2025-10-16 20:10:00.029544+00
5133	sla_violation	4	{}	2025-10-16 20:10:00.031917+00
5139	memory_usage	19.373226165771484	{}	2025-10-16 20:15:00.029239+00
5142	disk_usage	7	{}	2025-10-16 20:15:00.037127+00
5145	whatsapp_success_rate	100	{}	2025-10-16 20:15:00.040121+00
5149	sla_violation	4	{}	2025-10-16 20:15:00.043217+00
5169	memory_usage	19.380521774291992	{}	2025-10-16 20:25:00.01714+00
5173	disk_usage	7	{}	2025-10-16 20:25:00.024186+00
5177	whatsapp_success_rate	100	{}	2025-10-16 20:25:00.026834+00
5181	sla_violation	4	{}	2025-10-16 20:25:00.029064+00
5187	memory_usage	19.402647018432617	{}	2025-10-16 20:30:00.029916+00
5192	disk_usage	7	{}	2025-10-16 20:30:00.038833+00
5195	whatsapp_success_rate	100	{}	2025-10-16 20:30:00.043109+00
5198	sla_violation	4	{}	2025-10-16 20:30:00.045431+00
5217	memory_usage	19.38338279724121	{}	2025-10-16 20:40:00.018072+00
5220	disk_usage	7	{}	2025-10-16 20:40:00.026379+00
5224	whatsapp_success_rate	100	{}	2025-10-16 20:40:00.029579+00
5227	sla_violation	4	{}	2025-10-16 20:40:00.031752+00
5235	memory_usage	19.39873695373535	{}	2025-10-16 20:45:00.030085+00
5239	disk_usage	7	{}	2025-10-16 20:45:00.036972+00
5242	whatsapp_success_rate	100	{}	2025-10-16 20:45:00.041846+00
5246	sla_violation	4	{}	2025-10-16 20:45:00.044828+00
5265	memory_usage	19.361591339111328	{}	2025-10-16 20:55:00.018899+00
5270	disk_usage	7	{}	2025-10-16 20:55:00.026945+00
5272	whatsapp_success_rate	100	{}	2025-10-16 20:55:00.029819+00
5276	sla_violation	4	{}	2025-10-16 20:55:00.032516+00
5282	memory_usage	19.40298080444336	{}	2025-10-16 21:00:00.027536+00
4437	disk_usage	7	{}	2025-10-16 16:35:00.025052+00
4441	whatsapp_success_rate	100	{}	2025-10-16 16:35:00.028174+00
4444	sla_violation	4	{}	2025-10-16 16:35:00.030584+00
4449	memory_usage	18.938827514648438	{}	2025-10-16 16:40:00.017306+00
4450	memory_usage	18.938827514648438	{}	2025-10-16 16:40:00.017713+00
4451	memory_usage	18.926668167114258	{}	2025-10-16 16:40:00.018463+00
4452	memory_usage	18.967723846435547	{}	2025-10-16 16:40:00.024185+00
4453	disk_usage	7	{}	2025-10-16 16:40:00.025757+00
4454	disk_usage	7	{}	2025-10-16 16:40:00.026105+00
4455	disk_usage	7	{}	2025-10-16 16:40:00.026219+00
4456	whatsapp_success_rate	100	{}	2025-10-16 16:40:00.028924+00
4457	whatsapp_success_rate	100	{}	2025-10-16 16:40:00.029154+00
4458	whatsapp_success_rate	100	{}	2025-10-16 16:40:00.029261+00
4459	disk_usage	7	{}	2025-10-16 16:40:00.030655+00
4460	sla_violation	4	{}	2025-10-16 16:40:00.031227+00
4461	sla_violation	4	{}	2025-10-16 16:40:00.031777+00
4462	sla_violation	4	{}	2025-10-16 16:40:00.031908+00
4463	whatsapp_success_rate	100	{}	2025-10-16 16:40:00.033246+00
4464	sla_violation	4	{}	2025-10-16 16:40:00.036042+00
4465	memory_usage	18.92876625061035	{}	2025-10-16 16:45:00.027039+00
4466	memory_usage	18.931913375854492	{}	2025-10-16 16:45:00.027393+00
4467	memory_usage	18.93291473388672	{}	2025-10-16 16:45:00.031021+00
4468	disk_usage	7	{}	2025-10-16 16:45:00.036982+00
4469	disk_usage	7	{}	2025-10-16 16:45:00.03703+00
4470	disk_usage	7	{}	2025-10-16 16:45:00.038547+00
4471	whatsapp_success_rate	100	{}	2025-10-16 16:45:00.041106+00
4472	whatsapp_success_rate	100	{}	2025-10-16 16:45:00.041394+00
4473	memory_usage	19.00796890258789	{}	2025-10-16 16:45:00.041168+00
4474	whatsapp_success_rate	100	{}	2025-10-16 16:45:00.043244+00
4475	sla_violation	4	{}	2025-10-16 16:45:00.044065+00
4476	sla_violation	4	{}	2025-10-16 16:45:00.046007+00
4477	sla_violation	4	{}	2025-10-16 16:45:00.046956+00
4478	disk_usage	7	{}	2025-10-16 16:45:00.048199+00
4479	whatsapp_success_rate	100	{}	2025-10-16 16:45:00.052407+00
4480	sla_violation	4	{}	2025-10-16 16:45:00.054469+00
4481	memory_usage	18.966007232666016	{}	2025-10-16 16:50:00.017991+00
4482	memory_usage	18.966007232666016	{}	2025-10-16 16:50:00.01826+00
4483	memory_usage	18.967247009277344	{}	2025-10-16 16:50:00.018423+00
4484	memory_usage	18.966007232666016	{}	2025-10-16 16:50:00.019654+00
4485	disk_usage	7	{}	2025-10-16 16:50:00.025591+00
4486	disk_usage	7	{}	2025-10-16 16:50:00.025648+00
4487	disk_usage	7	{}	2025-10-16 16:50:00.02592+00
4488	disk_usage	7	{}	2025-10-16 16:50:00.025931+00
4489	whatsapp_success_rate	100	{}	2025-10-16 16:50:00.029131+00
4490	whatsapp_success_rate	100	{}	2025-10-16 16:50:00.029133+00
4491	whatsapp_success_rate	100	{}	2025-10-16 16:50:00.029133+00
4492	whatsapp_success_rate	100	{}	2025-10-16 16:50:00.029237+00
4493	sla_violation	4	{}	2025-10-16 16:50:00.031304+00
4494	sla_violation	4	{}	2025-10-16 16:50:00.031882+00
4495	sla_violation	4	{}	2025-10-16 16:50:00.032028+00
4496	sla_violation	4	{}	2025-10-16 16:50:00.032055+00
4497	memory_usage	18.93448829650879	{}	2025-10-16 16:55:00.019854+00
4498	memory_usage	18.93153190612793	{}	2025-10-16 16:55:00.019772+00
4499	memory_usage	18.93153190612793	{}	2025-10-16 16:55:00.019715+00
4500	memory_usage	18.96510124206543	{}	2025-10-16 16:55:00.024428+00
4501	disk_usage	7	{}	2025-10-16 16:55:00.02664+00
4502	disk_usage	7	{}	2025-10-16 16:55:00.026873+00
4503	disk_usage	7	{}	2025-10-16 16:55:00.027038+00
4504	whatsapp_success_rate	100	{}	2025-10-16 16:55:00.029176+00
4505	whatsapp_success_rate	100	{}	2025-10-16 16:55:00.02942+00
4506	whatsapp_success_rate	100	{}	2025-10-16 16:55:00.030134+00
4507	disk_usage	7	{}	2025-10-16 16:55:00.03036+00
4508	sla_violation	4	{}	2025-10-16 16:55:00.031441+00
4509	sla_violation	4	{}	2025-10-16 16:55:00.03184+00
4510	sla_violation	4	{}	2025-10-16 16:55:00.03266+00
4511	whatsapp_success_rate	100	{}	2025-10-16 16:55:00.033125+00
4512	sla_violation	4	{}	2025-10-16 16:55:00.036106+00
4513	memory_usage	19.063234329223633	{}	2025-10-16 17:00:00.031715+00
4514	memory_usage	19.053268432617188	{}	2025-10-16 17:00:00.034779+00
4515	memory_usage	19.053268432617188	{}	2025-10-16 17:00:00.036589+00
4516	memory_usage	19.103097915649414	{}	2025-10-16 17:00:00.037399+00
4517	disk_usage	7	{}	2025-10-16 17:00:00.039423+00
4518	whatsapp_success_rate	100	{}	2025-10-16 17:00:00.042731+00
4519	disk_usage	7	{}	2025-10-16 17:00:00.043593+00
4520	disk_usage	7	{}	2025-10-16 17:00:00.043834+00
4521	disk_usage	7	{}	2025-10-16 17:00:00.04624+00
4522	sla_violation	4	{}	2025-10-16 17:00:00.046896+00
4523	whatsapp_success_rate	100	{}	2025-10-16 17:00:00.047213+00
4524	whatsapp_success_rate	100	{}	2025-10-16 17:00:00.048573+00
4525	whatsapp_success_rate	100	{}	2025-10-16 17:00:00.049508+00
4526	sla_violation	4	{}	2025-10-16 17:00:00.050076+00
4527	sla_violation	4	{}	2025-10-16 17:00:00.051237+00
4528	sla_violation	4	{}	2025-10-16 17:00:00.054526+00
4529	memory_usage	19.072294235229492	{}	2025-10-16 17:05:00.018131+00
4530	memory_usage	19.072294235229492	{}	2025-10-16 17:05:00.018093+00
4531	memory_usage	19.072294235229492	{}	2025-10-16 17:05:00.019515+00
4532	memory_usage	19.072294235229492	{}	2025-10-16 17:05:00.020009+00
4533	disk_usage	7	{}	2025-10-16 17:05:00.025793+00
4534	disk_usage	7	{}	2025-10-16 17:05:00.025843+00
4535	disk_usage	7	{}	2025-10-16 17:05:00.02612+00
4536	disk_usage	7	{}	2025-10-16 17:05:00.026304+00
4537	whatsapp_success_rate	100	{}	2025-10-16 17:05:00.028768+00
4538	whatsapp_success_rate	100	{}	2025-10-16 17:05:00.028789+00
4539	whatsapp_success_rate	100	{}	2025-10-16 17:05:00.029077+00
4540	whatsapp_success_rate	100	{}	2025-10-16 17:05:00.029158+00
4541	sla_violation	4	{}	2025-10-16 17:05:00.030928+00
4542	sla_violation	4	{}	2025-10-16 17:05:00.031533+00
4543	sla_violation	4	{}	2025-10-16 17:05:00.031704+00
4544	sla_violation	4	{}	2025-10-16 17:05:00.031757+00
4545	memory_usage	19.050121307373047	{}	2025-10-16 17:10:00.017477+00
4546	memory_usage	19.050121307373047	{}	2025-10-16 17:10:00.017418+00
4547	memory_usage	19.050121307373047	{}	2025-10-16 17:10:00.019189+00
4548	memory_usage	19.050121307373047	{}	2025-10-16 17:10:00.019584+00
4549	disk_usage	7	{}	2025-10-16 17:10:00.024288+00
4550	disk_usage	7	{}	2025-10-16 17:10:00.02463+00
4551	disk_usage	7	{}	2025-10-16 17:10:00.024868+00
4552	disk_usage	7	{}	2025-10-16 17:10:00.025584+00
4553	whatsapp_success_rate	100	{}	2025-10-16 17:10:00.02672+00
4554	whatsapp_success_rate	100	{}	2025-10-16 17:10:00.026982+00
4555	whatsapp_success_rate	100	{}	2025-10-16 17:10:00.027456+00
4556	whatsapp_success_rate	100	{}	2025-10-16 17:10:00.02819+00
4557	sla_violation	4	{}	2025-10-16 17:10:00.028886+00
4558	sla_violation	4	{}	2025-10-16 17:10:00.0292+00
4559	sla_violation	4	{}	2025-10-16 17:10:00.029583+00
4658	memory_usage	19.037342071533203	{}	2025-10-16 17:45:00.030509+00
4662	disk_usage	7	{}	2025-10-16 17:45:00.037843+00
4665	whatsapp_success_rate	100	{}	2025-10-16 17:45:00.041154+00
4669	sla_violation	4	{}	2025-10-16 17:45:00.043449+00
4689	memory_usage	19.063377380371094	{}	2025-10-16 17:55:00.019598+00
4693	disk_usage	7	{}	2025-10-16 17:55:00.02658+00
4695	whatsapp_success_rate	100	{}	2025-10-16 17:55:00.029115+00
4699	sla_violation	4	{}	2025-10-16 17:55:00.031379+00
4710	memory_usage	19.188690185546875	{}	2025-10-16 18:00:00.035665+00
4718	disk_usage	7	{}	2025-10-16 18:00:00.044198+00
4719	whatsapp_success_rate	100	{}	2025-10-16 18:00:00.048664+00
4720	sla_violation	4	{}	2025-10-16 18:00:00.051687+00
4739	memory_usage	19.353580474853516	{}	2025-10-16 18:10:00.021344+00
4743	disk_usage	7	{}	2025-10-16 18:10:00.02814+00
4748	whatsapp_success_rate	100	{}	2025-10-16 18:10:00.03109+00
4752	sla_violation	4	{}	2025-10-16 18:10:00.033545+00
4770	memory_usage	19.37694549560547	{}	2025-10-16 18:20:00.017936+00
4773	disk_usage	7	{}	2025-10-16 18:20:00.024524+00
4778	whatsapp_success_rate	100	{}	2025-10-16 18:20:00.028118+00
4782	sla_violation	4	{}	2025-10-16 18:20:00.030401+00
4801	memory_usage	19.34185028076172	{}	2025-10-16 18:30:00.026445+00
4805	disk_usage	7	{}	2025-10-16 18:30:00.032736+00
4808	whatsapp_success_rate	100	{}	2025-10-16 18:30:00.037474+00
4812	sla_violation	4	{}	2025-10-16 18:30:00.039933+00
4820	memory_usage	19.359350204467773	{}	2025-10-16 18:35:00.021023+00
4827	disk_usage	7	{}	2025-10-16 18:35:00.028724+00
4831	whatsapp_success_rate	100	{}	2025-10-16 18:35:00.030908+00
4832	sla_violation	4	{}	2025-10-16 18:35:00.033498+00
4851	memory_usage	19.36941146850586	{}	2025-10-16 18:45:00.030762+00
4857	disk_usage	7	{}	2025-10-16 18:45:00.03883+00
4860	whatsapp_success_rate	100	{}	2025-10-16 18:45:00.041731+00
4863	sla_violation	4	{}	2025-10-16 18:45:00.044724+00
4882	memory_usage	19.403076171875	{}	2025-10-16 18:55:00.017722+00
4887	disk_usage	7	{}	2025-10-16 18:55:00.025675+00
4890	whatsapp_success_rate	100	{}	2025-10-16 18:55:00.028995+00
4894	sla_violation	4	{}	2025-10-16 18:55:00.03152+00
4901	memory_usage	19.46096420288086	{}	2025-10-16 19:00:00.049753+00
4907	disk_usage	7	{}	2025-10-16 19:00:00.056849+00
4911	whatsapp_success_rate	100	{}	2025-10-16 19:00:00.060462+00
4912	sla_violation	4	{}	2025-10-16 19:00:00.063265+00
4930	memory_usage	19.441938400268555	{}	2025-10-16 19:10:00.018389+00
4934	disk_usage	7	{}	2025-10-16 19:10:00.025623+00
4937	whatsapp_success_rate	100	{}	2025-10-16 19:10:00.02821+00
4941	sla_violation	4	{}	2025-10-16 19:10:00.030626+00
4948	memory_usage	19.41819190979004	{}	2025-10-16 19:15:00.029859+00
4952	disk_usage	7	{}	2025-10-16 19:15:00.036645+00
4956	whatsapp_success_rate	100	{}	2025-10-16 19:15:00.040251+00
4960	sla_violation	4	{}	2025-10-16 19:15:00.042902+00
4978	memory_usage	19.39229965209961	{}	2025-10-16 19:25:00.017499+00
4983	disk_usage	7	{}	2025-10-16 19:25:00.025265+00
4987	whatsapp_success_rate	100	{}	2025-10-16 19:25:00.02825+00
4991	sla_violation	4	{}	2025-10-16 19:25:00.030563+00
4996	memory_usage	19.43826675415039	{}	2025-10-16 19:30:00.030694+00
5000	disk_usage	7	{}	2025-10-16 19:30:00.037377+00
5004	whatsapp_success_rate	100	{}	2025-10-16 19:30:00.039582+00
5006	sla_violation	4	{}	2025-10-16 19:30:00.041826+00
5025	memory_usage	19.378662109375	{}	2025-10-16 19:40:00.017337+00
5029	disk_usage	7	{}	2025-10-16 19:40:00.025804+00
5033	whatsapp_success_rate	100	{}	2025-10-16 19:40:00.028583+00
5037	sla_violation	4	{}	2025-10-16 19:40:00.030906+00
5048	memory_usage	19.435930252075195	{}	2025-10-16 19:45:00.0381+00
5053	disk_usage	7	{}	2025-10-16 19:45:00.044773+00
5055	whatsapp_success_rate	100	{}	2025-10-16 19:45:00.047338+00
5056	sla_violation	4	{}	2025-10-16 19:45:00.050063+00
5074	memory_usage	19.348526000976562	{}	2025-10-16 19:55:00.020594+00
5076	disk_usage	7	{}	2025-10-16 19:55:00.028061+00
5080	whatsapp_success_rate	100	{}	2025-10-16 19:55:00.031284+00
5082	sla_violation	4	{}	2025-10-16 19:55:00.033552+00
5092	memory_usage	19.415950775146484	{}	2025-10-16 20:00:00.034518+00
5098	disk_usage	7	{}	2025-10-16 20:00:00.041016+00
5102	whatsapp_success_rate	100	{}	2025-10-16 20:00:00.044572+00
5104	sla_violation	4	{}	2025-10-16 20:00:00.047228+00
5122	memory_usage	19.332122802734375	{}	2025-10-16 20:10:00.018662+00
5125	disk_usage	7	{}	2025-10-16 20:10:00.026532+00
5130	whatsapp_success_rate	100	{}	2025-10-16 20:10:00.029835+00
5134	sla_violation	4	{}	2025-10-16 20:10:00.032503+00
5140	memory_usage	19.378995895385742	{}	2025-10-16 20:15:00.030467+00
5144	disk_usage	7	{}	2025-10-16 20:15:00.038313+00
5148	whatsapp_success_rate	100	{}	2025-10-16 20:15:00.041424+00
5152	sla_violation	4	{}	2025-10-16 20:15:00.043849+00
5170	memory_usage	19.379711151123047	{}	2025-10-16 20:25:00.017609+00
5176	disk_usage	7	{}	2025-10-16 20:25:00.024929+00
5179	whatsapp_success_rate	100	{}	2025-10-16 20:25:00.027471+00
5183	sla_violation	4	{}	2025-10-16 20:25:00.029739+00
5189	memory_usage	19.452905654907227	{}	2025-10-16 20:30:00.036961+00
5197	disk_usage	7	{}	2025-10-16 20:30:00.043787+00
5199	whatsapp_success_rate	100	{}	2025-10-16 20:30:00.047303+00
5200	sla_violation	4	{}	2025-10-16 20:30:00.049458+00
5218	memory_usage	19.38338279724121	{}	2025-10-16 20:40:00.018267+00
5222	disk_usage	7	{}	2025-10-16 20:40:00.02677+00
5226	whatsapp_success_rate	100	{}	2025-10-16 20:40:00.030207+00
5230	sla_violation	4	{}	2025-10-16 20:40:00.032725+00
5238	memory_usage	19.43516731262207	{}	2025-10-16 20:45:00.036243+00
5245	disk_usage	7	{}	2025-10-16 20:45:00.043993+00
5247	whatsapp_success_rate	100	{}	2025-10-16 20:45:00.048014+00
5248	sla_violation	4	{}	2025-10-16 20:45:00.05015+00
5266	memory_usage	19.361591339111328	{}	2025-10-16 20:55:00.019949+00
5269	disk_usage	7	{}	2025-10-16 20:55:00.026656+00
5271	whatsapp_success_rate	100	{}	2025-10-16 20:55:00.029164+00
5275	sla_violation	4	{}	2025-10-16 20:55:00.031755+00
5283	memory_usage	19.40298080444336	{}	2025-10-16 21:00:00.030885+00
5286	disk_usage	7	{}	2025-10-16 21:00:00.035798+00
5287	disk_usage	7	{}	2025-10-16 21:00:00.037616+00
5289	whatsapp_success_rate	100	{}	2025-10-16 21:00:00.040221+00
5290	whatsapp_success_rate	100	{}	2025-10-16 21:00:00.040568+00
5294	sla_violation	4	{}	2025-10-16 21:00:00.043262+00
5295	sla_violation	4	{}	2025-10-16 21:00:00.04327+00
5299	memory_usage	19.403600692749023	{}	2025-10-16 21:05:00.021777+00
5302	disk_usage	7	{}	2025-10-16 21:05:00.028744+00
5305	whatsapp_success_rate	100	{}	2025-10-16 21:05:00.031616+00
5308	sla_violation	4	{}	2025-10-16 21:05:00.03378+00
5310	disk_usage	7	{}	2025-10-16 21:05:00.035742+00
4560	sla_violation	4	{}	2025-10-16 17:10:00.030761+00
4561	memory_usage	19.06566619873047	{}	2025-10-16 17:15:00.024337+00
4562	memory_usage	19.063854217529297	{}	2025-10-16 17:15:00.027228+00
4563	memory_usage	19.089984893798828	{}	2025-10-16 17:15:00.030599+00
4564	memory_usage	19.097185134887695	{}	2025-10-16 17:15:00.030643+00
4565	disk_usage	7	{}	2025-10-16 17:15:00.033288+00
4566	disk_usage	7	{}	2025-10-16 17:15:00.033773+00
4567	whatsapp_success_rate	100	{}	2025-10-16 17:15:00.03649+00
4568	whatsapp_success_rate	100	{}	2025-10-16 17:15:00.037151+00
4569	disk_usage	7	{}	2025-10-16 17:15:00.037808+00
4570	disk_usage	7	{}	2025-10-16 17:15:00.038384+00
4571	sla_violation	4	{}	2025-10-16 17:15:00.039321+00
4572	whatsapp_success_rate	100	{}	2025-10-16 17:15:00.04058+00
4573	sla_violation	4	{}	2025-10-16 17:15:00.041767+00
4574	whatsapp_success_rate	100	{}	2025-10-16 17:15:00.042538+00
4575	sla_violation	4	{}	2025-10-16 17:15:00.043397+00
4576	sla_violation	4	{}	2025-10-16 17:15:00.050232+00
4577	memory_usage	19.042587280273438	{}	2025-10-16 17:20:00.018068+00
4578	memory_usage	19.039583206176758	{}	2025-10-16 17:20:00.018292+00
4579	memory_usage	19.051551818847656	{}	2025-10-16 17:20:00.019789+00
4580	memory_usage	19.045639038085938	{}	2025-10-16 17:20:00.019805+00
4581	disk_usage	7	{}	2025-10-16 17:20:00.024964+00
4582	disk_usage	7	{}	2025-10-16 17:20:00.025999+00
4583	disk_usage	7	{}	2025-10-16 17:20:00.026232+00
4584	disk_usage	7	{}	2025-10-16 17:20:00.026281+00
4585	whatsapp_success_rate	100	{}	2025-10-16 17:20:00.027513+00
4586	whatsapp_success_rate	100	{}	2025-10-16 17:20:00.028216+00
4587	whatsapp_success_rate	100	{}	2025-10-16 17:20:00.029021+00
4588	whatsapp_success_rate	100	{}	2025-10-16 17:20:00.029279+00
4589	sla_violation	4	{}	2025-10-16 17:20:00.029764+00
4590	sla_violation	4	{}	2025-10-16 17:20:00.030275+00
4591	sla_violation	4	{}	2025-10-16 17:20:00.031666+00
4592	sla_violation	4	{}	2025-10-16 17:20:00.031685+00
4593	memory_usage	19.0096378326416	{}	2025-10-16 17:25:00.017998+00
4594	memory_usage	19.007396697998047	{}	2025-10-16 17:25:00.019071+00
4595	memory_usage	19.007396697998047	{}	2025-10-16 17:25:00.019968+00
4596	memory_usage	19.03553009033203	{}	2025-10-16 17:25:00.022217+00
4597	disk_usage	7	{}	2025-10-16 17:25:00.024954+00
4598	disk_usage	7	{}	2025-10-16 17:25:00.025858+00
4599	disk_usage	7	{}	2025-10-16 17:25:00.026435+00
4600	whatsapp_success_rate	100	{}	2025-10-16 17:25:00.028096+00
4601	disk_usage	7	{}	2025-10-16 17:25:00.028688+00
4602	whatsapp_success_rate	100	{}	2025-10-16 17:25:00.028981+00
4603	whatsapp_success_rate	100	{}	2025-10-16 17:25:00.029714+00
4604	sla_violation	4	{}	2025-10-16 17:25:00.030349+00
4605	whatsapp_success_rate	100	{}	2025-10-16 17:25:00.030992+00
4606	sla_violation	4	{}	2025-10-16 17:25:00.031721+00
4607	sla_violation	4	{}	2025-10-16 17:25:00.032248+00
4608	sla_violation	4	{}	2025-10-16 17:25:00.033215+00
4609	memory_usage	19.021940231323242	{}	2025-10-16 17:30:00.029468+00
4610	memory_usage	19.020414352416992	{}	2025-10-16 17:30:00.032399+00
4611	memory_usage	19.040870666503906	{}	2025-10-16 17:30:00.035937+00
4612	memory_usage	19.040870666503906	{}	2025-10-16 17:30:00.036304+00
4613	disk_usage	7	{}	2025-10-16 17:30:00.039457+00
4614	disk_usage	7	{}	2025-10-16 17:30:00.040099+00
4615	disk_usage	7	{}	2025-10-16 17:30:00.043824+00
4616	disk_usage	7	{}	2025-10-16 17:30:00.044313+00
4617	whatsapp_success_rate	100	{}	2025-10-16 17:30:00.044709+00
4618	whatsapp_success_rate	100	{}	2025-10-16 17:30:00.047225+00
4619	sla_violation	4	{}	2025-10-16 17:30:00.048054+00
4620	whatsapp_success_rate	100	{}	2025-10-16 17:30:00.048208+00
4621	whatsapp_success_rate	100	{}	2025-10-16 17:30:00.048557+00
4622	sla_violation	4	{}	2025-10-16 17:30:00.051801+00
4623	sla_violation	4	{}	2025-10-16 17:30:00.052301+00
4624	sla_violation	4	{}	2025-10-16 17:30:00.053355+00
4625	memory_usage	19.00153160095215	{}	2025-10-16 17:35:00.017136+00
4626	memory_usage	19.001388549804688	{}	2025-10-16 17:35:00.017527+00
4627	memory_usage	19.004440307617188	{}	2025-10-16 17:35:00.01861+00
4628	memory_usage	19.004440307617188	{}	2025-10-16 17:35:00.019066+00
4629	disk_usage	7	{}	2025-10-16 17:35:00.023769+00
4630	disk_usage	7	{}	2025-10-16 17:35:00.024079+00
4631	disk_usage	7	{}	2025-10-16 17:35:00.02431+00
4632	disk_usage	7	{}	2025-10-16 17:35:00.02543+00
4633	whatsapp_success_rate	100	{}	2025-10-16 17:35:00.0263+00
4634	whatsapp_success_rate	100	{}	2025-10-16 17:35:00.026627+00
4635	whatsapp_success_rate	100	{}	2025-10-16 17:35:00.026982+00
4636	whatsapp_success_rate	100	{}	2025-10-16 17:35:00.027942+00
4637	sla_violation	4	{}	2025-10-16 17:35:00.028591+00
4638	sla_violation	4	{}	2025-10-16 17:35:00.028973+00
4639	sla_violation	4	{}	2025-10-16 17:35:00.029436+00
4640	sla_violation	4	{}	2025-10-16 17:35:00.030227+00
4659	memory_usage	19.036340713500977	{}	2025-10-16 17:45:00.031359+00
4663	disk_usage	7	{}	2025-10-16 17:45:00.038734+00
4667	whatsapp_success_rate	100	{}	2025-10-16 17:45:00.042058+00
4670	sla_violation	4	{}	2025-10-16 17:45:00.044787+00
4690	memory_usage	19.06266212463379	{}	2025-10-16 17:55:00.021083+00
4694	disk_usage	7	{}	2025-10-16 17:55:00.027665+00
4697	whatsapp_success_rate	100	{}	2025-10-16 17:55:00.029992+00
4701	sla_violation	4	{}	2025-10-16 17:55:00.0321+00
4721	memory_usage	19.34366226196289	{}	2025-10-16 18:05:00.017455+00
4724	disk_usage	7	{}	2025-10-16 18:05:00.024377+00
4728	whatsapp_success_rate	100	{}	2025-10-16 18:05:00.027374+00
4730	sla_violation	4	{}	2025-10-16 18:05:00.031129+00
4740	memory_usage	19.376707077026367	{}	2025-10-16 18:10:00.022497+00
4744	disk_usage	7	{}	2025-10-16 18:10:00.028332+00
4747	whatsapp_success_rate	100	{}	2025-10-16 18:10:00.030732+00
4751	sla_violation	4	{}	2025-10-16 18:10:00.0331+00
4771	memory_usage	19.37694549560547	{}	2025-10-16 18:20:00.018421+00
4772	disk_usage	7	{}	2025-10-16 18:20:00.024394+00
4776	whatsapp_success_rate	100	{}	2025-10-16 18:20:00.027019+00
4779	sla_violation	4	{}	2025-10-16 18:20:00.02926+00
4802	memory_usage	19.342756271362305	{}	2025-10-16 18:30:00.026438+00
4806	disk_usage	7	{}	2025-10-16 18:30:00.034273+00
4809	whatsapp_success_rate	100	{}	2025-10-16 18:30:00.038339+00
4813	sla_violation	4	{}	2025-10-16 18:30:00.040565+00
4833	memory_usage	19.365453720092773	{}	2025-10-16 18:40:00.017229+00
4837	disk_usage	7	{}	2025-10-16 18:40:00.024367+00
4840	whatsapp_success_rate	100	{}	2025-10-16 18:40:00.026994+00
4844	sla_violation	4	{}	2025-10-16 18:40:00.029298+00
4852	memory_usage	19.39396858215332	{}	2025-10-16 18:45:00.030935+00
4858	disk_usage	7	{}	2025-10-16 18:45:00.039429+00
4862	whatsapp_success_rate	100	{}	2025-10-16 18:45:00.043032+00
4864	sla_violation	4	{}	2025-10-16 18:45:00.045477+00
5312	sla_violation	4	{}	2025-10-16 21:05:00.042465+00
5313	memory_usage	19.382190704345703	{}	2025-10-16 21:10:00.018517+00
5314	memory_usage	19.382190704345703	{}	2025-10-16 21:10:00.018682+00
5315	memory_usage	19.389677047729492	{}	2025-10-16 21:10:00.018831+00
5316	memory_usage	19.42286491394043	{}	2025-10-16 21:10:00.022697+00
5317	disk_usage	7	{}	2025-10-16 21:10:00.027163+00
5318	disk_usage	7	{}	2025-10-16 21:10:00.027758+00
5319	disk_usage	7	{}	2025-10-16 21:10:00.028015+00
5320	disk_usage	7	{}	2025-10-16 21:10:00.028432+00
5321	whatsapp_success_rate	100	{}	2025-10-16 21:10:00.03059+00
5322	whatsapp_success_rate	100	{}	2025-10-16 21:10:00.031163+00
5323	whatsapp_success_rate	100	{}	2025-10-16 21:10:00.031232+00
5324	whatsapp_success_rate	100	{}	2025-10-16 21:10:00.031458+00
5325	sla_violation	4	{}	2025-10-16 21:10:00.034433+00
5326	sla_violation	4	{}	2025-10-16 21:10:00.034874+00
5327	sla_violation	4	{}	2025-10-16 21:10:00.034934+00
5328	sla_violation	4	{}	2025-10-16 21:10:00.034988+00
5329	memory_usage	19.495677947998047	{}	2025-10-16 21:15:00.016655+00
5330	memory_usage	19.505929946899414	{}	2025-10-16 21:15:00.017581+00
5331	disk_usage	7	{}	2025-10-16 21:15:00.024313+00
5332	disk_usage	7	{}	2025-10-16 21:15:00.024868+00
5333	memory_usage	19.505929946899414	{}	2025-10-16 21:15:00.02675+00
5334	whatsapp_success_rate	100	{}	2025-10-16 21:15:00.027638+00
5335	whatsapp_success_rate	100	{}	2025-10-16 21:15:00.027734+00
5336	memory_usage	19.49944496154785	{}	2025-10-16 21:15:00.02885+00
5337	sla_violation	4	{}	2025-10-16 21:15:00.030278+00
5338	sla_violation	4	{}	2025-10-16 21:15:00.030473+00
5339	disk_usage	7	{}	2025-10-16 21:15:00.033154+00
5340	disk_usage	7	{}	2025-10-16 21:15:00.036384+00
5341	whatsapp_success_rate	100	{}	2025-10-16 21:15:00.036966+00
5342	whatsapp_success_rate	100	{}	2025-10-16 21:15:00.038837+00
5343	sla_violation	4	{}	2025-10-16 21:15:00.039104+00
5344	sla_violation	4	{}	2025-10-16 21:15:00.040976+00
5345	memory_usage	19.40927505493164	{}	2025-10-16 21:20:00.018056+00
5346	memory_usage	19.40317153930664	{}	2025-10-16 21:20:00.018178+00
5347	memory_usage	19.436931610107422	{}	2025-10-16 21:20:00.023125+00
5348	disk_usage	7	{}	2025-10-16 21:20:00.025315+00
5349	disk_usage	7	{}	2025-10-16 21:20:00.025412+00
5350	memory_usage	19.436931610107422	{}	2025-10-16 21:20:00.02623+00
5351	whatsapp_success_rate	100	{}	2025-10-16 21:20:00.028109+00
5352	whatsapp_success_rate	100	{}	2025-10-16 21:20:00.028682+00
5353	sla_violation	4	{}	2025-10-16 21:20:00.031076+00
5354	sla_violation	4	{}	2025-10-16 21:20:00.032639+00
5355	disk_usage	7	{}	2025-10-16 21:20:00.03272+00
5356	disk_usage	7	{}	2025-10-16 21:20:00.032843+00
5357	whatsapp_success_rate	100	{}	2025-10-16 21:20:00.035714+00
5358	whatsapp_success_rate	100	{}	2025-10-16 21:20:00.035734+00
5359	sla_violation	4	{}	2025-10-16 21:20:00.037768+00
5360	sla_violation	4	{}	2025-10-16 21:20:00.038164+00
5361	memory_usage	19.41547393798828	{}	2025-10-16 21:25:00.017159+00
5362	memory_usage	19.414138793945312	{}	2025-10-16 21:25:00.017978+00
5363	memory_usage	19.41547393798828	{}	2025-10-16 21:25:00.017917+00
5364	memory_usage	19.422388076782227	{}	2025-10-16 21:25:00.019632+00
5365	disk_usage	7	{}	2025-10-16 21:25:00.024186+00
5366	disk_usage	7	{}	2025-10-16 21:25:00.025072+00
5367	disk_usage	7	{}	2025-10-16 21:25:00.025513+00
5368	disk_usage	7	{}	2025-10-16 21:25:00.025807+00
5369	whatsapp_success_rate	100	{}	2025-10-16 21:25:00.026787+00
5370	whatsapp_success_rate	100	{}	2025-10-16 21:25:00.0276+00
5371	whatsapp_success_rate	100	{}	2025-10-16 21:25:00.028327+00
5372	whatsapp_success_rate	100	{}	2025-10-16 21:25:00.028489+00
5373	sla_violation	4	{}	2025-10-16 21:25:00.029664+00
5374	sla_violation	4	{}	2025-10-16 21:25:00.029978+00
5375	sla_violation	4	{}	2025-10-16 21:25:00.030471+00
5376	sla_violation	4	{}	2025-10-16 21:25:00.030954+00
5377	memory_usage	19.423818588256836	{}	2025-10-16 21:30:00.03122+00
5378	memory_usage	19.449472427368164	{}	2025-10-16 21:30:00.032099+00
5379	memory_usage	19.45662498474121	{}	2025-10-16 21:30:00.034019+00
5380	memory_usage	19.4516658782959	{}	2025-10-16 21:30:00.035392+00
5381	disk_usage	7	{}	2025-10-16 21:30:00.039921+00
5382	disk_usage	7	{}	2025-10-16 21:30:00.043049+00
5383	disk_usage	7	{}	2025-10-16 21:30:00.04335+00
5384	disk_usage	7	{}	2025-10-16 21:30:00.043641+00
5385	whatsapp_success_rate	100	{}	2025-10-16 21:30:00.043952+00
5386	whatsapp_success_rate	100	{}	2025-10-16 21:30:00.045808+00
5387	sla_violation	4	{}	2025-10-16 21:30:00.046695+00
5388	whatsapp_success_rate	100	{}	2025-10-16 21:30:00.046717+00
5389	whatsapp_success_rate	100	{}	2025-10-16 21:30:00.0471+00
5390	sla_violation	4	{}	2025-10-16 21:30:00.047952+00
5391	sla_violation	4	{}	2025-10-16 21:30:00.04958+00
5392	sla_violation	4	{}	2025-10-16 21:30:00.049597+00
5393	memory_usage	19.4002628326416	{}	2025-10-16 21:35:00.017016+00
5394	memory_usage	19.4002628326416	{}	2025-10-16 21:35:00.017584+00
5395	memory_usage	19.410419464111328	{}	2025-10-16 21:35:00.017989+00
5396	memory_usage	19.4002628326416	{}	2025-10-16 21:35:00.019359+00
5397	disk_usage	7	{}	2025-10-16 21:35:00.024268+00
5398	disk_usage	7	{}	2025-10-16 21:35:00.024499+00
5399	disk_usage	7	{}	2025-10-16 21:35:00.024774+00
5400	disk_usage	7	{}	2025-10-16 21:35:00.025575+00
5401	whatsapp_success_rate	100	{}	2025-10-16 21:35:00.026796+00
5403	whatsapp_success_rate	100	{}	2025-10-16 21:35:00.027497+00
5402	whatsapp_success_rate	100	{}	2025-10-16 21:35:00.027492+00
5404	whatsapp_success_rate	100	{}	2025-10-16 21:35:00.027813+00
5405	sla_violation	4	{}	2025-10-16 21:35:00.028923+00
5406	sla_violation	4	{}	2025-10-16 21:35:00.029665+00
5407	sla_violation	4	{}	2025-10-16 21:35:00.030145+00
5408	sla_violation	4	{}	2025-10-16 21:35:00.030322+00
5409	memory_usage	19.416046142578125	{}	2025-10-16 21:40:00.017166+00
5410	memory_usage	19.41051483154297	{}	2025-10-16 21:40:00.018039+00
5411	memory_usage	19.426441192626953	{}	2025-10-16 21:40:00.019515+00
5412	memory_usage	19.453716278076172	{}	2025-10-16 21:40:00.021952+00
5413	disk_usage	7	{}	2025-10-16 21:40:00.024553+00
5414	disk_usage	7	{}	2025-10-16 21:40:00.024816+00
5415	disk_usage	7	{}	2025-10-16 21:40:00.026057+00
5416	whatsapp_success_rate	100	{}	2025-10-16 21:40:00.027263+00
5417	whatsapp_success_rate	100	{}	2025-10-16 21:40:00.027631+00
5418	disk_usage	7	{}	2025-10-16 21:40:00.027857+00
5419	whatsapp_success_rate	100	{}	2025-10-16 21:40:00.0286+00
5420	sla_violation	4	{}	2025-10-16 21:40:00.029725+00
5421	sla_violation	4	{}	2025-10-16 21:40:00.030341+00
5422	whatsapp_success_rate	100	{}	2025-10-16 21:40:00.030752+00
5423	sla_violation	4	{}	2025-10-16 21:40:00.030938+00
5424	sla_violation	4	{}	2025-10-16 21:40:00.033045+00
5425	memory_usage	19.42744255065918	{}	2025-10-16 21:45:00.027832+00
5426	memory_usage	19.435405731201172	{}	2025-10-16 21:45:00.029+00
5427	memory_usage	19.43807601928711	{}	2025-10-16 21:45:00.030804+00
5428	memory_usage	19.42744255065918	{}	2025-10-16 21:45:00.032782+00
5429	disk_usage	7	{}	2025-10-16 21:45:00.037518+00
5430	disk_usage	7	{}	2025-10-16 21:45:00.038108+00
5431	disk_usage	7	{}	2025-10-16 21:45:00.038113+00
5432	whatsapp_success_rate	100	{}	2025-10-16 21:45:00.040584+00
5433	whatsapp_success_rate	100	{}	2025-10-16 21:45:00.040995+00
5434	disk_usage	7	{}	2025-10-16 21:45:00.04174+00
5435	whatsapp_success_rate	100	{}	2025-10-16 21:45:00.042385+00
5436	sla_violation	4	{}	2025-10-16 21:45:00.043456+00
5437	sla_violation	4	{}	2025-10-16 21:45:00.043599+00
5438	sla_violation	4	{}	2025-10-16 21:45:00.044822+00
5439	whatsapp_success_rate	100	{}	2025-10-16 21:45:00.045728+00
5440	sla_violation	4	{}	2025-10-16 21:45:00.04795+00
5441	memory_usage	19.43035125732422	{}	2025-10-16 21:50:00.018017+00
5442	memory_usage	19.43035125732422	{}	2025-10-16 21:50:00.01921+00
5443	memory_usage	19.43035125732422	{}	2025-10-16 21:50:00.019385+00
5444	memory_usage	19.466543197631836	{}	2025-10-16 21:50:00.022556+00
5445	disk_usage	7	{}	2025-10-16 21:50:00.025527+00
5446	disk_usage	7	{}	2025-10-16 21:50:00.026381+00
5447	disk_usage	7	{}	2025-10-16 21:50:00.027912+00
5448	whatsapp_success_rate	100	{}	2025-10-16 21:50:00.028337+00
5449	whatsapp_success_rate	100	{}	2025-10-16 21:50:00.028831+00
5450	disk_usage	7	{}	2025-10-16 21:50:00.029088+00
5451	whatsapp_success_rate	100	{}	2025-10-16 21:50:00.030293+00
5452	sla_violation	4	{}	2025-10-16 21:50:00.030663+00
5453	sla_violation	4	{}	2025-10-16 21:50:00.030923+00
5454	whatsapp_success_rate	100	{}	2025-10-16 21:50:00.031551+00
5455	sla_violation	4	{}	2025-10-16 21:50:00.032417+00
5456	sla_violation	4	{}	2025-10-16 21:50:00.034109+00
5457	memory_usage	19.432830810546875	{}	2025-10-16 21:55:00.01828+00
5458	memory_usage	19.432830810546875	{}	2025-10-16 21:55:00.018263+00
5459	memory_usage	19.432830810546875	{}	2025-10-16 21:55:00.01871+00
5460	memory_usage	19.440841674804688	{}	2025-10-16 21:55:00.02031+00
5461	disk_usage	7	{}	2025-10-16 21:55:00.025185+00
5462	disk_usage	7	{}	2025-10-16 21:55:00.025203+00
5463	disk_usage	7	{}	2025-10-16 21:55:00.025317+00
5464	disk_usage	7	{}	2025-10-16 21:55:00.026999+00
5465	whatsapp_success_rate	100	{}	2025-10-16 21:55:00.027681+00
5466	whatsapp_success_rate	100	{}	2025-10-16 21:55:00.027957+00
5467	whatsapp_success_rate	100	{}	2025-10-16 21:55:00.027987+00
5468	whatsapp_success_rate	100	{}	2025-10-16 21:55:00.029633+00
5469	sla_violation	4	{}	2025-10-16 21:55:00.029996+00
5470	sla_violation	4	{}	2025-10-16 21:55:00.030229+00
5471	sla_violation	4	{}	2025-10-16 21:55:00.030271+00
5472	sla_violation	4	{}	2025-10-16 21:55:00.03213+00
5473	memory_usage	19.448423385620117	{}	2025-10-16 22:00:00.025841+00
5474	memory_usage	19.469833374023438	{}	2025-10-16 22:00:00.027155+00
5475	memory_usage	19.449186325073242	{}	2025-10-16 22:00:00.028796+00
5476	disk_usage	7	{}	2025-10-16 22:00:00.034563+00
5477	disk_usage	7	{}	2025-10-16 22:00:00.035018+00
5478	disk_usage	7	{}	2025-10-16 22:00:00.035534+00
5479	whatsapp_success_rate	100	{}	2025-10-16 22:00:00.037322+00
5480	memory_usage	19.515609741210938	{}	2025-10-16 22:00:00.037367+00
5481	whatsapp_success_rate	100	{}	2025-10-16 22:00:00.03849+00
5482	whatsapp_success_rate	100	{}	2025-10-16 22:00:00.039138+00
5483	sla_violation	4	{}	2025-10-16 22:00:00.03963+00
5484	sla_violation	4	{}	2025-10-16 22:00:00.040826+00
5485	sla_violation	4	{}	2025-10-16 22:00:00.041386+00
5486	disk_usage	7	{}	2025-10-16 22:00:00.044687+00
5487	whatsapp_success_rate	100	{}	2025-10-16 22:00:00.047775+00
5488	sla_violation	4	{}	2025-10-16 22:00:00.050291+00
5489	memory_usage	19.4185733795166	{}	2025-10-16 22:05:00.01713+00
5490	memory_usage	19.4185733795166	{}	2025-10-16 22:05:00.017482+00
5491	memory_usage	19.4185733795166	{}	2025-10-16 22:05:00.017933+00
5492	memory_usage	19.441699981689453	{}	2025-10-16 22:05:00.022461+00
5493	disk_usage	7	{}	2025-10-16 22:05:00.024231+00
5494	disk_usage	7	{}	2025-10-16 22:05:00.024461+00
5495	disk_usage	7	{}	2025-10-16 22:05:00.024508+00
5496	whatsapp_success_rate	100	{}	2025-10-16 22:05:00.026958+00
5497	whatsapp_success_rate	100	{}	2025-10-16 22:05:00.027257+00
5498	whatsapp_success_rate	100	{}	2025-10-16 22:05:00.027276+00
5499	disk_usage	7	{}	2025-10-16 22:05:00.027881+00
5500	sla_violation	4	{}	2025-10-16 22:05:00.029886+00
5501	sla_violation	4	{}	2025-10-16 22:05:00.029915+00
5502	whatsapp_success_rate	100	{}	2025-10-16 22:05:00.030122+00
5503	sla_violation	4	{}	2025-10-16 22:05:00.030493+00
5504	sla_violation	4	{}	2025-10-16 22:05:00.032766+00
5505	memory_usage	19.434404373168945	{}	2025-10-16 22:10:00.01679+00
5506	memory_usage	19.43531036376953	{}	2025-10-16 22:10:00.017557+00
5507	memory_usage	19.45333480834961	{}	2025-10-16 22:10:00.021971+00
5508	disk_usage	7	{}	2025-10-16 22:10:00.024017+00
5509	disk_usage	7	{}	2025-10-16 22:10:00.024245+00
5510	memory_usage	19.45328712463379	{}	2025-10-16 22:10:00.0252+00
5511	whatsapp_success_rate	100	{}	2025-10-16 22:10:00.026755+00
5512	whatsapp_success_rate	100	{}	2025-10-16 22:10:00.027128+00
5513	disk_usage	7	{}	2025-10-16 22:10:00.028364+00
5514	sla_violation	4	{}	2025-10-16 22:10:00.029551+00
5515	sla_violation	4	{}	2025-10-16 22:10:00.029571+00
5516	whatsapp_success_rate	100	{}	2025-10-16 22:10:00.030693+00
5517	disk_usage	7	{}	2025-10-16 22:10:00.030763+00
5518	sla_violation	4	{}	2025-10-16 22:10:00.032879+00
5519	whatsapp_success_rate	100	{}	2025-10-16 22:10:00.033535+00
5520	sla_violation	4	{}	2025-10-16 22:10:00.038444+00
5521	memory_usage	19.427061080932617	{}	2025-10-16 22:15:00.024784+00
5522	memory_usage	19.438934326171875	{}	2025-10-16 22:15:00.028236+00
5523	memory_usage	19.497203826904297	{}	2025-10-16 22:15:00.031682+00
5524	memory_usage	19.46854591369629	{}	2025-10-16 22:15:00.03211+00
5525	disk_usage	7	{}	2025-10-16 22:15:00.032814+00
5526	disk_usage	7	{}	2025-10-16 22:15:00.036411+00
5527	whatsapp_success_rate	100	{}	2025-10-16 22:15:00.037624+00
5528	whatsapp_success_rate	100	{}	2025-10-16 22:15:00.039498+00
5529	disk_usage	7	{}	2025-10-16 22:15:00.040045+00
5530	sla_violation	4	{}	2025-10-16 22:15:00.040866+00
5531	disk_usage	7	{}	2025-10-16 22:15:00.041418+00
5532	sla_violation	4	{}	2025-10-16 22:15:00.041679+00
5533	whatsapp_success_rate	100	{}	2025-10-16 22:15:00.042649+00
5534	whatsapp_success_rate	100	{}	2025-10-16 22:15:00.043972+00
5535	sla_violation	4	{}	2025-10-16 22:15:00.049842+00
5536	sla_violation	4	{}	2025-10-16 22:15:00.04995+00
5537	memory_usage	19.4455623626709	{}	2025-10-16 22:20:00.017703+00
5538	memory_usage	19.4455623626709	{}	2025-10-16 22:20:00.018026+00
5539	memory_usage	19.4455623626709	{}	2025-10-16 22:20:00.018914+00
5540	memory_usage	19.4455623626709	{}	2025-10-16 22:20:00.019917+00
5541	disk_usage	7	{}	2025-10-16 22:20:00.025343+00
5542	disk_usage	7	{}	2025-10-16 22:20:00.025481+00
5544	disk_usage	7	{}	2025-10-16 22:20:00.027191+00
5545	whatsapp_success_rate	100	{}	2025-10-16 22:20:00.027935+00
5546	whatsapp_success_rate	100	{}	2025-10-16 22:20:00.028656+00
5548	whatsapp_success_rate	100	{}	2025-10-16 22:20:00.030288+00
5549	sla_violation	4	{}	2025-10-16 22:20:00.030794+00
5551	sla_violation	4	{}	2025-10-16 22:20:00.031353+00
5552	sla_violation	4	{}	2025-10-16 22:20:00.032534+00
5543	disk_usage	7	{}	2025-10-16 22:20:00.025935+00
5547	whatsapp_success_rate	100	{}	2025-10-16 22:20:00.028685+00
5550	sla_violation	4	{}	2025-10-16 22:20:00.031169+00
5553	memory_usage	19.449186325073242	{}	2025-10-16 22:25:00.01791+00
5554	memory_usage	19.449186325073242	{}	2025-10-16 22:25:00.018343+00
5555	memory_usage	19.4638729095459	{}	2025-10-16 22:25:00.022636+00
5556	memory_usage	19.4638729095459	{}	2025-10-16 22:25:00.024526+00
5557	disk_usage	7	{}	2025-10-16 22:25:00.025197+00
5558	disk_usage	7	{}	2025-10-16 22:25:00.025733+00
5559	whatsapp_success_rate	100	{}	2025-10-16 22:25:00.027803+00
5560	disk_usage	7	{}	2025-10-16 22:25:00.029465+00
5561	whatsapp_success_rate	100	{}	2025-10-16 22:25:00.029631+00
5562	sla_violation	4	{}	2025-10-16 22:25:00.030104+00
5563	disk_usage	7	{}	2025-10-16 22:25:00.031646+00
5564	whatsapp_success_rate	100	{}	2025-10-16 22:25:00.03211+00
5565	sla_violation	4	{}	2025-10-16 22:25:00.032584+00
5566	whatsapp_success_rate	100	{}	2025-10-16 22:25:00.03426+00
5567	sla_violation	4	{}	2025-10-16 22:25:00.034494+00
5568	sla_violation	4	{}	2025-10-16 22:25:00.036495+00
5569	memory_usage	19.481182098388672	{}	2025-10-16 22:30:00.026053+00
5570	memory_usage	19.48094367980957	{}	2025-10-16 22:30:00.028616+00
5571	memory_usage	19.50845718383789	{}	2025-10-16 22:30:00.029014+00
5572	memory_usage	19.513893127441406	{}	2025-10-16 22:30:00.035374+00
5573	disk_usage	7	{}	2025-10-16 22:30:00.035988+00
5574	disk_usage	7	{}	2025-10-16 22:30:00.03604+00
5575	disk_usage	7	{}	2025-10-16 22:30:00.036894+00
5576	whatsapp_success_rate	100	{}	2025-10-16 22:30:00.039272+00
5577	whatsapp_success_rate	100	{}	2025-10-16 22:30:00.039353+00
5578	whatsapp_success_rate	100	{}	2025-10-16 22:30:00.040706+00
5579	sla_violation	4	{}	2025-10-16 22:30:00.041964+00
5580	disk_usage	7	{}	2025-10-16 22:30:00.042223+00
5581	sla_violation	4	{}	2025-10-16 22:30:00.042707+00
5582	sla_violation	4	{}	2025-10-16 22:30:00.043422+00
5583	whatsapp_success_rate	100	{}	2025-10-16 22:30:00.046648+00
5584	sla_violation	4	{}	2025-10-16 22:30:00.048775+00
5585	memory_usage	19.455766677856445	{}	2025-10-16 22:35:00.017188+00
5586	memory_usage	19.45629119873047	{}	2025-10-16 22:35:00.017154+00
5587	memory_usage	19.461488723754883	{}	2025-10-16 22:35:00.018158+00
5588	memory_usage	19.467592239379883	{}	2025-10-16 22:35:00.018996+00
5589	disk_usage	7	{}	2025-10-16 22:35:00.024981+00
5590	disk_usage	7	{}	2025-10-16 22:35:00.025275+00
5591	disk_usage	7	{}	2025-10-16 22:35:00.025334+00
5592	disk_usage	7	{}	2025-10-16 22:35:00.025563+00
5593	whatsapp_success_rate	100	{}	2025-10-16 22:35:00.027487+00
5594	whatsapp_success_rate	100	{}	2025-10-16 22:35:00.02773+00
5595	whatsapp_success_rate	100	{}	2025-10-16 22:35:00.027771+00
5596	whatsapp_success_rate	100	{}	2025-10-16 22:35:00.028215+00
5597	sla_violation	4	{}	2025-10-16 22:35:00.029775+00
5598	sla_violation	4	{}	2025-10-16 22:35:00.030042+00
5599	sla_violation	4	{}	2025-10-16 22:35:00.030087+00
5600	sla_violation	4	{}	2025-10-16 22:35:00.03109+00
5601	memory_usage	19.512462615966797	{}	2025-10-16 22:40:00.018166+00
5602	memory_usage	19.53740119934082	{}	2025-10-16 22:40:00.021648+00
5603	memory_usage	19.529104232788086	{}	2025-10-16 22:40:00.021722+00
5604	memory_usage	19.523906707763672	{}	2025-10-16 22:40:00.022689+00
5605	disk_usage	7	{}	2025-10-16 22:40:00.025775+00
5606	whatsapp_success_rate	100	{}	2025-10-16 22:40:00.028432+00
5608	disk_usage	7	{}	2025-10-16 22:40:00.028521+00
5607	disk_usage	7	{}	2025-10-16 22:40:00.028508+00
5609	disk_usage	7	{}	2025-10-16 22:40:00.029566+00
5610	sla_violation	4	{}	2025-10-16 22:40:00.030666+00
5611	whatsapp_success_rate	100	{}	2025-10-16 22:40:00.031246+00
5612	whatsapp_success_rate	100	{}	2025-10-16 22:40:00.031274+00
5613	whatsapp_success_rate	100	{}	2025-10-16 22:40:00.03178+00
5614	sla_violation	4	{}	2025-10-16 22:40:00.033633+00
5615	sla_violation	4	{}	2025-10-16 22:40:00.034111+00
5616	sla_violation	4	{}	2025-10-16 22:40:00.034186+00
5617	memory_usage	19.51160430908203	{}	2025-10-16 22:45:00.025872+00
5618	memory_usage	19.513940811157227	{}	2025-10-16 22:45:00.028835+00
5619	memory_usage	19.513940811157227	{}	2025-10-16 22:45:00.029622+00
5620	disk_usage	7	{}	2025-10-16 22:45:00.033475+00
5621	memory_usage	19.54174041748047	{}	2025-10-16 22:45:00.033833+00
5622	whatsapp_success_rate	100	{}	2025-10-16 22:45:00.036805+00
5623	disk_usage	7	{}	2025-10-16 22:45:00.037061+00
5624	disk_usage	7	{}	2025-10-16 22:45:00.03727+00
5625	sla_violation	4	{}	2025-10-16 22:45:00.039641+00
5626	whatsapp_success_rate	100	{}	2025-10-16 22:45:00.041014+00
5627	whatsapp_success_rate	100	{}	2025-10-16 22:45:00.041107+00
5628	disk_usage	7	{}	2025-10-16 22:45:00.041191+00
5629	whatsapp_success_rate	100	{}	2025-10-16 22:45:00.044001+00
5630	sla_violation	4	{}	2025-10-16 22:45:00.045406+00
5631	sla_violation	4	{}	2025-10-16 22:45:00.045556+00
5632	sla_violation	4	{}	2025-10-16 22:45:00.04659+00
5633	memory_usage	19.466018676757812	{}	2025-10-16 22:50:00.017862+00
5634	memory_usage	19.466018676757812	{}	2025-10-16 22:50:00.01788+00
5635	memory_usage	19.462966918945312	{}	2025-10-16 22:50:00.018099+00
5636	memory_usage	19.495010375976562	{}	2025-10-16 22:50:00.021941+00
5637	disk_usage	7	{}	2025-10-16 22:50:00.024304+00
5638	disk_usage	7	{}	2025-10-16 22:50:00.024909+00
5639	disk_usage	7	{}	2025-10-16 22:50:00.025384+00
5640	whatsapp_success_rate	100	{}	2025-10-16 22:50:00.026913+00
5641	whatsapp_success_rate	100	{}	2025-10-16 22:50:00.027133+00
5642	whatsapp_success_rate	100	{}	2025-10-16 22:50:00.028136+00
5643	disk_usage	7	{}	2025-10-16 22:50:00.028136+00
5644	sla_violation	4	{}	2025-10-16 22:50:00.029259+00
5645	sla_violation	4	{}	2025-10-16 22:50:00.029479+00
5646	sla_violation	4	{}	2025-10-16 22:50:00.030498+00
5647	whatsapp_success_rate	100	{}	2025-10-16 22:50:00.030838+00
5648	sla_violation	4	{}	2025-10-16 22:50:00.033251+00
5649	memory_usage	19.464778900146484	{}	2025-10-16 22:55:00.018769+00
5650	memory_usage	19.462251663208008	{}	2025-10-16 22:55:00.01979+00
5651	memory_usage	19.462251663208008	{}	2025-10-16 22:55:00.020027+00
5652	memory_usage	19.464778900146484	{}	2025-10-16 22:55:00.022154+00
5653	disk_usage	7	{}	2025-10-16 22:55:00.026074+00
5654	disk_usage	7	{}	2025-10-16 22:55:00.026477+00
5655	disk_usage	7	{}	2025-10-16 22:55:00.026681+00
5656	disk_usage	7	{}	2025-10-16 22:55:00.028665+00
5657	whatsapp_success_rate	100	{}	2025-10-16 22:55:00.028678+00
5658	whatsapp_success_rate	100	{}	2025-10-16 22:55:00.029156+00
5659	whatsapp_success_rate	100	{}	2025-10-16 22:55:00.029424+00
5660	whatsapp_success_rate	100	{}	2025-10-16 22:55:00.032015+00
5661	sla_violation	4	{}	2025-10-16 22:55:00.033973+00
5662	sla_violation	4	{}	2025-10-16 22:55:00.033994+00
5663	sla_violation	4	{}	2025-10-16 22:55:00.034027+00
5664	sla_violation	4	{}	2025-10-16 22:55:00.034904+00
5665	memory_usage	19.479894638061523	{}	2025-10-16 23:00:00.026394+00
5666	memory_usage	19.50054168701172	{}	2025-10-16 23:00:00.031444+00
5667	memory_usage	19.50054168701172	{}	2025-10-16 23:00:00.033593+00
5668	disk_usage	7	{}	2025-10-16 23:00:00.034863+00
5669	memory_usage	19.50054168701172	{}	2025-10-16 23:00:00.036372+00
5670	whatsapp_success_rate	100	{}	2025-10-16 23:00:00.038344+00
5671	disk_usage	7	{}	2025-10-16 23:00:00.038699+00
5672	disk_usage	7	{}	2025-10-16 23:00:00.040073+00
5673	whatsapp_success_rate	100	{}	2025-10-16 23:00:00.041702+00
5674	sla_violation	4	{}	2025-10-16 23:00:00.042167+00
5675	whatsapp_success_rate	100	{}	2025-10-16 23:00:00.042774+00
5676	sla_violation	4	{}	2025-10-16 23:00:00.04416+00
5677	disk_usage	7	{}	2025-10-16 23:00:00.044702+00
5678	sla_violation	4	{}	2025-10-16 23:00:00.044963+00
5679	whatsapp_success_rate	100	{}	2025-10-16 23:00:00.04744+00
5680	sla_violation	4	{}	2025-10-16 23:00:00.05002+00
5681	memory_usage	19.467544555664062	{}	2025-10-16 23:05:00.017258+00
5682	memory_usage	19.472217559814453	{}	2025-10-16 23:05:00.017754+00
5683	memory_usage	19.493436813354492	{}	2025-10-16 23:05:00.023458+00
5684	disk_usage	7	{}	2025-10-16 23:05:00.024517+00
5685	memory_usage	19.493436813354492	{}	2025-10-16 23:05:00.02434+00
5686	disk_usage	7	{}	2025-10-16 23:05:00.025731+00
5687	whatsapp_success_rate	100	{}	2025-10-16 23:05:00.028515+00
5688	whatsapp_success_rate	100	{}	2025-10-16 23:05:00.028658+00
5689	disk_usage	7	{}	2025-10-16 23:05:00.030196+00
5690	disk_usage	7	{}	2025-10-16 23:05:00.030752+00
5691	sla_violation	4	{}	2025-10-16 23:05:00.031209+00
5692	sla_violation	4	{}	2025-10-16 23:05:00.031532+00
5693	whatsapp_success_rate	100	{}	2025-10-16 23:05:00.032936+00
5694	whatsapp_success_rate	100	{}	2025-10-16 23:05:00.033607+00
5695	sla_violation	4	{}	2025-10-16 23:05:00.035037+00
5696	sla_violation	4	{}	2025-10-16 23:05:00.036116+00
5697	memory_usage	19.484376907348633	{}	2025-10-16 23:10:00.01812+00
5698	memory_usage	19.484376907348633	{}	2025-10-16 23:10:00.018113+00
5699	memory_usage	19.514131546020508	{}	2025-10-16 23:10:00.022558+00
5700	memory_usage	19.490528106689453	{}	2025-10-16 23:10:00.022821+00
5701	disk_usage	7	{}	2025-10-16 23:10:00.024789+00
5702	disk_usage	7	{}	2025-10-16 23:10:00.025602+00
5703	whatsapp_success_rate	100	{}	2025-10-16 23:10:00.027805+00
5704	whatsapp_success_rate	100	{}	2025-10-16 23:10:00.028688+00
5705	disk_usage	7	{}	2025-10-16 23:10:00.02956+00
5706	sla_violation	4	{}	2025-10-16 23:10:00.030271+00
5707	disk_usage	7	{}	2025-10-16 23:10:00.030912+00
5708	sla_violation	4	{}	2025-10-16 23:10:00.032068+00
5709	whatsapp_success_rate	100	{}	2025-10-16 23:10:00.03236+00
5710	whatsapp_success_rate	100	{}	2025-10-16 23:10:00.033739+00
5711	sla_violation	4	{}	2025-10-16 23:10:00.034826+00
5712	sla_violation	4	{}	2025-10-16 23:10:00.036077+00
5713	memory_usage	19.480228424072266	{}	2025-10-16 23:15:00.026797+00
5714	memory_usage	19.49634552001953	{}	2025-10-16 23:15:00.027605+00
5715	memory_usage	19.502687454223633	{}	2025-10-16 23:15:00.031925+00
5717	disk_usage	7	{}	2025-10-16 23:15:00.03494+00
5716	memory_usage	19.533157348632812	{}	2025-10-16 23:15:00.034378+00
5718	disk_usage	7	{}	2025-10-16 23:15:00.036283+00
5719	whatsapp_success_rate	100	{}	2025-10-16 23:15:00.038788+00
5720	disk_usage	7	{}	2025-10-16 23:15:00.040035+00
5721	whatsapp_success_rate	100	{}	2025-10-16 23:15:00.041111+00
5722	sla_violation	4	{}	2025-10-16 23:15:00.041788+00
5723	whatsapp_success_rate	100	{}	2025-10-16 23:15:00.042452+00
5724	disk_usage	7	{}	2025-10-16 23:15:00.04306+00
5725	sla_violation	4	{}	2025-10-16 23:15:00.044285+00
5726	sla_violation	4	{}	2025-10-16 23:15:00.045347+00
5727	whatsapp_success_rate	100	{}	2025-10-16 23:15:00.04583+00
5728	sla_violation	4	{}	2025-10-16 23:15:00.05078+00
5729	memory_usage	19.47174072265625	{}	2025-10-16 23:20:00.017022+00
5730	memory_usage	19.47174072265625	{}	2025-10-16 23:20:00.017141+00
5731	memory_usage	19.47174072265625	{}	2025-10-16 23:20:00.017062+00
5732	memory_usage	19.477033615112305	{}	2025-10-16 23:20:00.01947+00
5733	disk_usage	7	{}	2025-10-16 23:20:00.02404+00
5734	disk_usage	7	{}	2025-10-16 23:20:00.024308+00
5735	disk_usage	7	{}	2025-10-16 23:20:00.024615+00
5736	disk_usage	7	{}	2025-10-16 23:20:00.025088+00
5737	whatsapp_success_rate	100	{}	2025-10-16 23:20:00.026712+00
5738	whatsapp_success_rate	100	{}	2025-10-16 23:20:00.02737+00
5739	whatsapp_success_rate	100	{}	2025-10-16 23:20:00.027684+00
5740	whatsapp_success_rate	100	{}	2025-10-16 23:20:00.027839+00
5741	sla_violation	4	{}	2025-10-16 23:20:00.028884+00
5742	sla_violation	4	{}	2025-10-16 23:20:00.029812+00
5743	sla_violation	4	{}	2025-10-16 23:20:00.031072+00
5744	sla_violation	4	{}	2025-10-16 23:20:00.031081+00
5745	memory_usage	19.455814361572266	{}	2025-10-16 23:25:00.018532+00
5746	memory_usage	19.46086883544922	{}	2025-10-16 23:25:00.020755+00
5747	memory_usage	19.466066360473633	{}	2025-10-16 23:25:00.022387+00
5748	memory_usage	19.49176788330078	{}	2025-10-16 23:25:00.023488+00
5749	disk_usage	7	{}	2025-10-16 23:25:00.025869+00
5750	disk_usage	7	{}	2025-10-16 23:25:00.027264+00
5751	whatsapp_success_rate	100	{}	2025-10-16 23:25:00.028618+00
5752	disk_usage	7	{}	2025-10-16 23:25:00.029303+00
5753	whatsapp_success_rate	100	{}	2025-10-16 23:25:00.029654+00
5754	disk_usage	7	{}	2025-10-16 23:25:00.03001+00
5755	sla_violation	4	{}	2025-10-16 23:25:00.030823+00
5756	sla_violation	4	{}	2025-10-16 23:25:00.03192+00
5757	whatsapp_success_rate	100	{}	2025-10-16 23:25:00.032146+00
5758	whatsapp_success_rate	100	{}	2025-10-16 23:25:00.033693+00
5759	sla_violation	4	{}	2025-10-16 23:25:00.035416+00
5760	sla_violation	4	{}	2025-10-16 23:25:00.036063+00
5761	memory_usage	19.47150230407715	{}	2025-10-16 23:30:00.027625+00
5762	memory_usage	19.47164535522461	{}	2025-10-16 23:30:00.027889+00
5763	memory_usage	19.484281539916992	{}	2025-10-16 23:30:00.030704+00
5764	memory_usage	19.507122039794922	{}	2025-10-16 23:30:00.031597+00
5765	disk_usage	7	{}	2025-10-16 23:30:00.035701+00
5766	disk_usage	7	{}	2025-10-16 23:30:00.037498+00
5767	disk_usage	7	{}	2025-10-16 23:30:00.038017+00
5768	disk_usage	7	{}	2025-10-16 23:30:00.038332+00
5769	whatsapp_success_rate	100	{}	2025-10-16 23:30:00.03949+00
5770	whatsapp_success_rate	100	{}	2025-10-16 23:30:00.040582+00
5771	whatsapp_success_rate	100	{}	2025-10-16 23:30:00.040727+00
5772	whatsapp_success_rate	100	{}	2025-10-16 23:30:00.040922+00
5773	sla_violation	4	{}	2025-10-16 23:30:00.041851+00
5774	sla_violation	4	{}	2025-10-16 23:30:00.042675+00
5775	sla_violation	4	{}	2025-10-16 23:30:00.043191+00
5776	sla_violation	4	{}	2025-10-16 23:30:00.043267+00
5777	memory_usage	19.48246955871582	{}	2025-10-16 23:35:00.017455+00
5778	memory_usage	19.48246955871582	{}	2025-10-16 23:35:00.018117+00
5779	memory_usage	19.48246955871582	{}	2025-10-16 23:35:00.01855+00
5780	memory_usage	19.51756477355957	{}	2025-10-16 23:35:00.021624+00
5781	disk_usage	7	{}	2025-10-16 23:35:00.024389+00
5782	disk_usage	7	{}	2025-10-16 23:35:00.024701+00
5783	disk_usage	7	{}	2025-10-16 23:35:00.02502+00
5784	whatsapp_success_rate	100	{}	2025-10-16 23:35:00.026942+00
5785	whatsapp_success_rate	100	{}	2025-10-16 23:35:00.027789+00
5786	whatsapp_success_rate	100	{}	2025-10-16 23:35:00.028078+00
5787	disk_usage	7	{}	2025-10-16 23:35:00.028505+00
5788	sla_violation	4	{}	2025-10-16 23:35:00.029143+00
5789	sla_violation	4	{}	2025-10-16 23:35:00.03011+00
5790	sla_violation	4	{}	2025-10-16 23:35:00.030533+00
5791	whatsapp_success_rate	100	{}	2025-10-16 23:35:00.030972+00
5792	sla_violation	4	{}	2025-10-16 23:35:00.033569+00
5793	memory_usage	19.472837448120117	{}	2025-10-16 23:40:00.016862+00
5794	memory_usage	19.472837448120117	{}	2025-10-16 23:40:00.017983+00
5795	memory_usage	19.472837448120117	{}	2025-10-16 23:40:00.018929+00
5796	memory_usage	19.480037689208984	{}	2025-10-16 23:40:00.019627+00
5797	disk_usage	7	{}	2025-10-16 23:40:00.02503+00
5798	disk_usage	7	{}	2025-10-16 23:40:00.025144+00
5799	disk_usage	7	{}	2025-10-16 23:40:00.025423+00
5800	disk_usage	7	{}	2025-10-16 23:40:00.025571+00
5801	whatsapp_success_rate	100	{}	2025-10-16 23:40:00.027744+00
5802	whatsapp_success_rate	100	{}	2025-10-16 23:40:00.02804+00
5803	whatsapp_success_rate	100	{}	2025-10-16 23:40:00.028043+00
5804	whatsapp_success_rate	100	{}	2025-10-16 23:40:00.028287+00
5805	sla_violation	4	{}	2025-10-16 23:40:00.030131+00
5806	sla_violation	4	{}	2025-10-16 23:40:00.030693+00
5807	sla_violation	4	{}	2025-10-16 23:40:00.030702+00
5808	sla_violation	4	{}	2025-10-16 23:40:00.030969+00
5809	memory_usage	19.482421875	{}	2025-10-16 23:45:00.030079+00
5810	memory_usage	19.52047348022461	{}	2025-10-16 23:45:00.032274+00
5811	memory_usage	19.484329223632812	{}	2025-10-16 23:45:00.032854+00
5812	disk_usage	7	{}	2025-10-16 23:45:00.03911+00
5813	memory_usage	19.52047348022461	{}	2025-10-16 23:45:00.038922+00
5814	disk_usage	7	{}	2025-10-16 23:45:00.039711+00
5815	disk_usage	7	{}	2025-10-16 23:45:00.039721+00
5816	whatsapp_success_rate	100	{}	2025-10-16 23:45:00.041832+00
5817	whatsapp_success_rate	100	{}	2025-10-16 23:45:00.042059+00
5818	whatsapp_success_rate	100	{}	2025-10-16 23:45:00.042493+00
5819	sla_violation	4	{}	2025-10-16 23:45:00.044248+00
5820	sla_violation	4	{}	2025-10-16 23:45:00.044587+00
5821	disk_usage	7	{}	2025-10-16 23:45:00.045857+00
5822	sla_violation	4	{}	2025-10-16 23:45:00.046939+00
5823	whatsapp_success_rate	100	{}	2025-10-16 23:45:00.049611+00
5824	sla_violation	4	{}	2025-10-16 23:45:00.052721+00
5825	memory_usage	19.480609893798828	{}	2025-10-16 23:50:00.017956+00
5826	memory_usage	19.480609893798828	{}	2025-10-16 23:50:00.018213+00
5827	memory_usage	19.480609893798828	{}	2025-10-16 23:50:00.019258+00
5828	memory_usage	19.480609893798828	{}	2025-10-16 23:50:00.01977+00
5829	disk_usage	7	{}	2025-10-16 23:50:00.025165+00
5830	disk_usage	7	{}	2025-10-16 23:50:00.025168+00
5831	disk_usage	7	{}	2025-10-16 23:50:00.025271+00
5832	disk_usage	7	{}	2025-10-16 23:50:00.026457+00
5833	whatsapp_success_rate	100	{}	2025-10-16 23:50:00.027683+00
5834	whatsapp_success_rate	100	{}	2025-10-16 23:50:00.027956+00
5835	whatsapp_success_rate	100	{}	2025-10-16 23:50:00.028294+00
5836	whatsapp_success_rate	100	{}	2025-10-16 23:50:00.028785+00
5837	sla_violation	4	{}	2025-10-16 23:50:00.030047+00
5838	sla_violation	4	{}	2025-10-16 23:50:00.030442+00
5839	sla_violation	4	{}	2025-10-16 23:50:00.031172+00
5840	sla_violation	4	{}	2025-10-16 23:50:00.031304+00
5841	memory_usage	19.47479248046875	{}	2025-10-16 23:55:00.018683+00
5842	memory_usage	19.47484016418457	{}	2025-10-16 23:55:00.018709+00
5843	memory_usage	19.474267959594727	{}	2025-10-16 23:55:00.019092+00
5844	memory_usage	19.47479248046875	{}	2025-10-16 23:55:00.022742+00
5845	disk_usage	7	{}	2025-10-16 23:55:00.025942+00
5846	disk_usage	7	{}	2025-10-16 23:55:00.026353+00
5847	disk_usage	7	{}	2025-10-16 23:55:00.026578+00
5848	whatsapp_success_rate	100	{}	2025-10-16 23:55:00.028504+00
5849	whatsapp_success_rate	100	{}	2025-10-16 23:55:00.028719+00
5850	disk_usage	7	{}	2025-10-16 23:55:00.028921+00
5851	sla_violation	4	{}	2025-10-16 23:55:00.030676+00
5852	whatsapp_success_rate	100	{}	2025-10-16 23:55:00.030706+00
5853	sla_violation	4	{}	2025-10-16 23:55:00.030988+00
5854	whatsapp_success_rate	100	{}	2025-10-16 23:55:00.033131+00
5855	sla_violation	4	{}	2025-10-16 23:55:00.033595+00
5856	sla_violation	4	{}	2025-10-16 23:55:00.035307+00
5857	memory_usage	19.52509880065918	{}	2025-10-17 00:00:00.028294+00
5858	memory_usage	19.507789611816406	{}	2025-10-17 00:00:00.028351+00
5859	memory_usage	19.519662857055664	{}	2025-10-17 00:00:00.030621+00
5860	memory_usage	19.52509880065918	{}	2025-10-17 00:00:00.032318+00
5861	disk_usage	7	{}	2025-10-17 00:00:00.035959+00
5862	disk_usage	7	{}	2025-10-17 00:00:00.036527+00
5863	disk_usage	7	{}	2025-10-17 00:00:00.038879+00
5864	whatsapp_success_rate	100	{}	2025-10-17 00:00:00.039144+00
5865	disk_usage	7	{}	2025-10-17 00:00:00.039224+00
5866	whatsapp_success_rate	100	{}	2025-10-17 00:00:00.039603+00
5867	whatsapp_success_rate	100	{}	2025-10-17 00:00:00.041388+00
5868	sla_violation	4	{}	2025-10-17 00:00:00.041626+00
5869	whatsapp_success_rate	100	{}	2025-10-17 00:00:00.041771+00
5870	sla_violation	4	{}	2025-10-17 00:00:00.041936+00
5871	sla_violation	4	{}	2025-10-17 00:00:00.043594+00
5872	sla_violation	4	{}	2025-10-17 00:00:00.044557+00
5873	memory_usage	19.74811553955078	{}	2025-10-17 00:05:00.017776+00
5874	memory_usage	19.75417137145996	{}	2025-10-17 00:05:00.018189+00
5875	memory_usage	19.75417137145996	{}	2025-10-17 00:05:00.018478+00
5876	memory_usage	19.754505157470703	{}	2025-10-17 00:05:00.019382+00
5877	disk_usage	7	{}	2025-10-17 00:05:00.024836+00
5878	disk_usage	7	{}	2025-10-17 00:05:00.025448+00
5879	disk_usage	7	{}	2025-10-17 00:05:00.025607+00
5880	disk_usage	7	{}	2025-10-17 00:05:00.026062+00
5881	whatsapp_success_rate	100	{}	2025-10-17 00:05:00.027485+00
5882	whatsapp_success_rate	100	{}	2025-10-17 00:05:00.028108+00
5883	whatsapp_success_rate	100	{}	2025-10-17 00:05:00.028366+00
5884	whatsapp_success_rate	100	{}	2025-10-17 00:05:00.028464+00
5885	sla_violation	4	{}	2025-10-17 00:05:00.029856+00
5886	sla_violation	4	{}	2025-10-17 00:05:00.030514+00
5887	sla_violation	4	{}	2025-10-17 00:05:00.030944+00
5888	sla_violation	4	{}	2025-10-17 00:05:00.030947+00
5889	memory_usage	19.757413864135742	{}	2025-10-17 00:10:00.017762+00
5890	memory_usage	19.757413864135742	{}	2025-10-17 00:10:00.018024+00
5891	memory_usage	19.760799407958984	{}	2025-10-17 00:10:00.018599+00
5892	memory_usage	19.757413864135742	{}	2025-10-17 00:10:00.018663+00
5894	disk_usage	7	{}	2025-10-17 00:10:00.025486+00
5895	disk_usage	7	{}	2025-10-17 00:10:00.026053+00
5896	disk_usage	7	{}	2025-10-17 00:10:00.026143+00
5898	whatsapp_success_rate	100	{}	2025-10-17 00:10:00.028074+00
5899	whatsapp_success_rate	100	{}	2025-10-17 00:10:00.028222+00
5900	whatsapp_success_rate	100	{}	2025-10-17 00:10:00.028724+00
5902	sla_violation	4	{}	2025-10-17 00:10:00.030811+00
5903	sla_violation	4	{}	2025-10-17 00:10:00.030818+00
5904	sla_violation	4	{}	2025-10-17 00:10:00.031016+00
5893	disk_usage	7	{}	2025-10-17 00:10:00.024891+00
5897	whatsapp_success_rate	100	{}	2025-10-17 00:10:00.028015+00
5901	sla_violation	4	{}	2025-10-17 00:10:00.030361+00
5905	memory_usage	19.771575927734375	{}	2025-10-17 00:15:00.029661+00
5906	memory_usage	19.78163719177246	{}	2025-10-17 00:15:00.030003+00
5907	memory_usage	19.771575927734375	{}	2025-10-17 00:15:00.031147+00
5908	memory_usage	19.858407974243164	{}	2025-10-17 00:15:00.033642+00
5909	disk_usage	7	{}	2025-10-17 00:15:00.038999+00
5910	disk_usage	7	{}	2025-10-17 00:15:00.039513+00
5911	disk_usage	7	{}	2025-10-17 00:15:00.040492+00
5912	disk_usage	7	{}	2025-10-17 00:15:00.040609+00
5913	whatsapp_success_rate	100	{}	2025-10-17 00:15:00.043571+00
5914	whatsapp_success_rate	100	{}	2025-10-17 00:15:00.043913+00
5915	whatsapp_success_rate	100	{}	2025-10-17 00:15:00.044191+00
5916	whatsapp_success_rate	100	{}	2025-10-17 00:15:00.044503+00
5917	sla_violation	4	{}	2025-10-17 00:15:00.046159+00
5918	sla_violation	4	{}	2025-10-17 00:15:00.046946+00
5919	sla_violation	4	{}	2025-10-17 00:15:00.04838+00
5920	sla_violation	4	{}	2025-10-17 00:15:00.048454+00
5922	memory_usage	19.7873592376709	{}	2025-10-17 00:20:00.017759+00
5921	memory_usage	19.7873592376709	{}	2025-10-17 00:20:00.01775+00
5923	memory_usage	19.786787033081055	{}	2025-10-17 00:20:00.018484+00
5924	memory_usage	19.798946380615234	{}	2025-10-17 00:20:00.019974+00
5925	disk_usage	7	{}	2025-10-17 00:20:00.025721+00
5926	disk_usage	7	{}	2025-10-17 00:20:00.02617+00
5927	disk_usage	7	{}	2025-10-17 00:20:00.026793+00
5928	disk_usage	7	{}	2025-10-17 00:20:00.026792+00
5929	whatsapp_success_rate	100	{}	2025-10-17 00:20:00.028368+00
5930	whatsapp_success_rate	100	{}	2025-10-17 00:20:00.028574+00
5931	whatsapp_success_rate	100	{}	2025-10-17 00:20:00.029668+00
5932	whatsapp_success_rate	100	{}	2025-10-17 00:20:00.029964+00
5933	sla_violation	4	{}	2025-10-17 00:20:00.030624+00
5934	sla_violation	4	{}	2025-10-17 00:20:00.031675+00
5935	sla_violation	4	{}	2025-10-17 00:20:00.031873+00
5936	sla_violation	4	{}	2025-10-17 00:20:00.032417+00
5937	memory_usage	19.82722282409668	{}	2025-10-17 00:25:00.017816+00
5938	memory_usage	19.82722282409668	{}	2025-10-17 00:25:00.01765+00
5939	memory_usage	19.846105575561523	{}	2025-10-17 00:25:00.023155+00
5940	disk_usage	7	{}	2025-10-17 00:25:00.025367+00
5941	disk_usage	7	{}	2025-10-17 00:25:00.027101+00
5942	memory_usage	19.86708641052246	{}	2025-10-17 00:25:00.027242+00
5943	whatsapp_success_rate	100	{}	2025-10-17 00:25:00.028004+00
5944	disk_usage	7	{}	2025-10-17 00:25:00.029895+00
5945	whatsapp_success_rate	100	{}	2025-10-17 00:25:00.030134+00
5946	sla_violation	4	{}	2025-10-17 00:25:00.030711+00
5947	sla_violation	4	{}	2025-10-17 00:25:00.032683+00
5948	disk_usage	7	{}	2025-10-17 00:25:00.033779+00
5949	whatsapp_success_rate	100	{}	2025-10-17 00:25:00.033962+00
5950	whatsapp_success_rate	100	{}	2025-10-17 00:25:00.036329+00
5951	sla_violation	4	{}	2025-10-17 00:25:00.036625+00
5952	sla_violation	4	{}	2025-10-17 00:25:00.038482+00
5953	memory_usage	19.767236709594727	{}	2025-10-17 00:30:00.023037+00
5954	memory_usage	19.796228408813477	{}	2025-10-17 00:30:00.030595+00
5955	memory_usage	19.804048538208008	{}	2025-10-17 00:30:00.031296+00
5956	disk_usage	7	{}	2025-10-17 00:30:00.03231+00
5957	memory_usage	19.823932647705078	{}	2025-10-17 00:30:00.032608+00
5958	whatsapp_success_rate	100	{}	2025-10-17 00:30:00.037233+00
5959	disk_usage	7	{}	2025-10-17 00:30:00.037661+00
5960	disk_usage	7	{}	2025-10-17 00:30:00.039039+00
5961	sla_violation	4	{}	2025-10-17 00:30:00.039927+00
5962	whatsapp_success_rate	100	{}	2025-10-17 00:30:00.040464+00
5963	disk_usage	7	{}	2025-10-17 00:30:00.040746+00
5964	whatsapp_success_rate	100	{}	2025-10-17 00:30:00.042017+00
5965	sla_violation	4	{}	2025-10-17 00:30:00.043396+00
5966	sla_violation	4	{}	2025-10-17 00:30:00.044053+00
5967	whatsapp_success_rate	100	{}	2025-10-17 00:30:00.045511+00
5968	sla_violation	4	{}	2025-10-17 00:30:00.047888+00
5969	memory_usage	19.80266571044922	{}	2025-10-17 00:35:00.017517+00
5970	memory_usage	19.80266571044922	{}	2025-10-17 00:35:00.018755+00
5971	memory_usage	19.809484481811523	{}	2025-10-17 00:35:00.020625+00
5972	memory_usage	19.79975700378418	{}	2025-10-17 00:35:00.020803+00
5973	disk_usage	7	{}	2025-10-17 00:35:00.025154+00
5974	disk_usage	7	{}	2025-10-17 00:35:00.026095+00
5975	disk_usage	7	{}	2025-10-17 00:35:00.027164+00
5976	disk_usage	7	{}	2025-10-17 00:35:00.028013+00
5977	whatsapp_success_rate	100	{}	2025-10-17 00:35:00.028786+00
5978	whatsapp_success_rate	100	{}	2025-10-17 00:35:00.02945+00
5979	whatsapp_success_rate	100	{}	2025-10-17 00:35:00.029801+00
5980	whatsapp_success_rate	100	{}	2025-10-17 00:35:00.030352+00
5981	sla_violation	4	{}	2025-10-17 00:35:00.03107+00
5982	sla_violation	4	{}	2025-10-17 00:35:00.031559+00
5983	sla_violation	4	{}	2025-10-17 00:35:00.032603+00
5984	sla_violation	4	{}	2025-10-17 00:35:00.033017+00
5985	memory_usage	19.728374481201172	{}	2025-10-17 00:40:00.017648+00
5986	memory_usage	19.728374481201172	{}	2025-10-17 00:40:00.018072+00
5987	memory_usage	19.73438262939453	{}	2025-10-17 00:40:00.018374+00
5988	memory_usage	19.728374481201172	{}	2025-10-17 00:40:00.021885+00
5989	disk_usage	7	{}	2025-10-17 00:40:00.024908+00
5990	disk_usage	7	{}	2025-10-17 00:40:00.026312+00
5991	disk_usage	7	{}	2025-10-17 00:40:00.026709+00
5992	whatsapp_success_rate	100	{}	2025-10-17 00:40:00.027457+00
5993	disk_usage	7	{}	2025-10-17 00:40:00.027874+00
5994	whatsapp_success_rate	100	{}	2025-10-17 00:40:00.028994+00
5995	whatsapp_success_rate	100	{}	2025-10-17 00:40:00.029528+00
5996	sla_violation	4	{}	2025-10-17 00:40:00.029971+00
5997	whatsapp_success_rate	100	{}	2025-10-17 00:40:00.030711+00
5998	sla_violation	4	{}	2025-10-17 00:40:00.031159+00
5999	sla_violation	4	{}	2025-10-17 00:40:00.031917+00
6000	sla_violation	4	{}	2025-10-17 00:40:00.033139+00
6001	memory_usage	19.773483276367188	{}	2025-10-17 00:45:00.028991+00
6002	memory_usage	19.772815704345703	{}	2025-10-17 00:45:00.031379+00
6003	memory_usage	19.772815704345703	{}	2025-10-17 00:45:00.032604+00
6004	memory_usage	19.81353759765625	{}	2025-10-17 00:45:00.034435+00
6005	disk_usage	7	{}	2025-10-17 00:45:00.040239+00
6006	disk_usage	7	{}	2025-10-17 00:45:00.040419+00
6007	disk_usage	7	{}	2025-10-17 00:45:00.040426+00
6008	disk_usage	7	{}	2025-10-17 00:45:00.041017+00
6009	whatsapp_success_rate	100	{}	2025-10-17 00:45:00.044412+00
6010	whatsapp_success_rate	100	{}	2025-10-17 00:45:00.044429+00
6011	whatsapp_success_rate	100	{}	2025-10-17 00:45:00.044439+00
6012	whatsapp_success_rate	100	{}	2025-10-17 00:45:00.045638+00
6013	sla_violation	4	{}	2025-10-17 00:45:00.046801+00
6014	sla_violation	4	{}	2025-10-17 00:45:00.047363+00
6015	sla_violation	4	{}	2025-10-17 00:45:00.04754+00
6016	sla_violation	4	{}	2025-10-17 00:45:00.04803+00
6017	memory_usage	19.7659969329834	{}	2025-10-17 00:50:00.017351+00
6018	memory_usage	19.7659969329834	{}	2025-10-17 00:50:00.01763+00
6019	memory_usage	19.7659969329834	{}	2025-10-17 00:50:00.017964+00
6020	memory_usage	19.770240783691406	{}	2025-10-17 00:50:00.020085+00
6021	disk_usage	7	{}	2025-10-17 00:50:00.024848+00
6022	disk_usage	7	{}	2025-10-17 00:50:00.024999+00
6023	disk_usage	7	{}	2025-10-17 00:50:00.025137+00
6024	disk_usage	7	{}	2025-10-17 00:50:00.025952+00
6025	whatsapp_success_rate	100	{}	2025-10-17 00:50:00.027416+00
6026	whatsapp_success_rate	100	{}	2025-10-17 00:50:00.02769+00
6027	whatsapp_success_rate	100	{}	2025-10-17 00:50:00.02776+00
6028	whatsapp_success_rate	100	{}	2025-10-17 00:50:00.028476+00
6029	sla_violation	4	{}	2025-10-17 00:50:00.029639+00
6030	sla_violation	4	{}	2025-10-17 00:50:00.030027+00
6031	sla_violation	4	{}	2025-10-17 00:50:00.030071+00
6032	sla_violation	4	{}	2025-10-17 00:50:00.030707+00
6033	memory_usage	19.757461547851562	{}	2025-10-17 00:55:00.019157+00
6034	memory_usage	19.757461547851562	{}	2025-10-17 00:55:00.019246+00
6035	memory_usage	19.78626251220703	{}	2025-10-17 00:55:00.022472+00
6036	memory_usage	19.784021377563477	{}	2025-10-17 00:55:00.024319+00
6037	disk_usage	7	{}	2025-10-17 00:55:00.026879+00
6038	disk_usage	7	{}	2025-10-17 00:55:00.027627+00
6039	disk_usage	7	{}	2025-10-17 00:55:00.028533+00
6040	whatsapp_success_rate	100	{}	2025-10-17 00:55:00.030213+00
6041	whatsapp_success_rate	100	{}	2025-10-17 00:55:00.030278+00
6042	disk_usage	7	{}	2025-10-17 00:55:00.030612+00
6043	whatsapp_success_rate	100	{}	2025-10-17 00:55:00.030831+00
6044	sla_violation	4	{}	2025-10-17 00:55:00.032502+00
6045	sla_violation	4	{}	2025-10-17 00:55:00.032943+00
6046	whatsapp_success_rate	100	{}	2025-10-17 00:55:00.03298+00
6047	sla_violation	4	{}	2025-10-17 00:55:00.033275+00
6048	sla_violation	4	{}	2025-10-17 00:55:00.036285+00
6049	memory_usage	19.78898048400879	{}	2025-10-17 01:00:00.038674+00
6050	memory_usage	19.77715492248535	{}	2025-10-17 01:00:00.043486+00
6051	memory_usage	19.792556762695312	{}	2025-10-17 01:00:00.046601+00
6052	disk_usage	7	{}	2025-10-17 01:00:00.04745+00
6053	memory_usage	19.789743423461914	{}	2025-10-17 01:00:00.048206+00
6054	disk_usage	7	{}	2025-10-17 01:00:00.051428+00
6055	whatsapp_success_rate	100	{}	2025-10-17 01:00:00.053786+00
6056	whatsapp_success_rate	100	{}	2025-10-17 01:00:00.055427+00
6057	disk_usage	7	{}	2025-10-17 01:00:00.055482+00
6058	disk_usage	7	{}	2025-10-17 01:00:00.055782+00
6059	sla_violation	4	{}	2025-10-17 01:00:00.056879+00
6060	whatsapp_success_rate	100	{}	2025-10-17 01:00:00.05823+00
6061	whatsapp_success_rate	100	{}	2025-10-17 01:00:00.058357+00
6062	sla_violation	4	{}	2025-10-17 01:00:00.059048+00
6063	sla_violation	4	{}	2025-10-17 01:00:00.061339+00
6064	sla_violation	4	{}	2025-10-17 01:00:00.061468+00
6065	memory_usage	20.04528045654297	{}	2025-10-17 01:05:00.016704+00
6066	memory_usage	20.04528045654297	{}	2025-10-17 01:05:00.016808+00
6067	memory_usage	20.054292678833008	{}	2025-10-17 01:05:00.018493+00
6068	disk_usage	7	{}	2025-10-17 01:05:00.023888+00
6069	disk_usage	7	{}	2025-10-17 01:05:00.024244+00
6070	memory_usage	20.075464248657227	{}	2025-10-17 01:05:00.02447+00
6071	disk_usage	7	{}	2025-10-17 01:05:00.025757+00
6072	whatsapp_success_rate	100	{}	2025-10-17 01:05:00.026622+00
6073	whatsapp_success_rate	100	{}	2025-10-17 01:05:00.026882+00
6074	whatsapp_success_rate	100	{}	2025-10-17 01:05:00.028568+00
6075	sla_violation	4	{}	2025-10-17 01:05:00.028767+00
6076	sla_violation	4	{}	2025-10-17 01:05:00.029115+00
6077	disk_usage	7	{}	2025-10-17 01:05:00.030138+00
6078	sla_violation	4	{}	2025-10-17 01:05:00.031484+00
6079	whatsapp_success_rate	100	{}	2025-10-17 01:05:00.032998+00
6080	sla_violation	4	{}	2025-10-17 01:05:00.03556+00
6081	memory_usage	20.023727416992188	{}	2025-10-17 01:10:00.0174+00
6082	memory_usage	20.023727416992188	{}	2025-10-17 01:10:00.017356+00
6083	memory_usage	20.007753372192383	{}	2025-10-17 01:10:00.018278+00
6084	memory_usage	20.053434371948242	{}	2025-10-17 01:10:00.024249+00
6085	disk_usage	7	{}	2025-10-17 01:10:00.024822+00
6086	disk_usage	7	{}	2025-10-17 01:10:00.025036+00
6087	disk_usage	7	{}	2025-10-17 01:10:00.025186+00
6088	whatsapp_success_rate	100	{}	2025-10-17 01:10:00.02797+00
6090	whatsapp_success_rate	100	{}	2025-10-17 01:10:00.027976+00
6089	whatsapp_success_rate	100	{}	2025-10-17 01:10:00.02797+00
6091	disk_usage	7	{}	2025-10-17 01:10:00.030129+00
6092	sla_violation	4	{}	2025-10-17 01:10:00.030684+00
6093	sla_violation	4	{}	2025-10-17 01:10:00.034119+00
6094	sla_violation	4	{}	2025-10-17 01:10:00.03456+00
6095	whatsapp_success_rate	100	{}	2025-10-17 01:10:00.03518+00
6096	sla_violation	4	{}	2025-10-17 01:10:00.037799+00
6097	memory_usage	20.036649703979492	{}	2025-10-17 01:15:00.026545+00
6098	memory_usage	20.047378540039062	{}	2025-10-17 01:15:00.029544+00
6099	memory_usage	20.044422149658203	{}	2025-10-17 01:15:00.029789+00
6101	disk_usage	7	{}	2025-10-17 01:15:00.034416+00
6100	memory_usage	20.111703872680664	{}	2025-10-17 01:15:00.033899+00
6102	disk_usage	7	{}	2025-10-17 01:15:00.037913+00
6103	disk_usage	7	{}	2025-10-17 01:15:00.038207+00
6104	whatsapp_success_rate	100	{}	2025-10-17 01:15:00.039195+00
6105	whatsapp_success_rate	100	{}	2025-10-17 01:15:00.040555+00
6106	whatsapp_success_rate	100	{}	2025-10-17 01:15:00.041394+00
6107	disk_usage	7	{}	2025-10-17 01:15:00.042285+00
6108	sla_violation	4	{}	2025-10-17 01:15:00.042563+00
6109	sla_violation	4	{}	2025-10-17 01:15:00.042779+00
6110	sla_violation	4	{}	2025-10-17 01:15:00.043534+00
6111	whatsapp_success_rate	100	{}	2025-10-17 01:15:00.045098+00
6112	sla_violation	4	{}	2025-10-17 01:15:00.047487+00
6113	memory_usage	20.04861831665039	{}	2025-10-17 01:20:00.018004+00
6114	memory_usage	20.047378540039062	{}	2025-10-17 01:20:00.018427+00
6115	memory_usage	20.047378540039062	{}	2025-10-17 01:20:00.019533+00
6116	memory_usage	20.090723037719727	{}	2025-10-17 01:20:00.023636+00
6117	disk_usage	7	{}	2025-10-17 01:20:00.025738+00
6118	disk_usage	7	{}	2025-10-17 01:20:00.025797+00
6119	disk_usage	7	{}	2025-10-17 01:20:00.026157+00
6120	whatsapp_success_rate	100	{}	2025-10-17 01:20:00.028491+00
6121	whatsapp_success_rate	100	{}	2025-10-17 01:20:00.028528+00
6122	whatsapp_success_rate	100	{}	2025-10-17 01:20:00.028698+00
6123	sla_violation	4	{}	2025-10-17 01:20:00.030708+00
6124	disk_usage	7	{}	2025-10-17 01:20:00.030769+00
6125	sla_violation	4	{}	2025-10-17 01:20:00.031138+00
6126	sla_violation	4	{}	2025-10-17 01:20:00.03117+00
6127	whatsapp_success_rate	100	{}	2025-10-17 01:20:00.034012+00
6128	sla_violation	4	{}	2025-10-17 01:20:00.0366+00
6129	memory_usage	20.041275024414062	{}	2025-10-17 01:25:00.017949+00
6134	disk_usage	7	{}	2025-10-17 01:25:00.026427+00
6138	whatsapp_success_rate	100	{}	2025-10-17 01:25:00.029368+00
6141	sla_violation	4	{}	2025-10-17 01:25:00.03202+00
6131	memory_usage	20.04384994506836	{}	2025-10-17 01:25:00.019135+00
6135	disk_usage	7	{}	2025-10-17 01:25:00.026678+00
6137	whatsapp_success_rate	100	{}	2025-10-17 01:25:00.029368+00
6142	sla_violation	4	{}	2025-10-17 01:25:00.032033+00
6211	memory_usage	20.09720802307129	{}	2025-10-17 01:50:00.018816+00
6212	disk_usage	7	{}	2025-10-17 01:50:00.024802+00
6216	whatsapp_success_rate	100	{}	2025-10-17 01:50:00.027823+00
6219	sla_violation	4	{}	2025-10-17 01:50:00.031423+00
6132	memory_usage	20.08352279663086	{}	2025-10-17 01:25:00.022602+00
6139	disk_usage	7	{}	2025-10-17 01:25:00.029915+00
6143	whatsapp_success_rate	100	{}	2025-10-17 01:25:00.032488+00
6144	sla_violation	4	{}	2025-10-17 01:25:00.035031+00
6214	memory_usage	20.128440856933594	{}	2025-10-17 01:50:00.02497+00
6220	disk_usage	7	{}	2025-10-17 01:50:00.032145+00
6223	whatsapp_success_rate	100	{}	2025-10-17 01:50:00.036116+00
6224	sla_violation	4	{}	2025-10-17 01:50:00.039402+00
6145	memory_usage	20.052623748779297	{}	2025-10-17 01:30:00.026284+00
6149	disk_usage	7	{}	2025-10-17 01:30:00.035278+00
6152	whatsapp_success_rate	100	{}	2025-10-17 01:30:00.038147+00
6156	sla_violation	4	{}	2025-10-17 01:30:00.040751+00
6225	memory_usage	20.067501068115234	{}	2025-10-17 01:55:00.018307+00
6230	disk_usage	7	{}	2025-10-17 01:55:00.027043+00
6232	whatsapp_success_rate	100	{}	2025-10-17 01:55:00.031918+00
6236	sla_violation	4	{}	2025-10-17 01:55:00.038502+00
6146	memory_usage	20.054006576538086	{}	2025-10-17 01:30:00.02796+00
6150	disk_usage	7	{}	2025-10-17 01:30:00.036315+00
6153	whatsapp_success_rate	100	{}	2025-10-17 01:30:00.039053+00
6157	sla_violation	4	{}	2025-10-17 01:30:00.041195+00
6226	memory_usage	20.066261291503906	{}	2025-10-17 01:55:00.018678+00
6227	disk_usage	7	{}	2025-10-17 01:55:00.02524+00
6231	whatsapp_success_rate	100	{}	2025-10-17 01:55:00.027927+00
6234	sla_violation	4	{}	2025-10-17 01:55:00.032956+00
6147	memory_usage	20.06983757019043	{}	2025-10-17 01:30:00.029652+00
6151	disk_usage	7	{}	2025-10-17 01:30:00.036738+00
6155	whatsapp_success_rate	100	{}	2025-10-17 01:30:00.03996+00
6158	sla_violation	4	{}	2025-10-17 01:30:00.042519+00
6228	memory_usage	20.0864315032959	{}	2025-10-17 01:55:00.025835+00
6233	disk_usage	7	{}	2025-10-17 01:55:00.032205+00
6238	whatsapp_success_rate	100	{}	2025-10-17 01:55:00.040292+00
6240	sla_violation	4	{}	2025-10-17 01:55:00.043267+00
6148	memory_usage	20.11885643005371	{}	2025-10-17 01:30:00.030648+00
6154	disk_usage	7	{}	2025-10-17 01:30:00.039833+00
6159	whatsapp_success_rate	100	{}	2025-10-17 01:30:00.044298+00
6160	sla_violation	4	{}	2025-10-17 01:30:00.046375+00
6229	memory_usage	20.090246200561523	{}	2025-10-17 01:55:00.025977+00
6235	disk_usage	7	{}	2025-10-17 01:55:00.033035+00
6237	whatsapp_success_rate	100	{}	2025-10-17 01:55:00.03928+00
6239	sla_violation	4	{}	2025-10-17 01:55:00.041842+00
6161	memory_usage	20.093727111816406	{}	2025-10-17 01:35:00.017788+00
6165	disk_usage	7	{}	2025-10-17 01:35:00.025234+00
6167	whatsapp_success_rate	100	{}	2025-10-17 01:35:00.027865+00
6170	sla_violation	4	{}	2025-10-17 01:35:00.030142+00
6241	memory_usage	20.08991241455078	{}	2025-10-17 02:00:00.030789+00
6245	disk_usage	7	{}	2025-10-17 02:00:00.038682+00
6246	whatsapp_success_rate	100	{}	2025-10-17 02:00:00.042648+00
6248	sla_violation	4	{}	2025-10-17 02:00:00.045021+00
6162	memory_usage	20.093727111816406	{}	2025-10-17 01:35:00.017863+00
6166	disk_usage	7	{}	2025-10-17 01:35:00.025611+00
6168	whatsapp_success_rate	100	{}	2025-10-17 01:35:00.02829+00
6172	sla_violation	4	{}	2025-10-17 01:35:00.031055+00
6242	memory_usage	20.07889747619629	{}	2025-10-17 02:00:00.033729+00
6247	disk_usage	7	{}	2025-10-17 02:00:00.043553+00
6252	whatsapp_success_rate	100	{}	2025-10-17 02:00:00.049935+00
6255	sla_violation	4	{}	2025-10-17 02:00:00.052553+00
6163	memory_usage	20.116424560546875	{}	2025-10-17 01:35:00.022672+00
6169	disk_usage	7	{}	2025-10-17 01:35:00.029814+00
6173	whatsapp_success_rate	100	{}	2025-10-17 01:35:00.032675+00
6175	sla_violation	4	{}	2025-10-17 01:35:00.034869+00
6243	memory_usage	20.07889747619629	{}	2025-10-17 02:00:00.035288+00
6250	disk_usage	7	{}	2025-10-17 02:00:00.046375+00
6254	whatsapp_success_rate	100	{}	2025-10-17 02:00:00.05254+00
6256	sla_violation	4	{}	2025-10-17 02:00:00.054973+00
6164	memory_usage	20.113372802734375	{}	2025-10-17 01:35:00.023701+00
6171	disk_usage	7	{}	2025-10-17 01:35:00.030709+00
6174	whatsapp_success_rate	100	{}	2025-10-17 01:35:00.033285+00
6176	sla_violation	4	{}	2025-10-17 01:35:00.035389+00
6244	memory_usage	20.07889747619629	{}	2025-10-17 02:00:00.037194+00
6249	disk_usage	7	{}	2025-10-17 02:00:00.045771+00
6251	whatsapp_success_rate	100	{}	2025-10-17 02:00:00.049906+00
6253	sla_violation	4	{}	2025-10-17 02:00:00.052155+00
6177	memory_usage	20.059871673583984	{}	2025-10-17 01:40:00.017508+00
6183	disk_usage	7	{}	2025-10-17 01:40:00.025359+00
6188	whatsapp_success_rate	100	{}	2025-10-17 01:40:00.028465+00
6190	sla_violation	4	{}	2025-10-17 01:40:00.030595+00
6178	memory_usage	20.058774948120117	{}	2025-10-17 01:40:00.017511+00
6182	disk_usage	7	{}	2025-10-17 01:40:00.025249+00
6187	whatsapp_success_rate	100	{}	2025-10-17 01:40:00.028393+00
6191	sla_violation	4	{}	2025-10-17 01:40:00.030713+00
6179	memory_usage	20.05629539489746	{}	2025-10-17 01:40:00.018161+00
6184	disk_usage	7	{}	2025-10-17 01:40:00.025904+00
6186	whatsapp_success_rate	100	{}	2025-10-17 01:40:00.028234+00
6192	sla_violation	4	{}	2025-10-17 01:40:00.03074+00
6180	memory_usage	20.06230354309082	{}	2025-10-17 01:40:00.018569+00
6181	disk_usage	7	{}	2025-10-17 01:40:00.025038+00
6185	whatsapp_success_rate	100	{}	2025-10-17 01:40:00.027987+00
6189	sla_violation	4	{}	2025-10-17 01:40:00.030171+00
6193	memory_usage	20.023155212402344	{}	2025-10-17 01:45:00.027956+00
6197	disk_usage	7	{}	2025-10-17 01:45:00.03617+00
6200	whatsapp_success_rate	100	{}	2025-10-17 01:45:00.038942+00
6201	sla_violation	4	{}	2025-10-17 01:45:00.0419+00
6194	memory_usage	20.02263069152832	{}	2025-10-17 01:45:00.030417+00
6198	disk_usage	7	{}	2025-10-17 01:45:00.037841+00
6203	whatsapp_success_rate	100	{}	2025-10-17 01:45:00.042843+00
6206	sla_violation	4	{}	2025-10-17 01:45:00.046666+00
6195	memory_usage	20.025634765625	{}	2025-10-17 01:45:00.032402+00
6199	disk_usage	7	{}	2025-10-17 01:45:00.038886+00
6202	whatsapp_success_rate	100	{}	2025-10-17 01:45:00.041981+00
6205	sla_violation	4	{}	2025-10-17 01:45:00.045162+00
6196	memory_usage	20.0167179107666	{}	2025-10-17 01:45:00.035621+00
6204	disk_usage	7	{}	2025-10-17 01:45:00.044894+00
6207	whatsapp_success_rate	100	{}	2025-10-17 01:45:00.047371+00
6208	sla_violation	4	{}	2025-10-17 01:45:00.049894+00
6209	memory_usage	20.09720802307129	{}	2025-10-17 01:50:00.017835+00
6213	disk_usage	7	{}	2025-10-17 01:50:00.025102+00
6217	whatsapp_success_rate	100	{}	2025-10-17 01:50:00.028573+00
6221	sla_violation	4	{}	2025-10-17 01:50:00.032186+00
6210	memory_usage	20.09720802307129	{}	2025-10-17 01:50:00.018259+00
6215	disk_usage	7	{}	2025-10-17 01:50:00.026439+00
6218	whatsapp_success_rate	100	{}	2025-10-17 01:50:00.029933+00
6222	sla_violation	4	{}	2025-10-17 01:50:00.032794+00
6130	memory_usage	20.04384994506836	{}	2025-10-17 01:25:00.017956+00
6133	disk_usage	7	{}	2025-10-17 01:25:00.025937+00
6136	whatsapp_success_rate	100	{}	2025-10-17 01:25:00.029066+00
6140	sla_violation	4	{}	2025-10-17 01:25:00.031614+00
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: aglis_user
--

COPY public.system_settings (id, setting_key, setting_value, description, created_at, updated_at) FROM stdin;
1	invoice_payment_terms	Payment due within 7 days. Late payments may incur additional charges.	Default payment terms for invoices	2025-10-14 14:24:52.020129	2025-10-14 14:24:52.020129
2	invoice_tax_percentage	11.00	Default tax percentage (PPN)	2025-10-14 14:24:52.020129	2025-10-14 14:24:52.020129
3	invoice_due_days	7	Default days until invoice due date	2025-10-14 14:24:52.020129	2025-10-14 14:24:52.020129
4	billing_day_of_month	1	Default day of month for recurring billing	2025-10-14 14:24:52.020129	2025-10-14 14:24:52.020129
5	overdue_reminder_days	3	Days after due date to send overdue reminder	2025-10-14 14:24:52.020129	2025-10-14 14:24:52.020129
\.


--
-- Data for Name: technician_equipment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.technician_equipment (id, technician_id, equipment_type, equipment_name, brand, model, serial_number, condition, assigned_date, return_date, is_active, notes, created_at) FROM stdin;
14	1	vehicle	Service Van	Toyota	Hiace 2022	TV001	excellent	2022-01-15	\N	t	Primary service vehicle	2025-10-13 00:09:00.153392
15	1	tool	Fiber Fusion Splicer	Fujikura	FSM-70S	FS001	good	2022-02-01	\N	t	High-precision splicer	2025-10-13 00:09:00.153392
16	1	tool	OTDR Tester	EXFO	FTB-1v2	OT001	good	2022-02-01	\N	t	Optical time domain reflectometer	2025-10-13 00:09:00.153392
17	1	device	Tablet	Samsung	Galaxy Tab S8	TB001	excellent	2022-01-15	\N	t	Field work tablet	2025-10-13 00:09:00.153392
18	1	safety	Safety Helmet	MSA	V-Gard	SH001	good	2022-01-15	\N	t	Standard safety equipment	2025-10-13 00:09:00.153392
19	2	vehicle	Motorcycle	Honda	Vario 160	MC001	good	2023-03-20	\N	t	Urban mobility	2025-10-13 00:09:00.153392
20	2	tool	WiFi Analyzer	Fluke	AirCheck G2	WA001	excellent	2023-04-01	\N	t	Wireless network analyzer	2025-10-13 00:09:00.153392
21	2	tool	Cable Tester	Klein Tools	VDV501-851	CT001	good	2023-03-20	\N	t	Network cable tester	2025-10-13 00:09:00.153392
22	2	device	Smartphone	Samsung	Galaxy S23	SP001	excellent	2023-03-20	\N	t	Communication device	2025-10-13 00:09:00.153392
23	3	vehicle	Service Truck	Isuzu	ELF 2023	ST001	excellent	2021-06-10	\N	t	Large equipment transport	2025-10-13 00:09:00.153392
24	3	tool	Network Analyzer	Fluke	OptiView XG	NA001	excellent	2021-07-01	\N	t	Enterprise network analyzer	2025-10-13 00:09:00.153392
25	3	tool	Fiber Cleaver	Sumitomo	FC-6S	FC001	good	2021-07-01	\N	t	Precision fiber cleaver	2025-10-13 00:09:00.153392
26	3	device	Laptop	Lenovo	ThinkPad X1	LP001	good	2021-06-10	\N	t	Configuration and diagnostics	2025-10-13 00:09:00.153392
\.


--
-- Data for Name: technician_location_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.technician_location_history (id, technician_id, latitude, longitude, accuracy, speed, heading, activity_type, battery_level, recorded_at) FROM stdin;
8	1	-6.20880000	106.84560000	5.20	0.00	0.00	stationary	85	2025-10-12 23:09:00.154337
9	1	-6.20950000	106.84630000	4.80	25.50	45.20	driving	82	2025-10-12 22:09:00.154337
10	1	-6.21020000	106.84710000	6.10	0.00	0.00	stationary	78	2025-10-12 21:09:00.154337
11	2	-6.22970000	106.81750000	3.90	0.00	0.00	stationary	92	2025-10-12 23:39:00.154337
12	2	-6.22890000	106.81680000	4.20	15.30	120.80	driving	89	2025-10-12 23:09:00.154337
13	3	-6.17510000	106.86500000	2.80	0.00	0.00	stationary	76	2025-10-12 23:24:00.154337
14	3	-6.17580000	106.86570000	3.50	35.70	230.10	driving	73	2025-10-12 22:39:00.154337
\.


--
-- Data for Name: technician_performance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.technician_performance (id, technician_id, period_start, period_end, tickets_assigned, tickets_completed, tickets_cancelled, average_resolution_time, customer_satisfaction_avg, first_time_fix_rate, sla_compliance_rate, travel_time_avg, utilization_rate, supervisor_rating, supervisor_notes, improvement_areas, achievements, created_at, created_by) FROM stdin;
4	1	2025-09-13	2025-10-12	52	50	2	2.30	4.70	92.30	94.50	0.80	87.50	4.80	Excellent performance, consistently meets targets	\N	{"Completed fiber installation project ahead of schedule","Received customer excellence award"}	2025-10-13 00:09:00.152485	\N
5	2	2025-09-13	2025-10-12	35	32	3	3.10	4.40	85.70	89.20	1.20	78.30	4.20	Good progress, improving troubleshooting skills	\N	{"Completed wireless certification","Zero safety incidents"}	2025-10-13 00:09:00.152485	\N
6	3	2025-09-13	2025-10-12	68	66	2	1.80	4.90	97.10	97.80	0.60	92.10	5.00	Outstanding performance, team leader	\N	{"Led successful enterprise deployment","Mentored 3 junior technicians","Perfect SLA compliance"}	2025-10-13 00:09:00.152485	\N
\.


--
-- Data for Name: technician_schedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.technician_schedule (id, technician_id, schedule_date, shift_start, shift_end, break_start, break_end, is_working_day, schedule_type, notes, created_at) FROM stdin;
16	1	2025-10-13	08:00:00	17:00:00	12:00:00	13:00:00	t	regular	\N	2025-10-13 00:09:00.151509
17	1	2025-10-14	08:00:00	17:00:00	12:00:00	13:00:00	t	regular	\N	2025-10-13 00:09:00.151509
18	1	2025-10-15	08:00:00	17:00:00	12:00:00	13:00:00	t	regular	\N	2025-10-13 00:09:00.151509
19	1	2025-10-16	08:00:00	17:00:00	12:00:00	13:00:00	t	regular	\N	2025-10-13 00:09:00.151509
20	1	2025-10-17	08:00:00	17:00:00	12:00:00	13:00:00	t	regular	\N	2025-10-13 00:09:00.151509
21	2	2025-10-13	09:00:00	18:00:00	13:00:00	14:00:00	t	regular	\N	2025-10-13 00:09:00.151509
22	2	2025-10-14	09:00:00	18:00:00	13:00:00	14:00:00	t	regular	\N	2025-10-13 00:09:00.151509
23	2	2025-10-15	09:00:00	18:00:00	13:00:00	14:00:00	t	regular	\N	2025-10-13 00:09:00.151509
24	2	2025-10-16	09:00:00	18:00:00	13:00:00	14:00:00	t	regular	\N	2025-10-13 00:09:00.151509
25	2	2025-10-17	09:00:00	18:00:00	13:00:00	14:00:00	t	regular	\N	2025-10-13 00:09:00.151509
26	3	2025-10-13	07:00:00	19:00:00	12:00:00	13:00:00	t	overtime	\N	2025-10-13 00:09:00.151509
27	3	2025-10-14	08:00:00	17:00:00	12:00:00	13:00:00	t	regular	\N	2025-10-13 00:09:00.151509
28	3	2025-10-15	08:00:00	17:00:00	12:00:00	13:00:00	t	regular	\N	2025-10-13 00:09:00.151509
29	3	2025-10-16	08:00:00	17:00:00	12:00:00	13:00:00	t	regular	\N	2025-10-13 00:09:00.151509
30	3	2025-10-17	10:00:00	22:00:00	15:00:00	16:00:00	t	on_call	\N	2025-10-13 00:09:00.151509
\.


--
-- Data for Name: technician_skills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.technician_skills (id, technician_id, skill_name, skill_category, proficiency_level, acquired_date, verified_by, verification_date, notes, created_at) FROM stdin;
18	1	Fiber Optic Installation	technical	5	2022-02-01	1	2022-02-15	Certified fiber optic specialist	2025-10-13 00:09:00.15012
19	1	Network Troubleshooting	technical	5	2022-01-20	1	2022-02-01	Expert level troubleshooting	2025-10-13 00:09:00.15012
20	1	Customer Communication	soft	4	2022-01-15	1	2022-03-01	Excellent customer service skills	2025-10-13 00:09:00.15012
21	1	OTDR Testing	certification	5	2022-03-10	1	2022-03-15	Certified OTDR operator	2025-10-13 00:09:00.15012
22	2	WiFi Configuration	technical	4	2023-04-01	1	2023-04-15	Proficient in wireless setup	2025-10-13 00:09:00.15012
23	2	Basic Installation	technical	3	2023-03-20	1	2023-04-01	Learning installation procedures	2025-10-13 00:09:00.15012
24	2	Customer Service	soft	4	2023-03-20	1	2023-05-01	Good communication skills	2025-10-13 00:09:00.15012
25	3	Enterprise Networking	technical	5	2021-07-01	1	2021-07-15	Expert in enterprise solutions	2025-10-13 00:09:00.15012
26	3	Network Security	technical	5	2021-08-01	1	2021-08-15	Security specialist	2025-10-13 00:09:00.15012
27	3	Project Management	soft	4	2021-09-01	1	2021-09-15	Leads complex projects	2025-10-13 00:09:00.15012
28	3	CCNA Certification	certification	5	2021-06-15	1	2021-06-20	Cisco certified	2025-10-13 00:09:00.15012
29	4	Corporate Solutions	technical	5	2022-10-01	1	2022-10-15	Specialist in corporate deployments	2025-10-13 00:09:00.15012
30	4	Security Implementation	technical	4	2022-09-15	1	2022-10-01	Security focused solutions	2025-10-13 00:09:00.15012
31	4	Client Management	soft	5	2022-09-05	1	2022-10-01	Excellent client relationships	2025-10-13 00:09:00.15012
32	5	Basic Installation	technical	2	2023-11-20	1	2023-12-01	New technician, learning basics	2025-10-13 00:09:00.15012
33	5	Fiber Splicing	technical	2	2023-12-01	1	2023-12-15	Basic fiber splicing skills	2025-10-13 00:09:00.15012
34	5	Safety Procedures	technical	4	2023-11-12	1	2023-11-15	Strong safety awareness	2025-10-13 00:09:00.15012
\.


--
-- Data for Name: technician_specializations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.technician_specializations (id, technician_id, specialization_id, proficiency_level, years_experience, acquired_date, is_active, created_at, updated_at) FROM stdin;
1	5	7	intermediate	3.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
2	7	8	expert	7.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
3	4	6	beginner	1.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
4	5	8	intermediate	3.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
5	2	6	intermediate	3.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
6	1	8	intermediate	3.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
7	1	1	intermediate	3.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
8	3	22	expert	5.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
9	6	1	beginner	1.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
10	5	10	intermediate	3.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
11	2	1	intermediate	3.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
12	7	12	expert	7.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
13	2	10	intermediate	3.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
14	1	9	intermediate	3.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
15	3	9	expert	5.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
16	7	7	expert	7.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
17	5	1	intermediate	3.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
18	3	8	expert	5.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
19	2	22	intermediate	3.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
20	4	1	beginner	1.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
21	3	15	expert	5.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
22	8	1	beginner	1.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
23	1	7	intermediate	3.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
24	7	14	expert	7.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
25	8	6	beginner	1.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
26	3	1	expert	5.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
27	6	22	beginner	1.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
28	7	9	expert	7.00	2025-10-14	t	2025-10-14 23:23:09.345792	2025-10-14 23:23:09.345792
29	13	1	beginner	0.00	2025-10-14	t	2025-10-14 23:53:49.413172	2025-10-14 23:53:49.413172
30	13	5	beginner	0.00	2025-10-14	t	2025-10-14 23:54:09.004477	2025-10-14 23:54:09.004477
31	13	10	beginner	0.00	2025-10-14	t	2025-10-14 23:54:55.118785	2025-10-14 23:54:55.118785
\.


--
-- Data for Name: technicians; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.technicians (id, user_id, employee_id, full_name, phone, phone_alt, email, address, emergency_contact_name, emergency_contact_phone, hire_date, employment_status, "position", department, supervisor_id, skill_level, specializations, certifications, work_zone, max_daily_tickets, preferred_shift, total_tickets_completed, average_completion_time, customer_rating, sla_compliance_rate, current_latitude, current_longitude, last_location_update, is_available, availability_status, created_at, updated_at, created_by, updated_by) FROM stdin;
5	1	TECH005	Eko Prasetyo	62267811005	085678901234	eko.prasetyo@aglisnet.id	Jl. Wirasaba No. 56, Telukjambe Barat, Karawang	Sri Eko	085678901235	2023-05-12	active	senior_technician	field_operations	\N	senior	{ftth_installation,repair,troubleshooting,fiber_splicing}	[]	Telukjambe Barat-Klari	9	day	128	\N	4.50	91.80	\N	\N	\N	t	available	2023-05-12 00:00:00	2025-10-16 03:31:43.507846	\N	\N
7	3	TECH007	Gilang Ramadhan	62267811007	087890123456	gilang.ramadhan@aglisnet.id	Jl. Galuh Mas Blok D No. 9, Karawang Timur	Maya Gilang	087890123457	2022-11-20	active	network_engineer	technical_support	\N	specialist	{network_troubleshooting,otdr_testing,splicing,core_network,odp_management}	[]	Karawang (Mobile)	5	flexible	178	\N	4.70	95.40	\N	\N	\N	t	available	2022-11-20 00:00:00	2025-10-16 03:31:43.507846	\N	\N
2	19	TECH002	Budi Santoso	62267811002	082345678901	budi.santoso@aglisnet.id	Jl. Pancasila No. 67, Karawang Timur, Karawang	Ani Budi	082345678902	2023-03-20	active	senior_technician	field_operations	\N	senior	{ftth_installation,repair,wifi_setup,customer_service}	[]	Karawang Timur	10	day	145	\N	5.00	92.30	\N	\N	\N	t	available	2023-03-20 00:00:00	2025-10-16 03:31:43.507846	\N	\N
1	18	TECH001	Ahmad Fauzi	62267811001	081234567890	ahmad.fauzi@aglisnet.id	Jl. Tuparev No. 45, Karawang Barat, Karawang	Siti Aminah	081234567891	2023-01-15	active	senior_technician	field_operations	\N	senior	{ftth_installation,fiber_splicing,troubleshooting,otdr_testing}	[]	Karawang Barat	10	day	157	\N	5.00	94.50	\N	\N	\N	t	available	2023-01-15 00:00:00	2025-10-16 03:31:43.507846	\N	\N
3	20	TECH003	Candra Wijaya	62267811003	083456789012	candra.wijaya@aglisnet.id	Jl. Arteri Taman Karawang No. 12, Karawang Barat	Dewi Candra	083456789013	2022-06-10	active	field_supervisor	field_operations	\N	expert	{ftth_installation,fiber_splicing,otdr_testing,network_design,team_management}	[]	Karawang (Mobile)	6	flexible	207	\N	5.00	96.70	\N	\N	\N	t	available	2022-06-10 00:00:00	2025-10-16 03:31:43.507846	\N	\N
13	26	TEC0005	Dani	628197670700	\N	dani@email.com	\N	\N	\N	2025-10-14	active	Field Technician	field_operations	\N	junior	\N	[]	karawang	8	day	4	\N	5.00	0.00	\N	\N	\N	t	available	2025-10-14 22:33:30.994829	2025-10-16 04:33:01.607645	17	\N
8	4	TECH008	Hendra Gunawan	62267811008	088901234567	hendra.gunawan@aglisnet.id	Jl. Veteran No. 34, Purwakarta	Linda Hendra	088901234568	2024-05-15	active	junior_technician	field_operations	3	junior	{ftth_installation,basic_repair,wifi_setup}	[]	Purwakarta-Tirtajaya	8	day	28	\N	4.10	85.30	\N	\N	\N	t	available	2024-05-15 00:00:00	2025-10-16 03:31:43.507846	\N	\N
4	21	TECH004	Dedi Hermawan	62267811004	084567890123	dedi.hermawan@aglisnet.id	Jl. Panatayuda I No. 23, Telukjambe Timur, Karawang	Rina Dedi	084567890124	2024-02-15	active	junior_technician	field_operations	3	junior	{ftth_installation,basic_repair,wifi_setup}	[]	Telukjambe Timur	8	day	45	\N	4.30	88.20	\N	\N	\N	t	available	2024-02-15 00:00:00	2025-10-16 03:31:43.507846	\N	\N
6	2	TECH006	Faisal Rahman	62267811006	086789012345	faisal.rahman@aglisnet.id	Jl. Ir. H. Juanda No. 78, Cikampek, Karawang	Nurul Faisal	086789012346	2024-04-01	active	junior_technician	field_operations	3	junior	{ftth_installation,basic_repair,customer_service}	[]	Cikampek-Rengasdengklok	8	day	34	\N	5.00	86.50	\N	\N	\N	t	available	2024-04-01 00:00:00	2025-10-16 03:31:43.507846	\N	17
9	23	TEC0001	Test Technician UPDATED	6281234567890	\N	test.tech.001@aglis.com	\N	\N	\N	2025-10-14	active	Field Technician	field_operations	\N	junior	\N	[]	Karawang	8	day	0	\N	0.00	0.00	\N	\N	\N	f	available	2025-10-14 15:11:11.344663	2025-10-16 03:31:43.511461	17	17
11	24	TEC0003	Jokowi	628197670700	\N	jokowi@email.com	\N	\N	\N	2025-10-14	active	Field Technician	field_operations	\N	junior	\N	[]	karawang	8	day	0	\N	0.00	0.00	\N	\N	\N	f	available	2025-10-14 19:48:46.310092	2025-10-16 03:31:43.511461	17	17
12	25	TEC0004	Dudung	628197670700	\N	dudung@email.com	\N	\N	\N	2025-10-14	active	Field Technician	field_operations	\N	junior	\N	[]	karawang	8	day	1	\N	5.00	0.00	\N	\N	\N	t	available	2025-10-14 19:53:02.767802	2025-10-16 03:31:43.511461	17	\N
10	22	TEC0002	Lufti Rahadiansyah	628197670700	\N	lufti@aglis.biz.id	\N	\N	\N	2025-10-14	active	Field Technician	field_operations	\N	junior	\N	[]	karawang	8	day	1	\N	5.00	0.00	\N	\N	\N	t	available	2025-10-14 19:05:43.096208	2025-10-16 03:31:43.511461	1	\N
\.


--
-- Data for Name: ticket_status_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ticket_status_history (id, ticket_id, old_status, new_status, changed_by, notes, created_at) FROM stdin;
1	16	open	assigned	17	Assigned to technician	2025-10-14 03:08:27.010541
2	16	assigned	in_progress	17	Status changed from assigned to in_progress	2025-10-14 03:08:36.455888
3	16	in_progress	completed	17	Status changed from in_progress to completed	2025-10-14 03:08:45.447023
4	15	open	assigned	17	📋 TICKET ASSIGNMENT\n\nTiket installation (TKT20251014008) berhasil di-assign.\n\nTeknisi: Hendra Gunawan (TECH008)\nCustomer: Nabila (AGLS202510140008)\nLokasi: Jalan kertanegara no.136 Grand Taruma\nPackage: Home Silver 50M\n\nStatus berubah: "open" → "Assigned"\n\nTeknisi akan segera menghubungi customer untuk koordinasi jadwal pekerjaan. Estimasi penyelesaian: 120 menit setelah mulai dikerjakan.	2025-10-14 03:13:55.395855
5	15	assigned	in_progress	17	🔧 INSTALLATION DIMULAI\n\nTeknisi: Hendra Gunawan (TECH008)\nCustomer: Nabila (AGLS202510140008)\nLokasi: Jalan kertanegara no.136 Grand Taruma\nPackage: Home Silver 50M (50 Mbps)\n\nEquipment: Dropcore fiber 50m, ONU/ONT, Patchcord LC-SC 3m, Rosette, Cable ties, Weatherproofing kit\n\nTimeline:\n- Mulai: 14/10/2025 10:13\n- Target selesai: 14/10/2025 12:13 (estimasi 120 menit)\n- SLA Deadline: 16/10/2025 09:04 (46 jam lagi)\n\nStatus: "assigned" → "In Progress"\n\nPekerjaan pemasangan fiber optic sedang berlangsung. Teknisi sedang melakukan routing kabel dan instalasi perangkat dengan monitoring signal quality.	2025-10-14 03:13:58.630547
6	15	in_progress	assigned	17	Status changed from in_progress to assigned	2025-10-14 03:17:19.826356
7	15	assigned	in_progress	17	Status changed from assigned to in_progress	2025-10-14 03:17:28.988403
8	15	in_progress	completed	17	Status changed from in_progress to completed	2025-10-14 03:17:38.148814
9	14	open	assigned	17	📋 TICKET ASSIGNMENT\n\nTiket installation (TKT20251014007) berhasil di-assign.\n\nTeknisi: Candra Wijaya (TECH003)\nCustomer: Test User Workflow 1760407191 (AGLS202510140007)\nLokasi: Jl. Test Workflow No. 123\nPackage: Home Bronze 30M\n\nStatus berubah: "open" → "Assigned"\n\nTeknisi akan segera menghubungi customer untuk koordinasi jadwal pekerjaan. Estimasi penyelesaian: 120 menit setelah mulai dikerjakan.	2025-10-14 03:21:52.127677
10	14	assigned	in_progress	17	🔧 INSTALLATION DIMULAI\n\nTeknisi: Candra Wijaya (TECH003)\nCustomer: Test User Workflow 1760407191 (AGLS202510140007)\nLokasi: Jl. Test Workflow No. 123\nPackage: Home Bronze 30M (30 Mbps)\n\nEquipment: Dropcore fiber 50m, ONU/ONT, Patchcord LC-SC 3m, Rosette, Cable ties, Weatherproofing kit\n\nTimeline:\n- Mulai: 14/10/2025 10:21\n- Target selesai: 14/10/2025 12:21 (estimasi 120 menit)\n- SLA Deadline: 16/10/2025 09:02 (46 jam lagi)\n\nStatus: "assigned" → "In Progress"\n\nPekerjaan pemasangan fiber optic sedang berlangsung. Teknisi sedang melakukan routing kabel dan instalasi perangkat dengan monitoring signal quality.	2025-10-14 03:21:56.143065
11	14	in_progress	completed	17	✅ INSTALLATION SELESAI\n\nTeknisi: Candra Wijaya (TECH003)\nCustomer: Test User Workflow 1760407191 (AGLS202510140007)\nCompletion: 14/10/2025 10:22\n\nInstallation Summary:\n✓ Fiber optic installed & terminated\n✓ ONU configured & activated\n✓ Service: Home Bronze 30M\n✓ Signal testing completed\n✓ Speed test passed\n✓ Customer demo & acceptance completed\n\nStatus: "in_progress" → "Completed"\n\nInstalasi telah selesai dengan sukses. Layanan internet sudah aktif dan customer telah menerima demo penggunaan. Ticket ditutup.	2025-10-14 03:22:29.424493
12	13	open	assigned	17	📋 TICKET ASSIGNMENT\n\nTiket installation (TKT20251014006) berhasil di-assign.\n\nTeknisi: Candra Wijaya (TECH003)\nCustomer: Test User Workflow 1760407267 (AGLS202510140006)\nLokasi: Jl. Test Workflow No. 123\nPackage: Home Bronze 30M\n\nStatus berubah: "open" → "Assigned"\n\nTeknisi akan segera menghubungi customer untuk koordinasi jadwal pekerjaan. Estimasi penyelesaian: 120 menit setelah mulai dikerjakan.	2025-10-14 03:31:26.098659
13	13	assigned	in_progress	17	🔧 INSTALLATION DIMULAI\n\nTeknisi: Candra Wijaya (TECH003)\nCustomer: Test User Workflow 1760407267 (AGLS202510140006)\nLokasi: Jl. Test Workflow No. 123\nPackage: Home Bronze 30M (30 Mbps)\n\nEquipment: Dropcore fiber 50m, ONU/ONT, Patchcord LC-SC 3m, Rosette, Cable ties, Weatherproofing kit\n\nTimeline:\n- Mulai: 14/10/2025 10:31\n- Target selesai: 14/10/2025 12:31 (estimasi 120 menit)\n- SLA Deadline: 16/10/2025 09:02 (46 jam lagi)\n\nStatus: "assigned" → "In Progress"\n\nPekerjaan pemasangan fiber optic sedang berlangsung. Teknisi sedang melakukan routing kabel dan instalasi perangkat dengan monitoring signal quality.	2025-10-14 03:31:29.088965
14	13	in_progress	completed	17	✅ INSTALLATION SELESAI\n\nTeknisi: Candra Wijaya (TECH003)\nCustomer: Test User Workflow 1760407267 (AGLS202510140006)\nCompletion: 14/10/2025 10:32\n\nInstallation Summary:\n✓ Fiber optic installed & terminated\n✓ ONU configured & activated\n✓ Service: Home Bronze 30M\n✓ Signal testing completed\n✓ Speed test passed\n✓ Customer demo & acceptance completed\n\nStatus: "in_progress" → "Completed"\n\nInstalasi telah selesai dengan sukses. Layanan internet sudah aktif dan customer telah menerima demo penggunaan. Ticket ditutup.	2025-10-14 03:32:09.212801
15	12	open	assigned	17	📋 TICKET ASSIGNMENT\n\nTiket installation (TKT20251014005) berhasil di-assign.\n\nTeknisi: Faisal Rahman (TECH006)\nCustomer: Test User Workflow 1760407323 (AGLS202510140005)\nLokasi: Jl. Test Workflow No. 123\nPackage: Home Bronze 30M\n\nStatus berubah: "open" → "Assigned"\n\nTeknisi akan segera menghubungi customer untuk koordinasi jadwal pekerjaan. Estimasi penyelesaian: 120 menit setelah mulai dikerjakan.	2025-10-14 03:36:12.647177
16	12	assigned	in_progress	17	🔧 INSTALLATION DIMULAI\n\nTeknisi: Faisal Rahman (TECH006)\nCustomer: Test User Workflow 1760407323 (AGLS202510140005)\nLokasi: Jl. Test Workflow No. 123\nPackage: Home Bronze 30M (30 Mbps)\n\nEquipment: Dropcore fiber 50m, ONU/ONT, Patchcord LC-SC 3m, Rosette, Cable ties, Weatherproofing kit\n\nTimeline:\n- Mulai: 14/10/2025 10:36\n- Target selesai: 14/10/2025 12:36 (estimasi 120 menit)\n- SLA Deadline: 16/10/2025 09:02 (46 jam lagi)\n\nStatus: "assigned" → "In Progress"\n\nPekerjaan pemasangan fiber optic sedang berlangsung. Teknisi sedang melakukan routing kabel dan instalasi perangkat dengan monitoring signal quality.	2025-10-14 03:36:15.843657
17	12	in_progress	completed	17	✅ INSTALLATION SELESAI\n\nTeknisi: Faisal Rahman (TECH006)\nCustomer: Test User Workflow 1760407323 (AGLS202510140005)\nCompletion: 14/10/2025 10:36\n\nInstallation Summary:\n✓ Fiber optic installed & terminated\n✓ ONU configured & activated\n✓ Service: Home Bronze 30M\n✓ Signal testing completed\n✓ Speed test passed\n✓ Customer demo & acceptance completed\n\nStatus: "in_progress" → "Completed"\n\nInstalasi telah selesai dengan sukses. Layanan internet sudah aktif dan customer telah menerima demo penggunaan. Ticket ditutup.	2025-10-14 03:36:54.36008
18	17	\N	open	17	\N	2025-10-14 03:44:24.083624
19	18	\N	open	17	\N	2025-10-14 04:07:33.769916
20	19	\N	open	17	\N	2025-10-14 04:10:01.67248
21	19	open	assigned	17	📋 TICKET ASSIGNMENT\n\nTiket repair (TKT20251013008) berhasil di-assign.\n\nTeknisi: Budi Santoso (TECH002)\nCustomer: Nabila (AGLS202510140008)\nLokasi: Jalan kertanegara no.136 Grand Taruma\nPackage: Home Silver 50M\n\nStatus berubah: "open" → "Assigned"\n\nTeknisi akan segera menghubungi customer untuk koordinasi jadwal pekerjaan. Estimasi penyelesaian: 60 menit setelah mulai dikerjakan.	2025-10-14 04:10:12.757387
22	19	assigned	in_progress	17	🔧 PEKERJAAN DIMULAI\n\nTeknisi: Budi Santoso (TECH002)\nCustomer: Nabila (AGLS202510140008)\nLokasi: Jalan kertanegara no.136 Grand Taruma\nTipe: repair\n\nEquipment: Standard technician toolkit\n\nTimeline:\n- Mulai: 14/10/2025 11:10\n- Target selesai: 14/10/2025 12:10 (estimasi 60 menit)\n- SLA Deadline: 15/10/2025 11:10 (23 jam lagi)\n\nStatus: "assigned" → "In Progress"\n\nPekerjaan repair sedang berlangsung. Teknisi sedang aktif di lokasi customer.	2025-10-14 04:10:15.719649
23	19	in_progress	completed	17	✅ PEKERJAAN SELESAI\n\nTeknisi: Budi Santoso (TECH002)\nCustomer: Nabila (AGLS202510140008)\nTipe: repair\nCompletion: 14/10/2025 11:10\n\nStatus: "in_progress" → "Completed"\n\nrepair untuk Nabila telah selesai dikerjakan dengan baik. Semua pekerjaan telah diselesaikan sesuai SLA. Ticket ditutup.	2025-10-14 04:10:48.95645
24	8	open	assigned	17	📋 TICKET ASSIGNMENT\n\nTiket installation (TKT20251014004) berhasil di-assign.\n\nTeknisi: Candra Wijaya (TECH003)\nCustomer: Rahadian (AGLS202510140004)\nLokasi: Grahayana Residence\nBlok G2/12\nPackage: Home Bronze 30M\n\nStatus berubah: "open" → "Assigned"\n\nTeknisi akan segera menghubungi customer untuk koordinasi jadwal pekerjaan. Estimasi penyelesaian: 120 menit setelah mulai dikerjakan.	2025-10-14 14:25:25.654655
25	8	assigned	in_progress	17	🔧 INSTALLATION DIMULAI\n\nTeknisi: Candra Wijaya (TECH003)\nCustomer: Rahadian (AGLS202510140004)\nLokasi: Grahayana Residence\nBlok G2/12\nPackage: Home Bronze 30M (30 Mbps)\n\nEquipment: Dropcore fiber 50m, ONU/ONT, Patchcord LC-SC 3m, Rosette, Cable ties, Weatherproofing kit\n\nTimeline:\n- Mulai: 14/10/2025 21:25\n- Target selesai: 14/10/2025 23:25 (estimasi 120 menit)\n- SLA Deadline: 16/10/2025 04:03 (30 jam lagi)\n\nStatus: "assigned" → "In Progress"\n\nPekerjaan pemasangan fiber optic sedang berlangsung. Teknisi sedang melakukan routing kabel dan instalasi perangkat dengan monitoring signal quality.	2025-10-14 14:25:30.017514
26	5	open	assigned	17	📋 TICKET ASSIGNMENT\n\nTiket installation (TKT20251014001) berhasil di-assign.\n\nTeknisi: Ahmad Fauzi (TECH001)\nCustomer: Test User (AGLS202510140001)\nLokasi: Test Address\nPackage: Home Bronze 30M\n\nStatus berubah: "open" → "Assigned"\n\nTeknisi akan segera menghubungi customer untuk koordinasi jadwal pekerjaan. Estimasi penyelesaian: 120 menit setelah mulai dikerjakan.	2025-10-14 14:26:25.641551
27	5	assigned	in_progress	17	🔧 INSTALLATION DIMULAI\n\nTeknisi: Ahmad Fauzi (TECH001)\nCustomer: Test User (AGLS202510140001)\nLokasi: Test Address\nPackage: Home Bronze 30M (30 Mbps)\n\nEquipment: Dropcore fiber 50m, ONU/ONT, Patchcord LC-SC 3m, Rosette, Cable ties, Weatherproofing kit\n\nTimeline:\n- Mulai: 14/10/2025 21:26\n- Target selesai: 14/10/2025 23:26 (estimasi 120 menit)\n- SLA Deadline: 16/10/2025 02:36 (29 jam lagi)\n\nStatus: "assigned" → "In Progress"\n\nPekerjaan pemasangan fiber optic sedang berlangsung. Teknisi sedang melakukan routing kabel dan instalasi perangkat dengan monitoring signal quality.	2025-10-14 14:26:27.926747
28	6	open	assigned	17	📋 TICKET ASSIGNMENT\n\nTiket installation (TKT20251014002) berhasil di-assign.\n\nTeknisi: Budi Santoso (TECH002)\nCustomer: Lufti Rahadiansyah (AGLS202510140002)\nLokasi: Grahayana Residence\nBlok G2/12\nPackage: Home Bronze 30M\n\nStatus berubah: "open" → "Assigned"\n\nTeknisi akan segera menghubungi customer untuk koordinasi jadwal pekerjaan. Estimasi penyelesaian: 120 menit setelah mulai dikerjakan.	2025-10-14 14:26:55.782173
29	7	open	assigned	17	📋 TICKET ASSIGNMENT\n\nTiket installation (TKT20251014003) berhasil di-assign.\n\nTeknisi: Faisal Rahman (TECH006)\nCustomer: Ega Nabila (AGLS202510140003)\nLokasi: Jalan kertanegara no.136 Grand Taruma\nPackage: Home Bronze 30M\n\nStatus berubah: "open" → "Assigned"\n\nTeknisi akan segera menghubungi customer untuk koordinasi jadwal pekerjaan. Estimasi penyelesaian: 120 menit setelah mulai dikerjakan.	2025-10-14 14:27:16.786033
30	20	open	assigned	22	Self-assigned via quick action	2025-10-14 16:41:58.478804
31	18	open	assigned	22	\N	2025-10-14 18:40:21.530237
32	17	open	assigned	22	\N	2025-10-14 19:01:00.078069
33	20	assigned	assigned	17	🔄 RE-ASSIGNMENT\n\nTiket installation (TKT20251014010) di-assign ulang.\n\nTeknisi Baru: Candra Wijaya (TECH003)\nCustomer: Test User Workflow 1760407142 (AGLS202510140010)\n\nStatus: "assigned" → "Assigned"\n\nProses penanganan akan dilanjutkan oleh teknisi yang baru. Koordinasi dengan customer akan segera dilakukan.	2025-10-14 19:01:56.632886
34	21	\N	open	17	\N	2025-10-14 19:02:32.405546
35	21	open	assigned	22	\N	2025-10-14 19:14:18.510393
36	22	\N	open	17	\N	2025-10-14 22:35:04.362131
37	22	open	assigned	17	📋 TICKET ASSIGNMENT\n\nTiket repair (TKT20251013011) berhasil di-assign.\n\nTeknisi: Dani (TEC0005)\nCustomer: Ega Nabila (AGLS202510140003)\nLokasi: Jalan kertanegara no.136 Grand Taruma\nPackage: Home Bronze 30M\n\nStatus berubah: "open" → "Assigned"\n\nTeknisi akan segera menghubungi customer untuk koordinasi jadwal pekerjaan. Estimasi penyelesaian: 60 menit setelah mulai dikerjakan.	2025-10-14 22:35:21.964359
38	22	assigned	in_progress	17	🔧 PEKERJAAN DIMULAI\n\nTeknisi: Dani (TEC0005)\nCustomer: Ega Nabila (AGLS202510140003)\nLokasi: Jalan kertanegara no.136 Grand Taruma\nTipe: repair\n\nEquipment: Standard technician toolkit\n\nTimeline:\n- Mulai: 15/10/2025 05:35\n- Target selesai: 15/10/2025 06:35 (estimasi 60 menit)\n- SLA Deadline: 16/10/2025 05:35 (23 jam lagi)\n\nStatus: "assigned" → "In Progress"\n\nPekerjaan repair sedang berlangsung. Teknisi sedang aktif di lokasi customer.	2025-10-14 22:35:30.239415
39	22	in_progress	completed	17	✅ PEKERJAAN SELESAI\n\nTeknisi: Dani (TEC0005)\nCustomer: Ega Nabila (AGLS202510140003)\nTipe: repair\nCompletion: 15/10/2025 05:50\n\nStatus: "in_progress" → "Completed"\n\nrepair untuk Ega Nabila telah selesai dikerjakan dengan baik. Semua pekerjaan telah diselesaikan sesuai SLA. Ticket ditutup.	2025-10-14 22:50:31.769914
40	8	in_progress	completed	17	✅ INSTALLATION SELESAI\n\nTeknisi: Candra Wijaya (TECH003)\nCustomer: Rahadian (AGLS202510140004)\nCompletion: 15/10/2025 05:53\n\nInstallation Summary:\n✓ Fiber optic installed & terminated\n✓ ONU configured & activated\n✓ Service: Home Bronze 30M\n✓ Signal testing completed\n✓ Speed test passed\n✓ Customer demo & acceptance completed\n\nStatus: "in_progress" → "Completed"\n\nInstalasi telah selesai dengan sukses. Layanan internet sudah aktif dan customer telah menerima demo penggunaan. Ticket ditutup.	2025-10-14 22:53:30.739669
41	6	assigned	in_progress	17	🔧 INSTALLATION DIMULAI\n\nTeknisi: Budi Santoso (TECH002)\nCustomer: Lufti Rahadiansyah (AGLS202510140002)\nLokasi: Grahayana Residence\nBlok G2/12\nPackage: Home Bronze 30M (30 Mbps)\n\nEquipment: Dropcore fiber 50m, ONU/ONT, Patchcord LC-SC 3m, Rosette, Cable ties, Weatherproofing kit\n\nTimeline:\n- Mulai: 15/10/2025 05:54\n- Target selesai: 15/10/2025 07:54 (estimasi 120 menit)\n- SLA Deadline: 16/10/2025 03:42 (21 jam lagi)\n\nStatus: "assigned" → "In Progress"\n\nPekerjaan pemasangan fiber optic sedang berlangsung. Teknisi sedang melakukan routing kabel dan instalasi perangkat dengan monitoring signal quality.	2025-10-14 22:54:01.751252
42	6	in_progress	completed	17	✅ INSTALLATION SELESAI\n\nTeknisi: Budi Santoso (TECH002)\nCustomer: Lufti Rahadiansyah (AGLS202510140002)\nCompletion: 15/10/2025 05:54\n\nInstallation Summary:\n✓ Fiber optic installed & terminated\n✓ ONU configured & activated\n✓ Service: Home Bronze 30M\n✓ Signal testing completed\n✓ Speed test passed\n✓ Customer demo & acceptance completed\n\nStatus: "in_progress" → "Completed"\n\nInstalasi telah selesai dengan sukses. Layanan internet sudah aktif dan customer telah menerima demo penggunaan. Ticket ditutup.	2025-10-14 22:54:34.365857
43	7	assigned	in_progress	17	🔧 INSTALLATION DIMULAI\n\nTeknisi: Faisal Rahman (TECH006)\nCustomer: Ega Nabila (AGLS202510140003)\nLokasi: Jalan kertanegara no.136 Grand Taruma\nPackage: Home Bronze 30M (30 Mbps)\n\nEquipment: Dropcore fiber 50m, ONU/ONT, Patchcord LC-SC 3m, Rosette, Cable ties, Weatherproofing kit\n\nTimeline:\n- Mulai: 15/10/2025 05:54\n- Target selesai: 15/10/2025 07:54 (estimasi 120 menit)\n- SLA Deadline: 16/10/2025 03:54 (21 jam lagi)\n\nStatus: "assigned" → "In Progress"\n\nPekerjaan pemasangan fiber optic sedang berlangsung. Teknisi sedang melakukan routing kabel dan instalasi perangkat dengan monitoring signal quality.	2025-10-14 22:54:55.196512
44	7	in_progress	completed	17	✅ INSTALLATION SELESAI\n\nTeknisi: Faisal Rahman (TECH006)\nCustomer: Ega Nabila (AGLS202510140003)\nCompletion: 15/10/2025 05:55\n\nInstallation Summary:\n✓ Fiber optic installed & terminated\n✓ ONU configured & activated\n✓ Service: Home Bronze 30M\n✓ Signal testing completed\n✓ Speed test passed\n✓ Customer demo & acceptance completed\n\nStatus: "in_progress" → "Completed"\n\nInstalasi telah selesai dengan sukses. Layanan internet sudah aktif dan customer telah menerima demo penggunaan. Ticket ditutup.	2025-10-14 22:55:21.237579
45	23	open	assigned	17	📋 TICKET ASSIGNMENT\n\nTiket installation (TKT20251015001) berhasil di-assign.\n\nTeknisi: Dani (TEC0005)\nCustomer: Ahmad Test Customer (AGLS202510150001)\nLokasi: Jl. Test Street No. 123\nPackage: Home Platinum 100M\n\nStatus berubah: "open" → "Assigned"\n\nTeknisi akan segera menghubungi customer untuk koordinasi jadwal pekerjaan. Estimasi penyelesaian: 120 menit setelah mulai dikerjakan.	2025-10-15 04:13:26.99494
46	23	assigned	in_progress	17	🔧 INSTALLATION DIMULAI\n\nTeknisi: Dani (TEC0005)\nCustomer: Ahmad Test Customer (AGLS202510150001)\nLokasi: Jl. Test Street No. 123\nPackage: Home Platinum 100M (100 Mbps)\n\nEquipment: Dropcore fiber 50m, ONU/ONT, Patchcord LC-SC 3m, Rosette, Cable ties, Weatherproofing kit\n\nTimeline:\n- Mulai: 15/10/2025 11:13\n- Target selesai: 15/10/2025 13:13 (estimasi 120 menit)\n- SLA Deadline: 17/10/2025 11:10 (47 jam lagi)\n\nStatus: "assigned" → "In Progress"\n\nPekerjaan pemasangan fiber optic sedang berlangsung. Teknisi sedang melakukan routing kabel dan instalasi perangkat dengan monitoring signal quality.	2025-10-15 04:13:31.25481
47	23	in_progress	completed	17	✅ INSTALLATION SELESAI\n\nTeknisi: Dani (TEC0005)\nCustomer: Ahmad Test Customer (AGLS202510150001)\nCompletion: 15/10/2025 11:14\n\nInstallation Summary:\n✓ Fiber optic installed & terminated\n✓ ONU configured & activated\n✓ Service: Home Platinum 100M\n✓ Signal testing completed\n✓ Speed test passed\n✓ Customer demo & acceptance completed\n\nStatus: "in_progress" → "Completed"\n\nInstalasi telah selesai dengan sukses. Layanan internet sudah aktif dan customer telah menerima demo penggunaan. Ticket ditutup.	2025-10-15 04:14:06.577428
48	24	open	assigned	17	📋 TICKET ASSIGNMENT\n\nTiket installation (TKT20251015002) berhasil di-assign.\n\nTeknisi: Dani (TEC0005)\nCustomer: Udin (AGLS202510150002)\nLokasi: Jalan kertanegara no.136 Grand Taruma\nPackage: Home Gold 75M\n\nStatus berubah: "open" → "Assigned"\n\nTeknisi akan segera menghubungi customer untuk koordinasi jadwal pekerjaan. Estimasi penyelesaian: 120 menit setelah mulai dikerjakan.	2025-10-15 05:11:28.612146
49	24	assigned	assigned	17	🔄 RE-ASSIGNMENT\n\nTiket installation (TKT20251015002) di-assign ulang.\n\nTeknisi Baru: Dani (TEC0005)\nCustomer: Udin (AGLS202510150002)\n\nStatus: "assigned" → "Assigned"\n\nProses penanganan akan dilanjutkan oleh teknisi yang baru. Koordinasi dengan customer akan segera dilakukan.	2025-10-15 05:16:07.052427
50	24	assigned	in_progress	17	🔧 INSTALLATION DIMULAI\n\nTeknisi: Dani (TEC0005)\nCustomer: Udin (AGLS202510150002)\nLokasi: Jalan kertanegara no.136 Grand Taruma\nPackage: Home Gold 75M (75 Mbps)\n\nEquipment: Dropcore fiber 50m, ONU/ONT, Patchcord LC-SC 3m, Rosette, Cable ties, Weatherproofing kit\n\nTimeline:\n- Mulai: 15/10/2025 12:16\n- Target selesai: 15/10/2025 14:16 (estimasi 120 menit)\n- SLA Deadline: 17/10/2025 12:07 (47 jam lagi)\n\nStatus: "assigned" → "In Progress"\n\nPekerjaan pemasangan fiber optic sedang berlangsung. Teknisi sedang melakukan routing kabel dan instalasi perangkat dengan monitoring signal quality.	2025-10-15 05:16:29.673412
51	24	in_progress	on_hold	17	⏸️ PEKERJAAN DITUNDA\n\nTeknisi: Dani (TEC0005)\nCustomer: Udin (AGLS202510150002)\nTipe: installation\n\nStatus: "in_progress" → "On Hold"\n\nPekerjaan installation ditunda sementara. Menunggu:\n- Informasi tambahan dari customer, atau\n- Material/equipment yang diperlukan, atau\n- Konfirmasi dari dispatcher/management\n\nPekerjaan akan dilanjutkan setelah requirement terpenuhi. Ticket tetap di-monitor.	2025-10-15 05:20:39.285117
52	24	on_hold	in_progress	17	🔧 INSTALLATION DIMULAI\n\nTeknisi: Dani (TEC0005)\nCustomer: Udin (AGLS202510150002)\nLokasi: Jalan kertanegara no.136 Grand Taruma\nPackage: Home Gold 75M (75 Mbps)\n\nEquipment: Dropcore fiber 50m, ONU/ONT, Patchcord LC-SC 3m, Rosette, Cable ties, Weatherproofing kit\n\nTimeline:\n- Mulai: 15/10/2025 12:21\n- Target selesai: 15/10/2025 14:21 (estimasi 120 menit)\n- SLA Deadline: 17/10/2025 12:07 (47 jam lagi)\n\nStatus: "on_hold" → "In Progress"\n\nPekerjaan pemasangan fiber optic sedang berlangsung. Teknisi sedang melakukan routing kabel dan instalasi perangkat dengan monitoring signal quality.	2025-10-15 05:21:01.537909
53	24	in_progress	on_hold	17	⏸️ PEKERJAAN DITUNDA\n\nTeknisi: Dani\nCustomer: Udin (AGLS202510150002)\nTipe: installation\n\nStatus: "in_progress" → "On Hold"\n\nPekerjaan installation ditunda sementara. Menunggu:\n- Informasi tambahan dari customer, atau\n- Material/equipment yang diperlukan, atau\n- Konfirmasi dari dispatcher/management\n\nPekerjaan akan dilanjutkan setelah requirement terpenuhi. Ticket tetap di-monitor.	2025-10-15 05:49:20.081936
54	24	on_hold	in_progress	17	🔧 INSTALLATION DIMULAI\n\nTeknisi: Dani\nCustomer: Udin (AGLS202510150002)\nLokasi: Jalan kertanegara no.136 Grand Taruma\nPackage: Home Gold 75M (75 Mbps)\n\nEquipment: Dropcore fiber 50m, ONU/ONT, Patchcord LC-SC 3m, Rosette, Cable ties, Weatherproofing kit\n\nTimeline:\n- Mulai: 15/10/2025 12:49\n- Target selesai: 15/10/2025 14:49 (estimasi 120 menit)\n- SLA Deadline: 17/10/2025 12:07 (47 jam lagi)\n\nStatus: "on_hold" → "In Progress"\n\nPekerjaan pemasangan fiber optic sedang berlangsung. Teknisi sedang melakukan routing kabel dan instalasi perangkat dengan monitoring signal quality.	2025-10-15 05:49:42.825149
55	24	in_progress	on_hold	17	⏸️ PEKERJAAN DITUNDA\n\nTeknisi: Dani\nCustomer: Udin (AGLS202510150002)\nTipe: installation\n\nStatus: "in_progress" → "On Hold"\n\nPekerjaan installation ditunda sementara. Menunggu:\n- Informasi tambahan dari customer, atau\n- Material/equipment yang diperlukan, atau\n- Konfirmasi dari dispatcher/management\n\nPekerjaan akan dilanjutkan setelah requirement terpenuhi. Ticket tetap di-monitor.	2025-10-15 06:02:10.654853
56	24	on_hold	in_progress	17	🔧 INSTALLATION DIMULAI\n\nTeknisi: Dani\nCustomer: Udin (AGLS202510150002)\nLokasi: Jalan kertanegara no.136 Grand Taruma\nPackage: Home Gold 75M (75 Mbps)\n\nEquipment: Dropcore fiber 50m, ONU/ONT, Patchcord LC-SC 3m, Rosette, Cable ties, Weatherproofing kit\n\nTimeline:\n- Mulai: 15/10/2025 13:02\n- Target selesai: 15/10/2025 15:02 (estimasi 120 menit)\n- SLA Deadline: 17/10/2025 12:07 (47 jam lagi)\n\nStatus: "on_hold" → "In Progress"\n\nPekerjaan pemasangan fiber optic sedang berlangsung. Teknisi sedang melakukan routing kabel dan instalasi perangkat dengan monitoring signal quality.	2025-10-15 06:02:27.614337
57	27	\N	open	17	\N	2025-10-15 06:24:25.720143
58	27	open	open	17	📋 TICKET DIBUKA KEMBALI\n\nTiket: installation (TKT20251014011)\nCustomer: Udin (AGLS202510150002)\nLokasi: Jalan kertanegara no.136 Grand Taruma\n\nStatus: "open" → "Open"\n\nTiket dibuka kembali dan menunggu assignment ke teknisi. Perlu tindak lanjut segera.\nSLA Deadline: 16/10/2025 13:24 (23 jam lagi)	2025-10-15 06:24:38.673858
59	27	open	assigned	17	📋 TICKET ASSIGNMENT\n\nTiket installation (TKT20251014011) berhasil di-assign.\n\nTeknisi: Dani (TEC0005)\nCustomer: Udin (AGLS202510150002)\nLokasi: Jalan kertanegara no.136 Grand Taruma\nPackage: Home Gold 75M\n\nStatus berubah: "open" → "Assigned"\n\nTeknisi akan segera menghubungi customer untuk koordinasi jadwal pekerjaan. Estimasi penyelesaian: 120 menit setelah mulai dikerjakan.	2025-10-15 06:24:55.897086
60	27	assigned	assigned	17	🔄 RE-ASSIGNMENT\n\nTiket installation (TKT20251014011) di-assign ulang.\n\nTeknisi Baru: Dudung (TEC0004)\nCustomer: Udin (AGLS202510150002)\n\nStatus: "assigned" → "Assigned"\n\nProses penanganan akan dilanjutkan oleh teknisi yang baru. Koordinasi dengan customer akan segera dilakukan.	2025-10-15 06:32:36.633203
61	27	assigned	in_progress	17	🔧 INSTALLATION DIMULAI\n\nTeknisi: Dudung (TEC0004)\nCustomer: Udin (AGLS202510150002)\nLokasi: Jalan kertanegara no.136 Grand Taruma\nPackage: Home Gold 75M (75 Mbps)\n\nEquipment: Dropcore fiber 50m, ONU/ONT, Patchcord LC-SC 3m, Rosette, Cable ties, Weatherproofing kit\n\nTimeline:\n- Mulai: 15/10/2025 23:53\n- Target selesai: 16/10/2025 01:53 (estimasi 120 menit)\n- SLA Deadline: 16/10/2025 13:24 (13 jam lagi)\n\nStatus: "assigned" → "In Progress"\n\nPekerjaan pemasangan fiber optic sedang berlangsung. Teknisi sedang melakukan routing kabel dan instalasi perangkat dengan monitoring signal quality.	2025-10-15 16:53:55.974956
62	27	in_progress	completed	17	✅ INSTALLATION SELESAI\n\nTeknisi: Dudung (TEC0004)\nCustomer: Udin (AGLS202510150002)\nCompletion: 15/10/2025 23:55\n\nInstallation Summary:\n✓ Fiber optic installed & terminated\n✓ ONU configured & activated\n✓ Service: Home Gold 75M\n✓ Signal testing completed\n✓ Speed test passed\n✓ Customer demo & acceptance completed\n\nStatus: "in_progress" → "Completed"\n\nInstalasi telah selesai dengan sukses. Layanan internet sudah aktif dan customer telah menerima demo penggunaan. Ticket ditutup.	2025-10-15 16:55:30.344571
63	24	in_progress	completed	17	✅ INSTALLATION SELESAI\n\nTeknisi: Dani\nCustomer: Udin (AGLS202510150002)\nCompletion: 16/10/2025 00:30\n\nInstallation Summary:\n✓ Fiber optic installed & terminated\n✓ ONU configured & activated\n✓ Service: Home Gold 75M\n✓ Signal testing completed\n✓ Speed test passed\n✓ Customer demo & acceptance completed\n\nStatus: "in_progress" → "Completed"\n\nInstalasi telah selesai dengan sukses. Layanan internet sudah aktif dan customer telah menerima demo penggunaan. Ticket ditutup.	2025-10-15 17:30:48.877751
64	21	assigned	in_progress	17	🔧 PEKERJAAN DIMULAI\n\nTeknisi: Lufti Rahadiansyah (TEC0002)\nCustomer: Ega Nabila (AGLS202510140003)\nLokasi: Jalan kertanegara no.136 Grand Taruma\nTipe: repair\n\nEquipment: Standard technician toolkit\n\nTimeline:\n- Mulai: 16/10/2025 00:37\n- Target selesai: 16/10/2025 01:37 (estimasi 60 menit)\n- SLA Deadline: 16/10/2025 02:02 (1 jam lagi)\n\nStatus: "assigned" → "In Progress"\n\nPekerjaan repair sedang berlangsung. Teknisi sedang aktif di lokasi customer.	2025-10-15 17:37:36.828441
65	21	in_progress	completed	17	✅ PEKERJAAN SELESAI\n\nTeknisi: Lufti Rahadiansyah (TEC0002)\nCustomer: Ega Nabila (AGLS202510140003)\nTipe: repair\nCompletion: 16/10/2025 00:39\n\nStatus: "in_progress" → "Completed"\n\nrepair untuk Ega Nabila telah selesai dikerjakan dengan baik. Semua pekerjaan telah diselesaikan sesuai SLA. Ticket ditutup.	2025-10-15 17:39:01.915736
66	28	\N	open	17	\N	2025-10-16 00:32:32.554884
67	29	\N	open	17	\N	2025-10-16 00:57:47.662474
68	30	\N	open	17	\N	2025-10-16 01:33:40.005291
69	30	open	assigned	17	📋 TICKET ASSIGNMENT\n\nTiket repair (TKT20251015005) berhasil di-assign.\n\nTeknisi: Candra Wijaya (TECH003)\nCustomer: Udin (AGLS202510150002)\nLokasi: Jalan kertanegara no.136 Grand Taruma\nPackage: Home Gold 75M\n\nStatus berubah: "open" → "Assigned"\n\nTeknisi akan segera menghubungi customer untuk koordinasi jadwal pekerjaan. Estimasi penyelesaian: 60 menit setelah mulai dikerjakan.	2025-10-16 01:49:01.658958
70	30	assigned	in_progress	17	🔧 PEKERJAAN DIMULAI\n\nTeknisi: Candra Wijaya (TECH003)\nCustomer: Udin (AGLS202510150002)\nLokasi: Jalan kertanegara no.136 Grand Taruma\nTipe: repair\n\nEquipment: Standard technician toolkit\n\nTimeline:\n- Mulai: 16/10/2025 08:49\n- Target selesai: 16/10/2025 09:49 (estimasi 60 menit)\n- SLA Deadline: 17/10/2025 08:33 (23 jam lagi)\n\nStatus: "assigned" → "In Progress"\n\nPekerjaan repair sedang berlangsung. Teknisi sedang aktif di lokasi customer.	2025-10-16 01:49:31.620658
71	30	in_progress	completed	17	✅ PEKERJAAN SELESAI\n\nTeknisi: Candra Wijaya (TECH003)\nCustomer: Udin (AGLS202510150002)\nTipe: repair\nCompletion: 16/10/2025 08:50\n\nStatus: "in_progress" → "Completed"\n\nrepair untuk Udin telah selesai dikerjakan dengan baik. Semua pekerjaan telah diselesaikan sesuai SLA. Ticket ditutup.	2025-10-16 01:50:39.09538
72	29	open	assigned	17	📝 STATUS UPDATE\n\nTiket: wifi_setup (TKT20251015004)\nCustomer: Udin (AGLS202510150002)\n\nStatus berubah: "open" → "assigned"\n\nUpdate pada: 16/10/2025 09:14	2025-10-16 02:14:37.688137
73	29	open	assigned	17	📝 STATUS UPDATE\n\nTiket: wifi_setup (TKT20251015004)\nCustomer: Udin (AGLS202510150002)\n\nStatus berubah: "open" → "assigned"\n\nUpdate pada: 16/10/2025 10:34	2025-10-16 03:34:01.913879
74	29	open	assigned	17	Testing team assignment with fixed phone numbers	2025-10-16 03:36:29.629258
75	29	assigned	in_progress	17	Started working on ticket	2025-10-16 04:13:18.627168
76	29	in_progress	completed	17	✅ PEKERJAAN SELESAI\n\nTeknisi: \nCustomer: Udin (AGLS202510150002)\nTipe: wifi_setup\nCompletion: 16/10/2025 11:14\n\nStatus: "in_progress" → "Completed"\n\nwifi_setup untuk Udin telah selesai dikerjakan dengan baik. Semua pekerjaan telah diselesaikan sesuai SLA. Ticket ditutup.	2025-10-16 04:14:45.908001
77	31	open	assigned	17	📋 TICKET ASSIGNMENT\n\nTiket installation (TKT20251016001) berhasil di-assign.\n\nTeknisi: Dani (TEC0005)\nCustomer: Riky Van Boomel (AGLS202510160001)\nLokasi: Jl. Neraka Jahanam No. 666\nPackage: Home Bronze 30M\n\nStatus berubah: "open" → "Assigned"\n\nTeknisi akan segera menghubungi customer untuk koordinasi jadwal pekerjaan. Estimasi penyelesaian: 120 menit setelah mulai dikerjakan.	2025-10-16 04:29:25.613917
78	31	assigned	in_progress	17	🔧 INSTALLATION DIMULAI\n\nTeknisi: Dani (TEC0005)\nCustomer: Riky Van Boomel (AGLS202510160001)\nLokasi: Jl. Neraka Jahanam No. 666\nPackage: Home Bronze 30M (30 Mbps)\n\nEquipment: Dropcore fiber 50m, ONU/ONT, Patchcord LC-SC 3m, Rosette, Cable ties, Weatherproofing kit\n\nTimeline:\n- Mulai: 16/10/2025 11:31\n- Target selesai: 16/10/2025 13:31 (estimasi 120 menit)\n- SLA Deadline: 18/10/2025 11:28 (47 jam lagi)\n\nStatus: "assigned" → "In Progress"\n\nPekerjaan pemasangan fiber optic sedang berlangsung. Teknisi sedang melakukan routing kabel dan instalasi perangkat dengan monitoring signal quality.	2025-10-16 04:31:18.344875
79	31	in_progress	completed	17	✅ INSTALLATION SELESAI\n\nTeknisi: Dani (TEC0005)\nCustomer: Riky Van Boomel (AGLS202510160001)\nCompletion: 16/10/2025 11:33\n\nInstallation Summary:\n✓ Fiber optic installed & terminated\n✓ ONU configured & activated\n✓ Service: Home Bronze 30M\n✓ Signal testing completed\n✓ Speed test passed\n✓ Customer demo & acceptance completed\n\nStatus: "in_progress" → "Completed"\n\nInstalasi telah selesai dengan sukses. Layanan internet sudah aktif dan customer telah menerima demo penggunaan. Ticket ditutup.	2025-10-16 04:33:01.607645
\.


--
-- Data for Name: ticket_technicians; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ticket_technicians (id, ticket_id, technician_id, role, assigned_at, assigned_by, notes, is_active, created_at, updated_at) FROM stdin;
1	16	1	lead	2025-10-14 02:07:45.051161+00	17	\N	t	2025-10-16 00:04:30.972851+00	2025-10-16 00:04:30.972851+00
2	15	2	lead	2025-10-14 02:04:18.886709+00	17	\N	t	2025-10-16 00:04:30.972851+00	2025-10-16 00:04:30.972851+00
3	14	3	lead	2025-10-14 02:02:57.934026+00	17	\N	t	2025-10-16 00:04:30.972851+00	2025-10-16 00:04:30.972851+00
4	13	3	lead	2025-10-14 02:02:43.255433+00	17	\N	t	2025-10-16 00:04:30.972851+00	2025-10-16 00:04:30.972851+00
5	5	1	lead	2025-10-13 19:36:48.160158+00	17	\N	t	2025-10-16 00:04:30.972851+00	2025-10-16 00:04:30.972851+00
6	6	2	lead	2025-10-13 20:42:08.040838+00	17	\N	t	2025-10-16 00:04:30.972851+00	2025-10-16 00:04:30.972851+00
7	12	6	lead	2025-10-14 02:02:10.13896+00	17	\N	t	2025-10-16 00:04:30.972851+00	2025-10-16 00:04:30.972851+00
8	19	2	lead	2025-10-14 04:10:01.67248+00	17	\N	t	2025-10-16 00:04:30.972851+00	2025-10-16 00:04:30.972851+00
9	21	10	lead	2025-10-14 19:02:32.405546+00	17	\N	t	2025-10-16 00:04:30.972851+00	2025-10-16 00:04:30.972851+00
10	18	9	lead	2025-10-14 04:07:33.769916+00	17	\N	t	2025-10-16 00:04:30.972851+00	2025-10-16 00:04:30.972851+00
11	17	9	lead	2025-10-14 03:44:24.083624+00	17	\N	t	2025-10-16 00:04:30.972851+00	2025-10-16 00:04:30.972851+00
12	20	3	lead	2025-10-14 04:28:10.445904+00	17	\N	t	2025-10-16 00:04:30.972851+00	2025-10-16 00:04:30.972851+00
13	22	13	lead	2025-10-14 22:35:04.362131+00	17	\N	t	2025-10-16 00:04:30.972851+00	2025-10-16 00:04:30.972851+00
14	8	3	lead	2025-10-13 21:03:14.714096+00	17	\N	t	2025-10-16 00:04:30.972851+00	2025-10-16 00:04:30.972851+00
15	7	6	lead	2025-10-13 20:54:22.556522+00	17	\N	t	2025-10-16 00:04:30.972851+00	2025-10-16 00:04:30.972851+00
16	23	13	lead	2025-10-15 04:10:08.465237+00	17	\N	t	2025-10-16 00:04:30.972851+00	2025-10-16 00:04:30.972851+00
17	27	12	lead	2025-10-15 06:24:25.720143+00	17	\N	t	2025-10-16 00:04:30.972851+00	2025-10-16 00:04:30.972851+00
18	24	13	lead	2025-10-15 05:07:05.294015+00	17	\N	t	2025-10-16 00:04:30.972851+00	2025-10-16 00:04:30.972851+00
19	29	3	lead	2025-10-16 02:14:37.688137+00	\N	\N	f	2025-10-16 02:14:37.688137+00	2025-10-16 02:14:37.688137+00
20	29	2	member	2025-10-16 02:14:37.688137+00	\N	\N	f	2025-10-16 02:14:37.688137+00	2025-10-16 02:14:37.688137+00
21	29	5	support	2025-10-16 02:14:37.688137+00	\N	\N	f	2025-10-16 02:14:37.688137+00	2025-10-16 02:14:37.688137+00
22	29	1	lead	2025-10-16 03:36:29.629258+00	\N	\N	t	2025-10-16 03:34:01.913879+00	2025-10-16 03:34:01.913879+00
23	29	7	member	2025-10-16 03:36:29.629258+00	\N	\N	t	2025-10-16 03:34:01.913879+00	2025-10-16 03:34:01.913879+00
\.


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tickets (id, ticket_number, customer_id, assigned_technician_id, created_by, type, priority, category, title, description, status, scheduled_date, started_at, completed_at, estimated_duration, actual_duration, sla_due_date, is_sla_breached, customer_rating, customer_feedback, equipment_needed, work_notes, resolution_notes, created_at, updated_at, completion_data) FROM stdin;
16	TKT20251014009	15	1	17	installation	normal	fiber_installation	Instalasi Baru - ega	Instalasi untuk customer baru\nPaket: Home Gold 75M\nAlamat: Grahayana Residence\nBlok G2/12	completed	2025-10-14 09:07:45.151	2025-10-14 10:08:36.456	2025-10-14 10:08:45.447	120	0	2025-10-16 09:07:45.151	f	5	\N	\N	Started installation work	Installation completed successfully	2025-10-14 02:07:45.051161	2025-10-14 03:08:45.447023	\N
15	TKT20251014008	14	2	17	installation	normal	fiber_installation	Instalasi Baru - Nabila	Instalasi untuk customer baru\nPaket: Home Silver 50M\nAlamat: Jalan kertanegara no.136 Grand Taruma	completed	2025-10-14 09:04:18.999	2025-10-14 10:13:58.63	2025-10-14 10:17:38.148	120	3	2025-10-16 09:04:18.999	f	5	Excellent service!	\N	Started work	Installation completed successfully. Equipment tested OK.	2025-10-14 02:04:18.886709	2025-10-14 03:17:38.148814	\N
14	TKT20251014007	13	3	17	installation	normal	fiber_installation	Instalasi Baru - Test User Workflow 1760407191	Instalasi untuk customer baru\nPaket: Home Bronze 30M\nAlamat: Jl. Test Workflow No. 123	completed	2025-10-21 00:00:00	2025-10-14 10:21:56.143	2025-10-14 10:22:29.424	120	0	2025-10-16 09:02:58.048	f	5	\N	\N	\N	Installation untuk Test User Workflow 1760407191 telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Bronze 30M dengan bandwidth 30 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.	2025-10-14 02:02:57.934026	2025-10-14 03:22:29.424493	{"odp_id": 3, "wifi_name": "ega", "otdr_photo": {"url": "/uploads/tickets/otdr/ticket_14/1760412149425_fa4389d35ab6dad1_Screenshot_2025_10_0.png", "path": "tickets/otdr/ticket_14/1760412149425_fa4389d35ab6dad1_Screenshot_2025_10_0.png", "filename": "Screenshot 2025-10-08 at 01.21.35.png"}, "odp_distance": "123", "odp_location": "ODP-KRW-003-C15", "wifi_password": "nabila", "modem_sn_photo": {"url": "/uploads/tickets/modem_sn/ticket_14/1760412149431_d8dc2a72fdadf03f_Screenshot_2025_09_3.png", "path": "tickets/modem_sn/ticket_14/1760412149431_d8dc2a72fdadf03f_Screenshot_2025_09_3.png", "filename": "Screenshot 2025-09-30 at 23.09.49.png"}, "activation_date": "2025-10-14T10:21", "attenuation_photo": {"url": "/uploads/tickets/attenuation/ticket_14/1760412149430_1dc183ed36368283_Screenshot_2025_10_0.png", "path": "tickets/attenuation/ticket_14/1760412149430_1dc183ed36368283_Screenshot_2025_10_0.png", "filename": "Screenshot 2025-10-01 at 14.54.47.png"}, "final_attenuation": "23"}
13	TKT20251014006	12	3	17	installation	normal	fiber_installation	Instalasi Baru - Test User Workflow 1760407267	Instalasi untuk customer baru\nPaket: Home Bronze 30M\nAlamat: Jl. Test Workflow No. 123	completed	2025-10-21 00:00:00	2025-10-14 10:31:29.089	2025-10-14 10:32:09.213	120	0	2025-10-16 09:02:43.358	f	5	\N	\N	\N	Installation untuk Test User Workflow 1760407267 telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Bronze 30M dengan bandwidth 30 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.	2025-10-14 02:02:43.255433	2025-10-14 03:32:09.212801	{"odp_id": 3, "wifi_name": "ega", "otdr_photo": {"url": "/uploads/tickets/otdr/ticket_13/1760412729214_8d3a177878301f87_Screenshot_2025_09_3.png", "path": "tickets/otdr/ticket_13/1760412729214_8d3a177878301f87_Screenshot_2025_09_3.png", "filename": "Screenshot 2025-09-30 at 16.44.45.png"}, "odp_distance": "121", "odp_location": "ODP-KRW-003-C15", "wifi_password": "nabila", "modem_sn_photo": {"url": "/uploads/tickets/modem_sn/ticket_13/1760412729226_4ca3ac1df4c2434c_Screenshot_2025_09_1.png", "path": "tickets/modem_sn/ticket_13/1760412729226_4ca3ac1df4c2434c_Screenshot_2025_09_1.png", "filename": "Screenshot 2025-09-14 at 14.20.23.png"}, "activation_date": "2025-10-14T10:31", "attenuation_photo": {"url": "/uploads/tickets/attenuation/ticket_13/1760412729221_0cc860b2bc4c3a1b_Screenshot_2025_09_1.png", "path": "tickets/attenuation/ticket_13/1760412729221_0cc860b2bc4c3a1b_Screenshot_2025_09_1.png", "filename": "Screenshot 2025-09-14 at 14.20.58.png"}, "final_attenuation": "21"}
5	TKT20251014001	5	1	17	installation	normal	fiber_installation	Instalasi Baru - Test User	Instalasi untuk customer baru\nPaket: Home Bronze 30M\nAlamat: Test Address	in_progress	2025-10-14 02:36:48.261	2025-10-14 21:26:27.926	\N	120	\N	2025-10-16 02:36:48.261	f	\N	\N	\N	\N	\N	2025-10-13 19:36:48.160158	2025-10-14 14:26:27.926747	\N
6	TKT20251014002	6	2	17	installation	normal	fiber_installation	Instalasi Baru - Lufti Rahadiansyah	Instalasi untuk customer baru\nPaket: Home Bronze 30M\nAlamat: Grahayana Residence\nBlok G2/12	completed	2025-10-14 03:42:08.152	2025-10-15 05:54:01.751	2025-10-15 05:54:34.365	120	0	2025-10-16 03:42:08.152	f	5	\N	\N	\N	Installation untuk Lufti Rahadiansyah telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Bronze 30M dengan bandwidth 30 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.	2025-10-13 20:42:08.040838	2025-10-14 22:54:34.365857	{"odp_id": 7, "wifi_name": "ega", "otdr_photo": {"url": "/uploads/tickets/otdr/ticket_6/1760482474366_184c1112acb2c344_Screenshot_2025_08_2.png", "path": "tickets/otdr/ticket_6/1760482474366_184c1112acb2c344_Screenshot_2025_08_2.png", "filename": "Screenshot 2025-08-25 at 22.02.36.png"}, "odp_distance": "34", "odp_location": "ODP-KRW-007-G18", "wifi_password": "nabila", "modem_sn_photo": {"url": "/uploads/tickets/modem_sn/ticket_6/1760482474369_7e6baf51dc73e471_Screenshot_2025_09_3.png", "path": "tickets/modem_sn/ticket_6/1760482474369_7e6baf51dc73e471_Screenshot_2025_09_3.png", "filename": "Screenshot 2025-09-30 at 23.09.49.png"}, "activation_date": "2025-10-15T05:54", "attenuation_photo": {"url": "/uploads/tickets/attenuation/ticket_6/1760482474368_730e8aff3e1ed9a8_Screenshot_2025_07_2.png", "path": "tickets/attenuation/ticket_6/1760482474368_730e8aff3e1ed9a8_Screenshot_2025_07_2.png", "filename": "Screenshot 2025-07-29 at 12.50.55.png"}, "final_attenuation": "12"}
12	TKT20251014005	11	6	17	installation	normal	fiber_installation	Instalasi Baru - Test User Workflow 1760407323	Instalasi untuk customer baru\nPaket: Home Bronze 30M\nAlamat: Jl. Test Workflow No. 123	completed	2025-10-21 00:00:00	2025-10-14 10:36:15.843	2025-10-14 10:36:54.36	120	0	2025-10-16 09:02:10.239	f	5	\N	\N	\N	Installation untuk Test User Workflow 1760407323 telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Bronze 30M dengan bandwidth 30 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.	2025-10-14 02:02:10.13896	2025-10-14 03:36:54.36008	{"odp_id": 7, "wifi_name": "ega", "otdr_photo": {"url": "/uploads/tickets/otdr/ticket_12/1760413014361_d265e5fd80ced55c_Screenshot_2025_09_3.png", "path": "tickets/otdr/ticket_12/1760413014361_d265e5fd80ced55c_Screenshot_2025_09_3.png", "filename": "Screenshot 2025-09-30 at 23.09.49.png"}, "odp_distance": "99", "odp_location": "ODP-KRW-007-G18", "wifi_password": "nabila", "modem_sn_photo": {"url": "/uploads/tickets/modem_sn/ticket_12/1760413014368_5515fd68976e8c73_Screenshot_2025_09_3.png", "path": "tickets/modem_sn/ticket_12/1760413014368_5515fd68976e8c73_Screenshot_2025_09_3.png", "filename": "Screenshot 2025-09-30 at 16.47.14.png"}, "activation_date": "2025-10-14T10:36", "attenuation_photo": {"url": "/uploads/tickets/attenuation/ticket_12/1760413014363_6f1cfbb81df0ee05_Screenshot_2025_10_1.png", "path": "tickets/attenuation/ticket_12/1760413014363_6f1cfbb81df0ee05_Screenshot_2025_10_1.png", "filename": "Screenshot 2025-10-14 at 10.23.14.png"}, "final_attenuation": "22"}
19	TKT20251013008	14	2	17	repair	normal		Repair - Nabila	INFORMASI PELANGGAN\nNama: Nabila\nAlamat: Jalan kertanegara no.136 Grand Taruma\nTelepon: 08197670700\nPaket: Home Silver 50M\nTipe Layanan: broadband\n\nJENIS PEKERJAAN\nService Type: Repair\n\nDESKRIPSI PEKERJAAN\nPengecekan perangkat, kabel, kualitas sinyal, troubleshooting masalah koneksi.	completed	2025-10-14 11:09:00	2025-10-14 11:10:15.719	2025-10-14 11:10:48.956	120	0	2025-10-15 11:10:01.672	f	5	\N	\N	\N	Ticket repair untuk Nabila telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.	2025-10-14 04:10:01.67248	2025-10-14 04:10:48.95645	{"odp_id": 4, "wifi_name": "", "otdr_photo": null, "repair_date": "2025-10-14T11:10", "odp_location": "ODP-KRW-004-D20", "wifi_password": "", "modem_sn_photo": null, "attenuation_photo": {"url": "/uploads/tickets/attenuation/ticket_19/1760415048957_b1ca753753fa0a4f_Screenshot_2025_10_0.png", "path": "tickets/attenuation/ticket_19/1760415048957_b1ca753753fa0a4f_Screenshot_2025_10_0.png", "filename": "Screenshot 2025-10-08 at 01.21.35.png"}, "final_attenuation": "20"}
21	TKT20251013010	7	10	17	repair	normal		Repair - Ega Nabila	INFORMASI PELANGGAN\nNama: Ega Nabila\nAlamat: Jalan kertanegara no.136 Grand Taruma\nTelepon: 08197670700\nPaket: Home Bronze 30M\nTipe Layanan: broadband\n\nJENIS PEKERJAAN\nService Type: Repair\n\nDESKRIPSI PEKERJAAN\nPengecekan perangkat, kabel, kualitas sinyal, troubleshooting masalah koneksi.	completed	2025-10-15 02:02:00	2025-10-16 00:37:36.828	2025-10-16 00:39:01.916	120	1	2025-10-16 02:02:32.405	f	5	\N	\N	\N	Ticket repair untuk Ega Nabila telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.	2025-10-14 19:02:32.405546	2025-10-15 17:39:01.915736	{"odp_id": 3, "wifi_name": "", "otdr_photo": null, "repair_date": "2025-10-16T00:38", "odp_location": "ODP-KRW-003-C15", "wifi_password": "", "modem_sn_photo": null, "attenuation_photo": null, "final_attenuation": "24"}
18	TKT20251013007	15	9	17	installation	normal		Installation - ega	INFORMASI PELANGGAN\nNama: ega\nAlamat: Grahayana Residence\nBlok G2/12\nTelepon: 08197670700\nPaket: Home Gold 75M\nTipe Layanan: broadband\n\nJENIS PEKERJAAN\nService Type: Installation\n\nDESKRIPSI PEKERJAAN\nSurvey lokasi, instalasi perangkat, konfigurasi koneksi, testing kualitas sinyal.	assigned	2025-10-14 11:06:00	\N	\N	120	\N	2025-10-15 11:07:33.769	f	\N	\N	\N	\N	\N	2025-10-14 04:07:33.769916	2025-10-14 18:40:21.530237	\N
17	TKT20251013006	6	9	17	repair	normal	\N	Test Ticket Creation	Testing ticket creation from API	assigned	\N	\N	\N	\N	\N	2025-10-15 10:44:24.083	f	\N	\N	\N	\N	\N	2025-10-14 03:44:24.083624	2025-10-14 19:01:00.078069	\N
20	TKT20251014010	16	3	17	installation	normal	fiber_installation	Instalasi Baru - Test User Workflow 1760407142	Instalasi untuk customer baru\nPaket: Home Bronze 30M\nAlamat: Jl. Test Workflow No. 123	assigned	2025-10-21 00:00:00	\N	\N	120	\N	2025-10-16 11:28:10.557	f	\N	\N	\N	\N	\N	2025-10-14 04:28:10.445904	2025-10-14 19:01:56.632886	\N
22	TKT20251013011	7	13	17	repair	normal		Repair - Ega Nabila	INFORMASI PELANGGAN\nNama: Ega Nabila\nAlamat: Jalan kertanegara no.136 Grand Taruma\nTelepon: 08197670700\nPaket: Home Bronze 30M\nTipe Layanan: broadband\n\nJENIS PEKERJAAN\nService Type: Repair\n\nDESKRIPSI PEKERJAAN\nPengecekan perangkat, kabel, kualitas sinyal, troubleshooting masalah koneksi.	completed	2025-10-15 05:34:00	2025-10-15 05:35:30.239	2025-10-15 05:50:31.77	120	15	2025-10-16 05:35:04.361	f	5	\N	\N	\N	Ticket repair untuk Ega Nabila telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.	2025-10-14 22:35:04.362131	2025-10-14 22:50:31.769914	{"odp_id": 4, "wifi_name": "", "otdr_photo": null, "repair_date": "2025-10-15T05:50", "odp_location": "ODP-KRW-004-D20", "wifi_password": "", "modem_sn_photo": null, "attenuation_photo": {"url": "/uploads/tickets/attenuation/ticket_22/1760482231770_4596b1ff952b15db_Screenshot_2025_10_1.png", "path": "tickets/attenuation/ticket_22/1760482231770_4596b1ff952b15db_Screenshot_2025_10_1.png", "filename": "Screenshot 2025-10-14 at 08.11.36.png"}, "final_attenuation": "22"}
8	TKT20251014004	8	3	17	installation	normal	fiber_installation	Instalasi Baru - Rahadian	Instalasi untuk customer baru\nPaket: Home Bronze 30M\nAlamat: Grahayana Residence\nBlok G2/12	completed	2025-10-14 04:03:14.826	2025-10-14 21:25:30.017	2025-10-15 05:53:30.739	120	508	2025-10-16 04:03:14.826	f	5	\N	\N	\N	Installation untuk Rahadian telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Bronze 30M dengan bandwidth 30 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.	2025-10-13 21:03:14.714096	2025-10-14 22:53:30.739669	{"odp_id": 2, "wifi_name": "ega", "otdr_photo": {"url": "/uploads/tickets/otdr/ticket_8/1760482410740_8517ca412d4e3ee5_Screenshot_2025_08_1.png", "path": "tickets/otdr/ticket_8/1760482410740_8517ca412d4e3ee5_Screenshot_2025_08_1.png", "filename": "Screenshot 2025-08-14 at 17.24.33.png"}, "odp_distance": "77", "odp_location": "ODP-KRW-002-B08", "wifi_password": "nabila", "modem_sn_photo": {"url": "/uploads/tickets/modem_sn/ticket_8/1760482410744_589f20e9d9505ea8_Screenshot_2025_09_0.png", "path": "tickets/modem_sn/ticket_8/1760482410744_589f20e9d9505ea8_Screenshot_2025_09_0.png", "filename": "Screenshot 2025-09-03 at 21.59.17.png"}, "activation_date": "2025-10-15T05:52", "attenuation_photo": {"url": "/uploads/tickets/attenuation/ticket_8/1760482410744_abbeaa3c2ee740c5_Screenshot_2025_07_1.png", "path": "tickets/attenuation/ticket_8/1760482410744_abbeaa3c2ee740c5_Screenshot_2025_07_1.png", "filename": "Screenshot 2025-07-15 at 13.52.51.png"}, "final_attenuation": "22"}
7	TKT20251014003	7	6	17	installation	normal	fiber_installation	Instalasi Baru - Ega Nabila	Instalasi untuk customer baru\nPaket: Home Bronze 30M\nAlamat: Jalan kertanegara no.136 Grand Taruma	completed	2025-10-14 03:54:22.659	2025-10-15 05:54:55.196	2025-10-15 05:55:21.237	120	0	2025-10-16 03:54:22.659	f	5	\N	\N	\N	Installation untuk Ega Nabila telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Bronze 30M dengan bandwidth 30 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.	2025-10-13 20:54:22.556522	2025-10-14 22:55:21.237579	{"odp_id": 10, "wifi_name": "ega", "otdr_photo": {"url": "/uploads/tickets/otdr/ticket_7/1760482521238_d82e5557f17ba5c8_Screenshot_2025_08_0.png", "path": "tickets/otdr/ticket_7/1760482521238_d82e5557f17ba5c8_Screenshot_2025_08_0.png", "filename": "Screenshot 2025-08-07 at 08.17.31.png"}, "odp_distance": "54", "odp_location": "ODP-KRW-010-J22", "wifi_password": "nabila", "modem_sn_photo": {"url": "/uploads/tickets/modem_sn/ticket_7/1760482521240_02b07d72106fc2a3_Screenshot_2025_08_0.png", "path": "tickets/modem_sn/ticket_7/1760482521240_02b07d72106fc2a3_Screenshot_2025_08_0.png", "filename": "Screenshot 2025-08-07 at 09.05.46.png"}, "activation_date": "2025-10-15T05:54", "attenuation_photo": {"url": "/uploads/tickets/attenuation/ticket_7/1760482521239_948e8a73efb770bb_Screenshot_2025_08_1.png", "path": "tickets/attenuation/ticket_7/1760482521239_948e8a73efb770bb_Screenshot_2025_08_1.png", "filename": "Screenshot 2025-08-14 at 00.16.08.png"}, "final_attenuation": "22"}
23	TKT20251015001	17	13	17	installation	normal	fiber_installation	Instalasi Baru - Ahmad Test Customer	Instalasi untuk customer baru\nPaket: Home Platinum 100M\nAlamat: Jl. Test Street No. 123	completed	2025-10-15 11:10:08.57	2025-10-15 11:13:31.254	2025-10-15 11:14:06.577	120	0	2025-10-17 11:10:08.57	f	5	\N	\N	\N	Installation untuk Ahmad Test Customer telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Platinum 100M dengan bandwidth 100 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.	2025-10-15 04:10:08.465237	2025-10-15 04:14:06.577428	{"odp_id": 7, "wifi_name": "ega", "otdr_photo": {"url": "/uploads/tickets/otdr/ticket_23/1760501646578_9159a14f5bb71074_Screenshot_2025_07_1.png", "path": "tickets/otdr/ticket_23/1760501646578_9159a14f5bb71074_Screenshot_2025_07_1.png", "filename": "Screenshot 2025-07-15 at 13.52.51.png"}, "odp_distance": "122", "odp_location": "ODP-KRW-007-G18", "wifi_password": "nabila", "modem_sn_photo": {"url": "/uploads/tickets/modem_sn/ticket_23/1760501646580_9f94a20ed31b0dee_Screenshot_2025_08_2.png", "path": "tickets/modem_sn/ticket_23/1760501646580_9f94a20ed31b0dee_Screenshot_2025_08_2.png", "filename": "Screenshot 2025-08-25 at 22.02.36.png"}, "activation_date": "2025-10-15T11:13", "attenuation_photo": {"url": "/uploads/tickets/attenuation/ticket_23/1760501646579_a585b8aa6a5aeaac_Screenshot_2025_09_0.png", "path": "tickets/attenuation/ticket_23/1760501646579_a585b8aa6a5aeaac_Screenshot_2025_09_0.png", "filename": "Screenshot 2025-09-03 at 21.59.17.png"}, "final_attenuation": "22"}
28	TKT20251015003	18	\N	17	repair	normal		Repair - Udin	INFORMASI PELANGGAN\nNama: Udin\nAlamat: Jalan kertanegara no.136 Grand Taruma\nTelepon: 0817102070\nPaket: Home Gold 75M\nTipe Layanan: broadband\n\nJENIS PEKERJAAN\nService Type: Repair\n\nDESKRIPSI PEKERJAAN\nPengecekan perangkat, kabel, kualitas sinyal, troubleshooting masalah koneksi.	open	2025-10-16 07:32:00	\N	\N	120	\N	2025-10-17 07:32:32.554	f	\N	\N	\N	\N	\N	2025-10-16 00:32:32.554884	2025-10-16 00:32:32.554884	\N
27	TKT20251014011	18	12	17	installation	normal		Installation - Udin	INFORMASI PELANGGAN\nNama: Udin\nAlamat: Jalan kertanegara no.136 Grand Taruma\nTelepon: 0817102070\nPaket: Home Gold 75M\nTipe Layanan: broadband\n\nJENIS PEKERJAAN\nService Type: Installation\n\nDESKRIPSI PEKERJAAN\nSurvey lokasi, instalasi perangkat, konfigurasi koneksi, testing kualitas sinyal.	completed	2025-10-15 13:24:00	2025-10-15 23:53:55.975	2025-10-15 23:55:30.344	120	1	2025-10-16 13:24:25.719	f	5	\N	\N	\N	Installation untuk Udin telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Gold 75M dengan bandwidth 75 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.	2025-10-15 06:24:25.720143	2025-10-15 16:55:30.344571	{"odp_id": 3, "wifi_name": "ega", "otdr_photo": {"url": "/uploads/tickets/otdr/ticket_27/1760547330345_d515da66c814c99f_Screenshot_2025_07_1.png", "path": "tickets/otdr/ticket_27/1760547330345_d515da66c814c99f_Screenshot_2025_07_1.png", "filename": "Screenshot 2025-07-15 at 13.52.51.png"}, "odp_distance": "122", "odp_location": "ODP-KRW-003-C15", "wifi_password": "nabila", "modem_sn_photo": {"url": "/uploads/tickets/modem_sn/ticket_27/1760547330347_f21da29c163c69a8_Screenshot_2025_07_1.png", "path": "tickets/modem_sn/ticket_27/1760547330347_f21da29c163c69a8_Screenshot_2025_07_1.png", "filename": "Screenshot 2025-07-15 at 13.52.51.png"}, "activation_date": "2025-10-15T23:55", "attenuation_photo": {"url": "/uploads/tickets/attenuation/ticket_27/1760547330346_0e43637708401341_Screenshot_2025_07_1.png", "path": "tickets/attenuation/ticket_27/1760547330346_0e43637708401341_Screenshot_2025_07_1.png", "filename": "Screenshot 2025-07-15 at 13.52.51.png"}, "final_attenuation": "21"}
24	TKT20251015002	18	13	17	installation	normal	fiber_installation	Instalasi Baru - Udin	Instalasi untuk customer baru\nPaket: Home Gold 75M\nAlamat: Jalan kertanegara no.136 Grand Taruma	completed	2025-10-15 12:07:05.406	2025-10-15 12:16:29.673	2025-10-16 00:30:48.878	120	734	2025-10-17 12:07:05.405	f	5	\N	\N	\N	Installation untuk Udin telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Gold 75M dengan bandwidth 75 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.	2025-10-15 05:07:05.294015	2025-10-15 17:30:48.877751	{"odp_id": 6, "wifi_name": "ega", "otdr_photo": {"url": "/uploads/tickets/otdr/ticket_24/1760549448878_8efb6ff97fecbb2e_Screenshot_2025_03_0.png", "path": "tickets/otdr/ticket_24/1760549448878_8efb6ff97fecbb2e_Screenshot_2025_03_0.png", "filename": "Screenshot 2025-03-01 at 13.34.01.png"}, "odp_distance": "110", "odp_location": "ODP-KRW-006-F12", "wifi_password": "nabila", "modem_sn_photo": {"url": "/uploads/tickets/modem_sn/ticket_24/1760549448880_9f0954d7f7ad968d_Screenshot_2025_02_2.png", "path": "tickets/modem_sn/ticket_24/1760549448880_9f0954d7f7ad968d_Screenshot_2025_02_2.png", "filename": "Screenshot 2025-02-25 at 05.08.06.png"}, "activation_date": "2025-10-16T00:30", "attenuation_photo": {"url": "/uploads/tickets/attenuation/ticket_24/1760549448880_0eaac55e7ed5ca42_Screenshot_2025_03_0.png", "path": "tickets/attenuation/ticket_24/1760549448880_0eaac55e7ed5ca42_Screenshot_2025_03_0.png", "filename": "Screenshot 2025-03-01 at 13.49.52.png"}, "final_attenuation": "16"}
30	TKT20251015005	18	3	17	repair	normal		Repair - Udin	INFORMASI PELANGGAN\nNama: Udin\nAlamat: Jalan kertanegara no.136 Grand Taruma\nTelepon: 0817102070\nPaket: Home Gold 75M\nTipe Layanan: broadband\n\nJENIS PEKERJAAN\nService Type: Repair\n\nDESKRIPSI PEKERJAAN\nPengecekan perangkat, kabel, kualitas sinyal, troubleshooting masalah koneksi.	completed	2025-10-16 08:33:00	2025-10-16 08:49:31.62	2025-10-16 08:50:39.095	120	1	2025-10-17 08:33:40.005	f	5	Pelayanan sangat memuaskan! Teknisi sangat profesional dan ramah. Masalah koneksi internet sudah teratasi dengan baik. Terima kasih AGLIS Net!	\N	Sedang melakukan pengecekan hardware router, testing koneksi internet, dan optimasi jaringan. Kualitas sinyal sudah membaik dari 75% menjadi 95%.	Ticket repair untuk Udin telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.	2025-10-16 01:33:40.005291	2025-10-16 01:50:39.09538	{"odp_id": 1, "wifi_name": "AGLIS_UDIN_75M", "otdr_photo": null, "repair_date": "2025-10-16T08:49", "odp_location": "ODP-KRW-001-A12", "wifi_password": "Udin2025!", "modem_sn_photo": null, "attenuation_photo": null, "final_attenuation": "-18.5"}
29	TKT20251015004	18	\N	17	wifi_setup	normal		WiFi Setup - Udin	INFORMASI PELANGGAN\nNama: Udin\nAlamat: Jalan kertanegara no.136 Grand Taruma\nTelepon: 0817102070\nPaket: Home Gold 75M\nTipe Layanan: broadband\n\nJENIS PEKERJAAN\nService Type: WiFi Setup\n\nDESKRIPSI PEKERJAAN\nSetup WiFi router, konfigurasi SSID dan password, optimisasi channel, testing coverage.	completed	2025-10-16 07:56:00	2025-10-16 11:13:18.627	2025-10-16 11:14:45.908	15	1	2025-10-17 07:57:47.662	f	5	Tim AGLIS sangat profesional! Ahmad sebagai lead koordinasi dengan baik, Gilang juga sangat membantu. WiFi setup cepat dan coverage sangat bagus. Terima kasih tim!	\N	\N	Ticket wifi_setup untuk Udin telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.	2025-10-16 00:57:47.662474	2025-10-16 04:14:45.908001	{"odp_id": null, "wifi_name": "AGLIS_UDIN_WiFi", "otdr_photo": null, "wifi_password": "Udin@WiFi2025", "modem_sn_photo": null, "attenuation_photo": null}
31	TKT20251016001	19	13	17	installation	normal	fiber_installation	Instalasi Baru - Riky Van Boomel	Instalasi untuk customer baru\nPaket: Home Bronze 30M\nAlamat: Jl. Neraka Jahanam No. 666	completed	2025-10-16 11:28:41.394	2025-10-16 11:31:18.344	2025-10-16 11:33:01.607	120	1	2025-10-18 11:28:41.394	f	5	ok	\N	\N	Installation untuk Riky Van Boomel telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Bronze 30M dengan bandwidth 30 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.	2025-10-16 04:28:41.281382	2025-10-16 04:33:01.607645	{"odp_id": 1, "wifi_name": "VAN BOOMEL", "otdr_photo": {"url": "/uploads/tickets/otdr/ticket_31/1760589181608_a535f826d22270f1_WhatsApp_Image_2025_.jpg", "path": "tickets/otdr/ticket_31/1760589181608_a535f826d22270f1_WhatsApp_Image_2025_.jpg", "filename": "WhatsApp Image 2025-10-16 at 01.34.20_30662e64.jpg"}, "odp_distance": "103", "odp_location": "ODP-KRW-001-A12", "wifi_password": "12345678", "modem_sn_photo": {"url": "/uploads/tickets/modem_sn/ticket_31/1760589181610_46da2e53e63d3b77_WhatsApp_Image_2025_.jpg", "path": "tickets/modem_sn/ticket_31/1760589181610_46da2e53e63d3b77_WhatsApp_Image_2025_.jpg", "filename": "WhatsApp Image 2025-10-16 at 01.34.20_30662e64.jpg"}, "activation_date": "2025-10-16T11:31", "attenuation_photo": {"url": "/uploads/tickets/attenuation/ticket_31/1760589181609_32c417897338a5bb_WhatsApp_Image_2025_.jpg", "path": "tickets/attenuation/ticket_31/1760589181609_32c417897338a5bb_WhatsApp_Image_2025_.jpg", "filename": "WhatsApp Image 2025-10-16 at 01.34.20_30662e64.jpg"}, "final_attenuation": "-19"}
\.


--
-- Data for Name: user_activity_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_activity_logs (id, user_id, action, target_user_id, target_username, details, ip_address, user_agent, created_at) FROM stdin;
1	17	created	22	lufti	{"role": "technician", "is_active": true}	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-14 14:29:39.160805
2	17	created	23	test_tech_001	{"role": "technician", "is_active": true, "technician_employee_id": "TEC0001", "auto_created_technician": true}	103.55.225.241	curl/7.81.0	2025-10-14 15:11:11.361752
3	17	updated	23	test_tech_001	{"full_name": "Test Technician UPDATED"}	103.55.225.241	curl/7.81.0	2025-10-14 15:12:40.231568
4	17	updated	23	test_tech_001	{"is_active": false}	103.55.225.241	curl/7.81.0	2025-10-14 15:13:10.821063
5	17	created	24	joko	{"role": "technician", "is_active": true, "technician_employee_id": "TEC0003", "auto_created_technician": true}	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-14 19:48:46.314716
6	17	updated	23	test_tech_001	{"role": "technician", "email": "test.tech.001@aglis.com", "phone": "081234567890", "full_name": "Test Technician UPDATED", "is_active": true}	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-14 19:48:55.973932
7	17	created	25	dudung	{"role": "technician", "is_active": true, "technician_employee_id": "TEC0004", "auto_created_technician": true}	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-14 19:53:02.773008
8	17	created	26	dani	{"role": "technician", "is_active": true, "technician_employee_id": "TEC0005", "auto_created_technician": true}	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-14 22:33:31.006886
9	17	updated	26	dani	{"role": "technician", "email": "dani@email.com", "phone": "08197670700", "full_name": "Dani", "is_active": true}	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-15 04:18:04.366941
10	17	updated	25	dudung	{"role": "technician", "email": "dudung@email.com", "phone": "08197670700", "full_name": "Dudung", "is_active": true}	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-15 06:32:23.431107
11	17	updated	22	lufti	{"role": "technician", "email": "lufti@aglis.biz.id", "phone": "08197670700", "full_name": "Lufti Rahadiansyah", "is_active": true}	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-15 06:32:59.638333
12	17	updated	24	joko	{"role": "technician", "email": "jokowi@email.com", "phone": "08197670700", "full_name": "Jokowi", "is_active": true}	103.55.224.49	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-15 06:33:07.210841
\.


--
-- Data for Name: user_devices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_devices (id, user_id, device_token, device_type, device_name, device_model, os_version, app_version, is_active, last_active_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, email, password_hash, full_name, phone, role, is_active, avatar_url, last_login, created_at, updated_at, deleted_at, deleted_by, email_verified, email_verified_at, email_verification_token, failed_login_attempts, locked_until, last_failed_login) FROM stdin;
1	tech5	eko.prasetyo@aglisnet.id	$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	Eko Prasetyo	0267811005	technician	t	\N	\N	2025-10-13 00:07:49.254549	2025-10-13 00:09:00.410227	\N	\N	f	\N	\N	0	\N	\N
2	tech6	faisal.rahman@aglisnet.id	$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	Faisal Rahman	0267811006	technician	t	\N	\N	2025-10-13 00:07:49.254549	2025-10-13 00:09:00.410227	\N	\N	f	\N	\N	0	\N	\N
3	tech7	gilang.ramadhan@aglisnet.id	$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	Gilang Ramadhan	0267811007	technician	t	\N	\N	2025-10-13 00:07:49.254549	2025-10-13 00:09:00.410227	\N	\N	f	\N	\N	0	\N	\N
4	tech8	hendra.gunawan@aglisnet.id	$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	Hendra Gunawan	0267811008	technician	t	\N	\N	2025-10-13 00:07:49.254549	2025-10-13 00:09:00.410227	\N	\N	f	\N	\N	0	\N	\N
5	cs2	tika.lestari@aglisnet.id	$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	Tika Lestari	0267800102	customer_service	t	\N	\N	2025-10-13 00:07:49.254549	2025-10-13 00:09:00.410227	\N	\N	f	\N	\N	0	\N	\N
6	cs3	wulan.sari@aglisnet.id	$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	Wulan Sari	0267800103	customer_service	t	\N	\N	2025-10-13 00:07:49.254549	2025-10-13 00:09:00.410227	\N	\N	f	\N	\N	0	\N	\N
7	billing1	indah.permata@aglisnet.id	$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	Indah Permata	0267800104	customer_service	t	\N	\N	2025-10-13 00:07:49.254549	2025-10-13 00:09:00.410227	\N	\N	f	\N	\N	0	\N	\N
8	noc1	wahyu.hidayat@aglisnet.id	$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	Wahyu Hidayat	0267800201	supervisor	t	\N	\N	2025-10-13 00:07:49.254549	2025-10-13 02:09:30.733409	\N	\N	t	2025-10-13 02:09:30.733409	\N	0	\N	\N
18	tech001	ahmad.fauzi@aglisnet.id	$2b$10$r3ZhKAbT/sRvzu0XicuM7.0V./kx/CbcYZK8DDZoUpZzMV7z2cXW.	Ahmad Fauzi	\N	technician	t	\N	\N	2025-10-14 02:14:17.015475	2025-10-14 02:14:17.015475	\N	\N	f	\N	\N	0	\N	\N
19	tech002	budi.santoso@aglisnet.id	$2b$10$X0xtXelTFwz/kuOleQCAPe0FhQ/QNGH3PCixmwUDA7lRnswzpa/.m	Budi Santoso	\N	technician	t	\N	\N	2025-10-14 02:14:17.015475	2025-10-14 02:14:17.015475	\N	\N	f	\N	\N	0	\N	\N
20	tech003	candra.wijaya@aglisnet.id	$2b$10$ncraQqmMlubUc7CTF1FIROiMWx88huOjLrxialZmR6EUbWN3HQaaK	Candra Wijaya	\N	technician	t	\N	\N	2025-10-14 02:14:17.015475	2025-10-14 02:14:17.015475	\N	\N	f	\N	\N	0	\N	\N
21	tech004	dedi.hermawan@aglisnet.id	$2b$10$XEvrGklTkKFvUy2VdKrpR.xOZokVE6CUudQl8K8rbBJxNYSC/7Ov6	Dedi Hermawan	\N	technician	t	\N	\N	2025-10-14 02:14:17.015475	2025-10-14 02:14:17.015475	\N	\N	f	\N	\N	0	\N	\N
23	test_tech_001	test.tech.001@aglis.com	$2a$10$wc17bMiogYLF4en2cKxqIeweBpzXMzr.2V2xgRegaXtY546tZBm/.	Test Technician UPDATED	081234567890	technician	t	\N	\N	2025-10-14 15:11:11.344663	2025-10-14 19:48:55.969251	\N	\N	f	\N	\N	0	\N	\N
26	dani	dani@email.com	$2a$10$qqOYnh5J7vRSt4lRlJbxgeOg6j93rlbXtugLHxhBxVQe6ROXZt1TK	Dani	08197670700	technician	t	\N	\N	2025-10-14 22:33:30.994829	2025-10-15 04:18:04.362558	\N	\N	f	\N	\N	0	\N	\N
25	dudung	dudung@email.com	$2a$10$V82dzLz7F/6KXNVq7iu4fOjJ2bgR8QL3cxsjBhicgtIJR5Ydin6jy	Dudung	08197670700	technician	t	\N	\N	2025-10-14 19:53:02.767802	2025-10-15 06:32:23.416183	\N	\N	f	\N	\N	0	\N	\N
22	lufti	lufti@aglis.biz.id	$2a$10$GqFtUGcZajX5N8bMl1JsZuEG/gr4.KYLW04SBlFgRpM4n61TrApm.	Lufti Rahadiansyah	08197670700	technician	t	\N	2025-10-14 19:12:42.278131	2025-10-14 14:29:39.158802	2025-10-15 06:32:59.627934	\N	\N	f	\N	\N	0	\N	\N
24	joko	jokowi@email.com	$2a$10$nUjauX7ocmk49HoSvQ47XOLKFLlXlt7zmrAFKdQNfy1OI3v.0Qq2.	Jokowi	08197670700	technician	t	\N	\N	2025-10-14 19:48:46.310092	2025-10-15 06:33:07.20634	\N	\N	f	\N	\N	0	\N	\N
17	admin	admin@aglis.biz.id	$2b$10$4IeXFvnVRp8jc05u.10P/ujJ16HP/lTsG9x.rmR7H25BHvOn7T0hm	AGLIS Administrator	08197670700	admin	t	\N	2025-10-16 04:59:16.129267	2025-10-13 00:16:38.563746	2025-10-16 04:59:16.129267	\N	\N	t	2025-10-13 02:09:30.733409	\N	0	\N	\N
\.


--
-- Data for Name: whatsapp_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.whatsapp_groups (id, name, description, category, work_zone, group_chat_id, phone_number, notification_types, priority_filter, is_active, is_verified, created_by, created_at, updated_at) FROM stdin;
8	Developer	WhatsApp group untuk Developer	all		120363419722776103@g.us	120363419722776103@g.us	["ticket_assigned", "new_ticket", "sla_warning", "ticket_completed", "urgent_alert", "daily_summary", "system_alert", "new_registration", "payment_alert", "critical_incident", "outage", "kpi_alert", "customer_complaint", "performance_alert", "weekly_report", "escalation"]	normal	t	f	17	2025-10-15 17:36:15.732061	2025-10-16 00:58:20.136236
5	NOC Team	WhatsApp group untuk Network Operations Center	noc		120363419722776103@g.us	120363419722776103@g.us	["system_alert", "outage", "critical_incident", "performance_alert"]	high	t	f	1	2025-10-15 01:13:56.063399	2025-10-15 17:36:59.571032
6	Management	WhatsApp group untuk manajemen	managers		120363419722776103@g.us	120363419722776103@g.us	["weekly_report", "kpi_alert", "critical_incident", "escalation", "ticket_completed"]	high	t	f	1	2025-10-15 01:13:56.063399	2025-10-15 17:37:02.811102
7	Customer Service Team	WhatsApp group untuk customer service	customer_service		120363419722776103@g.us	120363419722776103@g.us	["new_registration", "customer_complaint", "payment_alert"]	normal	t	f	1	2025-10-15 01:13:56.063399	2025-10-15 17:37:05.674343
4	Supervisor Team	WhatsApp group untuk para supervisor	supervisors		120363419722776103@g.us	120363419722776103@g.us	["sla_warning", "escalation", "daily_summary", "urgent_alert", "ticket_completed", "ticket_created"]	high	t	f	1	2025-10-15 01:13:56.063399	2025-10-15 17:36:56.452782
2	Teknisi Bekasi	WhatsApp group untuk teknisi area Bekasi	technicians	bekasi	120363419722776103@g.us	120363419722776103@g.us	["ticket_assigned", "new_ticket", "sla_warning", "urgent_alert", "ticket_created"]	normal	t	f	1	2025-10-15 01:13:56.063399	2025-10-15 04:02:42.107552
3	Teknisi Cikampek	WhatsApp group untuk teknisi area Cikampek	technicians	cikampek	120363419722776103@g.us	120363419722776103@g.us	["ticket_assigned", "new_ticket", "sla_warning", "urgent_alert", "ticket_created"]	normal	t	f	1	2025-10-15 01:13:56.063399	2025-10-15 04:02:45.736963
1	Teknisi Karawang	WhatsApp group untuk teknisi area Karawang	technicians	karawang	120363419722776103@g.us	120363419722776103@g.us	["ticket_assigned", "new_ticket", "sla_warning", "urgent_alert", "ticket_completed", "new_registration", "customer_complaint", "daily_summary", "ticket_created"]	normal	t	f	1	2025-10-15 01:13:56.063399	2025-10-15 17:29:52.586054
\.


--
-- Data for Name: whatsapp_message_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.whatsapp_message_templates (id, code, name, description, category, template, variables, example_message, language, is_active, created_by, created_at, updated_at) FROM stdin;
1	TICKET_ASSIGNED	Ticket Assignment Notification	Notifikasi ketika ticket di-assign ke teknisi	ticket	🎫 *TICKET BARU ASSIGNED*\n\nTicket: {{ticket_id}}\nCustomer: {{customer_name}}\nLokasi: {{work_zone}}\nIssue: {{issue_type}}\nPriority: {{priority}}\n\n📍 {{address}}\n📞 {{customer_phone}}\n\n🔗 Detail: {{ticket_url}}	["ticket_id", "customer_name", "work_zone", "issue_type", "priority", "address", "customer_phone", "ticket_url"]	🎫 *TICKET BARU ASSIGNED*\n\nTicket: TKT001\nCustomer: PT. ABC Indonesia\nLokasi: Karawang\nIssue: Installation FTTH\nPriority: High\n\n📍 Jl. Raya Karawang No. 123\n📞 08123456789\n\n🔗 Detail: https://portal.aglis.biz.id/tickets/TKT001	id	t	1	2025-10-15 01:13:56.068066	2025-10-15 01:13:56.068066
2	TICKET_STATUS_CHANGED	Ticket Status Update	Notifikasi ketika status ticket berubah	ticket	🔄 *TICKET STATUS UPDATE*\n\nTicket: {{ticket_id}}\nStatus: {{old_status}} → {{new_status}}\nTechnician: {{technician_name}}\n\n{{additional_notes}}	["ticket_id", "old_status", "new_status", "technician_name", "additional_notes"]	🔄 *TICKET STATUS UPDATE*\n\nTicket: TKT001\nStatus: Assigned → In Progress\nTechnician: Ahmad Fauzi\n\nPekerjaan dimulai, estimasi selesai 2 jam	id	t	1	2025-10-15 01:13:56.068066	2025-10-15 01:13:56.068066
3	SLA_WARNING	SLA Deadline Warning	Peringatan mendekati SLA deadline	ticket	⚠️ *SLA WARNING*\n\nTicket: {{ticket_id}}\nCustomer: {{customer_name}}\nStatus: {{status}}\nDeadline: {{sla_deadline}}\nRemaining: {{remaining_time}}\n\n⚡ *ACTION REQUIRED!*	["ticket_id", "customer_name", "status", "sla_deadline", "remaining_time"]	⚠️ *SLA WARNING*\n\nTicket: TKT001\nCustomer: PT. ABC Indonesia\nStatus: Assigned\nDeadline: 15 Okt 16:00\nRemaining: 2 jam\n\n⚡ *ACTION REQUIRED!*	id	t	1	2025-10-15 01:13:56.068066	2025-10-15 01:13:56.068066
4	NEW_TICKET_AVAILABLE	New Open Ticket for Assignment	Notifikasi ticket baru yang belum di-assign	ticket	🆕 *TICKET BARU TERSEDIA*\n\nTicket: {{ticket_id}}\nCustomer: {{customer_name}}\nLokasi: {{work_zone}}\nIssue: {{issue_type}}\nPriority: {{priority}}\n\n📍 {{address}}\n\n💡 Siapa yang available untuk handle?	["ticket_id", "customer_name", "work_zone", "issue_type", "priority", "address"]	🆕 *TICKET BARU TERSEDIA*\n\nTicket: TKT002\nCustomer: CV. XYZ\nLokasi: Karawang\nIssue: Repair - No Signal\nPriority: High\n\n📍 Jl. Industri Raya No. 45\n\n💡 Siapa yang available untuk handle?	id	t	1	2025-10-15 01:13:56.068066	2025-10-15 01:13:56.068066
5	REGISTRATION_APPROVED	Customer Registration Approved	Notifikasi persetujuan registrasi customer	customer	✅ *REGISTRASI DISETUJUI*\n\nSelamat! Registrasi Anda telah disetujui.\n\nCustomer ID: {{customer_id}}\nNama: {{customer_name}}\nPaket: {{package_name}}\nKecepatan: {{speed}}\nBiaya: {{monthly_fee}}/bulan\n\nTim kami akan segera menghubungi Anda untuk jadwal instalasi.\n\nTerima kasih! 🙏	["customer_id", "customer_name", "package_name", "speed", "monthly_fee"]	✅ *REGISTRASI DISETUJUI*\n\nSelamat! Registrasi Anda telah disetujui.\n\nCustomer ID: CUST001\nNama: Ahmad Yani\nPaket: Premium FTTH\nKecepatan: 50 Mbps\nBiaya: Rp 350.000/bulan\n\nTim kami akan segera menghubungi Anda untuk jadwal instalasi.\n\nTerima kasih! 🙏	id	t	1	2025-10-15 01:13:56.068066	2025-10-15 01:13:56.068066
6	PAYMENT_RECEIVED	Payment Confirmation	Konfirmasi pembayaran diterima	customer	💰 *PEMBAYARAN DITERIMA*\n\nTerima kasih atas pembayaran Anda!\n\nInvoice: {{invoice_number}}\nJumlah: {{amount}}\nMetode: {{payment_method}}\nTanggal: {{payment_date}}\n\nLayanan Anda aktif hingga {{next_due_date}}\n\nAGLIS Net - Connecting You Better 🌐	["invoice_number", "amount", "payment_method", "payment_date", "next_due_date"]	💰 *PEMBAYARAN DITERIMA*\n\nTerima kasih atas pembayaran Anda!\n\nInvoice: INV-2025-001\nJumlah: Rp 350.000\nMetode: Transfer BCA\nTanggal: 15 Okt 2025\n\nLayanan Anda aktif hingga 15 Nov 2025\n\nAGLIS Net - Connecting You Better 🌐	id	t	1	2025-10-15 01:13:56.068066	2025-10-15 01:13:56.068066
7	DAILY_SUMMARY	Daily Operations Summary	Summary harian untuk management	report	📊 *DAILY REPORT*\n{{date}}\n\n*Tickets*\nTotal: {{total_tickets}}\n✅ Completed: {{completed}}\n🔄 In Progress: {{in_progress}}\n📋 Assigned: {{assigned}}\n🆕 Open: {{open}}\n\n*Performance*\nSLA Compliance: {{sla_compliance}}%\nAvg Resolution: {{avg_resolution}}h\nCustomer Rating: {{avg_rating}}/5\n\n*Technicians*\nActive: {{active_techs}}\nBusy: {{busy_techs}}\nAvailable: {{available_techs}}	["date", "total_tickets", "completed", "in_progress", "assigned", "open", "sla_compliance", "avg_resolution", "avg_rating", "active_techs", "busy_techs", "available_techs"]	📊 *DAILY REPORT*\n15 Oktober 2025\n\n*Tickets*\nTotal: 25\n✅ Completed: 18\n🔄 In Progress: 4\n📋 Assigned: 2\n🆕 Open: 1\n\n*Performance*\nSLA Compliance: 95%\nAvg Resolution: 3.2h\nCustomer Rating: 4.7/5\n\n*Technicians*\nActive: 13\nBusy: 4\nAvailable: 9	id	t	1	2025-10-15 01:13:56.068066	2025-10-15 01:13:56.068066
8	SYSTEM_ALERT	System Alert Notification	Peringatan system issue	system	🚨 *SYSTEM ALERT*\n\nType: {{alert_type}}\nSeverity: {{severity}}\n\n{{message}}\n\n*Time:* {{timestamp}}\n*Affected:* {{affected_services}}\n\n⚡ *IMMEDIATE ATTENTION REQUIRED*	["alert_type", "severity", "message", "timestamp", "affected_services"]	🚨 *SYSTEM ALERT*\n\nType: Network Outage\nSeverity: CRITICAL\n\nOLT-KRW-01 tidak merespon. 150 customers affected.\n\n*Time:* 15 Okt 14:30\n*Affected:* Karawang Area\n\n⚡ *IMMEDIATE ATTENTION REQUIRED*	id	t	1	2025-10-15 01:13:56.068066	2025-10-15 01:13:56.068066
16	WELCOME_MESSAGE	Welcome Message - New Customer	Pesan selamat datang customer baru	customer	🎉 *SELAMAT DATANG DI AGLIS NET!*\n\nDear {{customerName}},\n\nSelamat! Instalasi selesai dan internet Anda sudah AKTIF! 🚀\n\n👤 Customer ID: {{customerId}}\n📦 Package: {{packageName}} ({{speedMbps}} Mbps)\n💰 Tagihan: Rp {{price}}/bulan\n📅 Tanggal Tagihan: Setiap tanggal {{billingDate}}\n\n🌐 *WiFi Info:*\n📶 SSID: {{wifiName}}\n🔒 Password: {{wifiPassword}}\n\n📞 Support: {{supportPhone}}\n📱 Portal: portal.aglis.biz.id\n\nNikmati internet cepat & stabil! 🌟	{"price": "350,000", "wifiName": "AGLIS-NET-001", "speedMbps": "100", "customerId": "AGLS001", "billingDate": "1", "packageName": "100 Mbps", "customerName": "Bapak Rizki", "supportPhone": "0821-xxx", "wifiPassword": "pass123"}	\N	id	t	\N	2025-10-15 03:36:22.638358	2025-10-15 03:36:22.638358
17	UPGRADE_OFFER	Package Upgrade Offer - Marketing	Penawaran upgrade paket	marketing	🎁 *SPECIAL UPGRADE OFFER!*\n\nHi {{customerName}}! 👋\n\n*Paket Saat Ini:*\n📦 {{currentPackage}} - {{currentSpeed}} Mbps\n💰 Rp {{currentPrice}}/bulan\n\n*🔥 UPGRADE KE:*\n📦 {{upgradePackage}} - {{upgradeSpeed}} Mbps\n💰 Rp {{upgradePrice}}/bulan\n🎉 DISKON: {{discount}}%!\n\n*Hanya tambah:* Rp {{priceDiff}}/bulan!\n\nBenefits:\n{{#each benefits}}✅ {{this}}\n{{/each}}\n\n⏰ Valid: {{validUntil}}\n\nReply "YES" atau hub CS!	{"benefits": ["2x faster", "HD streaming"], "discount": "20", "priceDiff": "100,000", "validUntil": "31 Okt", "currentPrice": "250,000", "currentSpeed": "50", "customerName": "Bapak Rizki", "upgradePrice": "350,000", "upgradeSpeed": "100", "currentPackage": "50 Mbps", "upgradePackage": "100 Mbps"}	\N	id	t	\N	2025-10-15 03:36:22.638358	2025-10-15 03:36:22.638358
18	SATISFACTION_SURVEY	Satisfaction Survey - Customer	Survey kepuasan customer	customer	⭐ *RATE OUR SERVICE*\n\nHi {{customerName}}!\n\nTeknisi {{technicianName}} sudah complete:\n🎫 Ticket: #{{ticketNumber}}\n📋 Service: {{serviceType}}\n✅ Done: {{completedDate}}\n\n*Bagaimana pengalaman Anda?*\n\n⭐⭐⭐⭐⭐ - Excellent\n⭐⭐⭐⭐ - Good\n⭐⭐⭐ - Average\n\n📝 Reply 1-5 atau klik:\n{{surveyUrl}}\n\nFeedback Anda sangat berharga! 🙏	{"surveyUrl": "portal.aglis.biz.id/survey/123", "serviceType": "FTTH Repair", "customerName": "Bapak Rizki", "ticketNumber": "TKT001", "completedDate": "15 Okt", "technicianName": "Ahmad"}	\N	id	t	\N	2025-10-15 03:36:22.638358	2025-10-15 03:36:22.638358
19	TECHNICIAN_PERFORMANCE	Performance Report - Technician	Laporan performa teknisi	team	🏆 *YOUR PERFORMANCE REPORT*\n\nHey {{technicianName}}! 👋\n\n*{{period}} Summary:*\n\n📊 *Statistics:*\n• Completed: {{ticketsCompleted}} ✅\n• Avg Rating: {{averageRating}}/5.0 ⭐\n• SLA: {{slaAchievement}}%\n• Rank: #{{rank}} of {{totalTechnicians}}\n\n{{#if topPerformerBonus}}🎁 Bonus: Rp {{topPerformerBonus}} (Top Performer!){{/if}}\n\nContinue the great work! 💪	{"rank": "2", "period": "This Week", "averageRating": "4.8", "slaAchievement": "100", "technicianName": "Ahmad Fajar", "ticketsCompleted": "15", "totalTechnicians": "10", "topPerformerBonus": "500,000"}	\N	id	t	\N	2025-10-15 03:36:22.638358	2025-10-15 03:36:22.638358
20	PROMOTION_CAMPAIGN	Promotion Campaign - Marketing	Kampanye promosi ke customer	marketing	🎉 *{{campaignTitle}}*\n\nHi {{customerName}}! 👋\n\n{{offer}}\n\n{{#if discount}}🔥 DISKON {{discount}}%!{{/if}}\n\n⏰ Berlaku sampai: {{validUntil}}\n\n{{#if terms}}*Syarat:*\n{{#each terms}}• {{this}}\n{{/each}}{{/if}}\n\n*{{ctaText}}*\n👉 {{ctaLink}}\n\n_Limited time offer!_ ⚡	{"offer": "Upgrade gratis ke 100 Mbps!", "terms": ["Min 6 bulan"], "ctaLink": "portal.aglis.biz.id/promo", "ctaText": "Ambil Sekarang", "discount": "50", "validUntil": "31 Mar 2025", "customerName": "Bapak Rizki", "campaignTitle": "RAMADAN PROMO 2025"}	\N	id	t	\N	2025-10-15 03:36:22.638358	2025-10-15 03:36:22.638358
21	OTP_VERIFICATION	OTP Verification Code	Kode OTP untuk verifikasi registrasi	customer	🔐 *KODE VERIFIKASI AGLIS*\n\nHi {{customerName}},\n\nKode verifikasi Anda: {{otpCode}}\n\n⏰ Berlaku: {{expiryMinutes}} menit\n📱 Untuk: {{purpose}}\n\n*JANGAN BERIKAN kode ini kepada siapapun!*\n\nAGLIS Internet Broadband - Secure & Reliable 🌐	{"otpCode": "123456", "purpose": "Verifikasi registrasi", "customerName": "Bapak Rizki", "expiryMinutes": "5"}	🔐 *KODE VERIFIKASI AGLIS*\n\nHi Bapak Rizki,\n\nKode verifikasi Anda: 123456\n\n⏰ Berlaku: 5 menit\n📱 Untuk: Verifikasi registrasi\n\n*JANGAN BERIKAN kode ini kepada siapapun!*	id	t	\N	2025-10-15 04:17:26.928099	2025-10-15 04:21:37.660532
22	OTP_LOGIN	OTP Login Code	Kode OTP untuk login customer portal	customer	🔑 *KODE LOGIN AGLIS*\n\nHi {{customerName}},\n\nKode login Anda: {{otpCode}}\n\n⏰ Berlaku: {{expiryMinutes}} menit\n🌐 Portal: {{portalUrl}}\n\n*JANGAN BERIKAN kode ini kepada siapapun!*\n\nAGLIS Internet Broadband - Secure Access 🔐	{"otpCode": "789012", "portalUrl": "portal.aglis.biz.id", "customerName": "Bapak Rizki", "expiryMinutes": "10"}	🔑 *KODE LOGIN AGLIS*\n\nHi Bapak Rizki,\n\nKode login Anda: 789012\n\n⏰ Berlaku: 10 menit\n🌐 Portal: portal.aglis.biz.id	id	t	\N	2025-10-15 04:17:26.928099	2025-10-15 04:21:04.442063
\.


--
-- Data for Name: whatsapp_notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.whatsapp_notifications (id, notification_id, user_id, group_id, recipient_type, phone_number, message, template_name, status, provider, provider_message_id, provider_response, error_message, retry_count, sent_at, delivered_at, read_at, failed_at, created_at, ticket_id, invoice_id, notification_type) FROM stdin;
1	\N	\N	1	group	120363419722776103	🧪 *TEST MESSAGE*\n\nHalo Teknisi Karawang!\n\nIni adalah test message dari AGLIS Management System.\n\nWaktu: 15/10/2025, 08.43.58\n\n✅ Jika Anda menerima pesan ini, grup sudah terkonfigurasi dengan benar!	\N	failed	fonnte	\N	{"error": "Invalid WhatsApp number format", "success": false}	\N	0	\N	\N	\N	\N	2025-10-15 01:44:02.983563	\N	\N	\N
2	\N	\N	1	group	120363419722776103@g.us	🧪 *TEST MESSAGE*\n\nHalo Teknisi Karawang!\n\nIni adalah test message dari AGLIS Management System.\n\nWaktu: 15/10/2025, 08.48.29\n\n✅ Jika Anda menerima pesan ini, grup sudah terkonfigurasi dengan benar!	\N	failed	fonnte	\N	{"error": "Invalid WhatsApp number format", "success": false}	\N	0	\N	\N	\N	\N	2025-10-15 01:48:39.139883	\N	\N	\N
3	\N	\N	1	group	120363419722776103@g.us	🧪 *TEST MESSAGE*\n\nHalo Teknisi Karawang!\n\nIni adalah test message dari AGLIS Management System.\n\nWaktu: 15/10/2025, 08.53.53\n\n✅ Jika Anda menerima pesan ini, grup sudah terkonfigurasi dengan benar!	\N	sent	fonnte	\N	{"data": {"reason": "invalid group id", "status": false, "requestid": 146745838}, "success": true, "provider": "fonnte"}	\N	0	\N	\N	\N	\N	2025-10-15 01:53:58.373653	\N	\N	\N
4	\N	\N	1	group	120363419722776103@g.us	🧪 *TEST MESSAGE*\n\nHalo Teknisi Karawang!\n\nIni adalah test message dari AGLIS Management System.\n\nWaktu: 15/10/2025, 09.06.15\n\n✅ Jika Anda menerima pesan ini, grup sudah terkonfigurasi dengan benar!	\N	failed	fonnte	\N	{"error": "Invalid WhatsApp number format", "success": false}	\N	0	\N	\N	\N	\N	2025-10-15 02:06:17.322404	\N	\N	\N
5	\N	\N	1	group	120363419722776103@g.us	🧪 *TEST MESSAGE*\n\nHalo Teknisi Karawang!\n\nIni adalah test message dari AGLIS Management System.\n\nWaktu: 15/10/2025, 09.08.36\n\n✅ Jika Anda menerima pesan ini, grup sudah terkonfigurasi dengan benar!	\N	failed	fonnte	\N	{"error": "Invalid WhatsApp number format", "success": false}	\N	0	\N	\N	\N	\N	2025-10-15 02:08:43.506973	\N	\N	\N
6	\N	\N	1	group	120363419722776103@g.us	🧪 *TEST MESSAGE*\n\nHalo Teknisi Karawang!\n\nIni adalah test message dari AGLIS Management System.\n\nWaktu: 15/10/2025, 09.21.55\n\n✅ Jika Anda menerima pesan ini, grup sudah terkonfigurasi dengan benar!	\N	failed	fonnte	\N	{"error": "Invalid WhatsApp number format", "success": false}	\N	0	\N	\N	\N	\N	2025-10-15 02:21:57.423271	\N	\N	\N
7	\N	\N	1	group	120363419722776103@g.us	🧪 *TEST MESSAGE*\n\nHalo Teknisi Karawang!\n\nIni adalah test message dari AGLIS Management System.\n\nWaktu: 15/10/2025, 09.24.13\n\n✅ Jika Anda menerima pesan ini, grup sudah terkonfigurasi dengan benar!	\N	failed	fonnte	\N	{"error": "Invalid WhatsApp number format", "success": false}	\N	0	\N	\N	\N	\N	2025-10-15 02:24:19.284526	\N	\N	\N
8	\N	\N	1	group	120363419722776103@g.us	🧪 *TEST MESSAGE*\n\nHalo Teknisi Karawang!\n\nIni adalah test message dari AGLIS Management System.\n\nWaktu: 15/10/2025, 09.38.34\n\n✅ Jika Anda menerima pesan ini, grup sudah terkonfigurasi dengan benar!	\N	failed	fonnte	\N	{"error": "Invalid WhatsApp number format", "success": false}	\N	0	\N	\N	\N	\N	2025-10-15 02:38:36.051245	\N	\N	\N
9	\N	\N	1	group	120363419722776103@g.us	🧪 *TEST MESSAGE*\n\nHalo Teknisi Karawang!\n\nIni adalah test message dari AGLIS Management System.\n\nWaktu: 15/10/2025, 09.45.42\n\n✅ Jika Anda menerima pesan ini, grup sudah terkonfigurasi dengan benar!	\N	sent	fonnte	\N	{"data": {"id": ["125974898"], "quota": {"628179380800": {"used": 1, "quota": 836, "details": "deduced from total quota", "remaining": 835}}, "detail": "success! message in queue", "status": true, "target": ["120363419722776103@g.us"], "process": "pending", "requestid": 146834371}, "success": true, "provider": "fonnte"}	\N	0	\N	\N	\N	\N	2025-10-15 02:45:45.880877	\N	\N	\N
10	\N	\N	1	group	120363419722776103@g.us	🧪 *TEST MESSAGE*\n\nHalo Teknisi Karawang!\n\nIni adalah test message dari AGLIS Management System.\n\nWaktu: 15/10/2025, 10.37.02\n\n✅ Jika Anda menerima pesan ini, grup sudah terkonfigurasi dengan benar!	\N	sent	fonnte	\N	{"data": {"id": ["125987755"], "quota": {"628179380800": {"used": 1, "quota": 10000, "details": "deduced from total quota", "remaining": 9999}}, "detail": "success! message in queue", "status": true, "target": ["120363419722776103@g.us"], "process": "pending", "requestid": 146919238}, "success": true, "provider": "fonnte"}	\N	0	\N	\N	\N	\N	2025-10-15 03:37:03.587408	\N	\N	\N
12	\N	\N	\N	individual	0817102070	🔄 *UPDATE TIKET ANDA*\n\nTicket: #TKT20251015002\nStatus: on_hold → in_progress\n\nTeknisi: Dani\n\n_Teknisi kami sedang menangani masalah Anda._	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 05:21:01.638573	24	\N	ticket_status_update
13	\N	\N	\N	individual	0817102070	🔄 *UPDATE TIKET ANDA*\n\nTicket: #TKT20251015002\nStatus: on_hold → in_progress\n\nTeknisi: Dani\n\n_Teknisi kami sedang menangani masalah Anda._	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 05:49:42.916829	24	\N	ticket_status_update
14	\N	\N	\N	individual	08197670700	📩 *TIKET BARU ASSIGNED*\n\nTicket: #TKT20251015002\nCustomer: Udin\nLocation: Jalan kertanegara no.136 Grand Taruma\nPriority: 🟡 NORMAL\n\nIssue: Instalasi Baru - Udin\nSLA: 24 jam\nDeadline: 16 Okt 2025, 05.07\n\n📍 View Detail: http://localhost:3000/tickets/24\n\n_Mohon segera ditangani. Terima kasih!_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 05:56:22.431638	24	\N	ticket_assignment
15	\N	\N	\N	individual	08197670700	📩 *TIKET BARU ASSIGNED*\n\nTicket: #TKT20251015002\nCustomer: Udin\nLocation: Jalan kertanegara no.136 Grand Taruma\nPriority: 🟡 NORMAL\n\nIssue: Instalasi Baru - Udin\nSLA: 24 jam\nDeadline: 16 Okt 2025, 05.07\n\n📍 View Detail: http://localhost:3000/tickets/24\n\n_Mohon segera ditangani. Terima kasih!_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 05:58:02.642171	24	\N	ticket_assignment
16	\N	\N	\N	individual	0817102070	🔄 *UPDATE TIKET ANDA*\n\nTicket: #TKT20251015002\nStatus: on_hold → in_progress\n\nTeknisi: Dani\n\n_Teknisi kami sedang menangani masalah Anda._	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 06:02:27.710423	24	\N	ticket_status_update
17	\N	\N	\N	individual	0817102070	👤 *UPDATE TIKET ANDA*\n\nTicket: #TKT20251014011\nStatus: open → assigned\n\nTeknisi: Dani\n\n_Teknisi kami sedang menuju lokasi Anda._	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 06:24:55.998654	27	\N	ticket_status_update
18	\N	\N	\N	individual	08197670700	📩 *TIKET BARU ASSIGNED*\n\nTicket: #TKT20251014011\nCustomer: Udin\nLocation: Jalan kertanegara no.136 Grand Taruma\nPriority: 🟡 NORMAL\n\nIssue: Installation - Udin\nSLA: 24 jam\nDeadline: 16 Okt 2025, 06.24\n\n📍 View Detail: http://localhost:3000/tickets/27\n\n_Mohon segera ditangani. Terima kasih!_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 06:24:55.999912	27	\N	ticket_assignment
19	\N	\N	\N	individual	08197670700	📩 *TIKET BARU ASSIGNED*\n\nTicket: #TKT20251014011\nCustomer: Udin\nLocation: Jalan kertanegara no.136 Grand Taruma\nPriority: 🟡 NORMAL\n\nIssue: Installation - Udin\nSLA: 24 jam\nDeadline: 16 Okt 2025, 06.24\n\n📍 View Detail: https://portal.aglis.biz.id/tickets/27\n\n_Mohon segera ditangani. Terima kasih!_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 06:32:36.730707	27	\N	ticket_assignment
20	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 3 jam 47 menit ⏰\nProgress: 84%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 08:15:00.0268	21	\N	sla_warning
21	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 3 jam 47 menit ⏰\nProgress: 84%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 08:15:00.027473	21	\N	sla_warning
22	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 3 jam 47 menit ⏰\nProgress: 84%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 08:15:00.029039	21	\N	sla_warning
23	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 3 jam 47 menit ⏰\nProgress: 84%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 08:15:00.02973	21	\N	sla_warning
24	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 3 jam 32 menit ⏰\nProgress: 85%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 08:30:00.026554	21	\N	sla_warning
25	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 3 jam 32 menit ⏰\nProgress: 85%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 08:30:00.027873	21	\N	sla_warning
26	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 3 jam 32 menit ⏰\nProgress: 85%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 08:30:00.033157	21	\N	sla_warning
27	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 3 jam 32 menit ⏰\nProgress: 85%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 08:30:00.033541	21	\N	sla_warning
28	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 3 jam 17 menit ⏰\nProgress: 86%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 08:45:00.027748	21	\N	sla_warning
29	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 3 jam 17 menit ⏰\nProgress: 86%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 08:45:00.028115	21	\N	sla_warning
30	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 3 jam 17 menit ⏰\nProgress: 86%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 08:45:00.030321	21	\N	sla_warning
31	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 3 jam 17 menit ⏰\nProgress: 86%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 08:45:00.030483	21	\N	sla_warning
32	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 3 jam 2 menit ⏰\nProgress: 87%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 09:00:00.025742	21	\N	sla_warning
33	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 3 jam 2 menit ⏰\nProgress: 87%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 09:00:00.026009	21	\N	sla_warning
34	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 3 jam 2 menit ⏰\nProgress: 87%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 09:00:00.028419	21	\N	sla_warning
35	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 3 jam 2 menit ⏰\nProgress: 87%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 09:00:00.03445	21	\N	sla_warning
36	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 jam 47 menit ⏰\nProgress: 88%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 09:15:00.02596	21	\N	sla_warning
37	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 jam 47 menit ⏰\nProgress: 88%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 09:15:00.027346	21	\N	sla_warning
38	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 jam 47 menit ⏰\nProgress: 88%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 09:15:00.02867	21	\N	sla_warning
39	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 jam 47 menit ⏰\nProgress: 88%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 09:15:00.028684	21	\N	sla_warning
40	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 jam 32 menit ⏰\nProgress: 89%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 09:30:00.025781	21	\N	sla_warning
41	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 jam 32 menit ⏰\nProgress: 89%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 09:30:00.026685	21	\N	sla_warning
42	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 jam 32 menit ⏰\nProgress: 89%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 09:30:00.027464	21	\N	sla_warning
43	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 jam 32 menit ⏰\nProgress: 89%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 09:30:00.02822	21	\N	sla_warning
44	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 jam 17 menit ⏰\nProgress: 90%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 09:45:00.025996	21	\N	sla_warning
45	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 jam 17 menit ⏰\nProgress: 90%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 09:45:00.026901	21	\N	sla_warning
46	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 jam 17 menit ⏰\nProgress: 90%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 09:45:00.027135	21	\N	sla_warning
47	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 jam 17 menit ⏰\nProgress: 90%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 09:45:00.027189	21	\N	sla_warning
48	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 jam 2 menit ⏰\nProgress: 91%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 10:00:00.024986	21	\N	sla_warning
49	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 jam 2 menit ⏰\nProgress: 91%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 10:00:00.025929	21	\N	sla_warning
50	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 jam 2 menit ⏰\nProgress: 91%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 10:00:00.025975	21	\N	sla_warning
51	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 jam 2 menit ⏰\nProgress: 91%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 10:00:00.026419	21	\N	sla_warning
52	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 1 jam 47 menit ⏰\nProgress: 92%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 10:15:00.025706	21	\N	sla_warning
53	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 1 jam 47 menit ⏰\nProgress: 92%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 10:15:00.025807	21	\N	sla_warning
54	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 1 jam 47 menit ⏰\nProgress: 92%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 10:15:00.025789	21	\N	sla_warning
55	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 1 jam 47 menit ⏰\nProgress: 92%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 10:15:00.027978	21	\N	sla_warning
56	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 1 jam 32 menit ⏰\nProgress: 93%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 10:30:00.02392	21	\N	sla_warning
57	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 1 jam 32 menit ⏰\nProgress: 93%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 10:30:00.024534	21	\N	sla_warning
58	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 1 jam 32 menit ⏰\nProgress: 93%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 10:30:00.026194	21	\N	sla_warning
59	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 1 jam 32 menit ⏰\nProgress: 93%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 10:30:00.030386	21	\N	sla_warning
60	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 1 jam 17 menit ⏰\nProgress: 94%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 10:45:00.026341	21	\N	sla_warning
61	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 1 jam 17 menit ⏰\nProgress: 94%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 10:45:00.02638	21	\N	sla_warning
62	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 1 jam 17 menit ⏰\nProgress: 94%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 10:45:00.028275	21	\N	sla_warning
63	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 1 jam 17 menit ⏰\nProgress: 94%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 10:45:00.029438	21	\N	sla_warning
64	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 1 jam 2 menit ⏰\nProgress: 95%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 11:00:00.024459	21	\N	sla_warning
65	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 1 jam 2 menit ⏰\nProgress: 95%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 11:00:00.025273	21	\N	sla_warning
66	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 1 jam 2 menit ⏰\nProgress: 95%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 11:00:00.028223	21	\N	sla_warning
67	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 1 jam 2 menit ⏰\nProgress: 95%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 11:00:00.032802	21	\N	sla_warning
68	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 47 menit ⏰\nProgress: 96%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 11:15:00.023442	21	\N	sla_warning
69	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 47 menit ⏰\nProgress: 96%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 11:15:00.025145	21	\N	sla_warning
70	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 47 menit ⏰\nProgress: 96%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 11:15:00.025443	21	\N	sla_warning
71	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 47 menit ⏰\nProgress: 96%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 11:15:00.026296	21	\N	sla_warning
72	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 32 menit ⏰\nProgress: 97%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 11:30:00.024989	21	\N	sla_warning
73	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 32 menit ⏰\nProgress: 97%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 11:30:00.026065	21	\N	sla_warning
74	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 32 menit ⏰\nProgress: 97%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 11:30:00.026145	21	\N	sla_warning
75	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 32 menit ⏰\nProgress: 97%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 11:30:00.027065	21	\N	sla_warning
76	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 17 menit ⏰\nProgress: 98%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 11:45:00.026497	21	\N	sla_warning
77	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 17 menit ⏰\nProgress: 98%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 11:45:00.027205	21	\N	sla_warning
78	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 17 menit ⏰\nProgress: 98%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 11:45:00.031436	21	\N	sla_warning
79	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 17 menit ⏰\nProgress: 98%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 11:45:00.031685	21	\N	sla_warning
80	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 menit ⏰\nProgress: 99%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 12:00:00.026262	21	\N	sla_warning
81	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 menit ⏰\nProgress: 99%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 12:00:00.026981	21	\N	sla_warning
82	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 menit ⏰\nProgress: 99%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 12:00:00.027103	21	\N	sla_warning
83	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\nSLA Target: 24 jam\nRemaining: 2 menit ⏰\nProgress: 99%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/21\n\n_Butuh escalation?_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-15 12:00:00.02772	21	\N	sla_warning
84	\N	\N	\N	individual	0817102070	🔄 *UPDATE TIKET ANDA*\n\nTicket: #TKT20251014011\nStatus: assigned → in_progress\n\nTeknisi: Dudung\n\n_Teknisi kami sedang menangani masalah Anda._	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 16:53:56.077632	27	\N	ticket_status_update
85	\N	\N	\N	individual	0817102070	✅ *UPDATE TIKET ANDA*\n\nTicket: #TKT20251014011\nStatus: in_progress → completed\n\nTeknisi: Dudung\nSelesai: 15/10/2025, 23.55.30\nDurasi: 17 jam 31 menit\n\nMasalah: Installation - Udin\n\nSolusi: Installation untuk Udin telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Gold 75M dengan bandwidth 75 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.\n\n⭐ Rate our service: https://portal.aglis.biz.id/tickets/27/rate\n\n_Terima kasih atas kepercayaan Anda!_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 16:55:30.464389	27	\N	ticket_status_update
86	\N	\N	\N	individual	0817102070	✅ *UPDATE TIKET ANDA*\n\nTicket: #TKT20251015002\nStatus: in_progress → completed\n\nTeknisi: Dani\nSelesai: 16/10/2025, 00.30.48\nDurasi: 19 jam 23 menit\n\nMasalah: Instalasi Baru - Udin\n\nSolusi: Installation untuk Udin telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Gold 75M dengan bandwidth 75 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.\n\n⭐ Rate our service: https://portal.aglis.biz.id/tickets/24/rate\n\n_Terima kasih atas kepercayaan Anda!_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 17:30:48.997345	24	\N	ticket_status_update
87	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251015002\nCustomer: Udin\nTeknisi: Dani\n\n⏱️ Selesai: 16/10/2025, 00.30.48\n⌛ Durasi: 19 jam 23 menit\n\n📝 Masalah: Instalasi Baru - Udin\n\n✅ Solusi: Installation untuk Udin telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Gold 75M dengan bandwidth 75 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 17:30:49.042194	24	\N	ticket_completed
88	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251015002\nCustomer: Udin\nTeknisi: Dani\n\n⏱️ Selesai: 16/10/2025, 00.30.48\n⌛ Durasi: 19 jam 23 menit\n\n📝 Masalah: Instalasi Baru - Udin\n\n✅ Solusi: Installation untuk Udin telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Gold 75M dengan bandwidth 75 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 17:30:49.075698	24	\N	ticket_completed
89	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251015002\nCustomer: Udin\nTeknisi: Dani\n\n⏱️ Selesai: 16/10/2025, 00.30.48\n⌛ Durasi: 19 jam 23 menit\n\n📝 Masalah: Instalasi Baru - Udin\n\n✅ Solusi: Installation untuk Udin telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Gold 75M dengan bandwidth 75 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 17:30:49.110638	24	\N	ticket_completed
90	\N	\N	\N	individual	08197670700	🔄 *UPDATE TIKET ANDA*\n\nTicket: #TKT20251013010\nStatus: assigned → in_progress\n\nTeknisi: Lufti Rahadiansyah\n\n_Teknisi kami sedang menangani masalah Anda._	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 17:37:36.941167	21	\N	ticket_status_update
91	\N	\N	\N	individual	08197670700	✅ *UPDATE TIKET ANDA*\n\nTicket: #TKT20251013010\nStatus: in_progress → completed\n\nTeknisi: Lufti Rahadiansyah\nSelesai: 16/10/2025, 00.39.01\nDurasi: 29 jam 36 menit\n\nMasalah: Repair - Ega Nabila\n\nSolusi: Ticket repair untuk Ega Nabila telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.\n\n⭐ Rate our service: https://portal.aglis.biz.id/tickets/21/rate\n\n_Terima kasih atas kepercayaan Anda!_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 17:39:02.020103	21	\N	ticket_status_update
92	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\n⏱️ Selesai: 16/10/2025, 00.39.01\n⌛ Durasi: 29 jam 36 menit\n\n📝 Masalah: Repair - Ega Nabila\n\n✅ Solusi: Ticket repair untuk Ega Nabila telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 17:39:02.054893	21	\N	ticket_completed
93	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\n⏱️ Selesai: 16/10/2025, 00.39.01\n⌛ Durasi: 29 jam 36 menit\n\n📝 Masalah: Repair - Ega Nabila\n\n✅ Solusi: Ticket repair untuk Ega Nabila telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 17:39:02.089911	21	\N	ticket_completed
94	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\n⏱️ Selesai: 16/10/2025, 00.39.01\n⌛ Durasi: 29 jam 36 menit\n\n📝 Masalah: Repair - Ega Nabila\n\n✅ Solusi: Ticket repair untuk Ega Nabila telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 17:39:02.119343	21	\N	ticket_completed
95	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251013010\nCustomer: Ega Nabila\nTeknisi: Lufti Rahadiansyah\n\n⏱️ Selesai: 16/10/2025, 00.39.01\n⌛ Durasi: 29 jam 36 menit\n\n📝 Masalah: Repair - Ega Nabila\n\n✅ Solusi: Ticket repair untuk Ega Nabila telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-15 17:39:02.157741	21	\N	ticket_completed
96	\N	\N	\N	individual	0817102070	✅ *TICKET BERHASIL DIBUAT*\n\nHi Udin,\nTicket Anda telah berhasil dibuat!\n\nTicket: #TKT20251015004\nJenis: WiFi Setup\nJudul: WiFi Setup - Udin\n\nStatus: ⏳ Open (Menunggu Assignment)\n\nTicket Anda sedang diproses. \nTim kami akan segera menindaklanjuti.\n\n📱 Track ticket: https://portal.aglis.biz.id/tickets/29\n\nAnda akan menerima update via WhatsApp saat teknisi di-assign.\n\n_AGLIS Net - Fast Response!_ 🚀	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 00:57:47.712241	29	\N	ticket_created
97	\N	\N	\N	individual	0817102070	✅ *TICKET BERHASIL DIBUAT*\n\nHi Udin,\nTicket Anda telah berhasil dibuat!\n\nTicket: #TKT20251015005\nJenis: Repair\nJudul: Repair - Udin\n\nStatus: ⏳ Open (Menunggu Assignment)\n\nTicket Anda sedang diproses. \nTim kami akan segera menindaklanjuti.\n\n📱 Track ticket: https://portal.aglis.biz.id/tickets/30\n\nAnda akan menerima update via WhatsApp saat teknisi di-assign.\n\n_AGLIS Net - Fast Response!_ 🚀	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 01:33:40.061592	30	\N	ticket_created
98	\N	\N	\N	group	120363419722776103@g.us	🆕 *TICKET BARU - PERLU ASSIGNMENT!*\n\n🟢 #TKT20251015005\n\nCustomer: Udin\nPhone: 0817102070\nType: Repair\nPriority: NORMAL\nJudul: Repair - Udin\n\n⏳ Status: Open (Unassigned)\n\n*Action needed: Assign teknisi ASAP*\n\n📱 Assign sekarang: https://portal.aglis.biz.id/tickets\n\n_AGLIS Net - Quick Response Team!_ ⚡	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 01:33:40.095281	30	\N	ticket_created
99	\N	\N	\N	group	120363419722776103@g.us	🔔 *TICKET TERSEDIA!*\n\n🟢 NORMAL\n\n#TKT20251015005 - Repair\nCustomer: Udin\nLokasi: Jalan kertanegara no.136 Grand Taruma\n\nDetail: INFORMASI PELANGGAN\nNama: Udin\nAlamat: Jalan kertanegara no.136 Grand Taruma\nTelepon: 0817102070\nPak...\n\nSiapa yang available untuk handle ticket ini?\nKoordinasi dengan supervisor untuk assignment.\n\n_AGLIS Net - Team Available!_ 💪	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 01:33:40.127755	30	\N	ticket_created
100	\N	\N	\N	individual	0267811003	📩 *TIKET BARU ASSIGNED*\n\nTicket: #TKT20251015005\nCustomer: Udin\nLocation: Jalan kertanegara no.136 Grand Taruma\nPriority: 🟡 NORMAL\n\nIssue: Repair - Udin\nSLA: 24 jam\nDeadline: 17 Okt 2025, 01.33\n\n📍 View Detail: https://portal.aglis.biz.id/tickets/30\n\n_Mohon segera ditangani. Terima kasih!_	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-16 01:49:01.671959	30	\N	ticket_assignment
101	\N	\N	\N	individual	0817102070	👤 *UPDATE TIKET ANDA*\n\nTicket: #TKT20251015005\nStatus: open → assigned\n\nTeknisi: Candra Wijaya\n\n_Teknisi kami sedang menuju lokasi Anda._	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 01:49:01.710453	30	\N	ticket_status_update
102	\N	\N	\N	individual	0817102070	🔄 *UPDATE TIKET ANDA*\n\nTicket: #TKT20251015005\nStatus: assigned → in_progress\n\nTeknisi: Candra Wijaya\n\n_Teknisi kami sedang menangani masalah Anda._	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 01:49:31.666841	30	\N	ticket_status_update
103	\N	\N	\N	individual	0817102070	✅ *UPDATE TIKET ANDA*\n\nTicket: #TKT20251015005\nStatus: in_progress → completed\n\nTeknisi: Candra Wijaya\nSelesai: 16/10/2025, 08.50.39\nDurasi: 7 jam 16 menit\n\nMasalah: Repair - Udin\n\nSolusi: Ticket repair untuk Udin telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.\n\n⭐ Rate our service: https://portal.aglis.biz.id/tickets/30/rate\n\n_Terima kasih atas kepercayaan Anda!_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 01:50:39.148245	30	\N	ticket_status_update
104	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251015005\nCustomer: Udin\nTeknisi: Candra Wijaya\n\n⏱️ Selesai: 16/10/2025, 08.50.39\n⌛ Durasi: 7 jam 16 menit\n\n📝 Masalah: Repair - Udin\n\n✅ Solusi: Ticket repair untuk Udin telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 01:50:39.181799	30	\N	ticket_completed
105	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251015005\nCustomer: Udin\nTeknisi: Candra Wijaya\n\n⏱️ Selesai: 16/10/2025, 08.50.39\n⌛ Durasi: 7 jam 16 menit\n\n📝 Masalah: Repair - Udin\n\n✅ Solusi: Ticket repair untuk Udin telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 01:50:39.211824	30	\N	ticket_completed
106	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251015005\nCustomer: Udin\nTeknisi: Candra Wijaya\n\n⏱️ Selesai: 16/10/2025, 08.50.39\n⌛ Durasi: 7 jam 16 menit\n\n📝 Masalah: Repair - Udin\n\n✅ Solusi: Ticket repair untuk Udin telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 01:50:39.248179	30	\N	ticket_completed
107	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251015005\nCustomer: Udin\nTeknisi: Candra Wijaya\n\n⏱️ Selesai: 16/10/2025, 08.50.39\n⌛ Durasi: 7 jam 16 menit\n\n📝 Masalah: Repair - Udin\n\n✅ Solusi: Ticket repair untuk Udin telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 01:50:39.283727	30	\N	ticket_completed
137	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 3 jam 32 menit ⏰\nProgress: 85%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 14:00:00.08751	28	\N	sla_warning
108	\N	\N	\N	individual	0267811003	🎫 *TICKET ASSIGNED - LEAD TECHNICIAN*\n\nHi Candra Wijaya,\nAnda ditunjuk sebagai *LEAD TECHNICIAN*!\n\nTicket: #TKT20251015004\nCustomer: Udin\nLokasi: Jalan kertanegara no.136 Grand Taruma\n\n👥 *Tim Anda (3 teknisi):*\n   - Budi Santoso (member)\n   - Eko Prasetyo (support)\n\n*Tanggung Jawab:*\n✅ Koordinasi tim\n✅ Update progress\n✅ Quality control\n\n📱 View detail: https://portal.aglis.biz.id/tickets/29\n\n_AGLIS Net - Teamwork Makes The Dream Work!_ 🚀	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-16 02:14:37.707638	29	\N	team_assignment
109	\N	\N	\N	individual	0267811002	🎫 *TICKET ASSIGNED - TEAM MEMBER*\n\nHi Budi Santoso,\nAnda ditambahkan ke tim ticket!\n\nTicket: #TKT20251015004\nCustomer: Udin\nLokasi: Jalan kertanegara no.136 Grand Taruma\n\n👤 *Lead Technician:*\n   Candra Wijaya\n   📱 0267811003\n\nRole Anda: Team Member\n\n*Koordinasi dengan lead untuk:*\n✅ Pembagian tugas\n✅ Jadwal kerja\n✅ Update progress\n\n📱 View detail: https://portal.aglis.biz.id/tickets/29\n\n_AGLIS Net - Together We Achieve More!_ 🤝	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-16 02:14:37.708691	29	\N	team_assignment
110	\N	\N	\N	individual	0267811005	🎫 *TICKET ASSIGNED - SUPPORT*\n\nHi Eko Prasetyo,\nAnda ditambahkan ke tim ticket!\n\nTicket: #TKT20251015004\nCustomer: Udin\nLokasi: Jalan kertanegara no.136 Grand Taruma\n\n👤 *Lead Technician:*\n   Candra Wijaya\n   📱 0267811003\n\nRole Anda: Support\n\n*Koordinasi dengan lead untuk:*\n✅ Pembagian tugas\n✅ Jadwal kerja\n✅ Update progress\n\n📱 View detail: https://portal.aglis.biz.id/tickets/29\n\n_AGLIS Net - Together We Achieve More!_ 🤝	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-16 02:14:37.719823	29	\N	team_assignment
111	\N	\N	\N	individual	0817102070	👤 *UPDATE TIKET ANDA*\n\nTicket: #TKT20251015004\nStatus: open → assigned\n\nTeknisi: Candra Wijaya\n\n_Teknisi kami sedang menuju lokasi Anda._	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 02:14:37.756586	29	\N	ticket_status_update
112	\N	\N	\N	individual	62267811001	🎫 *TICKET ASSIGNED - LEAD TECHNICIAN*\n\nHi Ahmad Fauzi,\nAnda ditunjuk sebagai *LEAD TECHNICIAN*!\n\nTicket: #TKT20251015004\nCustomer: Udin\nLokasi: Jalan kertanegara no.136 Grand Taruma\n\n👥 *Tim Anda (2 teknisi):*\n   - Gilang Ramadhan (member)\n\n*Tanggung Jawab:*\n✅ Koordinasi tim\n✅ Update progress\n✅ Quality control\n\n📱 View detail: https://portal.aglis.biz.id/tickets/29\n\n_AGLIS Net - Teamwork Makes The Dream Work!_ 🚀	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-16 03:34:01.926253	29	\N	team_assignment
113	\N	\N	\N	individual	62267811007	🎫 *TICKET ASSIGNED - TEAM MEMBER*\n\nHi Gilang Ramadhan,\nAnda ditambahkan ke tim ticket!\n\nTicket: #TKT20251015004\nCustomer: Udin\nLokasi: Jalan kertanegara no.136 Grand Taruma\n\n👤 *Lead Technician:*\n   Ahmad Fauzi\n   📱 62267811001\n\nRole Anda: Team Member\n\n*Koordinasi dengan lead untuk:*\n✅ Pembagian tugas\n✅ Jadwal kerja\n✅ Update progress\n\n📱 View detail: https://portal.aglis.biz.id/tickets/29\n\n_AGLIS Net - Together We Achieve More!_ 🤝	\N	failed	fonnte	\N	\N	Invalid WhatsApp number format	0	\N	\N	\N	\N	2025-10-16 03:34:01.926783	29	\N	team_assignment
114	\N	\N	\N	individual	0817102070	👤 *UPDATE TIKET ANDA*\n\nTicket: #TKT20251015004\nStatus: open → assigned\n\nTeknisi: Ahmad Fauzi\n\n_Teknisi kami sedang menuju lokasi Anda._	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 03:34:01.968904	29	\N	ticket_status_update
115	\N	\N	\N	individual	62267811007	🎫 *TICKET ASSIGNED - TEAM MEMBER*\n\nHi Gilang Ramadhan,\nAnda ditambahkan ke tim ticket!\n\nTicket: #TKT20251015004\nCustomer: Udin\nLokasi: Jalan kertanegara no.136 Grand Taruma\n\n👤 *Lead Technician:*\n   Ahmad Fauzi\n   📱 62267811001\n\nRole Anda: Team Member\n\n*Koordinasi dengan lead untuk:*\n✅ Pembagian tugas\n✅ Jadwal kerja\n✅ Update progress\n\n📱 View detail: https://portal.aglis.biz.id/tickets/29\n\n_AGLIS Net - Together We Achieve More!_ 🤝	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 03:36:29.681706	29	\N	team_assignment
116	\N	\N	\N	individual	62267811001	🎫 *TICKET ASSIGNED - LEAD TECHNICIAN*\n\nHi Ahmad Fauzi,\nAnda ditunjuk sebagai *LEAD TECHNICIAN*!\n\nTicket: #TKT20251015004\nCustomer: Udin\nLokasi: Jalan kertanegara no.136 Grand Taruma\n\n👥 *Tim Anda (2 teknisi):*\n   - Gilang Ramadhan (member)\n\n*Tanggung Jawab:*\n✅ Koordinasi tim\n✅ Update progress\n✅ Quality control\n\n📱 View detail: https://portal.aglis.biz.id/tickets/29\n\n_AGLIS Net - Teamwork Makes The Dream Work!_ 🚀	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 03:36:29.682648	29	\N	team_assignment
117	\N	\N	\N	individual	0817102070	👤 *UPDATE TIKET ANDA*\n\nTicket: #TKT20251015004\nStatus: open → assigned\n\nTeknisi: Tim Kami\n\n_Teknisi kami sedang menuju lokasi Anda._	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 03:36:29.697665	29	\N	ticket_status_update
118	\N	\N	\N	individual	0817102070	🔄 *UPDATE TIKET ANDA*\n\nTicket: #TKT20251015004\nStatus: assigned → in_progress\n\nTeknisi: Tim Kami\n\n_Teknisi kami sedang menangani masalah Anda._	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 04:13:18.671588	29	\N	ticket_status_update
119	\N	\N	\N	individual	0817102070	✅ *UPDATE TIKET ANDA*\n\nTicket: #TKT20251015004\nStatus: in_progress → completed\n\nTeknisi: Tim Kami\nSelesai: 16/10/2025, 11.14.45\nDurasi: 10 jam 16 menit\n\nMasalah: WiFi Setup - Udin\n\nSolusi: Ticket wifi_setup untuk Udin telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.\n\n⭐ Rate our service: https://portal.aglis.biz.id/tickets/29/rate\n\n_Terima kasih atas kepercayaan Anda!_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 04:14:45.958657	29	\N	ticket_status_update
120	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251015004\nCustomer: Udin\nTeknisi: Tim Kami\n\n⏱️ Selesai: 16/10/2025, 11.14.45\n⌛ Durasi: 10 jam 16 menit\n\n📝 Masalah: WiFi Setup - Udin\n\n✅ Solusi: Ticket wifi_setup untuk Udin telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 04:14:45.994046	29	\N	ticket_completed
121	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251015004\nCustomer: Udin\nTeknisi: Tim Kami\n\n⏱️ Selesai: 16/10/2025, 11.14.45\n⌛ Durasi: 10 jam 16 menit\n\n📝 Masalah: WiFi Setup - Udin\n\n✅ Solusi: Ticket wifi_setup untuk Udin telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 04:14:46.028483	29	\N	ticket_completed
122	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251015004\nCustomer: Udin\nTeknisi: Tim Kami\n\n⏱️ Selesai: 16/10/2025, 11.14.45\n⌛ Durasi: 10 jam 16 menit\n\n📝 Masalah: WiFi Setup - Udin\n\n✅ Solusi: Ticket wifi_setup untuk Udin telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 04:14:46.058306	29	\N	ticket_completed
123	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251015004\nCustomer: Udin\nTeknisi: Tim Kami\n\n⏱️ Selesai: 16/10/2025, 11.14.45\n⌛ Durasi: 10 jam 16 menit\n\n📝 Masalah: WiFi Setup - Udin\n\n✅ Solusi: Ticket wifi_setup untuk Udin telah diselesaikan dengan baik. Semua pekerjaan yang diperlukan telah dikerjakan sesuai SLA. Testing telah dilakukan dan hasilnya memuaskan. Customer confirm satisfied dengan hasil pekerjaan. Tidak ada outstanding issue. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 04:14:46.092615	29	\N	ticket_completed
124	\N	\N	\N	individual	08197670700	📩 *TIKET BARU ASSIGNED*\n\nTicket: #TKT20251016001\nCustomer: Riky Van Boomel\nLocation: Jl. Neraka Jahanam No. 666\nPriority: 🟡 NORMAL\n\nIssue: Instalasi Baru - Riky Van Boomel\nSLA: 24 jam\nDeadline: 17 Okt 2025, 04.28\n\n📍 View Detail: https://portal.aglis.biz.id/tickets/31\n\n_Mohon segera ditangani. Terima kasih!_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 04:29:25.65407	31	\N	ticket_assignment
125	\N	\N	\N	individual	082321922280	👤 *UPDATE TIKET ANDA*\n\nTicket: #TKT20251016001\nStatus: open → assigned\n\nTeknisi: Dani\n\n_Teknisi kami sedang menuju lokasi Anda._	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 04:29:25.65549	31	\N	ticket_status_update
126	\N	\N	\N	individual	082321922280	🔄 *UPDATE TIKET ANDA*\n\nTicket: #TKT20251016001\nStatus: assigned → in_progress\n\nTeknisi: Dani\n\n_Teknisi kami sedang menangani masalah Anda._	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 04:31:18.382774	31	\N	ticket_status_update
127	\N	\N	\N	individual	082321922280	✅ *UPDATE TIKET ANDA*\n\nTicket: #TKT20251016001\nStatus: in_progress → completed\n\nTeknisi: Dani\nSelesai: 16/10/2025, 11.33.01\nDurasi: 7 jam 4 menit\n\nMasalah: Instalasi Baru - Riky Van Boomel\n\nSolusi: Installation untuk Riky Van Boomel telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Bronze 30M dengan bandwidth 30 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.\n\n⭐ Rate our service: https://portal.aglis.biz.id/tickets/31/rate\n\n_Terima kasih atas kepercayaan Anda!_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 04:33:01.658177	31	\N	ticket_status_update
128	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251016001\nCustomer: Riky Van Boomel\nTeknisi: Dani\n\n⏱️ Selesai: 16/10/2025, 11.33.01\n⌛ Durasi: 7 jam 4 menit\n\n📝 Masalah: Instalasi Baru - Riky Van Boomel\n\n✅ Solusi: Installation untuk Riky Van Boomel telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Bronze 30M dengan bandwidth 30 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 04:33:01.69024	31	\N	ticket_completed
129	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251016001\nCustomer: Riky Van Boomel\nTeknisi: Dani\n\n⏱️ Selesai: 16/10/2025, 11.33.01\n⌛ Durasi: 7 jam 4 menit\n\n📝 Masalah: Instalasi Baru - Riky Van Boomel\n\n✅ Solusi: Installation untuk Riky Van Boomel telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Bronze 30M dengan bandwidth 30 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 04:33:01.722827	31	\N	ticket_completed
130	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251016001\nCustomer: Riky Van Boomel\nTeknisi: Dani\n\n⏱️ Selesai: 16/10/2025, 11.33.01\n⌛ Durasi: 7 jam 4 menit\n\n📝 Masalah: Instalasi Baru - Riky Van Boomel\n\n✅ Solusi: Installation untuk Riky Van Boomel telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Bronze 30M dengan bandwidth 30 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 04:33:01.752964	31	\N	ticket_completed
131	\N	\N	\N	group	120363419722776103@g.us	🎉 *TICKET COMPLETED*\n\nTicket: #TKT20251016001\nCustomer: Riky Van Boomel\nTeknisi: Dani\n\n⏱️ Selesai: 16/10/2025, 11.33.01\n⌛ Durasi: 7 jam 4 menit\n\n📝 Masalah: Instalasi Baru - Riky Van Boomel\n\n✅ Solusi: Installation untuk Riky Van Boomel telah selesai dengan sukses. Fiber optic telah terpasang dengan baik dan signal quality dalam kondisi optimal. ONU telah dikonfigurasi untuk package Home Bronze 30M dengan bandwidth 30 Mbps. Speed test menunjukkan hasil sesuai spesifikasi. Customer telah menerima perangkat dalam kondisi baik, menerima demo penggunaan layanan, dan menandatangani berita acara serah terima. Layanan internet sudah aktif dan berjalan normal. Tidak ada issue yang ditemukan. Ticket ditutup dengan status completed.\n\n_AGLIS Net - Excellent Service!_ 🌐	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 04:33:01.784532	31	\N	ticket_completed
132	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 3 jam 47 menit ⏰\nProgress: 84%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 13:45:00.079442	28	\N	sla_warning
133	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 3 jam 47 menit ⏰\nProgress: 84%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 13:45:00.080956	28	\N	sla_warning
134	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 3 jam 47 menit ⏰\nProgress: 84%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 13:45:00.083086	28	\N	sla_warning
135	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 3 jam 47 menit ⏰\nProgress: 84%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 13:45:00.084151	28	\N	sla_warning
136	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 3 jam 32 menit ⏰\nProgress: 85%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 14:00:00.086162	28	\N	sla_warning
138	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 3 jam 32 menit ⏰\nProgress: 85%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 14:00:00.089873	28	\N	sla_warning
139	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 3 jam 32 menit ⏰\nProgress: 85%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 14:00:00.090996	28	\N	sla_warning
140	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 3 jam 17 menit ⏰\nProgress: 86%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 14:15:00.080567	28	\N	sla_warning
141	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 3 jam 17 menit ⏰\nProgress: 86%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 14:15:00.082507	28	\N	sla_warning
142	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 3 jam 17 menit ⏰\nProgress: 86%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 14:15:00.083396	28	\N	sla_warning
143	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 3 jam 17 menit ⏰\nProgress: 86%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 14:15:05.095494	28	\N	sla_warning
144	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 3 jam 2 menit ⏰\nProgress: 87%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 14:30:00.091812	28	\N	sla_warning
145	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 3 jam 2 menit ⏰\nProgress: 87%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 14:30:00.092069	28	\N	sla_warning
146	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 3 jam 2 menit ⏰\nProgress: 87%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 14:30:00.092276	28	\N	sla_warning
147	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 3 jam 2 menit ⏰\nProgress: 87%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 14:30:00.09379	28	\N	sla_warning
148	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 jam 47 menit ⏰\nProgress: 88%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 14:45:00.076911	28	\N	sla_warning
149	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 jam 47 menit ⏰\nProgress: 88%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 14:45:00.079653	28	\N	sla_warning
150	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 jam 47 menit ⏰\nProgress: 88%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 14:45:00.081898	28	\N	sla_warning
151	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 jam 47 menit ⏰\nProgress: 88%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 14:45:00.086221	28	\N	sla_warning
152	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 jam 32 menit ⏰\nProgress: 89%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 15:00:00.077215	28	\N	sla_warning
153	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 jam 32 menit ⏰\nProgress: 89%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 15:00:00.077145	28	\N	sla_warning
154	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 jam 32 menit ⏰\nProgress: 89%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 15:00:00.080265	28	\N	sla_warning
155	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 jam 32 menit ⏰\nProgress: 89%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 15:00:00.08278	28	\N	sla_warning
156	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 jam 17 menit ⏰\nProgress: 90%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 15:15:00.084402	28	\N	sla_warning
157	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 jam 17 menit ⏰\nProgress: 90%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 15:15:00.086045	28	\N	sla_warning
158	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 jam 17 menit ⏰\nProgress: 90%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 15:15:00.086374	28	\N	sla_warning
159	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 jam 17 menit ⏰\nProgress: 90%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 15:15:00.096439	28	\N	sla_warning
160	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 jam 2 menit ⏰\nProgress: 91%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 15:30:00.080802	28	\N	sla_warning
161	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 jam 2 menit ⏰\nProgress: 91%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 15:30:00.08277	28	\N	sla_warning
162	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 jam 2 menit ⏰\nProgress: 91%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 15:30:00.085078	28	\N	sla_warning
163	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 jam 2 menit ⏰\nProgress: 91%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 15:30:00.087485	28	\N	sla_warning
164	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 1 jam 47 menit ⏰\nProgress: 92%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 15:45:00.07647	28	\N	sla_warning
165	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 1 jam 47 menit ⏰\nProgress: 92%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 15:45:00.078803	28	\N	sla_warning
166	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 1 jam 47 menit ⏰\nProgress: 92%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 15:45:00.079542	28	\N	sla_warning
167	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 1 jam 47 menit ⏰\nProgress: 92%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 15:45:00.082724	28	\N	sla_warning
168	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 1 jam 32 menit ⏰\nProgress: 93%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 16:00:00.08171	28	\N	sla_warning
169	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 1 jam 32 menit ⏰\nProgress: 93%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 16:00:00.082692	28	\N	sla_warning
170	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 1 jam 32 menit ⏰\nProgress: 93%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 16:00:00.084222	28	\N	sla_warning
171	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 1 jam 32 menit ⏰\nProgress: 93%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 16:00:00.117914	28	\N	sla_warning
172	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 1 jam 17 menit ⏰\nProgress: 94%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 16:15:00.063792	28	\N	sla_warning
173	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 1 jam 17 menit ⏰\nProgress: 94%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 16:15:00.065769	28	\N	sla_warning
174	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 1 jam 17 menit ⏰\nProgress: 94%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 16:15:00.075976	28	\N	sla_warning
175	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 1 jam 17 menit ⏰\nProgress: 94%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 16:15:00.098536	28	\N	sla_warning
176	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 1 jam 2 menit ⏰\nProgress: 95%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 16:30:00.076689	28	\N	sla_warning
177	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 1 jam 2 menit ⏰\nProgress: 95%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 16:30:00.078059	28	\N	sla_warning
178	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 1 jam 2 menit ⏰\nProgress: 95%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 16:30:00.0822	28	\N	sla_warning
179	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 1 jam 2 menit ⏰\nProgress: 95%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 16:30:00.086042	28	\N	sla_warning
180	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 47 menit ⏰\nProgress: 96%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 16:45:00.079101	28	\N	sla_warning
181	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 47 menit ⏰\nProgress: 96%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 16:45:00.080487	28	\N	sla_warning
182	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 47 menit ⏰\nProgress: 96%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 16:45:00.082048	28	\N	sla_warning
183	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 47 menit ⏰\nProgress: 96%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 16:45:00.086158	28	\N	sla_warning
184	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 32 menit ⏰\nProgress: 97%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 17:00:00.078746	28	\N	sla_warning
185	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 32 menit ⏰\nProgress: 97%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 17:00:00.079545	28	\N	sla_warning
186	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 32 menit ⏰\nProgress: 97%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 17:00:00.082457	28	\N	sla_warning
187	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 32 menit ⏰\nProgress: 97%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 17:00:00.096047	28	\N	sla_warning
188	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 17 menit ⏰\nProgress: 98%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 17:15:00.0745	28	\N	sla_warning
189	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 17 menit ⏰\nProgress: 98%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 17:15:00.083178	28	\N	sla_warning
190	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 17 menit ⏰\nProgress: 98%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 17:15:00.084391	28	\N	sla_warning
191	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 17 menit ⏰\nProgress: 98%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 17:15:00.091279	28	\N	sla_warning
192	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 menit ⏰\nProgress: 99%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 17:30:00.09092	28	\N	sla_warning
193	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 menit ⏰\nProgress: 99%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 17:30:00.092084	28	\N	sla_warning
194	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 menit ⏰\nProgress: 99%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 17:30:00.092207	28	\N	sla_warning
195	\N	\N	\N	individual	0267800201	⚠️ *SLA WARNING*\n\nTicket: #TKT20251015003\nCustomer: Udin\nTeknisi: Belum di-assign\n\nSLA Target: 24 jam\nRemaining: 2 menit ⏰\nProgress: 99%\n\n🚨 Ticket mendekati deadline!\n\n📍 View: https://portal.aglis.biz.id/tickets/28\n\n_Butuh escalation?_	\N	sent	fonnte	\N	\N	\N	0	\N	\N	\N	\N	2025-10-16 17:30:00.094658	28	\N	sla_warning
\.


--
-- Name: alert_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.alert_history_id_seq', 192, true);


--
-- Name: alert_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.alert_rules_id_seq', 8, true);


--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attachments_id_seq', 1, false);


--
-- Name: billing_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.billing_alerts_id_seq', 1, false);


--
-- Name: billing_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.billing_schedules_id_seq', 1, false);


--
-- Name: customer_complaints_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_complaints_id_seq', 1, false);


--
-- Name: customer_equipment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_equipment_id_seq', 22, true);


--
-- Name: customer_payment_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.customer_payment_methods_id_seq', 1, false);


--
-- Name: customer_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_payments_id_seq', 32, true);


--
-- Name: customer_registrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_registrations_id_seq', 13, true);


--
-- Name: customer_service_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_service_history_id_seq', 1, false);


--
-- Name: customer_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_sessions_id_seq', 10, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_id_seq', 19, true);


--
-- Name: equipment_master_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.equipment_master_id_seq', 33, true);


--
-- Name: equipment_service_mapping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.equipment_service_mapping_id_seq', 1, false);


--
-- Name: failed_login_attempts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.failed_login_attempts_id_seq', 19, true);


--
-- Name: inventory_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_items_id_seq', 1, false);


--
-- Name: inventory_stock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.inventory_stock_id_seq', 66, true);


--
-- Name: inventory_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_transactions_id_seq', 1, false);


--
-- Name: invoice_line_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.invoice_line_items_id_seq', 1, false);


--
-- Name: invoice_number_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.invoice_number_seq', 1000, false);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.invoices_id_seq', 1, false);


--
-- Name: notification_analytics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_analytics_id_seq', 1, false);


--
-- Name: notification_analytics_summary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_analytics_summary_id_seq', 1, false);


--
-- Name: notification_push_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_push_log_id_seq', 1, false);


--
-- Name: notification_routing_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_routing_rules_id_seq', 8, true);


--
-- Name: notification_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_schedules_id_seq', 1, false);


--
-- Name: notification_settings_advanced_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_settings_advanced_id_seq', 1, true);


--
-- Name: notification_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_settings_id_seq', 18, true);


--
-- Name: notification_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_templates_id_seq', 10, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_id_seq', 98, true);


--
-- Name: odp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.odp_id_seq', 27, true);


--
-- Name: packages_master_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.packages_master_id_seq', 4, true);


--
-- Name: payment_number_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.payment_number_seq', 1000, false);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.permissions_id_seq', 36, true);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.role_permissions_id_seq', 118, true);


--
-- Name: service_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.service_categories_id_seq', 69, true);


--
-- Name: service_pricelist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.service_pricelist_id_seq', 47, true);


--
-- Name: service_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.service_types_id_seq', 12, true);


--
-- Name: skill_levels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.skill_levels_id_seq', 4, true);


--
-- Name: specialization_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.specialization_categories_id_seq', 6, true);


--
-- Name: specializations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.specializations_id_seq', 28, true);


--
-- Name: system_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_metrics_id_seq', 6256, true);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aglis_user
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 5, true);


--
-- Name: technician_equipment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.technician_equipment_id_seq', 26, true);


--
-- Name: technician_location_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.technician_location_history_id_seq', 14, true);


--
-- Name: technician_performance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.technician_performance_id_seq', 6, true);


--
-- Name: technician_schedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.technician_schedule_id_seq', 30, true);


--
-- Name: technician_skills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.technician_skills_id_seq', 34, true);


--
-- Name: technician_specializations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.technician_specializations_id_seq', 31, true);


--
-- Name: technicians_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.technicians_id_seq', 13, true);


--
-- Name: ticket_status_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_status_history_id_seq', 79, true);


--
-- Name: ticket_technicians_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_technicians_id_seq', 25, true);


--
-- Name: tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tickets_id_seq', 31, true);


--
-- Name: user_activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_activity_logs_id_seq', 12, true);


--
-- Name: user_devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_devices_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 26, true);


--
-- Name: whatsapp_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.whatsapp_groups_id_seq', 8, true);


--
-- Name: whatsapp_message_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.whatsapp_message_templates_id_seq', 22, true);


--
-- Name: whatsapp_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.whatsapp_notifications_id_seq', 195, true);


--
-- Name: alert_history alert_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_history
    ADD CONSTRAINT alert_history_pkey PRIMARY KEY (id);


--
-- Name: alert_rules alert_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_rules
    ADD CONSTRAINT alert_rules_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: billing_alerts billing_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.billing_alerts
    ADD CONSTRAINT billing_alerts_pkey PRIMARY KEY (id);


--
-- Name: billing_schedules billing_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.billing_schedules
    ADD CONSTRAINT billing_schedules_pkey PRIMARY KEY (id);


--
-- Name: customer_complaints customer_complaints_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_complaints
    ADD CONSTRAINT customer_complaints_pkey PRIMARY KEY (id);


--
-- Name: customer_equipment customer_equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_equipment
    ADD CONSTRAINT customer_equipment_pkey PRIMARY KEY (id);


--
-- Name: customer_payment_methods customer_payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.customer_payment_methods
    ADD CONSTRAINT customer_payment_methods_pkey PRIMARY KEY (id);


--
-- Name: customer_payments customer_payments_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_payments
    ADD CONSTRAINT customer_payments_invoice_number_key UNIQUE (invoice_number);


--
-- Name: customer_payments customer_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_payments
    ADD CONSTRAINT customer_payments_pkey PRIMARY KEY (id);


--
-- Name: customer_registrations customer_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_registrations
    ADD CONSTRAINT customer_registrations_pkey PRIMARY KEY (id);


--
-- Name: customer_registrations customer_registrations_registration_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_registrations
    ADD CONSTRAINT customer_registrations_registration_number_key UNIQUE (registration_number);


--
-- Name: customer_service_history customer_service_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_service_history
    ADD CONSTRAINT customer_service_history_pkey PRIMARY KEY (id);


--
-- Name: customer_sessions customer_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_sessions
    ADD CONSTRAINT customer_sessions_pkey PRIMARY KEY (id);


--
-- Name: customer_sessions customer_sessions_session_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_sessions
    ADD CONSTRAINT customer_sessions_session_token_key UNIQUE (session_token);


--
-- Name: customers customers_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_customer_id_key UNIQUE (customer_id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: customers customers_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_username_key UNIQUE (username);


--
-- Name: equipment_master equipment_master_equipment_code_key; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.equipment_master
    ADD CONSTRAINT equipment_master_equipment_code_key UNIQUE (equipment_code);


--
-- Name: equipment_master equipment_master_pkey; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.equipment_master
    ADD CONSTRAINT equipment_master_pkey PRIMARY KEY (id);


--
-- Name: equipment_service_mapping equipment_service_mapping_equipment_id_service_type_code_se_key; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.equipment_service_mapping
    ADD CONSTRAINT equipment_service_mapping_equipment_id_service_type_code_se_key UNIQUE (equipment_id, service_type_code, service_category_code);


--
-- Name: equipment_service_mapping equipment_service_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.equipment_service_mapping
    ADD CONSTRAINT equipment_service_mapping_pkey PRIMARY KEY (id);


--
-- Name: failed_login_attempts failed_login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.failed_login_attempts
    ADD CONSTRAINT failed_login_attempts_pkey PRIMARY KEY (id);


--
-- Name: inventory_items inventory_items_item_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_item_code_key UNIQUE (item_code);


--
-- Name: inventory_items inventory_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_pkey PRIMARY KEY (id);


--
-- Name: inventory_stock inventory_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.inventory_stock
    ADD CONSTRAINT inventory_stock_pkey PRIMARY KEY (id);


--
-- Name: inventory_transactions inventory_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_pkey PRIMARY KEY (id);


--
-- Name: invoice_line_items invoice_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.invoice_line_items
    ADD CONSTRAINT invoice_line_items_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: notification_analytics notification_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_analytics
    ADD CONSTRAINT notification_analytics_pkey PRIMARY KEY (id);


--
-- Name: notification_analytics_summary notification_analytics_summary_date_type_priority_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_analytics_summary
    ADD CONSTRAINT notification_analytics_summary_date_type_priority_key UNIQUE (date, type, priority);


--
-- Name: notification_analytics_summary notification_analytics_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_analytics_summary
    ADD CONSTRAINT notification_analytics_summary_pkey PRIMARY KEY (id);


--
-- Name: notification_push_log notification_push_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_push_log
    ADD CONSTRAINT notification_push_log_pkey PRIMARY KEY (id);


--
-- Name: notification_routing_rules notification_routing_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_routing_rules
    ADD CONSTRAINT notification_routing_rules_pkey PRIMARY KEY (id);


--
-- Name: notification_schedules notification_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_schedules
    ADD CONSTRAINT notification_schedules_pkey PRIMARY KEY (id);


--
-- Name: notification_settings_advanced notification_settings_advanced_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_settings_advanced
    ADD CONSTRAINT notification_settings_advanced_pkey PRIMARY KEY (id);


--
-- Name: notification_settings_advanced notification_settings_advanced_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_settings_advanced
    ADD CONSTRAINT notification_settings_advanced_user_id_key UNIQUE (user_id);


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_user_id_key UNIQUE (user_id);


--
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- Name: notification_templates notification_templates_template_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_template_code_key UNIQUE (template_code);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: odp odp_name_key; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.odp
    ADD CONSTRAINT odp_name_key UNIQUE (name);


--
-- Name: odp odp_pkey; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.odp
    ADD CONSTRAINT odp_pkey PRIMARY KEY (id);


--
-- Name: packages_master packages_master_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packages_master
    ADD CONSTRAINT packages_master_pkey PRIMARY KEY (id);


--
-- Name: payments payments_payment_number_key; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_payment_number_key UNIQUE (payment_number);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_name_key; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_key UNIQUE (name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_role_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_permission_id_key UNIQUE (role, permission_id);


--
-- Name: service_categories service_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.service_categories
    ADD CONSTRAINT service_categories_pkey PRIMARY KEY (id);


--
-- Name: service_categories service_categories_service_type_code_category_code_key; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.service_categories
    ADD CONSTRAINT service_categories_service_type_code_category_code_key UNIQUE (service_type_code, category_code);


--
-- Name: service_pricelist service_pricelist_pkey; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.service_pricelist
    ADD CONSTRAINT service_pricelist_pkey PRIMARY KEY (id);


--
-- Name: service_types service_types_pkey; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.service_types
    ADD CONSTRAINT service_types_pkey PRIMARY KEY (id);


--
-- Name: service_types service_types_type_code_key; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.service_types
    ADD CONSTRAINT service_types_type_code_key UNIQUE (type_code);


--
-- Name: skill_levels skill_levels_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skill_levels
    ADD CONSTRAINT skill_levels_code_key UNIQUE (code);


--
-- Name: skill_levels skill_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skill_levels
    ADD CONSTRAINT skill_levels_pkey PRIMARY KEY (id);


--
-- Name: specialization_categories specialization_categories_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specialization_categories
    ADD CONSTRAINT specialization_categories_code_key UNIQUE (code);


--
-- Name: specialization_categories specialization_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specialization_categories
    ADD CONSTRAINT specialization_categories_pkey PRIMARY KEY (id);


--
-- Name: specializations specializations_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specializations
    ADD CONSTRAINT specializations_code_key UNIQUE (code);


--
-- Name: specializations specializations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specializations
    ADD CONSTRAINT specializations_pkey PRIMARY KEY (id);


--
-- Name: system_metrics system_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_metrics
    ADD CONSTRAINT system_metrics_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_setting_key_key UNIQUE (setting_key);


--
-- Name: technician_equipment technician_equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technician_equipment
    ADD CONSTRAINT technician_equipment_pkey PRIMARY KEY (id);


--
-- Name: technician_location_history technician_location_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technician_location_history
    ADD CONSTRAINT technician_location_history_pkey PRIMARY KEY (id);


--
-- Name: technician_performance technician_performance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technician_performance
    ADD CONSTRAINT technician_performance_pkey PRIMARY KEY (id);


--
-- Name: technician_schedule technician_schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technician_schedule
    ADD CONSTRAINT technician_schedule_pkey PRIMARY KEY (id);


--
-- Name: technician_schedule technician_schedule_technician_id_schedule_date_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technician_schedule
    ADD CONSTRAINT technician_schedule_technician_id_schedule_date_key UNIQUE (technician_id, schedule_date);


--
-- Name: technician_skills technician_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technician_skills
    ADD CONSTRAINT technician_skills_pkey PRIMARY KEY (id);


--
-- Name: technician_specializations technician_specializations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technician_specializations
    ADD CONSTRAINT technician_specializations_pkey PRIMARY KEY (id);


--
-- Name: technician_specializations technician_specializations_technician_id_specialization_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technician_specializations
    ADD CONSTRAINT technician_specializations_technician_id_specialization_id_key UNIQUE (technician_id, specialization_id);


--
-- Name: technicians technicians_employee_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technicians
    ADD CONSTRAINT technicians_employee_id_key UNIQUE (employee_id);


--
-- Name: technicians technicians_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technicians
    ADD CONSTRAINT technicians_pkey PRIMARY KEY (id);


--
-- Name: ticket_status_history ticket_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_status_history
    ADD CONSTRAINT ticket_status_history_pkey PRIMARY KEY (id);


--
-- Name: ticket_technicians ticket_technicians_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_technicians
    ADD CONSTRAINT ticket_technicians_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_ticket_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_ticket_number_key UNIQUE (ticket_number);


--
-- Name: ticket_technicians unique_ticket_technician; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_technicians
    ADD CONSTRAINT unique_ticket_technician UNIQUE (ticket_id, technician_id);


--
-- Name: user_activity_logs user_activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity_logs
    ADD CONSTRAINT user_activity_logs_pkey PRIMARY KEY (id);


--
-- Name: user_devices user_devices_device_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_devices
    ADD CONSTRAINT user_devices_device_token_key UNIQUE (device_token);


--
-- Name: user_devices user_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_devices
    ADD CONSTRAINT user_devices_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: whatsapp_groups whatsapp_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whatsapp_groups
    ADD CONSTRAINT whatsapp_groups_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_message_templates whatsapp_message_templates_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whatsapp_message_templates
    ADD CONSTRAINT whatsapp_message_templates_code_key UNIQUE (code);


--
-- Name: whatsapp_message_templates whatsapp_message_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whatsapp_message_templates
    ADD CONSTRAINT whatsapp_message_templates_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_notifications whatsapp_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whatsapp_notifications
    ADD CONSTRAINT whatsapp_notifications_pkey PRIMARY KEY (id);


--
-- Name: idx_alert_history_rule; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alert_history_rule ON public.alert_history USING btree (alert_rule_id, triggered_at DESC);


--
-- Name: idx_alert_history_triggered; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alert_history_triggered ON public.alert_history USING btree (triggered_at DESC);


--
-- Name: idx_alert_history_unresolved; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alert_history_unresolved ON public.alert_history USING btree (resolved_at) WHERE (resolved_at IS NULL);


--
-- Name: idx_attachments_ticket; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attachments_ticket ON public.attachments USING btree (ticket_id);


--
-- Name: idx_attachments_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attachments_type ON public.attachments USING btree (upload_type);


--
-- Name: idx_billing_alerts_customer; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_billing_alerts_customer ON public.billing_alerts USING btree (customer_id);


--
-- Name: idx_billing_alerts_invoice; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_billing_alerts_invoice ON public.billing_alerts USING btree (invoice_id);


--
-- Name: idx_billing_alerts_unread; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_billing_alerts_unread ON public.billing_alerts USING btree (is_read, created_at DESC) WHERE (is_read = false);


--
-- Name: idx_billing_schedules_customer; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_billing_schedules_customer ON public.billing_schedules USING btree (customer_id) WHERE (is_active = true);


--
-- Name: idx_billing_schedules_next_date; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_billing_schedules_next_date ON public.billing_schedules USING btree (next_billing_date) WHERE (is_active = true);


--
-- Name: idx_customer_complaints_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_complaints_customer_id ON public.customer_complaints USING btree (customer_id);


--
-- Name: idx_customer_equipment_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_equipment_customer_id ON public.customer_equipment USING btree (customer_id);


--
-- Name: idx_customer_payments_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_payments_customer_id ON public.customer_payments USING btree (customer_id);


--
-- Name: idx_customer_payments_payment_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_payments_payment_date ON public.customer_payments USING btree (payment_date);


--
-- Name: idx_customer_service_history_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_service_history_customer_id ON public.customer_service_history USING btree (customer_id);


--
-- Name: idx_customer_sessions_customer; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_sessions_customer ON public.customer_sessions USING btree (customer_id, created_at DESC);


--
-- Name: idx_customer_sessions_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_sessions_token ON public.customer_sessions USING btree (session_token);


--
-- Name: idx_customers_account_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_account_status ON public.customers USING btree (account_status);


--
-- Name: idx_customers_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_active ON public.customers USING btree (id, name, customer_id, service_type) WHERE ((account_status)::text = 'active'::text);


--
-- Name: idx_customers_city; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_city ON public.customers USING btree (city);


--
-- Name: idx_customers_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_customer_id ON public.customers USING btree (customer_id);


--
-- Name: idx_customers_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_email ON public.customers USING btree (email);


--
-- Name: idx_customers_package_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_package_fk ON public.customers USING btree (package_id) WHERE (package_id IS NOT NULL);


--
-- Name: idx_customers_package_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_package_id ON public.customers USING btree (package_id);


--
-- Name: idx_customers_payment_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_payment_status ON public.customers USING btree (payment_status) WHERE ((payment_status)::text = ANY ((ARRAY['unpaid'::character varying, 'pending'::character varying])::text[]));


--
-- Name: idx_customers_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_phone ON public.customers USING btree (phone);


--
-- Name: idx_customers_province; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_province ON public.customers USING btree (province);


--
-- Name: idx_customers_search_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_search_id ON public.customers USING btree (customer_id varchar_pattern_ops);


--
-- Name: idx_customers_search_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_search_name ON public.customers USING gin (to_tsvector('simple'::regconfig, (name)::text));


--
-- Name: idx_customers_service_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_service_type ON public.customers USING btree (service_type);


--
-- Name: idx_customers_status_service; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_status_service ON public.customers USING btree (account_status, service_type, created_at DESC);


--
-- Name: INDEX idx_customers_status_service; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON INDEX public.idx_customers_status_service IS 'Composite index for customer filtering by status and service type';


--
-- Name: idx_equipment_active_category; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_equipment_active_category ON public.equipment_master USING btree (is_active, category, equipment_name) WHERE (is_active = true);


--
-- Name: INDEX idx_equipment_active_category; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON INDEX public.idx_equipment_active_category IS 'Index for equipment dropdown filtering by category';


--
-- Name: idx_equipment_code; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_equipment_code ON public.equipment_master USING btree (equipment_code) WHERE (is_active = true);


--
-- Name: idx_equipment_master_active; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_equipment_master_active ON public.equipment_master USING btree (is_active);


--
-- Name: idx_equipment_master_category; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_equipment_master_category ON public.equipment_master USING btree (category);


--
-- Name: idx_equipment_master_code; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_equipment_master_code ON public.equipment_master USING btree (equipment_code);


--
-- Name: idx_failed_login_attempted_at; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_failed_login_attempted_at ON public.failed_login_attempts USING btree (attempted_at);


--
-- Name: idx_failed_login_ip; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_failed_login_ip ON public.failed_login_attempts USING btree (ip_address);


--
-- Name: idx_failed_login_user_id; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_failed_login_user_id ON public.failed_login_attempts USING btree (user_id);


--
-- Name: idx_failed_login_username; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_failed_login_username ON public.failed_login_attempts USING btree (username);


--
-- Name: idx_inventory_equipment; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_inventory_equipment ON public.inventory_stock USING btree (equipment_id);


--
-- Name: idx_inventory_equipment_fk; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_inventory_equipment_fk ON public.inventory_stock USING btree (equipment_id);


--
-- Name: idx_inventory_items_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_items_active ON public.inventory_items USING btree (is_active);


--
-- Name: idx_inventory_items_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_items_category ON public.inventory_items USING btree (category);


--
-- Name: idx_inventory_items_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_items_code ON public.inventory_items USING btree (item_code);


--
-- Name: idx_inventory_location; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_inventory_location ON public.inventory_stock USING btree (warehouse_location);


--
-- Name: idx_inventory_low_stock; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_inventory_low_stock ON public.inventory_stock USING btree (equipment_id, current_stock, minimum_stock) WHERE (current_stock <= minimum_stock);


--
-- Name: INDEX idx_inventory_low_stock; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON INDEX public.idx_inventory_low_stock IS 'Partial index for low stock alerts and monitoring';


--
-- Name: idx_inventory_stock_level; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_inventory_stock_level ON public.inventory_stock USING btree (current_stock, minimum_stock);


--
-- Name: idx_inventory_transactions_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_transactions_date ON public.inventory_transactions USING btree (transaction_date);


--
-- Name: idx_inventory_transactions_item; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_transactions_item ON public.inventory_transactions USING btree (item_id);


--
-- Name: idx_inventory_transactions_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_transactions_type ON public.inventory_transactions USING btree (transaction_type);


--
-- Name: idx_invoice_items_invoice_id; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_invoice_items_invoice_id ON public.invoice_line_items USING btree (invoice_id);


--
-- Name: idx_invoice_items_type; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_invoice_items_type ON public.invoice_line_items USING btree (item_type);


--
-- Name: idx_invoices_customer_id; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_invoices_customer_id ON public.invoices USING btree (customer_id) WHERE (is_deleted = false);


--
-- Name: idx_invoices_due_date; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_invoices_due_date ON public.invoices USING btree (due_date) WHERE (is_deleted = false);


--
-- Name: idx_invoices_invoice_date; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_invoices_invoice_date ON public.invoices USING btree (invoice_date DESC) WHERE (is_deleted = false);


--
-- Name: idx_invoices_number; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_invoices_number ON public.invoices USING btree (invoice_number);


--
-- Name: idx_invoices_outstanding; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_invoices_outstanding ON public.invoices USING btree (outstanding_amount) WHERE ((outstanding_amount > (0)::numeric) AND (is_deleted = false));


--
-- Name: idx_invoices_overdue; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_invoices_overdue ON public.invoices USING btree (due_date, status) WHERE (((status)::text <> 'paid'::text) AND (is_deleted = false));


--
-- Name: idx_invoices_status; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_invoices_status ON public.invoices USING btree (status) WHERE (is_deleted = false);


--
-- Name: idx_location_coords; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_location_coords ON public.technician_location_history USING btree (latitude, longitude);


--
-- Name: idx_notification_analytics_clicked; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_analytics_clicked ON public.notification_analytics USING btree (clicked_at);


--
-- Name: idx_notification_analytics_notification; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_analytics_notification ON public.notification_analytics USING btree (notification_id);


--
-- Name: idx_notification_analytics_read; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_analytics_read ON public.notification_analytics USING btree (read_at);


--
-- Name: idx_notification_analytics_summary_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_analytics_summary_date ON public.notification_analytics_summary USING btree (date);


--
-- Name: idx_notification_analytics_summary_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_analytics_summary_type ON public.notification_analytics_summary USING btree (type);


--
-- Name: idx_notification_analytics_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_analytics_user ON public.notification_analytics USING btree (user_id);


--
-- Name: idx_notification_analytics_viewed; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_analytics_viewed ON public.notification_analytics USING btree (viewed_at);


--
-- Name: idx_notification_push_log_device; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_push_log_device ON public.notification_push_log USING btree (device_id);


--
-- Name: idx_notification_push_log_notification; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_push_log_notification ON public.notification_push_log USING btree (notification_id);


--
-- Name: idx_notification_push_log_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_push_log_status ON public.notification_push_log USING btree (status);


--
-- Name: idx_notification_routing_rules_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_routing_rules_is_active ON public.notification_routing_rules USING btree (is_active);


--
-- Name: idx_notification_routing_rules_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_routing_rules_type ON public.notification_routing_rules USING btree (notification_type);


--
-- Name: idx_notification_schedules_next_run; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_schedules_next_run ON public.notification_schedules USING btree (next_run_at, status);


--
-- Name: idx_notification_schedules_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_schedules_status ON public.notification_schedules USING btree (status);


--
-- Name: idx_notification_settings_advanced_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_settings_advanced_user ON public.notification_settings_advanced USING btree (user_id);


--
-- Name: idx_notification_settings_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_settings_user_id ON public.notification_settings USING btree (user_id);


--
-- Name: idx_notification_templates_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_templates_active ON public.notification_templates USING btree (is_active);


--
-- Name: idx_notification_templates_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_templates_category ON public.notification_templates USING btree (category);


--
-- Name: idx_notification_templates_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_templates_code ON public.notification_templates USING btree (template_code);


--
-- Name: idx_notification_templates_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notification_templates_type ON public.notification_templates USING btree (type);


--
-- Name: idx_notifications_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_created_at ON public.notifications USING btree (created_at);


--
-- Name: idx_notifications_data; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_data ON public.notifications USING gin (data);


--
-- Name: idx_notifications_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_expires_at ON public.notifications USING btree (expires_at);


--
-- Name: idx_notifications_is_archived; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_is_archived ON public.notifications USING btree (is_archived);


--
-- Name: idx_notifications_is_read; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_is_read ON public.notifications USING btree (is_read);


--
-- Name: idx_notifications_priority; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_priority ON public.notifications USING btree (priority);


--
-- Name: idx_notifications_read; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_read ON public.notifications USING btree (is_read);


--
-- Name: idx_notifications_template; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_template ON public.notifications USING btree (template_id);


--
-- Name: idx_notifications_ticket; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_ticket ON public.notifications USING btree (ticket_id);


--
-- Name: idx_notifications_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_type ON public.notifications USING btree (type);


--
-- Name: idx_notifications_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_user ON public.notifications USING btree (user_id);


--
-- Name: idx_notifications_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: idx_notifications_user_unread; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_user_unread ON public.notifications USING btree (user_id, is_read, created_at DESC) WHERE (is_read = false);


--
-- Name: INDEX idx_notifications_user_unread; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON INDEX public.idx_notifications_user_unread IS 'Index for unread notifications per user (notification center)';


--
-- Name: idx_odp_area; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_odp_area ON public.odp USING btree (area);


--
-- Name: idx_odp_status; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_odp_status ON public.odp USING btree (status);


--
-- Name: idx_packages_active_type_price; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_packages_active_type_price ON public.packages_master USING btree (is_active, package_type, monthly_price) WHERE (is_active = true);


--
-- Name: INDEX idx_packages_active_type_price; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON INDEX public.idx_packages_active_type_price IS 'Composite index for package listing with filter by active status and type, sorted by price';


--
-- Name: idx_packages_bandwidth; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_packages_bandwidth ON public.packages_master USING btree (bandwidth_down DESC, bandwidth_up DESC) WHERE (is_active = true);


--
-- Name: idx_payment_methods_active; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_payment_methods_active ON public.customer_payment_methods USING btree (is_active) WHERE (is_deleted = false);


--
-- Name: idx_payment_methods_customer; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_payment_methods_customer ON public.customer_payment_methods USING btree (customer_id) WHERE (is_deleted = false);


--
-- Name: idx_payments_customer_id; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_payments_customer_id ON public.payments USING btree (customer_id) WHERE (is_deleted = false);


--
-- Name: idx_payments_date; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_payments_date ON public.payments USING btree (payment_date DESC) WHERE (is_deleted = false);


--
-- Name: idx_payments_invoice_id; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_payments_invoice_id ON public.payments USING btree (invoice_id) WHERE (is_deleted = false);


--
-- Name: idx_payments_method; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_payments_method ON public.payments USING btree (payment_method) WHERE (is_deleted = false);


--
-- Name: idx_payments_number; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_payments_number ON public.payments USING btree (payment_number);


--
-- Name: idx_payments_status; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_payments_status ON public.payments USING btree (status) WHERE (is_deleted = false);


--
-- Name: idx_permissions_name; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_permissions_name ON public.permissions USING btree (name);


--
-- Name: idx_permissions_resource; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_permissions_resource ON public.permissions USING btree (resource);


--
-- Name: idx_pricelist_active; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_pricelist_active ON public.service_pricelist USING btree (is_active);


--
-- Name: idx_pricelist_active_service; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_pricelist_active_service ON public.service_pricelist USING btree (is_active, service_type_code, service_category_code) WHERE (is_active = true);


--
-- Name: INDEX idx_pricelist_active_service; Type: COMMENT; Schema: public; Owner: aglis_user
--

COMMENT ON INDEX public.idx_pricelist_active_service IS 'Composite index for pricelist filtering in ticket creation';


--
-- Name: idx_pricelist_category; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_pricelist_category ON public.service_pricelist USING btree (service_category_code);


--
-- Name: idx_pricelist_package; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_pricelist_package ON public.service_pricelist USING btree (applies_to_package);


--
-- Name: idx_pricelist_package_type; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_pricelist_package_type ON public.service_pricelist USING btree (applies_to_package) WHERE (is_active = true);


--
-- Name: idx_pricelist_type; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_pricelist_type ON public.service_pricelist USING btree (service_type_code);


--
-- Name: idx_registrations_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_registrations_created_at ON public.customer_registrations USING btree (created_at);


--
-- Name: idx_registrations_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_registrations_email ON public.customer_registrations USING btree (email);


--
-- Name: idx_registrations_package_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_registrations_package_fk ON public.customer_registrations USING btree (package_id) WHERE (package_id IS NOT NULL);


--
-- Name: idx_registrations_pending; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_registrations_pending ON public.customer_registrations USING btree (status, created_at DESC) WHERE ((status)::text <> ALL ((ARRAY['customer_created'::character varying, 'rejected'::character varying, 'cancelled'::character varying])::text[]));


--
-- Name: idx_registrations_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_registrations_phone ON public.customer_registrations USING btree (phone);


--
-- Name: idx_registrations_registration_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_registrations_registration_number ON public.customer_registrations USING btree (registration_number);


--
-- Name: idx_registrations_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_registrations_status ON public.customer_registrations USING btree (status);


--
-- Name: idx_registrations_status_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_registrations_status_created ON public.customer_registrations USING btree (status, created_at DESC);


--
-- Name: INDEX idx_registrations_status_created; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON INDEX public.idx_registrations_status_created IS 'Primary index for registration list filtering and sorting';


--
-- Name: idx_role_permissions_granted; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_role_permissions_granted ON public.role_permissions USING btree (granted);


--
-- Name: idx_role_permissions_permission; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_role_permissions_permission ON public.role_permissions USING btree (permission_id);


--
-- Name: idx_role_permissions_role; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_role_permissions_role ON public.role_permissions USING btree (role);


--
-- Name: idx_service_categories_active; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_service_categories_active ON public.service_categories USING btree (is_active);


--
-- Name: idx_service_categories_order; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_service_categories_order ON public.service_categories USING btree (display_order);


--
-- Name: idx_service_categories_type; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_service_categories_type ON public.service_categories USING btree (service_type_code);


--
-- Name: idx_service_types_active; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_service_types_active ON public.service_types USING btree (is_active);


--
-- Name: idx_service_types_code; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_service_types_code ON public.service_types USING btree (type_code);


--
-- Name: idx_service_types_order; Type: INDEX; Schema: public; Owner: aglis_user
--

CREATE INDEX idx_service_types_order ON public.service_types USING btree (display_order);


--
-- Name: idx_skill_levels_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_skill_levels_active ON public.skill_levels USING btree (is_active);


--
-- Name: idx_skill_levels_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_skill_levels_code ON public.skill_levels USING btree (code);


--
-- Name: idx_spec_categories_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_spec_categories_code ON public.specialization_categories USING btree (code);


--
-- Name: idx_specializations_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_specializations_active ON public.specializations USING btree (is_active);


--
-- Name: idx_specializations_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_specializations_category ON public.specializations USING btree (category_id);


--
-- Name: idx_specializations_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_specializations_code ON public.specializations USING btree (code);


--
-- Name: idx_system_metrics_recorded; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_metrics_recorded ON public.system_metrics USING btree (recorded_at DESC);


--
-- Name: idx_system_metrics_type_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_metrics_type_time ON public.system_metrics USING btree (metric_type, recorded_at DESC);


--
-- Name: idx_tech_specs_specialization; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tech_specs_specialization ON public.technician_specializations USING btree (specialization_id);


--
-- Name: idx_tech_specs_technician; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tech_specs_technician ON public.technician_specializations USING btree (technician_id);


--
-- Name: idx_technician_location_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_technician_location_time ON public.technician_location_history USING btree (technician_id, recorded_at);


--
-- Name: idx_technician_performance_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_technician_performance_period ON public.technician_performance USING btree (technician_id, period_start, period_end);


--
-- Name: idx_technician_schedule_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_technician_schedule_date ON public.technician_schedule USING btree (technician_id, schedule_date);


--
-- Name: idx_technician_skills_tech_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_technician_skills_tech_id ON public.technician_skills USING btree (technician_id);


--
-- Name: idx_technicians_availability; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_technicians_availability ON public.technicians USING btree (is_available, availability_status) WHERE ((employment_status)::text = 'active'::text);


--
-- Name: idx_technicians_available; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_technicians_available ON public.technicians USING btree (availability_status) WHERE ((availability_status)::text = 'available'::text);


--
-- Name: idx_technicians_employee_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_technicians_employee_id ON public.technicians USING btree (employee_id);


--
-- Name: idx_technicians_employment_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_technicians_employment_status ON public.technicians USING btree (employment_status, is_available) WHERE ((employment_status)::text = 'active'::text);


--
-- Name: idx_technicians_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_technicians_status ON public.technicians USING btree (employment_status, availability_status);


--
-- Name: idx_technicians_user_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_technicians_user_fk ON public.technicians USING btree (user_id);


--
-- Name: idx_technicians_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_technicians_user_id ON public.technicians USING btree (user_id);


--
-- Name: idx_technicians_zone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_technicians_zone ON public.technicians USING btree (work_zone);


--
-- Name: idx_templates_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_templates_category ON public.whatsapp_message_templates USING btree (category);


--
-- Name: idx_ticket_history_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_history_date ON public.ticket_status_history USING btree (created_at);


--
-- Name: idx_ticket_history_ticket; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_history_ticket ON public.ticket_status_history USING btree (ticket_id);


--
-- Name: idx_ticket_technicians_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_technicians_active ON public.ticket_technicians USING btree (is_active) WHERE (is_active = true);


--
-- Name: idx_ticket_technicians_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_technicians_role ON public.ticket_technicians USING btree (role);


--
-- Name: idx_ticket_technicians_tech; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_technicians_tech ON public.ticket_technicians USING btree (technician_id);


--
-- Name: idx_ticket_technicians_ticket; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_technicians_ticket ON public.ticket_technicians USING btree (ticket_id);


--
-- Name: idx_tickets_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_active ON public.tickets USING btree (status, priority, created_at DESC) WHERE ((status)::text <> ALL ((ARRAY['completed'::character varying, 'cancelled'::character varying])::text[]));


--
-- Name: idx_tickets_completion_data; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_completion_data ON public.tickets USING gin (completion_data);


--
-- Name: idx_tickets_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_created_at ON public.tickets USING btree (created_at);


--
-- Name: idx_tickets_created_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_created_status ON public.tickets USING btree (created_at DESC, status);


--
-- Name: idx_tickets_customer; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_customer ON public.tickets USING btree (customer_id);


--
-- Name: idx_tickets_customer_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_customer_status ON public.tickets USING btree (customer_id, status, created_at DESC);


--
-- Name: idx_tickets_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_number ON public.tickets USING btree (ticket_number);


--
-- Name: idx_tickets_priority; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_priority ON public.tickets USING btree (priority);


--
-- Name: idx_tickets_scheduled_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_scheduled_date ON public.tickets USING btree (scheduled_date);


--
-- Name: idx_tickets_sla_breach; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_sla_breach ON public.tickets USING btree (is_sla_breached, sla_due_date) WHERE ((is_sla_breached = true) OR ((status)::text <> ALL ((ARRAY['completed'::character varying, 'cancelled'::character varying])::text[])));


--
-- Name: idx_tickets_sla_due; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_sla_due ON public.tickets USING btree (sla_due_date);


--
-- Name: idx_tickets_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_status ON public.tickets USING btree (status);


--
-- Name: idx_tickets_status_priority_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_status_priority_date ON public.tickets USING btree (status, priority, created_at DESC);


--
-- Name: INDEX idx_tickets_status_priority_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON INDEX public.idx_tickets_status_priority_date IS 'Composite index for ticket dashboard with status and priority filters';


--
-- Name: idx_tickets_technician; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_technician ON public.tickets USING btree (assigned_technician_id);


--
-- Name: idx_tickets_technician_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_technician_status ON public.tickets USING btree (assigned_technician_id, status, created_at DESC) WHERE (assigned_technician_id IS NOT NULL);


--
-- Name: idx_tickets_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_type ON public.tickets USING btree (type);


--
-- Name: idx_user_activity_logs_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_activity_logs_action ON public.user_activity_logs USING btree (action);


--
-- Name: idx_user_activity_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_activity_logs_created_at ON public.user_activity_logs USING btree (created_at DESC);


--
-- Name: idx_user_activity_logs_target_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_activity_logs_target_user_id ON public.user_activity_logs USING btree (target_user_id);


--
-- Name: idx_user_activity_logs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_activity_logs_user_id ON public.user_activity_logs USING btree (user_id);


--
-- Name: idx_user_devices_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_devices_active ON public.user_devices USING btree (is_active, user_id);


--
-- Name: idx_user_devices_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_devices_token ON public.user_devices USING btree (device_token);


--
-- Name: idx_user_devices_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_devices_user_id ON public.user_devices USING btree (user_id);


--
-- Name: idx_users_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_active ON public.users USING btree (is_active);


--
-- Name: idx_users_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_deleted_at ON public.users USING btree (deleted_at);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_email_verified; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email_verified ON public.users USING btree (email_verified);


--
-- Name: idx_users_failed_attempts; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_failed_attempts ON public.users USING btree (failed_login_attempts);


--
-- Name: idx_users_locked_until; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_locked_until ON public.users USING btree (locked_until);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_username ON public.users USING btree (username) WHERE (is_active = true);


--
-- Name: idx_whatsapp_groups_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_whatsapp_groups_category ON public.whatsapp_groups USING btree (category);


--
-- Name: idx_whatsapp_groups_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_whatsapp_groups_is_active ON public.whatsapp_groups USING btree (is_active);


--
-- Name: idx_whatsapp_groups_work_zone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_whatsapp_groups_work_zone ON public.whatsapp_groups USING btree (work_zone);


--
-- Name: idx_whatsapp_notifications_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_whatsapp_notifications_created ON public.whatsapp_notifications USING btree (created_at DESC);


--
-- Name: idx_whatsapp_notifications_group_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_whatsapp_notifications_group_id ON public.whatsapp_notifications USING btree (group_id);


--
-- Name: idx_whatsapp_notifications_notification_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_whatsapp_notifications_notification_id ON public.whatsapp_notifications USING btree (notification_id);


--
-- Name: idx_whatsapp_notifications_sent_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_whatsapp_notifications_sent_at ON public.whatsapp_notifications USING btree (sent_at);


--
-- Name: idx_whatsapp_notifications_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_whatsapp_notifications_status ON public.whatsapp_notifications USING btree (status);


--
-- Name: idx_whatsapp_notifications_ticket; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_whatsapp_notifications_ticket ON public.whatsapp_notifications USING btree (ticket_id, created_at DESC);


--
-- Name: idx_whatsapp_notifications_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_whatsapp_notifications_user_id ON public.whatsapp_notifications USING btree (user_id);


--
-- Name: idx_whatsapp_templates_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_whatsapp_templates_category ON public.whatsapp_message_templates USING btree (category);


--
-- Name: idx_whatsapp_templates_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_whatsapp_templates_code ON public.whatsapp_message_templates USING btree (code);


--
-- Name: idx_whatsapp_templates_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_whatsapp_templates_is_active ON public.whatsapp_message_templates USING btree (is_active);


--
-- Name: customer_registrations auto_generate_registration_number; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER auto_generate_registration_number BEFORE INSERT ON public.customer_registrations FOR EACH ROW EXECUTE FUNCTION public.set_registration_number();


--
-- Name: role_permissions role_permissions_updated_at; Type: TRIGGER; Schema: public; Owner: aglis_user
--

CREATE TRIGGER role_permissions_updated_at BEFORE UPDATE ON public.role_permissions FOR EACH ROW EXECUTE FUNCTION public.update_role_permissions_updated_at();


--
-- Name: invoice_line_items trigger_invoice_items_updated_at; Type: TRIGGER; Schema: public; Owner: aglis_user
--

CREATE TRIGGER trigger_invoice_items_updated_at BEFORE UPDATE ON public.invoice_line_items FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: invoices trigger_invoices_updated_at; Type: TRIGGER; Schema: public; Owner: aglis_user
--

CREATE TRIGGER trigger_invoices_updated_at BEFORE UPDATE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: payments trigger_payments_updated_at; Type: TRIGGER; Schema: public; Owner: aglis_user
--

CREATE TRIGGER trigger_payments_updated_at BEFORE UPDATE ON public.payments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: invoices trigger_update_invoice_outstanding; Type: TRIGGER; Schema: public; Owner: aglis_user
--

CREATE TRIGGER trigger_update_invoice_outstanding BEFORE INSERT OR UPDATE OF total_amount, paid_amount ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.update_invoice_outstanding();


--
-- Name: customer_complaints update_customer_complaints_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_customer_complaints_updated_at BEFORE UPDATE ON public.customer_complaints FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: customer_equipment update_customer_equipment_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_customer_equipment_updated_at BEFORE UPDATE ON public.customer_equipment FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: customer_payments update_customer_payments_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_customer_payments_updated_at BEFORE UPDATE ON public.customer_payments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: customers update_customers_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_customers_updated_at BEFORE UPDATE ON public.customers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: equipment_master update_equipment_master_updated_at; Type: TRIGGER; Schema: public; Owner: aglis_user
--

CREATE TRIGGER update_equipment_master_updated_at BEFORE UPDATE ON public.equipment_master FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: inventory_items update_inventory_items_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_inventory_items_updated_at BEFORE UPDATE ON public.inventory_items FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: notification_schedules update_notification_schedules_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_notification_schedules_timestamp BEFORE UPDATE ON public.notification_schedules FOR EACH ROW EXECUTE FUNCTION public.update_notification_timestamp();


--
-- Name: notification_settings_advanced update_notification_settings_advanced_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_notification_settings_advanced_timestamp BEFORE UPDATE ON public.notification_settings_advanced FOR EACH ROW EXECUTE FUNCTION public.update_notification_timestamp();


--
-- Name: notification_templates update_notification_templates_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_notification_templates_timestamp BEFORE UPDATE ON public.notification_templates FOR EACH ROW EXECUTE FUNCTION public.update_notification_timestamp();


--
-- Name: packages_master update_packages_master_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_packages_master_updated_at BEFORE UPDATE ON public.packages_master FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: customer_registrations update_registrations_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_registrations_updated_at BEFORE UPDATE ON public.customer_registrations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: skill_levels update_skill_levels_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_skill_levels_updated_at BEFORE UPDATE ON public.skill_levels FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: specializations update_specializations_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_specializations_updated_at BEFORE UPDATE ON public.specializations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: technician_specializations update_tech_specs_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_tech_specs_updated_at BEFORE UPDATE ON public.technician_specializations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: technicians update_technicians_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_technicians_updated_at BEFORE UPDATE ON public.technicians FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: tickets update_tickets_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_tickets_updated_at BEFORE UPDATE ON public.tickets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: user_devices update_user_devices_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_user_devices_timestamp BEFORE UPDATE ON public.user_devices FOR EACH ROW EXECUTE FUNCTION public.update_notification_timestamp();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: alert_history alert_history_alert_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_history
    ADD CONSTRAINT alert_history_alert_rule_id_fkey FOREIGN KEY (alert_rule_id) REFERENCES public.alert_rules(id) ON DELETE SET NULL;


--
-- Name: alert_history alert_history_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_history
    ADD CONSTRAINT alert_history_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: attachments attachments_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: attachments attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: billing_alerts billing_alerts_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.billing_alerts
    ADD CONSTRAINT billing_alerts_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: billing_alerts billing_alerts_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.billing_alerts
    ADD CONSTRAINT billing_alerts_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: billing_schedules billing_schedules_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.billing_schedules
    ADD CONSTRAINT billing_schedules_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: customer_complaints customer_complaints_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_complaints
    ADD CONSTRAINT customer_complaints_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: customer_payment_methods customer_payment_methods_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.customer_payment_methods
    ADD CONSTRAINT customer_payment_methods_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: customer_payments customer_payments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_payments
    ADD CONSTRAINT customer_payments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: customer_registrations customer_registrations_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_registrations
    ADD CONSTRAINT customer_registrations_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: customer_registrations customer_registrations_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_registrations
    ADD CONSTRAINT customer_registrations_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: customer_registrations customer_registrations_installation_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_registrations
    ADD CONSTRAINT customer_registrations_installation_ticket_id_fkey FOREIGN KEY (installation_ticket_id) REFERENCES public.tickets(id);


--
-- Name: customer_registrations customer_registrations_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_registrations
    ADD CONSTRAINT customer_registrations_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.packages_master(id);


--
-- Name: customer_registrations customer_registrations_survey_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_registrations
    ADD CONSTRAINT customer_registrations_survey_ticket_id_fkey FOREIGN KEY (survey_ticket_id) REFERENCES public.tickets(id);


--
-- Name: customer_registrations customer_registrations_verified_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_registrations
    ADD CONSTRAINT customer_registrations_verified_by_fkey FOREIGN KEY (verified_by) REFERENCES public.users(id);


--
-- Name: customer_service_history customer_service_history_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_service_history
    ADD CONSTRAINT customer_service_history_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id);


--
-- Name: customer_sessions customer_sessions_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_sessions
    ADD CONSTRAINT customer_sessions_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: customers customers_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.packages_master(id);


--
-- Name: equipment_service_mapping equipment_service_mapping_equipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.equipment_service_mapping
    ADD CONSTRAINT equipment_service_mapping_equipment_id_fkey FOREIGN KEY (equipment_id) REFERENCES public.equipment_master(id) ON DELETE CASCADE;


--
-- Name: equipment_service_mapping equipment_service_mapping_service_type_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.equipment_service_mapping
    ADD CONSTRAINT equipment_service_mapping_service_type_code_fkey FOREIGN KEY (service_type_code) REFERENCES public.service_types(type_code) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: failed_login_attempts failed_login_attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.failed_login_attempts
    ADD CONSTRAINT failed_login_attempts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: inventory_stock inventory_stock_equipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.inventory_stock
    ADD CONSTRAINT inventory_stock_equipment_id_fkey FOREIGN KEY (equipment_id) REFERENCES public.equipment_master(id) ON DELETE CASCADE;


--
-- Name: inventory_transactions inventory_transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: inventory_transactions inventory_transactions_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.inventory_items(id) ON DELETE CASCADE;


--
-- Name: invoice_line_items invoice_line_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.invoice_line_items
    ADD CONSTRAINT invoice_line_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: invoices invoices_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id);


--
-- Name: notification_analytics notification_analytics_notification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_analytics
    ADD CONSTRAINT notification_analytics_notification_id_fkey FOREIGN KEY (notification_id) REFERENCES public.notifications(id) ON DELETE CASCADE;


--
-- Name: notification_analytics notification_analytics_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_analytics
    ADD CONSTRAINT notification_analytics_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notification_push_log notification_push_log_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_push_log
    ADD CONSTRAINT notification_push_log_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.user_devices(id) ON DELETE CASCADE;


--
-- Name: notification_push_log notification_push_log_notification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_push_log
    ADD CONSTRAINT notification_push_log_notification_id_fkey FOREIGN KEY (notification_id) REFERENCES public.notifications(id) ON DELETE CASCADE;


--
-- Name: notification_routing_rules notification_routing_rules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_routing_rules
    ADD CONSTRAINT notification_routing_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: notification_schedules notification_schedules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_schedules
    ADD CONSTRAINT notification_schedules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: notification_schedules notification_schedules_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_schedules
    ADD CONSTRAINT notification_schedules_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.notification_templates(id) ON DELETE SET NULL;


--
-- Name: notification_settings_advanced notification_settings_advanced_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_settings_advanced
    ADD CONSTRAINT notification_settings_advanced_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notification_settings notification_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notification_templates notification_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: notification_templates notification_templates_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: notifications notifications_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.notification_templates(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payments payments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: payments payments_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: payments payments_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id);


--
-- Name: payments payments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE SET NULL;


--
-- Name: payments payments_refunded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_refunded_by_fkey FOREIGN KEY (refunded_by) REFERENCES public.users(id);


--
-- Name: payments payments_verified_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_verified_by_fkey FOREIGN KEY (verified_by) REFERENCES public.users(id);


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: service_categories service_categories_service_type_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.service_categories
    ADD CONSTRAINT service_categories_service_type_code_fkey FOREIGN KEY (service_type_code) REFERENCES public.service_types(type_code) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: service_pricelist service_pricelist_service_type_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.service_pricelist
    ADD CONSTRAINT service_pricelist_service_type_code_fkey FOREIGN KEY (service_type_code) REFERENCES public.service_types(type_code) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: service_pricelist service_pricelist_service_type_code_service_category_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aglis_user
--

ALTER TABLE ONLY public.service_pricelist
    ADD CONSTRAINT service_pricelist_service_type_code_service_category_code_fkey FOREIGN KEY (service_type_code, service_category_code) REFERENCES public.service_categories(service_type_code, category_code) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: skill_levels skill_levels_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skill_levels
    ADD CONSTRAINT skill_levels_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: skill_levels skill_levels_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skill_levels
    ADD CONSTRAINT skill_levels_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: specializations specializations_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specializations
    ADD CONSTRAINT specializations_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.specialization_categories(id);


--
-- Name: specializations specializations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specializations
    ADD CONSTRAINT specializations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: specializations specializations_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specializations
    ADD CONSTRAINT specializations_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: technician_performance technician_performance_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technician_performance
    ADD CONSTRAINT technician_performance_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: technician_skills technician_skills_verified_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technician_skills
    ADD CONSTRAINT technician_skills_verified_by_fkey FOREIGN KEY (verified_by) REFERENCES public.users(id);


--
-- Name: technician_specializations technician_specializations_specialization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technician_specializations
    ADD CONSTRAINT technician_specializations_specialization_id_fkey FOREIGN KEY (specialization_id) REFERENCES public.specializations(id);


--
-- Name: technician_specializations technician_specializations_technician_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technician_specializations
    ADD CONSTRAINT technician_specializations_technician_id_fkey FOREIGN KEY (technician_id) REFERENCES public.technicians(id) ON DELETE CASCADE;


--
-- Name: technicians technicians_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technicians
    ADD CONSTRAINT technicians_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: technicians technicians_supervisor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technicians
    ADD CONSTRAINT technicians_supervisor_id_fkey FOREIGN KEY (supervisor_id) REFERENCES public.technicians(id);


--
-- Name: technicians technicians_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technicians
    ADD CONSTRAINT technicians_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: technicians technicians_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.technicians
    ADD CONSTRAINT technicians_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ticket_status_history ticket_status_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_status_history
    ADD CONSTRAINT ticket_status_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id);


--
-- Name: ticket_status_history ticket_status_history_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_status_history
    ADD CONSTRAINT ticket_status_history_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_technicians ticket_technicians_assigned_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_technicians
    ADD CONSTRAINT ticket_technicians_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- Name: ticket_technicians ticket_technicians_technician_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_technicians
    ADD CONSTRAINT ticket_technicians_technician_id_fkey FOREIGN KEY (technician_id) REFERENCES public.technicians(id) ON DELETE CASCADE;


--
-- Name: ticket_technicians ticket_technicians_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_technicians
    ADD CONSTRAINT ticket_technicians_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: tickets tickets_assigned_technician_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_assigned_technician_id_fkey FOREIGN KEY (assigned_technician_id) REFERENCES public.technicians(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: user_activity_logs user_activity_logs_target_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity_logs
    ADD CONSTRAINT user_activity_logs_target_user_id_fkey FOREIGN KEY (target_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_activity_logs user_activity_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity_logs
    ADD CONSTRAINT user_activity_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_devices user_devices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_devices
    ADD CONSTRAINT user_devices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: whatsapp_groups whatsapp_groups_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whatsapp_groups
    ADD CONSTRAINT whatsapp_groups_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: whatsapp_message_templates whatsapp_message_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whatsapp_message_templates
    ADD CONSTRAINT whatsapp_message_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: whatsapp_notifications whatsapp_notifications_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whatsapp_notifications
    ADD CONSTRAINT whatsapp_notifications_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.whatsapp_groups(id);


--
-- Name: whatsapp_notifications whatsapp_notifications_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whatsapp_notifications
    ADD CONSTRAINT whatsapp_notifications_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id);


--
-- Name: whatsapp_notifications whatsapp_notifications_notification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whatsapp_notifications
    ADD CONSTRAINT whatsapp_notifications_notification_id_fkey FOREIGN KEY (notification_id) REFERENCES public.notifications(id) ON DELETE CASCADE;


--
-- Name: whatsapp_notifications whatsapp_notifications_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whatsapp_notifications
    ADD CONSTRAINT whatsapp_notifications_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id);


--
-- Name: whatsapp_notifications whatsapp_notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whatsapp_notifications
    ADD CONSTRAINT whatsapp_notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: TABLE alert_history; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.alert_history TO aglis_user;


--
-- Name: SEQUENCE alert_history_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.alert_history_id_seq TO aglis_user;


--
-- Name: TABLE alert_rules; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.alert_rules TO aglis_user;


--
-- Name: SEQUENCE alert_rules_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.alert_rules_id_seq TO aglis_user;


--
-- Name: TABLE attachments; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.attachments TO aglis_user;


--
-- Name: SEQUENCE attachments_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.attachments_id_seq TO aglis_user;


--
-- Name: TABLE customer_complaints; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.customer_complaints TO aglis_user;


--
-- Name: SEQUENCE customer_complaints_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.customer_complaints_id_seq TO aglis_user;


--
-- Name: TABLE customer_equipment; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.customer_equipment TO aglis_user;


--
-- Name: SEQUENCE customer_equipment_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.customer_equipment_id_seq TO aglis_user;


--
-- Name: TABLE customer_payments; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.customer_payments TO aglis_user;


--
-- Name: SEQUENCE customer_payments_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.customer_payments_id_seq TO aglis_user;


--
-- Name: TABLE customer_registrations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.customer_registrations TO aglis_user;


--
-- Name: SEQUENCE customer_registrations_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.customer_registrations_id_seq TO aglis_user;


--
-- Name: TABLE customer_service_history; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.customer_service_history TO aglis_user;


--
-- Name: SEQUENCE customer_service_history_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.customer_service_history_id_seq TO aglis_user;


--
-- Name: TABLE customer_sessions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.customer_sessions TO aglis_user;


--
-- Name: SEQUENCE customer_sessions_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.customer_sessions_id_seq TO aglis_user;


--
-- Name: TABLE customers; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.customers TO aglis_user;


--
-- Name: SEQUENCE customers_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.customers_id_seq TO aglis_user;


--
-- Name: TABLE inventory_items; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.inventory_items TO aglis_user;


--
-- Name: SEQUENCE inventory_items_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.inventory_items_id_seq TO aglis_user;


--
-- Name: TABLE inventory_transactions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.inventory_transactions TO aglis_user;


--
-- Name: SEQUENCE inventory_transactions_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.inventory_transactions_id_seq TO aglis_user;


--
-- Name: TABLE notification_analytics; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.notification_analytics TO aglis_user;


--
-- Name: SEQUENCE notification_analytics_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.notification_analytics_id_seq TO aglis_user;


--
-- Name: TABLE notification_analytics_summary; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.notification_analytics_summary TO aglis_user;


--
-- Name: SEQUENCE notification_analytics_summary_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.notification_analytics_summary_id_seq TO aglis_user;


--
-- Name: TABLE notification_push_log; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.notification_push_log TO aglis_user;


--
-- Name: SEQUENCE notification_push_log_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.notification_push_log_id_seq TO aglis_user;


--
-- Name: TABLE notification_routing_rules; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.notification_routing_rules TO aglis_user;


--
-- Name: SEQUENCE notification_routing_rules_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.notification_routing_rules_id_seq TO aglis_user;


--
-- Name: TABLE notification_schedules; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.notification_schedules TO aglis_user;


--
-- Name: SEQUENCE notification_schedules_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.notification_schedules_id_seq TO aglis_user;


--
-- Name: TABLE notification_settings; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.notification_settings TO aglis_user;


--
-- Name: TABLE notification_settings_advanced; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.notification_settings_advanced TO aglis_user;


--
-- Name: SEQUENCE notification_settings_advanced_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.notification_settings_advanced_id_seq TO aglis_user;


--
-- Name: SEQUENCE notification_settings_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.notification_settings_id_seq TO aglis_user;


--
-- Name: TABLE notification_templates; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.notification_templates TO aglis_user;


--
-- Name: SEQUENCE notification_templates_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.notification_templates_id_seq TO aglis_user;


--
-- Name: TABLE notifications; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.notifications TO aglis_user;


--
-- Name: SEQUENCE notifications_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.notifications_id_seq TO aglis_user;


--
-- Name: TABLE packages_master; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.packages_master TO aglis_user;


--
-- Name: SEQUENCE packages_master_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.packages_master_id_seq TO aglis_user;


--
-- Name: TABLE skill_levels; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.skill_levels TO aglis_user;


--
-- Name: SEQUENCE skill_levels_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.skill_levels_id_seq TO aglis_user;


--
-- Name: TABLE specialization_categories; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.specialization_categories TO aglis_user;


--
-- Name: SEQUENCE specialization_categories_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.specialization_categories_id_seq TO aglis_user;


--
-- Name: TABLE specializations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.specializations TO aglis_user;


--
-- Name: SEQUENCE specializations_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.specializations_id_seq TO aglis_user;


--
-- Name: TABLE system_metrics; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.system_metrics TO aglis_user;


--
-- Name: SEQUENCE system_metrics_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.system_metrics_id_seq TO aglis_user;


--
-- Name: TABLE technician_equipment; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.technician_equipment TO aglis_user;


--
-- Name: SEQUENCE technician_equipment_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.technician_equipment_id_seq TO aglis_user;


--
-- Name: TABLE technician_location_history; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.technician_location_history TO aglis_user;


--
-- Name: SEQUENCE technician_location_history_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.technician_location_history_id_seq TO aglis_user;


--
-- Name: TABLE technician_performance; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.technician_performance TO aglis_user;


--
-- Name: SEQUENCE technician_performance_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.technician_performance_id_seq TO aglis_user;


--
-- Name: TABLE technician_schedule; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.technician_schedule TO aglis_user;


--
-- Name: SEQUENCE technician_schedule_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.technician_schedule_id_seq TO aglis_user;


--
-- Name: TABLE technician_skills; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.technician_skills TO aglis_user;


--
-- Name: SEQUENCE technician_skills_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.technician_skills_id_seq TO aglis_user;


--
-- Name: TABLE technician_specializations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.technician_specializations TO aglis_user;


--
-- Name: SEQUENCE technician_specializations_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.technician_specializations_id_seq TO aglis_user;


--
-- Name: TABLE technicians; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.technicians TO aglis_user;


--
-- Name: SEQUENCE technicians_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.technicians_id_seq TO aglis_user;


--
-- Name: TABLE ticket_status_history; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ticket_status_history TO aglis_user;


--
-- Name: SEQUENCE ticket_status_history_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.ticket_status_history_id_seq TO aglis_user;


--
-- Name: TABLE ticket_technicians; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ticket_technicians TO aglis_user;


--
-- Name: SEQUENCE ticket_technicians_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.ticket_technicians_id_seq TO aglis_user;


--
-- Name: TABLE tickets; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tickets TO aglis_user;


--
-- Name: SEQUENCE tickets_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.tickets_id_seq TO aglis_user;


--
-- Name: TABLE user_activity_logs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_activity_logs TO aglis_user;


--
-- Name: SEQUENCE user_activity_logs_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.user_activity_logs_id_seq TO aglis_user;


--
-- Name: TABLE user_devices; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_devices TO aglis_user;


--
-- Name: SEQUENCE user_devices_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.user_devices_id_seq TO aglis_user;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.users TO aglis_user;


--
-- Name: SEQUENCE users_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.users_id_seq TO aglis_user;


--
-- Name: TABLE whatsapp_groups; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.whatsapp_groups TO aglis_user;


--
-- Name: SEQUENCE whatsapp_groups_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.whatsapp_groups_id_seq TO aglis_user;


--
-- Name: TABLE whatsapp_message_templates; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.whatsapp_message_templates TO aglis_user;


--
-- Name: SEQUENCE whatsapp_message_templates_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.whatsapp_message_templates_id_seq TO aglis_user;


--
-- Name: TABLE whatsapp_notifications; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.whatsapp_notifications TO aglis_user;


--
-- Name: SEQUENCE whatsapp_notifications_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.whatsapp_notifications_id_seq TO aglis_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES  TO aglis_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES  TO aglis_user;


--
-- PostgreSQL database dump complete
--

\unrestrict 2GCpJmvmGIe72mYBbCagUEyNkyM9bxc6YOnSXNr0fsdywnpcRz5feNqfjAhW3Tf

